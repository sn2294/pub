% nreg is the number of I(1) regressors
% truep is the order of the deterministic trend function in the DGP
% p is the order of the deterministic function in the regression

function [tstat]=adf(y,k,p);
global bb1inv;
[bigt,bign]=size(y);
pval=zeros(1,bign);
tstat=zeros(1,bign);
constant=ones(bigt-1,1);
trend=(1:1:bigt-1)';

for i=1:bign; % looping over N obs.

dy=y(2:bigt,i)-y(1:bigt-1,i);
reg=y(1:bigt-1,i);
for j=1:k;
reg=[reg lagn(dy,j)];
end;
if p ==0;
reg=[reg constant];
end;
if p ==1; reg=[reg constant trend];end;
if k > 0;
reg=trimr(reg,k,0);
dy=trimr(dy,k,0);
end;
alpha=reg\dy;
e=dy-reg*alpha;
sig2=e'*e/rows(dy);
xx=inv(reg'*reg);
tstat(i)=alpha(1)/sqrt(sig2*xx(1,1));

end;
