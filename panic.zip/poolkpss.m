function [pvala, pvalb]= poolkpss(a,x);
N=rows(x);
pval=zeros(N,1);
for i=1:N;
aa=abs(a(:,1)-x(i));
[j1,j2]=min(aa);
pval(i)=1-a(j2,2);
if pval(i)<.00001;pval(i)=.00001;end;
end;



pvala=-2*sum(log(pval));
pvalb=(pvala-2*N)/sqrt(4*N);

