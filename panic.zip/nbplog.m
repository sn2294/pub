% determine the number of factors as in the IC of Bai and Ng (2002, Econometrica
% panel BIC is best when there is  substantial cross correlation   in the errors
% X is observed
% r is the true number of true factors
% F is T by r matrix of true factors
% Lambda N by r is the true loading matrix
% C=F*Lambda' T by N is the true common component
% chat is the estimated common component

function [ic1, chat,Fhat]=NBPLOG(X,kmax,jj);
T=size(X,1);
N=size(X,2);
NT=N*T;
NT1=N+T;
CT=zeros(1,kmax);
GCT=min([N;T]);
ii=1:1:kmax;
if jj ==1;CT(1,:)=log(NT/NT1)*ii*NT1/NT;end;
if jj==2; CT(1,:)=(NT1/NT)*log(GCT)*ii;end;
if jj==3; CT(1,:)=log(NT)*ii*NT1/NT;end; % this is the panel BIC..

X=X-ones(T,1)*mean(X);
IC1=zeros(size(CT,1),kmax+1);
Sigma=zeros(1,kmax+1);
XX=X*X';
[Fhat0,eigval,Fhat1]=svd(XX');
for i=kmax:-1:1;
Fhat=Fhat0(:,1:i);
lambda=Fhat'*X;
chat=Fhat*lambda;
ehat=X-chat;
Sigma(i)=mean(sum(ehat.*ehat/T));
IC1(:,i)=log(Sigma(i))+CT(:,i);
end;
Sigma(kmax+1)=mean(sum(X.*X/T));
IC1(:,kmax+1)=log(Sigma(kmax+1));
ic1=minindc(IC1')';
disp('IC1 ');
[(1:1:kmax) 0]
[IC1]
ic1=ic1 .*(ic1 <= kmax);
Fhat=[];
Fhat=Fhat0(:,1:ic1);
lambda=Fhat'*X;
chat=Fhat*lambda;
disp('Ratio of Eigenvalues ');
dd=diag(eigval);
disp(dd(1:ic1+4)'/sum(dd));
