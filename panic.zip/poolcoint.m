function [pvala, pvalb]=poolcoint(a,x,r);


N=rows(x);
pval=zeros(N,1);
for i=1:N;
aa=abs(a(:,r)-x(i));
[j1,j2]=min(aa);
pval(i)=a(j2,4);
end;



pvala=-2*sum(log(pval));
pvalb=(pvala-2*N)/sqrt(4*N);
