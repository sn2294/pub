clear;
% load the look up tables for quantiles and p-values
% adfnc is the DF test with no constant
% adfc is the DF test with a constant
% adft is the DF test with a constant and a time trend
% lm1 is the DF test for e0 when p=1, it is the distribution in Schmidt
% coint0 is the Phillips-Ouliaris Zt test with a constant.
% coint1 is the Phillips-Ouliaris Zt test with a constant and a trend.
% coint0 and 1 are tabulated  for 1,2, and 3 regressors
% bb1 is the first level brownian bridge
% bb2 is second level browian bridge
% shin0 is shin's cointegration test with a constant
% shin1 is shin's cointegration test with a time trend

% p is the order of the polynomial time trend
% r is the number of factors

load -ascii adfnc.asc;
load -ascii adfc.asc;
load -ascii adft.asc;
load -ascii lm1.asc;
load -ascii coint0.asc;
load -ascii coint1.asc;

% for illustration, simulate some data

T=100;N=30;rstar=1;rhoe=1;rhof=.5;sigf=1;
[y,f0,lam0,u]=dgp1(T,N,rstar,rhoe,rhof,sigf);

% always demean the data
% standardize if desired
y=y-repmat(mean(y),T,1);
y1=y(2:T,:);
dy=y(2:T,:)-y(1:T-1,:);


% NBPLOG is the IC procedure developed in Bai and Ng (2002, Econometrica)
% to determine the number of factors
% method 3 (the panel BIC) is more robust when there is cross
%     correlation in the idiosyncratic errors

for jj=1:3;
[ic,chat,Fhat]=NBPLOG(dy,5,jj);
disp(sprintf('N = %d T = %d IC%d = %d',N,T,jj,ic));
end;

% PANIC starts here
% assume e is I(1) and test non-stationarity using ADF

r=1;p=0;
k1=4*ceil((T/100)^(1/4));
[dehat,dfhat,lamhat]=pc(dy,r);

fhat0=cumsum(dfhat);
ehat0=cumsum(dehat);


ehat1=zeros(T-1,1);
reg=[ones(T-1,1) fhat0];
beta1=zeros(r+1,N);
for i=1:N;
beta1(:,i)=reg\y1(:,i);
ehat1(:,i)=y1(:,i)-reg*beta1(:,i);
end;


% some diagnostics to see the importance of the factors

R21=zeros(N,1);
R22=zeros(N,1);
fit=zeros(size(fhat0,1),N);
for i=1:N;
fit1(:,i)=fhat0*lamhat(i,:)';
fit2(:,i)=dfhat*lamhat(i,:)';
R21(i)=std(dehat(:,i))^2/std(dy(:,i))^2;
R22(i)=std(fit1(:,i))/std(ehat0(:,i));
end;



adf10=zeros(N,1);adf20=zeros(N,1);
adf30=zeros(N,1);adf40=zeros(N,1);adf50=zeros(N,1);

adf10 =adf(y,k1,p);
for i=1:r;
adf20(i) =adf(fhat0(:,i),k1,p);  % test fhat0 for a unit root
end;
adf30 =adf(ehat0,k1,-1);      % test ehat0
adf50 =adf(ehat1,k1,-1);      % test ehat1

% now do the pooled test


[adf10a adf10b]=pool(adfc,adf10');
[adf30a adf30b]=pool(adfnc,adf30');
[adf50a adf50b]=poolcoint(coint0,adf50',r);


% do the DFGLS of Elliott, Rothenberg and Stock (1996, Econometrica)
%khat is the lag selected by the MAIC, Ng and Perron (2001, Econometrica)
khat=zeros(N,1);
glsadf=zeros(N,1);
for i=1:N;
[glsadf(i),khat(i)]=dfgls(y(:,i),0,k1,0,p);
end;

disp(sprintf('adf '));
disp(sprintf('              dfgls k  adf   ehat  ehat1    R2  sigF/sige'));
for i=1:N;
disp(sprintf('Series %4d %6.3f %d %6.3f %6.3f %6.3f %6.3f %6.3f %6.3f',...
i,glsadf(i),khat(i),adf10(i),adf30(i),adf50(i),R21(i),R22(i)));
end;
disp(sprintf('\n\nTests on fhat adf20 \n'));
for i=1:r;
disp(sprintf('Factor %d %6.3f ',i,adf20(i)));
end;

disp(sprintf('\n Pooled test'));
disp(sprintf('    X %6.3f %6.3f\n',adf10a,adf10b));
disp(sprintf('ehat0 %6.3f %6.3f\n',adf30a,adf30b));
disp(sprintf('ehat1 %6.3f %6.3f\n',adf50a,adf50b));

diary off;
