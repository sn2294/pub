function [hac]=lrhac(u,fixk);
[n,nreg]=size(u);
rho=zeros(nreg,1);
sigma=zeros(nreg,1);
d=zeros(nreg,nreg);
beta=zeros(nreg,nreg);


v=u;

if fixk==0;
bot=0;top=0;
for i=1:nreg;
top=top+4*(rho(i)^2)*sigma(i)^2/(1-rho(i))^8;
bot=bot+sigma(i)^2/((1-rho(i))^4);
end;
alpha=top/bot;
k=ceil(2.6614*(alpha*n)^(0.2));
if k > n/2; k = n/2;end;
else;
k=fixk;
end;

vcv=v'*v/n;
for i=1:k;
x=i/k;
if abs(x)>= 0 & abs(x) <=.5;
w=1-6*(abs(x))^2+6*abs(x)^3;
else;
w=2*(1-abs(x))^3;
end;
cov=v(i+1:rows(v),:)'*v(1:rows(v)-i,:)/n;
vcv=vcv+w*cov;
cov=v(1:rows(v)-i,:)'*v(i+1:rows(v),:)/n;
vcv=vcv+w*cov;
end;
hac=vcv;
