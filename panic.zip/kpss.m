function [lm]=kpss(y,fixk,p);
% cv for p=0 .463
% cv for p=1 .146

[bigt,bign]=size(y);
lm=zeros(1,bign);
xmat=ones(bigt,1);
if p ==1; xmat=[xmat (1:1:bigt)'];end;
M=eye(bigt)-xmat*inv(xmat'*xmat)*xmat';
ehat=[];
Sit=[];
Sit2=zeros(bign,1);
sig2=zeros(bign,1);

for i=1:bign;
if p>=0;
ehat=M*y(:,i);
else;
ehat=y(:,i);
end;

Sit=cumsum(ehat);
Sit2(i)=sum(Sit.*Sit)/(bigt^2);

if fixk==0;
sig2(i)=ehat'*ehat/bigt;
else;
sig2(i)=hac(ehat,fixk);
end;

lm(i)=Sit2(i)/sig2(i);
end;
