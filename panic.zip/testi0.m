clear;
% load the look up tables for quantiles and p-values
% adfnc is the DF test with no constant
% adfc is the DF test with a constant
% adft is the DF test with a constant and a time trend
% lm1 is the DF test for e0 when p=1, it is the distribution in Schmidt
% coint0 is the Phillips-Ouliaris Zt test with a constant.
% coint1 is the Phillips-Ouliaris Zt test with a constant and a trend.
% coint0 and 1 are tabulated  for 1,2, and 3 regressors
% bb1 is the first level brownian bridge
% bb2 is second level browian bridge
% shin0 is shin's cointegration test with a constant
% shin1 is shin's cointegration test with a time trend

load -ascii bb1.asc;
load -ascii bb2.asc;
load -ascii shin0.asc;
load -ascii shin1.asc;

% p is the order of the polynomial time trend
% r is the number of factors



% for illustration, simulate some data

T=100;N=30;rstar=1;rhoe=1;rhof=.5;sigf=1;
[y,f0,lam0,u]=dgp1(T,N,rstar,rhoe,rhof,sigf);

% always demean the data
% standardize if desired
y=y-repmat(mean(y),T,1);
y1=y(2:T,:);
dy=y(2:T,:)-y(1:T-1,:);


% NBPLOG is the IC procedure developed in Bai and Ng (2002, Econometrica)
% to determine the number of factors
% method 3 (the panel BIC) is more robust when there is cross
%     correlation in the idiosyncratic errors

for jj=1:3;
[ic,chat,Fhat]=NBPLOG(dy,5,jj);
disp(sprintf('N = %d T = %d IC%d = %d',N,T,jj,ic));
end;

% panel stationarity test starts here
% assume e is I(1) and test non-stationarity using ADF

r=1;p=0;
k1=4*ceil((T/100)^(1/4));
[dehat,dfhat,lamhat]=pc(dy,r);

fhat0=cumsum(dfhat);
ehat0=cumsum(dehat);

ehat1=ehat0;
reg=[ones(rows(ehat0),1) fhat0];
for i=1:N;
ehat1(:,i)=ehat0(:,i)-reg*(reg\ehat0(:,i));
end;


% some diagnostics to see the importance of the factors

R21=zeros(N,1);
R22=zeros(N,1);
fit=zeros(size(fhat0,1),N);
for i=1:N;
fit1(:,i)=fhat0*lamhat(i,:)';
fit2(:,i)=dfhat*lamhat(i,:)';
R21(i)=std(dehat(:,i))^2/std(dy(:,i))^2;
R22(i)=std(fit1(:,i))/std(ehat0(:,i));
end;



kpss10=zeros(N,1);kpss20=zeros(N,1);
kpss30=zeros(N,1);kpss50=zeros(N,1);

k=12;
kcoint=12;
p=0;
kpss10=kpss(y,k,p);
for i=1:r;
kpss20=kpss(fhat0,k,p);
end;
kpss30=kpss(ehat0,k,p);
kpss50=kpss(ehat1,kcoint,-1);


% now do the pooled test


[kpss10a kpss10b]=poolkpss(bb1,kpss10');
[kpss30a kpss30b]=poolkpss(bb1,kpss30');
[kpss50a kpss50b]=poolshin(shin0,kpss50',r);


disp(sprintf('kpss '));
disp(sprintf('             X     ehat    ehat1    R2  sigF/sige'));
for i=1:N;
disp(sprintf('Series %4d %6.3f %6.3f %6.3f %6.3f %6.3f %6.3f',...
i,kpss10(i),kpss30(i),kpss50(i),R21(i),R22(i)));
end;
disp(sprintf('\n\nTests on fhat kpss20 \n'));
for i=1:r;
disp(sprintf('Factor %d %6.3f ',i,kpss20(i)));
end;

disp(sprintf('\n Pooled test'));
disp(sprintf('    X %6.3f %6.3f\n',kpss10a,kpss10b));
disp(sprintf('ehat0 %6.3f %6.3f\n',kpss30a,kpss30b));
disp(sprintf('ehat1 %6.3f %6.3f\n',kpss50a,kpss50b));

