function b=myols(y,x);
b=x\y;
