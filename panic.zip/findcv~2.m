% find x% critical value for shin's cointegration test with r I(1) regressors
function pval= findcv_shin(a,x,r);

aa=abs(a(:,4)-x);
[j1,j2]=min(aa);
pval=a(j2,r);
