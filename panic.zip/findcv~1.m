% returns the c.v. of phillips-ouliaris cointegration test
% r is the number of I(1) regressors
% x is the significance level
% a is the asymptotic percentage points of the test statistic

function pval= findcv_coint(a,x,r);

aa=abs(a(:,4)-x);
[j1,j2]=min(aa);
pval=a(j2,r);
