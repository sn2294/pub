function [pvala, pvalb]=poolshin(a,x,r);


N=rows(x);
pval=zeros(N,1);
for i=1:N;
aa=abs(a(:,r)-x(i));
[j1,j2]=min(aa);
pval(i)=1-a(j2,4);
if pval(i)<.00001;pval(i)=.00001;end;
end;


pvala=-2*sum(log(pval));
pvalb=(pvala-2*N)/sqrt(4*N);
