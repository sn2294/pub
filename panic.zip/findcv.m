% given significance level x, find the critical value of the test with percentage points a
function cv= findcv(a,x);

aa=abs(a(:,2)-x);
[j1,j2]=min(aa);
cv=a(j2,1);
