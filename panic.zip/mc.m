


clear;
addpath ~/matlab/factors;
load -ascii adfnc.asc;
load -ascii adfc.asc;
load -ascii adft.asc;
load -ascii lm1.asc;
load -ascii bb1.asc;
load -ascii sp.asc;
load -ascii coint0.asc;
load -ascii coint1.asc;

% from phillips-ouliaris
cv_coint_0=[-3.27 -3.74];
cv_coint_1=[-3.77 -4.11];

kappa=1;
r=1;
maxit=1000;
nfac=2*r;
ncases=7;
finite=0;
xNT=[ 20 20; 20 50; 20 100; 50 20; 50 50; 50 100; 100 20; 100 50;    100 100];
xkappa=[1; .5; 2];
xkappa=1;
  outfile='mc_panic.0';
  outfile1='mc_panic.1';

fp=fopen(outfile,'w');
fclose(fp);
fp=fopen(outfile1,'w');
fclose(fp);

for inorm=0:0;
for ikappa=1:rows(xkappa);
kappa=xkappa(ikappa);
for icase=1:ncases;
  table=[];table1=[];
  for iNT=1:rows(xNT);
    N=xNT(iNT,1); T=xNT(iNT,2);
k1=ceil(4*(T/100)^(1/4));

      switch(icase);
   case 1; rho=ones(r,1); theta=ones(N,1);  DGP=1; xif=1; xie=1;
   case 2; rho=ones(r,1); theta=uniform_ab(N,.97,.99); DGP=1; xif=1;xie=0;
   case 3; rho=.98*ones(r,1); theta=ones(N,1); DGP=1; xif=0; xie=1;
   case 4; rho=.95*ones(r,1); theta=.95*ones(N,1); DGP=1; xif=0; xie=0;
   case 5; rho=.5*ones(r,1); theta=uniform_ab(N,.97,.99); DGP=1; xif=0; xie=0;
   case 6; delta=ones(N,1);  DGP=2; xif=1;xie=1;
   case 7; delta=uniform_ab(N,.95,.99);  DGP=2; xif=0;xie=0;

  end;  


t_a=[];rhohat=[];ic=[];
adf10=zeros(maxit,N);
adf20=zeros(maxit,r);
adf30=zeros(maxit,N);
adf40=zeros(maxit,r);
adf50=zeros(maxit,N);
adf10a=zeros(maxit,1); adf20a=zeros(maxit,1);
adf30a=zeros(maxit,1); adf40a=zeros(maxit,1);
adf50a=zeros(maxit,1);
adf10b=zeros(maxit,1); adf20b=zeros(maxit,1);
adf30b=zeros(maxit,1); adf40b=zeros(maxit,1);
adf50b=zeros(maxit,1);

adf11=zeros(maxit,N);
adf21=zeros(maxit,r);
adf31=zeros(maxit,N);
adf41=zeros(maxit,r);
adf51=zeros(maxit,N);
adf11a=zeros(maxit,1); adf21a=zeros(maxit,1);
adf31a=zeros(maxit,1); adf41a=zeros(maxit,1);
adf51a=zeros(maxit,1);
adf11b=zeros(maxit,1); adf21b=zeros(maxit,1);
adf31b=zeros(maxit,1); adf41b=zeros(maxit,1);
adf51b=zeros(maxit,1);

randn('state',999);
rand('state',123);

for it=1:maxit;
  switch(DGP);
  case 1;
u=randn(T,N);     % begin DGP
L=zeros(N,r);;
for i=1:r;
L(:,i)=uniform_ab(N,-1,3);
end;
f=kappa*randn(T,r);
F=f;
for i=1:r;
  F(:,i)=filter(1,[1 -rho(i)], f(:,i));
end;  
mu=0*repmat(rand(1,N),T,1);     % fixed effects
C=F*L';
U=u;
for i=1:N;
  U(:,i)=filter(1,[1 -theta(i)],u(:,i));
end;  
X=mu+C+U;            % end DGP

 case 2;
  u=randn(T,N);     % begin DGP
L=zeros(N,r);
if inorm==0;
for i=1:r;
L(:,i)=uniform_ab(N,-1,3);
end;
mu=repmat(rand(1,N),T,1);     % non-normal lambdas and fixed effects
else;
L=randn(N,r);;
mu=repmat(randn(1,N),T,1);     % normal lambda and fixed effects
end;
F=kappa*randn(T,r);
C=F*L';
U=C+u;
Y=U;
for i=1:N;
  Y(:,i)=filter(1,[1 -delta(i)],U(:,i));
end;  
X=mu+Y;            % end DGP
end;

y=X;

dy=trimr(mydiff(y,1),1,0);
y1=trimr(y,1,0);

% assume e is I(1) and test non-stationarity using ADF
[dehat,dfhat,lamhat]=pc(dy,r);
fhat0=cumsum(dfhat);
ehat0=cumsum(dehat);


% now do the adf tests for p=0
y1=trimr(y,1,0);
ehat1=zeros(T-1,1);
reg=[ones(T-1,1) fhat0];
beta1=zeros(r+1,N);
for i=1:N;
beta1(:,i)=reg\y1(:,i);
ehat1(:,i)=y1(:,i)-reg*beta1(:,i);
end;

p=0;
adf10(it,:) =adf(y,k1,p);
for i=1:r;
adf20(it,i) =adf(fhat0(:,i),k1,p);
end;
adf30(it,:) =adf(ehat0,k1,-1);
adf50(it,:) =adf(ehat1,k1,-1);


% now get p values of test on X with a constant;


[adf10a(it) adf10b(it)]=pool(adfc,adf10(it,:)');
[adf30a(it) adf30b(it)]=pool(adfnc,adf30(it,:)');
%[adf30a(it) adf30b(it)]=pool(adfc,adf30(it,:)');
[adf50a(it) adf50b(it)]=poolcoint(coint0,adf50(it,:)',r);


tt=(1:1:T-1)';
% now do the adf tests for p=1
p=1;
dy=dy-repmat(mean(dy),T-1,1);
[dehat,dfhat,lamhat]=pc(dy,r);
fhat0=cumsum(dfhat);
ehat0=cumsum(dehat);


ehat1=zeros(T-1,1);
reg=[ones(T-1,1) tt fhat0];
beta1=zeros(r+2,N);
for i=1:N;
beta1(:,i)=reg\y1(:,i);
ehat1(:,i)=y1(:,i)-reg*beta1(:,i);
end;


adf11(it,:) =adf(y,k1,p);
for i=1:r;
adf21(it,i) =adf(fhat0(:,i),k1,p);
end;
adf31(it,:) =adf(ehat0,k1,-1);
adf51(it,:) =adf(ehat1,k1,-1);


[adf11a(it) adf11b(it)]=pool(adft,adf11(it,:)');
[adf31a(it) adf31b(it)]=pool(lm1,adf31(it,:)');
%[adf31a(it) adf31b(it)]=pool(sp,adf31(it,:)');
%[adf31a(it) adf31b(it)]=pool(adft,adf31(it,:)');
[adf51a(it) adf51b(it)]=poolcoint(coint1,adf51(it,:)',r);



 end;    % end monte carlo


dum=[icase N T];
dum20=[dum mean(1-cdf('chi2',adf10a,2*N) < .05)];
dum20=[dum20 mean(1-cdf('chi2',adf30a,2*N) < .05)];
dum20=[dum20 mean(1-cdf('chi2',adf50a,2*N) < .05)];

dum20=[dum20 mean(1-cdf('norm',adf10b,0,1) < .05)];
dum20=[dum20 mean(1-cdf('norm',adf30b,0,1) < .05)];
dum20=[dum20 mean(1-cdf('norm',adf50b,0,1) < .05)];

dum21=[dum mean(1-cdf('chi2',adf11a,2*N) < .05)];
dum21=[dum21 mean(1-cdf('chi2',adf31a,2*N) < .05)];
dum21=[dum21 mean(1-cdf('chi2',adf51a,2*N) < .05)];

dum21=[dum21 mean(1-cdf('norm',adf11b,0,1) < .05)];
dum21=[dum21 mean(1-cdf('norm',adf31b,0,1) < .05)];
dum21=[dum21 mean(1-cdf('norm',adf51b,0,1) < .05)];


table=[table; dum20];
table1=[table1; dum21];
fmt=['\n%2d &%4d%4d' repmat(' & %5.3f ',1,cols(dum20)-3) '\\\\'];;
disp(sprintf(fmt,dum20));
disp(sprintf(fmt,dum21));
if iNT==1;
  fp=fopen(outfile,'a+');
fprintf(fp,'\n kappa= %3f F=I(%1d) e=I(%1d)\n',kappa,xif,xie);
fclose(fp);
  fp=fopen(outfile1,'a+');
fprintf(fp,'\n kappa= %3f F=I(%1d) e=I(%1d)\n',kappa,xif,xie);
fclose(fp);
end;
fp=fopen(outfile,'a+');
fprintf(fp,fmt,dum20);
fclose(fp);
fp=fopen(outfile1,'a+');
fprintf(fp,fmt,dum21);
fclose(fp);

  end; % end NT
fp=fopen(outfile,'a+');
fprintf(fp,'\n');
fclose(fp);
fp=fopen(outfile1,'a+');
fprintf(fp,'\n');
fclose(fp);
end; % end cases
fp=fopen(outfile,'a+');
fprintf(fp,'\n');
fclose(fp);
fp=fopen(outfile1,'a+');
fprintf(fp,'\n');
fclose(fp);
end; % end kappa
end; % end inorm


  
