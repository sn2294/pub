clear;
close all;
% addpath ~/dropbox/fsvar/varjln;
user=1;
if user==1;
    addpath C:\Dropbox\fsvar\varjln;
    cd 'C:\Dropbox\fsvar\july17'
    setupdata_0717;
end;

if user==2;
    addpath ../varjln;
    addpath ../lowrank;
    setupdata_0717;
end;

for ishrink=2:2; % iterate over PCA (1) and robust PCA (2)
    if ishrink==1;
        z=[     FXVU(:,1) VU(:,1) S(:,1)  house ip infl  ffr ];
        varname{1}='A1';
        varname{2}='VU1';
        varname{3}='S1';
        varname{4}='Housing permits';
        varname{5}='Indus.Production';
        varname{6}='Inflation';
        varname{7}='Fed Funds Rate';
        
    end;
    if ishrink==2;
        
        % remove interactions
        Xreg=ones(length(F0),1);
        
        N1=cols(fxvu);
        N1=3;
        for i1=1:N1
            for i2=i1:N1
                Xreg=[Xreg  F0(:,i1).*F0(:,i2)];
            end
        end
        
%         Xreg=[Xreg vu(:,1:2)];
        
        
        regS1=nwest(s(:,1),Xreg,0);
        S1res=regS1.yhat;
        
        
        z=[  fxvu(:,1) vu(:,1) S1res  house  ip infl  ffr];
        varname{1}='a1';
        varname{2}='vu1';
        varname{3}='s1';
        varname{4}='Housing permits';
        varname{5}='Indus.Production';
        varname{6}='Inflation';
        varname{7}='Fed-Funds Rate';
        
    end;
    T=rows(z);
    
    
    model=3;
    impulse     = 1:cols(z);
    response = 1:cols(z);
    estimate = 1;
    bound    = 0;
    p        = 4;
    tr         = 0;
    estimate_var;
    cd plots;
    if ishrink==1;
        save temp_var031 IR IRu IRd VD  impulse response varname;
    end;
    if ishrink==2;
        save temp_var032 IR IRu IRd VD  impulse response varname;
    end;
    
    outfile=['temp_var' num2str(model*10+ishrink) '.out'];
    delete(outfile);
    diary(outfile);
    pick=[1; 6; 12; 24; 60];
    nvar=7;
    in.fmt='%6.3f';
    vdbyvar=[];
    for j=1:nvar;
        disp(['\hline Shock ' varname{j} '\\ \hline' ]);
        %     mymprint(VD{j}(pick,:),in);
        latexmatrix([pick VD{j}(pick,:)],'%6.3f');
        temp=[];
        for k=1:nvar;
            temp=[temp VD{j}(pick,k)];
        end;
        vdbyvar{j}=temp;
    end;
    diary off;
    cd ..;
end
