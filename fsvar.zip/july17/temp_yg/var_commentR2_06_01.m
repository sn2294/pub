% plot responses of A and F to a shock in V
clear;
close all;
% addpath ~/dropbox/fsvar/varjln;
user=1;
if user==1;
    addpath C:\Dropbox\fsvar\varjln;
    addpath C:\Dropbox\fsvar\lowrank;
    addpath C:\Dropbox\fsvar\lowrank\PROPACK;
    cd 'C:\Dropbox\fsvar\july17'
    setupdata_0717;
end;

if user==2;
    addpath ../varjln;
    addpath ../lowrank;
    addpath ../lowrank/PROPACK;
    setupdata_0717;

end;

%%=========================================================================
%    RPCA: VAR 9: z=[     FXVU(:,1) VU(:,1) F0(:,1)  house ip infl  ffr ];
%=========================================================================
model='032';
infile=['plots/var' model];
load(infile);

disp(['VAR' model varname]);

dg  = [0.80,0.80,0.80];
d=[0, 0.5, 0];
c   = {'b','k','r','m'};




steps=(0:rows(IR{1})-1)';
xx=[steps(:,1),steps(:,1)];
nvar=length(varname);

ivar=[1 3];
shocks=[1;2;3];
figure(1);

ii=1;
for jj=1:2
    j=ivar(ii);
    for k=2:2;

        subplot(1,2,ii);
        hold on;

        irfU=IRd{shocks(k)}(:,j);
        irfD=IRu{shocks(k)}(:,j);

        xv = [(1:length(irfU))-1 (fliplr(1:length(irfD)))-1];
        yv = [irfD' fliplr(irfU') ];
        hReg = fill(xv,yv,[0.75 0.75 0.75],'EdgeColor','none'); % draw region
        hold on
        plot(steps,IR{shocks(k)}(:,j),'black-','Linewidth',2);
        hold off
        t=title([ 'Response of ' num2str(varname{j})]);
        ii=ii+1;
    end;
    hold off;
end; %% end jj
% diary off;


%
% %%=========================================================================
% %    RPCA: VAR 12: z=[     FXVU(:,1) VU(:,1) house ip infl  ffr ];
% %=========================================================================
%
% model='122';
% infile=['plots/july17_var' model];
% load(infile);
%
%
% % outfile=['go_var' num2str(model) '.out'];
% outfile=['go_var' model '.out'];
%
% delete(outfile);
% diary(outfile);
% % disp(['VAR' num2str(model) varname]);
% disp(['VAR' model varname]);
%
% dg  = [0.80,0.80,0.80];
% d=[0, 0.5, 0];
% c   = {'b','k','r','m'};
%
% steps=(0:rows(IR{1})-1)';
% xx=[steps(:,1),steps(:,1)];
% nvar=length(varname);
% ivar=[3 4 5 6];
% shocks=[1;2];
% figure(1);
%
% ii=1;
% for jj=3:6
%     j=ivar(ii);
%     for k=2:2;
%
%         subplot(2,2,ii);
%         hold on;
%         plot(steps,-IRu{shocks(k)}(:,j),'blue--');
%         plot(steps,-IR{shocks(k)}(:,j),'blue-');
%         plot(steps,-IRd{shocks(k)}(:,j),'blue--');
%         t=title([ 'Response of ' num2str(varname{j})]);
%         set(t,'FontSize',10);
%         ii=ii+1;
%     end;
%     hold off;
% end; %% end jj
h=gcf;
subplot(1,2,2)
l=legend('68% CI',...
    'IRF ($A_1$,$V_1$,$F_1$)',...
    '68% CI',...
    'IRF ($A_1$,$V_1$)',...
    'Location','NorthEast')
set(l,'interpreter','latex');

set(h,'PaperOrientation','landscape');
set(h,'PaperUnits','normalized');
set(h,'PaperPosition', [0 0 1 1]);
figname=['plots\fig_commentR2_06_01.pdf'];
set(h,'PaperOrientation','landscape');
set(h,'PaperUnits','normalized');
set(h,'PaperPosition', [0 0 1 1]);
print(figname,'-dpdf');

% %=====================================================================
% %       variance decomposition
% %=====================================================================
% pick=[1; 3; 6; 12; 24; 48; 60];
%
% in.fmt='%6.3f';
% vdbyvar=[];
% for j=1:4;
%     disp(['\hline Shock ' varname{j} '\\ \hline' ]);
% %     mymprint(VD{j}(pick,:),in);
%     latexmatrix([pick VD{j}(pick,:)],'%6.3f');
%     temp=[];
%     for k=1:nvar;
%         temp=[temp VD{j}(pick,k)];
%     end;
%     vdbyvar{j}=temp;
% end;
%
% diary off;



