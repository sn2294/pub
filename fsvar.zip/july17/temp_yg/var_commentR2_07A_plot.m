
clear;
close all;
% addpath ~/dropbox/fsvar/varjln;
user=1;
if user==1;
    addpath C:\Dropbox\fsvar\varjln;
    addpath C:\Dropbox\fsvar\lowrank;
    addpath C:\Dropbox\fsvar\lowrank\PROPACK;
    cd 'C:\Dropbox\fsvar\july17'
end;

if user==2;
    addpath ../varjln;
    addpath ../lowrank;
    addpath ../lowrank/PROPACK;
end;

%%=========================================================================
%    RPCA: VAR 9: z=[     FXVU(:,1) VU(:,1) F0(:,1)  house ip infl  ffr ];
%=========================================================================

infile=['plots/var_comment_R2_07A2'];
load(infile);

dg  = [0.80,0.80,0.80];
d=[0, 0.5, 0];
c   = {'b','k','r','m'};

steps=(0:rows(IR{1})-1)';
xx=[steps(:,1),steps(:,1)];
nvar=length(varname);



%========================================================================
ivar=[1 5 6 7 8];
shocks=[2;3;4];

figure(1);
ii=1;
for jj=1:5
    j=ivar(ii);
    for k=2:2;

        subplot(3,2,ii);
        hold on;

        irfU=IRd{shocks(k)}(:,j);
        irfD=IRu{shocks(k)}(:,j);

        xv = [(1:length(irfU))-1 (fliplr(1:length(irfD)))-1];
        yv = [irfD' fliplr(irfU') ];
        hReg = fill(xv,yv,[0.75 0.75 0.75],'EdgeColor','none'); % draw region
        hold on
        plot(steps,IR{shocks(k)}(:,j),'black-','Linewidth',2);
        hold off
        t=title([ 'Response of ' num2str(varname{j})]);
        ii=ii+1;
    end;
    hold off;
end; %% end jj
% diary off;

h=gcf;
subplot(3,2,4)
l=legend('68% CI',...
    'IRF ($A_1$,$V_1$,$F_1$)',...
    '68% CI',...
    'IRF ($A_1$,$V_1$)',...
    'Location','NorthEast')
set(l,'interpreter','latex');

set(h,'PaperOrientation','landscape');
set(h,'PaperUnits','normalized');
set(h,'PaperPosition', [0 0 1 1]);
figname=['plots\fig_commentR2_07A.pdf'];
set(h,'PaperOrientation','landscape');
set(h,'PaperUnits','normalized');
set(h,'PaperPosition', [0 0 1 1]);
print(figname,'-dpdf');

%=====================================================================
%========================================================================
figure(2);
ivar=[1 3 5 6 7 8];
shocks=[1;3;4];

ii=1;
for jj=1:6
    j=ivar(ii);
    for k=1:1;

        subplot(3,2,ii);
        hold on;

        irfU=IRd{shocks(k)}(:,j);
        irfD=IRu{shocks(k)}(:,j);

        xv = [(1:length(irfU))-1 (fliplr(1:length(irfD)))-1];
        yv = [irfD' fliplr(irfU') ];
        hReg = fill(xv,yv,[0.75 0.75 0.75],'EdgeColor','none'); % draw region
        hold on
        plot(steps,IR{shocks(k)}(:,j),'black-','Linewidth',2);
        hold off
        t=title([ 'Response of ' num2str(varname{j})]);
        ii=ii+1;
    end;
    hold off;
end; %% end jj
% diary off;

h=gcf;
subplot(3,2,4)
l=legend('68% CI',...
    'IRF ($A_1$,$V_1$,$F_1$)',...
    '68% CI',...
    'IRF ($A_1$,$V_1$)',...
    'Location','NorthEast')
set(l,'interpreter','latex');

set(h,'PaperOrientation','landscape');
set(h,'PaperUnits','normalized');
set(h,'PaperPosition', [0 0 1 1]);
figname=['plots\fig_commentR2_07A2.pdf'];
set(h,'PaperOrientation','landscape');
set(h,'PaperUnits','normalized');
set(h,'PaperPosition', [0 0 1 1]);
print(figname,'-dpdf');

