clear;
close all;
% addpath ~/dropbox/fsvar/varjln;

user=2;
if user==1;
addpath C:\Dropbox\fsvar\varjln;
setupdata_0717;
end;

if user==2;
addpath ~/dropbox/prog/fsvar/varjln;
setupdata_0717;
end;


smoothing_param=11; % the number of leads/lags in calculating MA

co = [0 0 1;
      0 0.5 0;
      0 0.75 0.75;
      0.75 0 0.75;
      0.75 0.75 0;
      0.25 0.25 0.25;
      1.0 0 0;
      ];
set(groot,'defaultAxesColorOrder',co);
load HQ_0717;

F0=lsout{1}.fhat(12:end,:); %  factors exctracted from X: PCA
f0=lsout{2}.fhat(12:end,:); %  factors exctracted from X: RPCA

H=hsout{1}.fhat(12:end,:);  % factors exctracted from X and X2: PCA
h=hsout{2}.fhat(12:end,:);  % factors exctracted from X and X2: RPCA

S=ssout{1}.fhat(12:end,:);  % factors exctracted from X^2: PCA
s=ssout{2}.fhat(12:end,:);  % factors exctracted from X^2: RPCA

VU=vsout{1}.fhat(12:end,:); % volatility factors: PCA
vu=vsout{2}.fhat(12:end,:); % volatility factors: RPCA
Vbar=vsout{1}.Vbar(12:end,:);
vbar=vsout{2}.Vbar(12:end,:);

F=fsxvuout{1}.fhat(12:end,:);  % script F factor: PCA
f=fsxvuout{2}.fhat(12:end,:);  % script F factor: RPCA


do_bw=0; do_fd=0; do_ldt=0; do_raw=1;
%setupdata_sng;
% setupdata_sng;



dates=mdates(12:end);

tempF1=[F0(:,1) F(:,1) f0(:,1) ];
tempF2=[ F0(:,2) F(:,2) f0(:,2)];
tempH=[H(:,1:2) h(:,1:2) ];

% load data from JLN (AER 2015)
load jln_uncertainty
% laod data from Baker, Bloom, Davis (Economic policy uncertainty)
BBD;
% load stochastic volatility estimates
load -ascii svfmeans_0717.txt;
sv=svfmeans_0717(4:end-3,:);


figure(1);
%% Time series of factors extracted from X

subplot(1,1,1);
plotNBERrec
ff0=plot(dates,smooth(standard(s(:,2)),smoothing_param),'red','Linewidth',2);
hold on;
fF0=plot(dates,smooth(standard(vu(:,1)),smoothing_param),'blue','Linewidth',1.5);
fJLN=plot(udates,smooth(standard(utcsa(:,1)),smoothing_param),'black-','Linewidth',1.0);
fBBD=plot(BBDseries(:,1),smooth(standard(BBDseries(:,2)),smoothing_param),'color',[0 0.5 0],'linestyle',':','Linewidth',1.5);
fSV1=plot(dates(5:end),smooth(standard(sv(:,7)),smoothing_param),'color',[.7 0.5 0],'linestyle',':','Linewidth',1.5);
hold off;
l=legend([ff0 fF0 fJLN fBBD fSV1],'$\tilde S_2$','$V_1$','JLN','EPU','SV1','Location','NorthWest','Orientation','horizontal' );
axis([1960 2016 -3 4]);
% legend boxoff;
set(l,'interpreter','latex');


h=gcf;
set(h,'PaperOrientation','landscape');
set(h,'PaperUnits','normalized');
set(h,'PaperPosition', [0 0 1 1]);
print '-dpdf' 'plots/july17_figure2.pdf';


%% correlation with measures of uncertainty
corr(smooth(vu(:,1),1),smooth(utcsa(9:660,1),1))
corr(smooth(vu(:,1),1),-smooth(s(:,1),1))

corr(smooth(vu(1:643,1),1),smooth(BBDseries(736:end,2),1))
% post -1990 period
corr(smooth(vu(1+346:643,1),1),smooth(BBDseries(736+346:end,2),1))

corr(smooth(vu(5:end,1),1),smooth(sv(:,7),1))
corr(smooth(vu(:,1),1),smooth(ip,1))
corr(smooth(-ip(1:643,1),1),smooth(BBDseries(736:end,1),1))

X=[-vu(1:643,1) BBDseries(736:end,2) utcsa(9:660-9,1) sv(1:643,7) s(1:643,1:2) ];
corr(X)


