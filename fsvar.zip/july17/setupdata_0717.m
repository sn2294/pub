% load ~/onedrive/fredmd/temp/mdata2015m12;


if user==1;
    load mdata2015m12;
    addpath C:\Dropbox\fsvar\varjln;
else;
    load mdata2015m12;
    addpath ~/dropbox/prog/fsvar/varjln;
end;

yt= macrodata;
xdata=trimr(yt,12,0);
xdata2=xdata.^2;
xdata_std=standard(xdata);
xdata_std2=standard(xdata.^2);

do_standard=0;
do_raw=0; do_bw=0; do_ldt=0; do_fd=1;

load vardata_0717;
if do_bw==1; data=bw; end;
if do_ldt==1; data=ldt; end;
if do_fd==1; data=fd; disp('fd'); end;
if do_raw==1; data=raw; end;
mp=data.mp(13:end,1);
ip=data.ip(13:end,1);
consum=data.cons(13:end,1);
rpi=data.rpi(13:end,1);
invest=data.inv(13:end,1);
orders=data.orders(13:end,1);
tb3m=data.tb3m(13:end,1);
infl=data.infl(13:end,1);
rr=data.rr(13:end,1);
ffr=data.ffr(13:end,1);
house=data.house(13:end,1);
permits=data.permits(13:end,1);
sav=data.sav(13:end,1);
emp=data.emp(13:end,1);
aaabaa=data.aaabaa(13:end,1);
dates=mdates(13:end,1);

load HQ_0717;
F0=lsout{1}.fhat(12:end,:);
S=ssout{1}.fhat(12:end,:);
H=hsout{1}.fhat(12:end,:);
VU=vsout{1}.fhat(12:end,:);
FXVU=fsxvuout{1}.fhat(12:end,:);
f0=lsout{2}.fhat(12:end,:);
s=ssout{2}.fhat(12:end,:);
h=hsout{2}.fhat(12:end,:);
vu=vsout{2}.fhat(12:end,:);
fxvu=fsxvuout{2}.fhat(12:end,:);

load -ascii svfmeans_0717.txt;
sv=svfmeans_0717(4:end-3,:);

if do_standard==1;
    for i=1:cols(F0);
    F0(:,i)=standard(F0(:,i));
    FXVU(:,i)=standard(FXVU(:,i));
    S(:,i)=standard(S(:,i));
    H(:,i)=standard(H(:,i));
    V(:,i)=standard(V(:,i));
    f0(:,i)=standard(f0(:,i));
    fxvu(:,i)=standard(fxvu(:,i));
    h(:,i)=standard(h(:,i));
    end;
    consum=standard(consum);
    ip=standard(ip);
    sav=standard(sav);
    emp=standard(emp);

end;

