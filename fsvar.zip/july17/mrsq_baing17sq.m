function [R2,mR2,IC1] = mrsq_baing17sq(X,Fhat,Lamhat,ic,d,colheaders,outfile,appendorwrite)
% -------------------------------------------------------------------------
% Compute R2 and marginal R2 from estimated factors and factor loadings
%   Input:  Fhat       = estimated factor matrix
%           lamhat     = factor loadings
%           ve2        = eigenvalues
%           colheaders = variable names
%           vartype    = variable type
%           outfile    = name of output file
%   Output: R2         = R2 for each series
%           mR2        = marginal R2 for each group
% -------------------------------------------------------------------------

% Compute values
[N r]     = size(Lamhat);
R2         = zeros(N,ic);
mR2        = zeros(N,ic);
T          = rows(Fhat);
totalR2    = sum(d.^2);
Rsq= cumsum(d.^2);
R2=zeros(N,r);
C=Fhat*Lamhat';
x=standard(X);
traceR2=N*T*trace(C'*C)/trace(x'*x);
for i=1:ic;
    for j=1:N;
       R2(j,i)  = N*T*var(Fhat(:,1:i)*Lamhat(j,1:i)')/var(x(:,j));
       mR2(j,i) = N*T*var(Fhat(:,i)*Lamhat(j,i))/var(x(:,j));
   end;
end;

% Print to file
if appendorwrite==1;
fp          = fopen(outfile,'w');
else;
fp          = fopen(outfile,'a+');
end;
in.fid      = fp;
in.outwidth = N;
series      = [];

for i = 1:N
    series  = str2mat(series,colheaders{i});
end
series      = series(2:end,:);
fmt1        = ['\n                    ' repmat('%7d',1,ic)];
fmt         = ['\n' repmat('%4d',1,1)  ' %s' repmat('%7.3f',1,ic) ];
fprintf(fp,fmt1,(1:1:ic));
fprintf(fp,'\n R2\n');
for i = 1:N;
    fprintf(fp,fmt, i,series(i,:),R2(i,1:ic));
end;
fprintf(fp,'\n\n Marginal R2\n');

for i = 1:N;
    fprintf(fp,fmt,i,series(i,:),mR2(i,1:ic));
end;
[vals,ind] = sort(mR2,'descend');
temp1=[];
temp2=[];
vartoprint=12;
fprintf(fp,'\n\n Number of factors %d %d %d', ic);
fprintf(fp,'\n\n Variation Explained %6.3f %6.3f %6.3f',sum(Rsq(1:ic)),traceR2,totalR2);
fprintf(fp,'\n\n By factors\n');
fprintf(fp,repmat('%6.3f & ',1,ic),cumsum(Rsq(1:ic)));
fprintf(fp,'\n\n Highest Marginal R2''s');
for ii = 1:ic;
    fprintf(fp,'\n\n Factor %d: total contribution = %0.4f %0.4f\n',ii,Rsq(ii),totalR2);
    temp1=[temp1; series(ind(1:vartoprint,ii),:)];
    temp2=[temp2; mR2(ind(1:vartoprint,ii),ii)];
    for j = 1:vartoprint;
        i = ind(j,ii);
        fprintf(fp,fmt,i,series(i,:),mR2(i,ii));
    end
end;
fprintf(fp,'\n\n');
fmt2=[ repmat('%10s& %4.3f & ',1,1) ];
k=[0 ;10 ;20 ;30];
    for j=1:10;
        for i=1:4;
            if k(i)+j<=rows(temp1);
    fprintf(fp,fmt2, temp1(k(i)+j,:),temp2(k(i)+j,:)');
end;
        end;
    fprintf(fp,'\\\\\n');
end;
k=[40; 50; 60; ];
if ic>7;
    k=[k; 70];
end;

fprintf(fp,' \n');
    for j=1:10;
        for i=1:ic-4;
    fprintf(fp,fmt2, temp1(k(i)+j,:),temp2(k(i)+j,:)');
        end;
    fprintf(fp,'\\\\\n');
end;
fprintf(fp,' \n');
fclose(fp);
end
