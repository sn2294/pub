clear;
close all;
% addpath ~/dropbox/fsvar/varjln;
user=1;
if user==1;
    addpath C:\Dropbox\fsvar\varjln;
    cd 'C:\Dropbox\fsvar\july17'
    setupdata_0717;
end;

if user==2;
    addpath ../varjln;
    addpath ../lowrank;
    setupdata_0717;
end;

% Xreg=ones(length(fxvu),1);
% 
% N1=cols(fxvu);
% N1=2;
% for i1=1:N1
%     for i2=i1:N1
%         Xreg=[Xreg  fxvu(:,i1).*fxvu(:,i2)];
%     end
% end

% Xreg=ones(length(F0),1);
% 
% N1=cols(F0);
% N1=2;
% for i1=1:N1
%     for i2=i1:N1
%         Xreg=[Xreg  F0(:,i1).*F0(:,i2)];
%     end
% end
% 
% Xreg=[Xreg vu(:,1)];

Xreg=ones(length(fxvu),1);

N1=cols([fxvu vu(:,1:2)]);
FF=[fxvu vu(:,1:2)];
for i1=1:N1
    for i2=i1:N1
        Xreg=[Xreg  FF(:,i1).*FF(:,i2)];
    end
end

    
regS1=nwest(s(:,1),Xreg,0);
S1res=regS1.resid;
figure(1)
plot(mdates(12:end),s(:,1),'red',mdates(12:end),S1res,'black')        