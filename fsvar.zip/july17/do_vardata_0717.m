clear;
close all;
%load ~/onedrive/fredqd/sngprog/qd_ctc;
%for i=1:2;
%F.trend{i}=trimr(F.trend{i},5,0);
%F.cycle{i}=trimr(F.cycle{i},5,0);
%end;
%clear -except F.trend F.cycle;

user=2;
if user==1;
load C:\Dropbox\fsvar\july17\mdata2015m12;
addpath C:\Dropbox\fsvar\varjln;
else;
load ~/dropbox/prog/fsvar/july17/mdata2015m12;
addpath ~/dropbox/prog/fsvar/varjln;
end;


% addpath ~/dropbox/fsvar/varjln;
data0=rawmdata;
varlist=[1 3  6 22 59 61 68 82 108 48 53 119];

oldvarlist=[3  6 61 68 82 109 48 53 119];

for i=1:length(varlist);
    disp(sprintf('%d %s', varlist(i),mnames{varlist(i)}));
end;
Cons=log(rawmdata(:,3));
Ip=log(rawmdata(:,6));
Orders=log(rawmdata(:,59));
Inv=log(rawmdata(:,61));
MP=log(rawmdata(:,68));
tb3m=rawmdata(:,82);
ffr=rawmdata(:,80);
p=log(rawmdata(:,108));
infl=100*(p-lagn(p,12));
house=log(rawmdata(:,48));
permits=log(rawmdata(:,53));
Cdur=log(rawmdata(:,119));
rr=tb3m-infl;
Rpi=log(rawmdata(:,1));
Emp=log(rawmdata(:,22));
Sav=Rpi-Cons;           % saving rate
aaabaa=rawmdata(:,92)-rawmdata(:,91); % BAA-AAA spread

raw.cons=Cons;
raw.inv=Inv;
raw.orders=Orders;
raw.mp=MP;
raw.ip=Ip;
raw.infl=infl;
raw.rr=rr;
raw.tb3m=tb3m;
raw.ffr=ffr;
raw.house=house;
raw.permits=permits;
raw.cdur=Cdur;
raw.rpi=Rpi;
raw.emp=Emp;
raw.sav=Sav;
raw.aaabaa=aaabaa;

ldt.cons=detrend(Cons);
ldt.inv=detrend(Inv);
ldt.mp=detrend(MP);
ldt.ip=detrend(Ip);
ldt.cdur=detrend(Cdur);
ldt.infl=infl;
ldt.rr=rr;
ldt.ffr=ffr;
ldt.tb3m=tb3m;
ldt.orders=Orders;
ldt.house=house;
ldt.permits=permits;
ldt.rpi=detrend(Rpi);
ldt.emp=detrend(Emp);
ldt.sav=detrend(Sav);
ltd.aaabaa=aaabaa;

fd.cons=Cons-lagn(Cons,1); fd.cons(1)=0;
fd.inv=Inv-lagn(Inv,1); fd.inv(1)=0;
fd.mp=MP-lagn(MP,1); fd.mp(1)=0;
fd.ip=Ip-lagn(Ip,1); fd.ip(1)=0;
fd.cdur=Cdur-lagn(Cdur,1); fd.cdur(1)=0;
fd.infl=infl;
fd.rr=rr;
fd.ffr=ffr;
fd.tb3m=tb3m;
fd.orders=Orders;
fd.house=house;
fd.permits=permits;
fd.rpi=Rpi-lagn(Rpi,1); fd.rpi(1)=0;
fd.emp=Emp-lagn(Emp,1); fd.emp(1)=0;
fd.sav=Sav; % Sav-lagn(Sav,1); fd.sav(1)=0;
fd.aaabaa=aaabaa-lagn(aaabaa,1); fd.aaabaa(1)=0;

bw.cons=Cons-bw_trend(Cons,100);
bw.inv=Inv-bw_trend(Inv,100);
bw.mp=MP-bw_trend(MP,100);
bw.ip=Ip-bw_trend(Ip,100);
bw.cdur=Cdur-bw_trend(Cdur,100);
bw.infl=infl;
bw.rr=rr;
bw.ffr=ffr;
bw.tb3m=tb3m;
bw.orders=Orders;
bw.house=house;
bw.permits=permits;
bw.rpi=Rpi-bw_trend(Rpi,100);
bw.rpi=Emp-bw_trend(Emp,100);
bw.Sav=Sav-bw_trend(Sav,100);
bw.aaabaa=aaabaa-bw_trend(aaabaa,100);

%    rr= [mean(rr(13:end))*ones(12,1); bw_trend(rr(13:end),100)];
%    infl=[mean(infl(13:end))*ones(12,1); bw_trend(infl(13:end),100)];


data0=rawmdata(:,varlist);
data1=[ MP  Ip Cons Inv   tb3m infl rr Rpi Emp Sav aaabaa];




save vardata_0717 mdates data0 data1  bw fd ldt raw;

