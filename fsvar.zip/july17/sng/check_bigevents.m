clear;

load HQ_0717;

ishrink=2; brk=4.0;
S=standard(ssout{ishrink}.fhat(13:end,1));
V=standard(vsout{ishrink}.fhat(13:end,1));
F=standard(lsout{ishrink}.fhat(13:end,1));
A=standard(fsxvuout{ishrink}.fhat(13:end,1));
dates=mdates(13:end,:);
f=abs(F>brk).*F;
s=abs(S>brk).*S;
a=abs(A>brk).*A;
v=abs(V>brk).*V;

ds=find(s);
dv=find(v);
df=find(f);
da=find(a);

disp('big F');
mymprint([dates(df) f(df)]);

disp('big S');
mymprint([dates(ds) s(ds)]);


disp('big A');
mymprint([dates(da) a(da)]);

disp('big V');
mymprint([dates(dv) v(dv)]);


