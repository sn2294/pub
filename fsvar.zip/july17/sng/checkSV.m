clear;
load ../HQ_0717;

ishrink=2;
S=ssout{ishrink}.fhat(16:end,:);
V=vsout{ishrink}.fhat(16:end,:);
F=lsout{ishrink}.fhat(16:end,:);
A=fsxvuout{ishrink}.fhat(16:end,:);

load -ascii ../svfmeans_0717.txt;
sv=svfmeans_0717(4:end-3,:);


HF=[];
 for i1=1:lsout{2}.ic2;
    for i2=i1:lsout{2}.ic2;
        HF=[HF F(:,i1).*F(:,i2)];
    end;
end;

HA=[];
 for i1=1:fsxvuout{2}.ic2;
    for i2=i1:fsxvuout{2}.ic2;
        HA=[HA A(:,i1).*A(:,i2)];
    end;
end;
AA=A(:,1:fsxvuout{2}.ic2).^2;
FF=F(:,1:lsout{2}.ic2).^2;
one=ones(rows(F),1);
out1a=nwest(S(:,1),[one HF ],0);
out1b=nwest(S(:,1),[one HA ],0);
out1c=nwest(S(:,1),[one HA V(:,1:2)],0);
out1d=nwest(S(:,1),[one HA  sv(:,7:8) ],0);
out1e=nwest(S(:,1),[one HA  V(:,1:2) sv(:,7:8) ],0);
out1f=nwest(S(:,1),[one   V(:,1:2) sv(:,7:8) ],0);
out2a=nwest(S(:,2),[one V(:,1) ],0);
out2b=nwest(S(:,2),[one V(:,1) sv(:,7:8)],0);
[out1a.rsqr out1b.rsqr out1c.rsqr out1d.rsqr out1e.rsqr out1f.rsqr]
[out2a.rsqr out2b.rsqr]