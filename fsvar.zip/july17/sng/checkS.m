clear;

load HQ_0717;
S=ssout{2}.fhat;
V=vsout{2}.fhat;
A=fsxvuout{2}.fhat;
F=lsout{2}.fhat;

Hreg=[]; varname=[];
for i1=1:3;
    for i2=i1:3;
        varname=[varname; i1 i2];
        Hreg=[Hreg  A(:,i1).*A(:,i2)];
    end;
end;
Rbar.S=[]; mR.S=[]; Rbar.A=[]; mR.A=[]; Rbar.F=[]; mR.F=[];
Hreg=[Hreg V(:,1) V(:,2)];
varname=[varname; 0 1; 0 2; 1 0  ];
HregA=[Hreg  A(:,1)  ones(rows(S),1)];
HregS=[Hreg  S(:,1)  ones(rows(S),1)];
HregF=[Hreg  F(:,1)  ones(rows(S),1)];
k=1;
for i=1:cols(HregA)-1;
    outF=nwest(A(2:end,k),HregA(1:end-1,1:i),0);
    Rbar.A=[Rbar.A; varname(i,:) outF.rbar];
    mR.A=[mR.A; varname(i,:)];

    outF=nwest(A(2:end,k),HregF(1:end-1,1:i),0);
    Rbar.F=[Rbar.F; varname(i,:) outF.rbar];
    mR.F=[mR.F; varname(i,:)];

    outS=nwest(S(2:end,k),HregS(1:end-1,1:i),0);
    Rbar.S=[Rbar.S; varname(i,:) outS.rbar];
    mR.S=[mR.S; varname(i,:)];
end;
mR.F=[Rbar.F(1,end); Rbar.F(2:end,end)-Rbar.F(1:end-1,end)];
mR.F=[varname mR.F];
mR.A=[Rbar.A(1,end); Rbar.A(2:end,end)-Rbar.A(1:end-1,end)];
mR.A=[varname mR.A];
mR.S=[Rbar.S(1,end); Rbar.S(2:end,end)-Rbar.S(1:end-1,end)];
mR.S=[varname mR.S];
mymprint([mR.F mR.A(:,3:end) mR.S(:,3:end)]);