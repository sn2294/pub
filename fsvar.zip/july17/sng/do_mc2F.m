clear;
seed=9876;
randn('state',seed);
rand('state',seed);
maxit=1000;
T=400;
N=100;
burn=100;
r=2; rmax=8;
sig.eps=0.0;
sig.eps2=0.0;
sig.F=[1.0 1.00 ];
rho.A=0.5;
in.fmt='%7.3f';
iprint=1;
outfile=['plots/mc2F'  ];

for icase=1:1;
    if icase==1;
        u=zeros(T+burn,2);
        u(:,1)=(randn(T+burn,1)*sig.F(1)).^2;  dist{icase}='chi-2';
        u(:,2)=(randn(T+burn,1)*sig.F(2)).^2;  
        sig.LamG=.01; sig.Lamu=.1;
    end;    %% chi square shock
    if icase==2;
        u=betarnd(2,5,T+burn,1); dist{icase}='beta';
        sig.LamG=.05; sig.Lamu=10;
    end;                % beta distribution shock
    store{icase}.true=[]; store{icase}.Ztilde=[]; store{icase}.ZF=[];
     store{icase}.ZA=[];store{icase}.ic=[];  store{icase}.ic0=[];
    store{icase}.V=[]; store{icase}.A=[]; store{icase}.F=[]; 
    store{icase}.Vbar=[]; store{icase}.Vhat=[];
    store{icase}.ZG=[]; store{icase}.ZV=[];

    disp(sprintf('distribution %s',dist{icase}));

for it=1:maxit;
    A=zeros(T+burn,2);
    sv.eps=repmat(1+randn(T+burn,1)*sig.eps,1,N);
    sv.eps2=repmat(1+randn(T+burn,1)*sig.eps2,1,N);
    eps=randn(T+burn,N).*sv.eps;
    eps2=randn(T+burn,N).*sv.eps2;
    A(:,1)=filter(1,[1 -rho.A(1)], randn(T+burn,1).*sqrt(u(:,1)));
    A(:,2)=randn(T+burn,1).*sqrt(u(:,2));
    Lambda.A=randn(N,r);
    Lambda.G=randn(N,r*(r+1)/2)*sqrt(sig.LamG);
    Lambda.u=randn(N,r)*sqrt(sig.Lamu);

    G=[];
    for i1=1:r;
        for i2=i1:r;
            G=[G A(:,i1).*A(:,i2)];
        end;
    end;
    X=A*Lambda.A'+G*Lambda.G'+u*Lambda.u'+eps;

    control.X=trimr(X,burn,0);

    control.u=trimr(u,burn,0);
    control.A=trimr(A,burn,0);
    control.G=trimr(G,burn,0);
    control.eps=trimr(eps,burn,0);
    V.A=var(control.A*Lambda.A')' ;
    V.G=var(control.G*Lambda.G')';
    V.u=var(control.u*Lambda.u')';
    V.eps=var(control.eps)';
    V.X=var(control.X)';

    z=control.X;
    z2=z.*z;
    Z=[z z2];
    [TT,NN]=size(Z);


    tau=0.05;
    outF0=baing17sq(standard(z)/sqrt(NN*TT),rmax,0);
    outS0=baing17sq(standard(z2)/sqrt(NN*TT),rmax,0);   % estimate H, the factors in Z and z^2
    outH0=baing17sq(standard(Z)/sqrt(2*NN*TT),rmax,0);   % estimate H, the factors in Z and z^2
    outF=baing17sq(standard(z)/sqrt(NN*TT),rmax,tau);
    outS=baing17sq(standard(z2)/sqrt(NN*TT),rmax,tau);   % estimate H, the factors in Z and z^2
    outH=baing17sq(standard(Z)/sqrt(2*NN*TT),rmax,tau);   % estimate H, the factors in Z and z^2

    Hreg=ones(TT,1);
    for i1=1:outF.ic2;
        for i2=i1:outF.ic2;
        Hreg=[Hreg outF.fhat(:,i1).*outF.fhat(:,i2)];
        end;
    end;

    Ztilde1=[]; Ztilde2=[]; check.Ztilde=[]; 
    check.ZF=[]; check.ZA=[]; check.control=[]; check.ZV=[]; check.ZG=[];
    for i=1:cols(z);
        outZ1=nwest(z(:,i),Hreg,0);
        Ztilde1=[Ztilde1 outZ1.resid];
        outZ2=nwest(z2(:,i),Hreg,0);
        Ztilde2=[Ztilde2 outZ2.resid];
        check.Ztilde=[check.Ztilde;  outZ1.rbar outZ2.rbar];
    end;
    outV=baing17sq(standard(Ztilde2)/sqrt(NN*TT),2,0);
    outV.Vbar=mean(Ztilde2')';

    Ztilde1A=[];
    if outV.ic2>0;
    Hreg1=[Hreg outV.fhat(:,1:outV.ic2)];
    else;
    Hreg1=[Hreg outV.Vbar];
    end;
    for i=1:cols(z);
        outZ1A=nwest(z(:,i), Hreg1,0);
        Ztilde1A=[Ztilde1A outZ1A.resid];
     end;
    outA=baing17sq(standard(Ztilde1A)/sqrt(NN*TT),rmax,tau);

    for i=1:outV.ic2;
        outV.fhat(:,i)=outV.fhat(:,i)*sign(corr(outF.fhat(:,1),outV.fhat(:,i)));
    end;

    for i=1:cols(z);
        reg01=nwest(z(:,i),[ones(T,1) control.A(:,1:r)],0);
        reg02=nwest(z(:,i),[ones(T,1) control.A(:,1:r) control.u],0);
        reg03=nwest(z(:,i),[ones(T,1) control.A(:,1:r) control.u control.G],0);
        reg11=nwest(z(:,i),[ones(T,1) outF.fhat(:,1:outF.ic2)],0);
        reg12=nwest(z(:,i),[ones(T,1) outF.fhat(:,1:outF.ic2) outV.fhat(:,1:outV.ic2)],0);
        reg21=nwest(z(:,i),[ones(T,1) outA.fhat(:,1:outA.ic2)],0);
        reg22=nwest(z(:,i),[ones(T,1) outA.fhat(:,1:outA.ic2) outV.fhat(:,1:outV.ic2)],0);
        reg31=nwest(z(:,i),[ones(T,1) control.u],0); 
        reg32=nwest(z(:,i),[ones(T,1) control.G],0); 
        check.control=[check.control; reg01.rbar reg02.rbar reg03.rbar];
        check.ZF=[check.ZF; reg11.rbar reg12.rbar];
        check.ZA=[check.ZA; reg21.rbar reg22.rbar ];
        check.ZV=[check.ZV; reg31.rbar];
        check.ZG=[check.ZG; reg32.rbar];
    end;
    check.V=[]; check.A=[]; check.F=[];
    for i=1:r;
        reg41=nwest(control.u(:,i),[ones(T,1) outV.fhat(:,1)],0);
        reg42=nwest(control.u(:,i),[ones(T,1) outV.fhat(:,1:outV.ic2)],0);
        reg43=nwest(control.u(:,i),[ones(T,1) outV.Vbar],0);
        check.V=[check.V reg41.rbar reg42.rbar reg43.rbar];
    end;
    for j=1:r;
        reg51=nwest(control.A(:,j),[ones(T,1) outA.fhat(:,1:outA.ic2)],0);
        check.A=[check.A reg51.rbar];
        reg52=nwest(control.A(:,j),[ones(T,1) outF.fhat(:,1:outF.ic2)],0);
        check.F=[check.F reg52.rbar];
    end;


    check.ic=[outF.ic2 outS.ic2 outH.ic2 outA.ic2 outV.ic2];
    check.ic0=[outF0.ic2 outS0.ic2 outH0.ic2];
    check.true=[mean(V.A)  mean(V.u) mean(V.G) mean(V.eps)]/mean(V.X);
    check.true=[check.true mean(check.control)];
    store{icase}.true=[store{icase}.true; check.true ];
    store{icase}.Ztilde=[store{icase}.Ztilde; mean(check.Ztilde)];
    store{icase}.ZF=[store{icase}.ZF; mean(check.ZF)];
    store{icase}.ZA=[store{icase}.ZA; mean(check.ZA)];
    store{icase}.ZG=[store{icase}.ZG; mean(check.ZG)];
    store{icase}.ZV=[store{icase}.ZV; mean(check.ZV)];
    store{icase}.ic=[store{icase}.ic; check.ic];
    store{icase}.ic0=[store{icase}.ic0; check.ic0];
    store{icase}.F=[store{icase}.F; check.F];
    store{icase}.A=[store{icase}.A; check.A];
    store{icase}.V=[store{icase}.V; check.V];
    store{icase}.Vbar=[store{icase}.Vbar; outV.Vbar'];
    store{icase}.Vhat=[store{icase}.Vhat; outV.fhat(:,1)'];

if it==1;
    fmt1=['%s'  repmat('%7.3f ',1,cols(check.true) ) '\n'];
    fprintf(fmt1,'VD: theory ',check.true);
    fmt2=['%s'  repmat('%7.3f ',1,cols(check.ZF) ) '\n'];
    fprintf(fmt2,'VD: data-F ',mean(check.ZF));
    fmt3=['%s'  repmat('%7.3f ',1,cols(check.ZA) ) '\n'];
    fprintf(fmt3,'VD: data-A ',mean(check.ZA));
    fmt4=['%s'  repmat('%7.3f ',1,cols(check.ic0) ) '\n'];
    fprintf(fmt4,'rhat:      ',check.ic0);
    fmt5=['%s'  repmat('%7.3f ',1,cols(check.ic) ) '\n'];
    fprintf(fmt5,'rbar:      ',check.ic);
    fmt6=['%s'  repmat('%7.3f ',1,cols(check.F) ) '\n'];
    fprintf(fmt6,'Check F    ',check.F);
    fmt7=['%s'  repmat('%7.3f ',1,cols(check.A) ) '\n'];
    fprintf(fmt7,'Check A    ',check.A);
    fmt8=['%s'  repmat('%7.3f ',1,cols(check.V) ) '\n'];
    fprintf(fmt8,'Check V    ',check.V);
    fmt9=['%s'  repmat('%7.3f ',1,cols(check.ZG)+cols(check.ZV) ) '\n'];
    fprintf(fmt9,'Check ZG,ZV    ',mean(check.ZG),mean(check.ZV));
    fmt10=['%s'  repmat('%7.3f ',1,cols(check.Ztilde) ) '\n'];
    fprintf(fmt10,'Check Ztilde    ',mean(check.Ztilde));
    figure(1);
plot(standard(control.u),'k','LineWidth',1.5);
%hold on;
%plot(standard(reg41.yhat),'r');
hold on;
plot(standard(outV.fhat(:,1)),'r','LineWidth',1.0);
hold on;
plot(standard(outV.Vbar),'b','LineWidth',1.0);
hold off;
end;
end; % end maxit;

if it>1 & iprint==1 & maxit>1;;
    fprintf('\n average over monte carlo\n');
    fprintf(fmt1,'VD: theory ',mean(store{icase}.true));
    fprintf(fmt2,'VD: data-F ',mean(store{icase}.ZF));
    fprintf(fmt3,'VD: data-A ',mean(store{icase}.ZA));
    fprintf(fmt4,'rhat:      ',mean(store{icase}.ic0));
    fprintf(fmt5,'rbar:      ',mean(store{icase}.ic));
    fprintf(fmt6,'Check F    ',mean(store{icase}.F));
    fprintf(fmt7,'Check A    ',mean(store{icase}.A));
    fprintf(fmt8,'Check V    ',mean(store{icase}.V));
    fprintf(fmt9,'Check ZG-ZV    ',mean(store{icase}.ZG),mean(store{icase}.ZV));
    fprintf(fmt10,'Check Ztilde    ',mean(store{icase}.Ztilde));
    figure(2);
    subplot(1,1,1);
    plot(standard(control.u),'k','LineWidth',1.5);
    hold on;
    plot(standard(mean(store{icase}.Vbar)'),'b','LineWidth',1.0);
    hold on;
    plot(standard(mean(store{icase}.Vhat)'),'r','LineWidth',1.0);
    temp1=max(abs(corr(control.u,mean(store{icase}.Vbar)')));
    temp2=max(abs(corr(control.u,mean(store{icase}.Vhat)')));
    title([ dist{icase} ' Distribution ' num2str(temp1) ' ' num2str(temp2)]);
    hold off;
%    print(gcf,'-dpdf',[outfile num2str(icase) '.pdf']);
end;  % end print
end; % nnd icase
%save(outfile, 'store');
