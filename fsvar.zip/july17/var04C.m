clear;
close all;
user=2;
if user==1;
    addpath C:\Dropbox\fsvar\varjln;
    setupdata_0717;
end;

if user==2;
addpath ../varjln;
setupdata_0717;
end;

% load additional data for measure of uncertainty
BBD;
load jln_uncertainty

    for ishrink=2:2; % iterate over PCA (1) and robust PCA (2)
            if ishrink==1;
                z=[FXVU(1:643,1) VU(1:643,1) utcsa(9:660-9,1) S(1:643,1)  house(1:643) ip(1:643) infl(1:643)  ffr(1:643) ];
                varname{1}='FXVU1';
                varname{2}='VU1';
                varname{3}='JLN';
                varname{4}='S1';
                
                varname{5}='Housing starts';
                varname{6}='Indus.Production';
                varname{7}='Inflation';
                varname{8}='Fed Funds Rate';

            end;
            if ishrink==2;
                z=[fxvu(1:643,1)  vu(1:643,1) utcsa(9:660-9,1) s(1:643,1) house(1:643) ip(1:643) infl(1:643) ffr(1:643) ];
                varname{1}='fxvu1';
                varname{2}='vu1';
                varname{3}='JLN';
                varname{4}='S1';
                
                varname{5}='Housing starts';
                varname{6}='Indus.Production';
                varname{7}='Inflation';
                varname{8}='Fed Funds Rate';

            end;
            T=rows(z);
            T=rows(VU(1:643,1));



            filename = 'var04C';
            model=04;
            impulse     = 1:cols(z);
            response = 1:cols(z);
            estimate = 1;
            bound    = 0;
            p        = 4;
            tr         = 0;
            estimate_var;
            cd plots;
            if ishrink==1;
                save jme_var04C1 IR IRu IRd VD  impulse response varname;
            end;
            if ishrink==2;
                save jme_var04C2 IR IRu IRd VD  impulse response varname;
            end;

            outfile=['var04C' num2str(ishrink) '.out'];
            delete(outfile);
            diary(outfile);
            pick=[1; 6; 12; 24; 60];
            nvar=8;
            in.fmt='%6.3f';
            vdbyvar=[];
            for j=1:nvar;
                disp(['\hline Shock ' varname{j} '\\ \hline' ]);
            %     mymprint(VD{j}(pick,:),in);
                latexmatrix([pick VD{j}(pick,:)],'%6.3f');
                temp=[];
                for k=1:nvar;
                    temp=[temp VD{j}(pick,k)];
                end;
                vdbyvar{j}=temp;
            end;
            diary off;
            cd ..;
    end









