clear all;
close all;
load gls_HQ_0717;
load gls_HQ_0717;
gls=lsout;
gvs=vsout;
gss=ssout;
gfxvu=fsxvuout;
addpath ~/dropbox/prog/fsvar/varjln;

load HQ_0717;
T=rows(lsout{1}.fhat);
ls=lsout;
vs=vsout;
fxvu=fsxvuout;

ss=ssout;

j1=1; j2=2;
figure(1);
subplot(4,1,1);
temp1=[ls{1}.fhat(:,j1)  gls{1}.fhat(:,j1) ls{2}.fhat(:,j1) ];
temp1(:,1)=-temp1(:,1);
for k=2:cols(temp1);
    temp1(:,k)=temp1(:,k)*sign(corr(temp1(:,1),temp1(:,k)));
end;
temp1_std=standard(temp1);
plotNBERrec;
ff0=plot(mdates,temp1_std(:,1),'k','LineWidth',1.0);
hold on;
ff0=plot(mdates,temp1_std(:,2),'b','LineWidth',.70);
hold on;
ff0=plot(mdates,temp1_std(:,3),'r','LineWidth',.50);
%legend('pca','gls','rpca');
%legend 'boxoff';
hold off;
title(['F' num2str(j1)]);
ylim([-5 5])
xlim([1960 2016])

subplot(4,1,2);
temp4=[ss{1}.fhat(:,j1) gss{1}.fhat(:,j1) ss{2}.fhat(:,j1)  ];
for k=2:cols(temp4);
    temp4(:,k)=temp4(:,k)*sign(corr(temp4(:,1),temp4(:,k)));
end;
temp4_std=standard(temp4);
plotNBERrec;
ff0=plot(mdates,temp4_std(:,1),'k','LineWidth',1.0);
hold on;
ff1=plot(mdates,temp4_std(:,2),'b','LineWidth',.70);
hold on;
ff2=plot(mdates,temp4_std(:,3),'r','LineWidth',.50);
%legend('pca','gls','rpca');
%legend 'boxoff';
hold off;
title(['S' num2str(j1)]);
ylim([-2 8])
xlim([1960 2016])
l=legend([ff0 ff1 ff2],'pca','gls','rpca','Location','NorthWest','Orientation','horizontal' );

j2=1;
subplot(4,1,3);
temp2=[fxvu{1}.fhat(:,j2)  gfxvu{1}.fhat(:,j2) fxvu{2}.fhat(:,j2) ];
temp2=[fxvu{1}.fhat(:,1)  gfxvu{1}.fhat(:,1) fxvu{2}.fhat(:,1) ];

for k=2:cols(temp2);
    temp2(:,k)=temp2(:,k)*sign(corr(temp2(:,1),temp2(:,k)));
end;
temp2_std=standard(temp2);
plotNBERrec;
ff0=plot(mdates,temp2_std(:,1),'k','LineWidth',1.0);
%hold on;
%ff0=plot(mdates,temp2_std(:,2),'b','LineWidth',.70);
hold on;
ff0=plot(mdates,temp2_std(:,3),'r','LineWidth',.50);
%legend('pca','gls','rpca');
%legend 'boxoff';
hold off;
title(['A' num2str(j2)]);
ylim([-5 5])
xlim([1960 2016])

subplot(4,1,4);
temp3=[-vs{1}.fhat(:,j1) gvs{1}.fhat(:,j1) vs{2}.fhat(:,j1)  ];
for k=2:cols(temp3);
    temp3(:,k)=temp3(:,k)*sign(corr(temp3(:,1),temp3(:,k)));
end;
temp3_std=standard(temp3);
temp3_std=temp3;
plotNBERrec;
ff0=plot(mdates,temp3_std(:,1),'k','LineWidth',1.0);
%hold on;
%ff1=plot(mdates,temp3_std(:,2),'b','LineWidth',.70);
hold on;
ff2=plot(mdates,temp3_std(:,3),'r','LineWidth',.50);
%legend 'boxoff';
hold off;
title(['V' num2str(j1)]);
ylim([-2 2])
xlim([1960 2016])




filename='plots/july17_figure1.pdf';
h=gcf;
% set(h,'PaperPositionMode','auto');
% set(h,'PaperOrientation','landscape');
% set(h,'Position',[50 50 1200 800]);

set(h,'PaperOrientation','landscape');
set(h,'PaperUnits','normalized');
set(h,'PaperPosition', [0 0 1 1]);

print('-f1',filename,'-dpdf');

names{1}='apca';names{2}='gls'; names{3}='rpca'; names{4}='gls-rpca';
bbb=3;
figure(99);
subplot(2,1,1);
temp31=[-vs{1}.fhat(:,j1) -gvs{1}.fhat(:,j1) vs{2}.fhat(:,j1) ];
%for k=2:cols(temp31);
%    temp31(:,k)=temp31(:,k)*sign(corr(temp31(:,1),temp31(:,k)));
%end;
temp31_std=standard(temp31);
temp31_std=temp31;
plotNBERrec;
%ff0=plot(mdates,temp31_std(:,1),'k','LineWidth',1.0);
%hold on;
%ff1=plot(mdates,temp31_std(:,4),'b','LineWidth',.70);
%hold on;
ff2=plot(mdates,temp31_std(:,bbb),'r','LineWidth',.50);
legend 'boxoff';
hold off;
title(['V' num2str(j1)]);
ylim([-2 2])
xlim([1960 2016])
%l=legend([ff2],names{bbb},'Location','NorthWest','Orientation','horizontal' );
j2=2;
subplot(2,1,2);
temp32=[-vs{1}.fhat(:,j2) gvs{1}.fhat(:,j2) vs{2}.fhat(:,j2) ];
%for k=2:cols(temp3);
%    temp32(:,k)=temp32(:,k)*sign(corr(temp32(:,1),temp32(:,k)));
%end;
temp32_std=standard(temp32);
temp32_std=temp32;
plotNBERrec;
%ff0=plot(mdates,temp32_std(:,1),'k','LineWidth',1.0);
%hold on;
%ff1=plot(mdates,temp32_std(:,4),'b','LineWidth',.70);
%hold on;
ff2=plot(mdates,temp32_std(:,bbb),'r','LineWidth',.50);
legend 'boxoff';
hold off;
title(['V' num2str(j2)]);
ylim([-2 2])
xlim([1960 2016])
filename=['plots/july17_figure1V-' names{bbb} '.pdf'];
print(gcf,filename,'-dpdf');

