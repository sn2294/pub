clear;
user=2;
if user==1;
    addpath C:\Dropbox\fsvar\varjln;
    cd 'C:\Dropbox\fsvar\july17'
else;
    addpath ~/dropbox/prog/fsvar/varjln;
end;

load HQ_0717;
F0=lsout{1}.fhat(12:end,:);
S=ssout{1}.fhat(12:end,:);
FXVU=fsxvuout{1}.fhat(12:end,:);
f0=lsout{2}.fhat(12:end,:);
s=ssout{2}.fhat(12:end,:);
fxvu=fsxvuout{2}.fhat(12:end,:);
dates=mdates(13:end,1);

ft=[F0(:,1:2) FXVU(:,1:2)  f0(:,1:2) fxvu(:,1:2) S(:,1:2) s(:,1:2)];


[T,R]  = size(ft);
pf     = 4;
q      = fix(4*(T/100)^(2/9));
fbetas = zeros(R,pf+1);
for i = 1:R
   X   = [ones(T,1),mlags(ft(:,i),pf)];
   reg = nwest(ft(pf+1:end,i),X(pf+1:end,:),q);
   vft(:,i)    = reg.resid;
   fbetas(i,:) = reg.beta';
end

dlmwrite('vft_0717.txt',vft,'delimiter','\t','precision',17);