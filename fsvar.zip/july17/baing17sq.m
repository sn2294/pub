function out=baing17sq(X,kmax,tau)
%% This program returns Fhat scaled by root-T and Lamhat scaled by root-N

[T,N]=size(X);
ii=(1:1:kmax)';
ii(kmax+1)=0;   %% 0 factors is put last
NT=(N*T);
NT1=(N+T);
CT=(NT1/NT)*log(min([N;T]))*ii;
CT(kmax+1)=0;
[U,D,V]=svd(X);
d0=diag(D);
total=sum(diag(D'*D));
Du=D(1:kmax,1:kmax);
Dr=Du-tau*eye(kmax);
du=diag(Du);
dr=diag(Du-tau*eye(kmax));
dr=dr.*(dr>0);
if tau>0;
    d=dr;
    D=diag(dr);
else;
    d=du;
    D=Du;
end;
explained=cumsum(d.^2);
explained(kmax+1)=0.0;
Sigma=total*ones(kmax+1,1)-explained;
IC2=log(Sigma)+CT;
ic2=minindc(IC2);
PC2k=(Sigma)+CT*Sigma(kmax);
PC20=(Sigma)+CT*Sigma(kmax+1);
pc2k=minindc(PC2k);
pc20=minindc(PC20);
out.ic2=ic2 .*(ic2 <= kmax);
out.pc2k=pc2k .*(pc2k <= kmax);
out.pc20=pc20 .*(pc20 <= kmax);
out.Fhat=U(:,1:kmax)*D(1:kmax,1:kmax).^(1/2);
out.Lamhat=V(:,1:kmax)*D(1:kmax,1:kmax).^(1/2);
out.Sigma=Sigma;
out.IC2=IC2;;
out.PC2k=PC2k;
out.PC20=PC20;
out.d=d;
out.fhat=out.Fhat*sqrt(T);
out.lambda=out.Lamhat*sqrt(N);

%disp(sprintf('Bai Ng-rpca %f',total));
%mymprint([ii explained Sigma CT IC2]);


