clear;
seed=9876;
randn('state',seed);
maxit=1; 1000;
T=1000;
N=100;
burn=100;
r=2; rmax=5; 
sig.eps=0.0;
sig.eps2=0.0;
sig.F=[1.0 1];
rho.A=0.5;
in.fmt='%7.3f';
store.true=[]; store.Ztilde=[]; store.ZF=[]; store.ZA=[];store.ic=[];  store.ic0=[];
store.V=[]; store.A=[];store.A2=[]; store.F=[]; store.Vfac=zeros(T,1);
u=(randn(T+burn,1)*sig.F(1)).^2;      %% chi square shock
u=betarnd(2,5,T+burn,1);                % beta distribution shock

% u=exp(randn(T+burn,1)*sig.F(1)-0.5);      %% log normal shock

for it=1:maxit;
    A=zeros(T+burn,2);
    sv.eps=repmat(1+randn(T+burn,1)*sig.eps,1,N);
    sv.eps2=repmat(1+randn(T+burn,1)*sig.eps2,1,N);
    eps=randn(T+burn,N).*sv.eps;        % innovations to levels of variables
    eps2=randn(T+burn,N).*sv.eps2;      % innovations to squares of variables
    A(:,1)=filter(1,[1 -rho.A(1)], randn(T+burn,1).*sqrt(u));
    A(:,2)=randn(T+burn,1)*sqrt(sig.F(2));
    
    % loadings for levels of variables
    Lambda.A=randn(N,r);                    % levels of factors
    Lambda.G=randn(N,r*(r+1)/2)*sqrt(.1); % interactions of level factors
    Lambda.u=randn(N,1)*sqrt(2);           % volatility factor for levels
    
    % loadings for squares of variables
    Lambda2.G=[];   
    % generate interactions of level factors (this includes squares)
    for i1=1:r
        for i2=i1:r
           f1=1+(i1~=i2); 
           Lambda2.G=[Lambda2.G f1*Lambda.A(:,i1).*Lambda.A(:,i2)];
        end
    end
    Lambda2.u=randn(N,1)*sqrt(10);           % volatility factor for squares

    G=[];
    for i1=1:r;
        for i2=i1:r;
            G=[G A(:,i1).*A(:,i2)];
        end;
    end;
    X=A*Lambda.A'+G*Lambda.G'+u*Lambda.u'+eps;  % levels of variables
    X2=G*Lambda2.G'+u*Lambda2.u'+eps2;          % squares of variables
    
    control.X=trimr(X,burn,0);
    control.X2=trimr(X2,burn,0);
    
    control.u=trimr(u,burn,0);
    control.A=trimr(A,burn,0);
    control.G=trimr(G,burn,0);
    control.eps=trimr(eps,burn,0);
    control.eps2=trimr(eps2,burn,0);
    
    V.A=var(control.A*Lambda.A')';
    V.G=var(control.G*Lambda.G')';
    V.u=var(control.u*Lambda.u')'; 
    V.eps=var(control.eps)';
    V.X=var(control.X)';

    V2.G=var(control.G*Lambda2.G')';
    V2.u=var(control.u*Lambda2.u')'; 
    V2.eps2=var(control.eps2)';
    V2.X2=var(control.X2)';
    
    z=control.X;
    z2=control.X2;
    Z=[z z2];
    [TT,NN]=size(Z);


    tau=0.05;
    outF0=baing17sq(standard(z)/sqrt(NN*TT),rmax,0);
    outS0=baing17sq(standard(z2)/sqrt(NN*TT),rmax,0);   % estimate H, the factors in Z and z^2
    outH0=baing17sq(standard(Z)/sqrt(2*NN*TT),rmax,0);   % estimate H, the factors in Z and z^2
    outF=baing17sq(standard(z)/sqrt(NN*TT),rmax,tau);
    outS=baing17sq(standard(z2)/sqrt(NN*TT),rmax,tau);   % estimate H, the factors in Z and z^2
    outH=baing17sq(standard(Z)/sqrt(2*NN*TT),rmax,tau);   % estimate H, the factors in Z and z^2

    Hreg=ones(TT,1);
    for i1=1:outH.ic2;
        for i2=i1:outH.ic2;
        Hreg=[Hreg outH.fhat(:,i1).*outH.fhat(:,i2)];
        end;
    end;

    Ztilde1=[]; Ztilde2=[]; check.Ztilde=[]; check.ZF=[]; check.ZA=[]; check.control=[];
    for i=1:cols(z);
        outZ1=nwest(z(:,i), Hreg,0);
        Ztilde1=[Ztilde1 outZ1.resid];
        outZ2=nwest(z2(:,i),Hreg,0);
        Ztilde2=[Ztilde2 outZ2.resid];
        check.Ztilde=[check.Ztilde; outZ1.rbar outZ2.rbar];
    end;

    outV=baing17sq(standard(Ztilde2)/sqrt(NN*TT),rmax,tau);
    % project Ztilde1 on outV
    Ztilde1A=[];
    Hreg=[ones(TT,1) outV.fhat(:,1:outV.ic2)] ;
    for i=1:cols(Ztilde1);
        outZ1=nwest(Ztilde1(:,i), Hreg,0);
        Ztilde1A=[Ztilde1A outZ1.resid];
    end;
    outA=baing17sq(standard(Ztilde1A)/sqrt(NN*TT),rmax,tau);

    
    for i=1:outV.ic2;
        [maxv,maxid]=max(abs(outV.fhat(:,i)));
        outV.fhat(:,i)=outV.fhat(:,i)*sign(outV.fhat(maxid,i));
    end;
    
    Vfac=outV.fhat(:,1);
    for i=1:cols(z);
        reg01=nwest(z(:,i),[ones(T,1) control.A(:,1:r)],0);
        reg02=nwest(z(:,i),[ones(T,1) control.A(:,1:r) control.u],0);
        reg03=nwest(z(:,i),[ones(T,1) control.A(:,1:r) control.u control.G],0);
        reg11=nwest(z(:,i),[ones(T,1) outF.fhat(:,1:outF.ic2)],0);
        reg12=nwest(z(:,i),[ones(T,1) outF.fhat(:,1:outF.ic2) outV.fhat(:,1:outV.ic2)],0);
        reg21=nwest(z(:,i),[ones(T,1) outA.fhat(:,1:outA.ic2)],0);
        reg22=nwest(z(:,i),[ones(T,1) outA.fhat(:,1:outA.ic2) outV.fhat(:,1:outV.ic2)],0);
        check.control=[check.control; reg01.rbar reg02.rbar reg03.rbar];
        check.ZF=[check.ZF; reg11.rbar reg12.rbar];
        check.ZA=[check.ZA; reg21.rbar reg22.rbar ];
    end;
    
    check.V=[]; check.A=[]; check.A2=[]; check.F=[];
    reg41=nwest(control.u,[ones(T,1) outV.fhat(:,:)],0);
    check.V=[check.V reg41.rbar];
    reg42=nwest(control.u,[ones(T,1) Vfac],0);
    check.V=[check.V reg42.rbar];

    for j=1:r;
    for i=1:3;
        reg51=nwest(control.A(:,j),[ones(T,1) outA.fhat(:,1:i)],0);
        check.A=[check.A reg51.rbar];
    end;
    for i=1:3;
        reg52=nwest(control.A(:,j),[ones(T,1) outF.fhat(:,1:i)],0);
        check.F=[check.F reg52.rbar];
    end;
    end;


    check.ic=[outF.ic2 outS.ic2 outH.ic2 outA.ic2 outV.ic2];
    check.ic0=[outF0.ic2 outS0.ic2 outH0.ic2];
    check.true=[mean(V.A)  mean(V.u) mean(V.G) mean(V.eps)]/mean(V.X);
    check.true=[check.true mean(check.control)];
    store.true=[store.true; check.true ];
    store.Ztilde=[store.Ztilde; mean(check.Ztilde)];
    store.ZF=[store.ZF; mean(check.ZF)];
    store.ZA=[store.ZA; mean(check.ZA)];
    store.ic=[store.ic; check.ic];
    store.ic0=[store.ic0; check.ic0];
    store.F=[store.F; check.F];
    store.A=[store.A; check.A];
    store.V=[store.V; check.V];
    store.Vfac=store.Vfac+Vfac;
if it==1;
disp('variance decomposition: theory');
mymprint(check.true,in);
disp('variance decomposition: data:F');
mymprint(mean(check.ZF),in)
disp('variance decomposition: data:A');
mymprint(mean(check.ZA),in);
disp('number of un-regularized factors');
mymprint(check.ic0,in);
disp('number of regularized factors');
mymprint(check.ic,in);
disp('check F');
mymprint(check.F,in);
disp('check A');
mymprint(check.A,in);
disp('check V');
mymprint(check.V,in);
figure(1);
plot(standard(control.u),'k','LineWidth',1.5);
%hold on;
%plot(standard(reg41.yhat),'r');
hold on;
plot(standard(Vfac),'b','LineWidth',1.0);
hold off;
end;
end; % end maxit;

if it>1;
disp('average over monte carlo');
disp('variance decomposition: theory');
mymprint(mean(store.true),in);
disp('variance decomposition: data:F');
mymprint(mean(store.ZF),in)
disp('variance decomposition: data:A');
mymprint(mean(store.ZA),in)
disp('number of un-regularized factors');
mymprint(mean(store.ic0),in);
disp('number of regularized factors');
mymprint(mean(store.ic),in);
disp('check F');
mymprint(check.F,in);
disp('check A');
mymprint(mean(store.A),in);
disp('check V');
mymprint(mean(store.V),in);
figure(2);
subplot(1,1,1);
plot(standard(control.u),'k','LineWidth',1.5);
%hold on;
%plot(standard(reg41.yhat),'r');
hold on;
plot(standard(store.Vfac/maxit),'b','LineWidth',1.0);
title(['True and Estimated V: correlation ' num2str(corr(control.u,store.Vfac/maxit))]);
hold off;
outfile='plots/mc_figure.pdf';
print(gcf,'-dpdf',outfile);
end;
