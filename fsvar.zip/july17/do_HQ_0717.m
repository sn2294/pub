clear;
%% data generated in generate_macrodata.m
%% estimate H
%% modification of lowrannk_fremdmd

user=2;
if user==1;
    load C:\Dropbox\fsvar\july17\mdata2015m12;
    addpath C:\Dropbox\fsvar\varjln;
    cd 'C:\Dropbox\fsvar\july17'
else;
    load ~/dropbox/prog/fsvar/july17/mdata2015m12;
    addpath ~/dropbox/prog/fsvar/varjln;
end;

varname='FRED-MD-HQ';
outfile1='july17_H.out';
outfile2='july17_V.out';
outfile3='july17_Fsxvu.out';
outfile4='july17_F0.out';
outfile5='july17_S.out';
outfile6='july17_XtildeR2.out';
kmax=8;
yt= macrodata;
[T,N]=size(yt);
reg0=ones(T,1);
do_ar=0;
if do_ar==1;
    yt0=yt;
    for i=1:cols(yt0);
        temp=nwest(yt0(2:end,i),[ones(T-1,1) yt0(1:end-1,i)],0);
        yt(2:end,i)=temp.resid;
    end;
end;

mnames_sq=mnames;
mnames2=[];
for i=1:length(mnames);
    mnames_sq{i+length(mnames)}=[mnames{i} '_sq'];
    mnames2{i}=[mnames{i} '_sq'];
end;

%% standardize data

xdata=trimr(yt,1,0);
xdata2=xdata.^2;
Xdata=[xdata xdata.^2];
xdata_std=standard(xdata);
xdata_std2=standard(xdata.^2);
Xdata_std=[xdata_std xdata_std2];
gama=[0.0; 0.05];
[T,N]=size(xdata);
storeR2=[];
for ishrink=1:2;
    disp('Now estimate F');
    lsout{ishrink}=baing17sq(xdata_std/sqrt(N*T),kmax,gama(ishrink));

    disp('Now estimate S');
    ssout{ishrink}=baing17sq(xdata_std2/sqrt(N*T),kmax,gama(ishrink));

    disp('Now estimate H');
    hsout{ishrink}=baing17sq(Xdata_std/sqrt(2*N*T),kmax,gama(ishrink));
    Onatski{ishrink}.F=onatski_restat(xdata_std,kmax);
    Onatski{ishrink}.S=onatski_restat(xdata_std2,kmax);
    Onatski{ishrink}.H=onatski_restat(Xdata_std,kmax);
    Onatski{ishrink}.staticF=onatski_statico(xdata_std,1,2);
    Onatski{ishrink}.staticS=onatski_statico(xdata_std2,1,2);
    Onatski{ishrink}.staticH=onatski_statico(Xdata_std,1,2);

%% project data to remove "quadratic" terms
%  generate Xtilde' and Xtilde2'

  Hmat=[];
  Xtilde1{ishrink}=zeros(T,N); % Xtilde
  Xtilde2{ishrink}=zeros(T,N); % Xtilde2

  Fhat=lsout{ishrink}.fhat(:,1:lsout{ishrink}.ic2);
  Hhat=hsout{ishrink}.fhat(:,1:hsout{ishrink}.ic2);
  Shat=ssout{ishrink}.fhat(:,1:ssout{ishrink}.ic2);

  Fmat=[];
  for i1=1:cols(Fhat)
      for i2=i1:cols(Fhat)
          Fmat=[Fmat Fhat(:,i1).*Fhat(:,i2)];
      end
  end

  Hmat=[];
  for i1=1:cols(Hhat)
      for i2=i1:cols(Hhat)
          Hmat=[Hmat Hhat(:,i1).*Hhat(:,i2)];
      end
  end
  Smat=[];
  for i1=1:cols(Shat)
      for i2=i1:cols(Shat)
          Smat=[Smat Shat(:,i1).*Shat(:,i2)];
      end
  end

  Hmat=[ones(T,1) Hmat]; Smat=[ones(T,1) Smat]; Fmat=[ones(T,1) Fmat];
  for i=1:cols(xdata);
    out1=nwest(xdata(:,i),Fmat,0);
    out2=nwest(xdata2(:,i),Fmat,0);
    Xtilde1{ishrink}(:,i)=out1.resid(1:T,1);
    Xtilde2{ishrink}(:,i)=out2.resid(1:T,1);
    storeR2{ishrink}(i,2)=out2.rsqr;
  end;
end;

%% Estimate skedastic factors
disp('Now estimate V');
for ishrink=1:2;
  X1tilde_std=standard(Xtilde1{ishrink});
  X2tilde_std=standard(Xtilde2{ishrink}) ;
  vout=baing17sq(X2tilde_std/sqrt(N*T),kmax,gama(ishrink));
  vsout{ishrink}.Fhat=vout.Fhat;         % Vhat
  vsout{ishrink}.fhat=vout.Fhat*sqrt(T); % Vhat
  vsout{ishrink}.Lamhat=vout.Lamhat;
  vsout{ishrink}.d=vout.d;
  vsout{ishrink}.ic2=vout.ic2;
  vsout{ishrink}.Vbar=mean(Xtilde2{ishrink}')';
  Onatski{ishrink}.V=onatski_restat(X2tilde_std,kmax);
  Onatski{ishrink}.staticV=onatski_statico(X2tilde_std,1,2);

end;

%% remove V from X1 tilde
nv=2; % number of factors in V
disp('Now estimate Fxvu');
for ishrink=1:2;
  Vhat=vsout{ishrink}.fhat;
  xmat1=Xtilde1{ishrink};
  reg=[ones(T,1) Vhat(:,1:nv)];
  xxmat1=xmat1;
  for i=1:N;
    outf=nwest(xmat1(:,i),reg,0);
    xxmat1(:,i)=outf.resid;
    storeR2{ishrink}(i,1)=outf.rsqr;
  end;
  xxmat1_std=standard(xxmat1);
  fxvuout=baing17sq(xxmat1_std/sqrt(N*T),kmax,gama(ishrink));
  fsxvuout{ishrink}.Fhat=fxvuout.Fhat;
  fsxvuout{ishrink}.fhat=fxvuout.Fhat*sqrt(T);
  fsxvuout{ishrink}.Lamhat=fxvuout.Lamhat;
  fsxvuout{ishrink}.d=fxvuout.d;
  fsxvuout{ishrink}.ic2=fxvuout.ic2;
  Xtilde11{ishrink}=xxmat1;
  Onatski{ishrink}.fsxvu=onatski_restat(xxmat1_std,kmax);
  Onatski{ishrink}.staticfsxvu=onatski_restat(xxmat1_std,kmax);
end;


%% correlations and cotnributions
mdates=mdates(2:end,1);
for i=1:2;
[R2.ls{i},mR2.ls{i}]=mrsq_baing17sq(xdata,lsout{i}.Fhat,lsout{i}.Lamhat,lsout{i}.ic2,lsout{i}.d,mnames,outfile4,i);
[R2.ss{i},mR2.ss{i}]=mrsq_baing17sq(xdata2,ssout{i}.Fhat,ssout{i}.Lamhat,ssout{i}.ic2,ssout{i}.d,mnames,outfile5,i);
[R2.vs{i},mR2.vs{i}]=mrsq_baing17sq(xdata,vsout{i}.Fhat,vsout{i}.Lamhat,vsout{i}.ic2,vsout{i}.d,mnames,outfile2,i);
[R2.hs{i},mR2.hs{i}]=mrsq_baing17sq(Xdata,hsout{i}.Fhat,hsout{i}.Lamhat,hsout{i}.ic2,hsout{i}.d,mnames_sq,outfile1,i);
[R2.fs{i},mR2.fs{i}]=mrsq_baing17sq(xdata,fsxvuout{i}.Fhat,fsxvuout{i}.Lamhat,fsxvuout{i}.ic2,fsxvuout{i}.d,mnames,outfile3,i);
end;
fp=fopen(outfile6,'w');
fmt=['%20s ', repmat('%6.3f ',1,8),'\n'];

for i=1:cols(xdata);
  outx11=nwest(xdata(:,i),[ones(T,1) Xtilde11{1}(:,i)],0); storeR2{1}(i,3)=outx11.rbar;
  outx12=nwest(xdata(:,i),[ones(T,1) Xtilde11{2}(:,i)],0); storeR2{2}(i,3)=outx12.rbar;
  outx21=nwest(xdata(:,i).^2,[ones(T,1) Xtilde2{1}(:,i)],0); storeR2{1}(i,4)=outx21.rbar;
  outx22=nwest(xdata(:,i).^2,[ones(T,1) Xtilde2{2}(:,i)],0); storeR2{2}(i,4)=outx22.rbar;
  fprintf(fp,fmt,mnames{i},storeR2{1}(i,:),storeR2{2}(i,:));
end;
fclose(fp);
save HQ_0717 lsout ssout hsout vsout  fsxvuout mdates mnames storeR2 Onatski;




