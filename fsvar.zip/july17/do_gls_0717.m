clear;
%% data generated in generate_macrodata.m
%% estimate H
%% modification of lowrannk_fremdmd

user=2;
if user==1;
load C:\Dropbox\fsvar\mykpsw\mdata2015m12;
addpath C:\Dropbox\fsvar\varjln;
else;
load ~/dropbox/prog/fsvar/mykpsw/mdata2015m12;
addpath ~/dropbox/prog/fsvar/varjln;

end;

varname='FRED-MD-HQ';
outfile1='gls_H.out';
outfile2='gls_V.out';
outfile3='gls_Fsxvu.out';
outfile4='gls_F0.out';
outfile5='gls_S.out';
kmax=8;
yt= macrodata;
[T,N]=size(yt);
reg0=ones(T,1);
do_ar=0;
if do_ar==1;
  yt0=yt;
for i=1:cols(yt0);
        temp=nwest(yt0(2:end,i),[ones(T-1,1) yt0(1:end-1,i)],0);
         yt(2:end,i)=temp.resid;
end;
end;

mnames_sq=mnames;
mnames2=[];
for i=1:length(mnames);
    mnames_sq{i+length(mnames)}=[mnames{i} '_sq'];
    mnames2{i}=[mnames{i} '_sq'];
end;

%% standardize data

zdata=trimr(yt,1,0);
zdata2=trimr(yt.^2,1,0);
zdata_std=standard(zdata);
zdata_std2=standard(zdata2);
Zdata=[zdata zdata2];

Zsout=baing17sq(zdata_std/sqrt(N*T),kmax,0);
resid=zdata_std*sqrt(N*T)-Zsout.fhat*Zsout.lambda'*sqrt(N*T);
Omega=diag(diag(cov(resid)));
Omega=diag(sqrt(inv(Omega)));
weights=Omega./sum(Omega);
xdata=zdata.*repmat(weights',rows(zdata),1);
xdata_std=zdata_std.*repmat(weights',rows(zdata),1);

Zsout2=baing17sq(zdata_std2/sqrt(N*T),kmax,0);
resid2=zdata_std2*sqrt(N*T)-Zsout2.fhat*Zsout2.lambda'*sqrt(N*T);
Omega2=diag(diag(cov(resid2)));
Omega2=diag(sqrt(inv(Omega2)));
weights2=Omega2./sum(Omega2);
xdata2=zdata2.*repmat(weights2',rows(zdata2),1);
xdata_std2=zdata_std2.*repmat(weights2',rows(zdata2),1);


%xdata2=xdata.^2;
%xdata_std2=standard(xdata.^2);
Xdata=[xdata xdata2];
Xdata_std=[xdata_std xdata_std2];
gama=[0.0; 0.05];


[T,N]=size(xdata);

for ishrink=1:1;
    disp('Now estimate F');
    lsout{ishrink}=baing17sq(xdata_std/sqrt(N*T),kmax,gama(ishrink));
    disp('Now estimate S');
    ssout{ishrink}=baing17sq(xdata_std2/sqrt(N*T),kmax,gama(ishrink));
    disp('Now estimate H');
    hsout{ishrink}=baing17sq(Xdata_std/sqrt(2*N*T),kmax,gama(ishrink));

%% project data to remove "quadratic" terms
%  generate Xtilde' and Xtilde2'

  Xtilde1{ishrink}=zeros(T,N); % Xtilde
  Xtilde2{ishrink}=zeros(T,N); % Xtilde2

    Fhat=lsout{ishrink}.fhat(:,1:lsout{ishrink}.ic2);
  Hhat=hsout{ishrink}.fhat(:,1:hsout{ishrink}.ic2);
  Shat=ssout{ishrink}.fhat(:,1:ssout{ishrink}.ic2);

  Fmat=[];
  for i1=1:cols(Fhat)
      for i2=i1:cols(Fhat)
          Fmat=[Fmat Fhat(:,i1).*Fhat(:,i2)];
      end
  end
  
  Hmat=[];
  for i1=1:cols(Hhat)
      for i2=i1:cols(Hhat)
          Hmat=[Hmat Hhat(:,i1).*Hhat(:,i2)];
      end
  end
  Smat=[];
  for i1=1:cols(Shat)
      for i2=i1:cols(Shat)
          Smat=[Smat Shat(:,i1).*Shat(:,i2)];
      end
  end

  Hmat=[ones(T,1) Hmat]; Smat=[ones(T,1) Smat]; Fmat=[ones(T,1) Fmat];
  for i=1:cols(xdata);
    out1=nwest(xdata(:,i),Fmat,0);
    out2=nwest(xdata2(:,i),Fmat,0);
    Xtilde1{ishrink}(:,i)=out1.resid(1:T,1);
    Xtilde2{ishrink}(:,i)=out2.resid(1:T,1);
    storeR2{ishrink}(i,:)=[out1.rsqr out2.rsqr];
  end;
end;

%% Estimate skedastic factors
disp('Now estimate V');
for ishrink=1:1;
  X1tilde_std=standard(Xtilde1{ishrink});
  X2tilde_std=standard(Xtilde2{ishrink}) ;
  vout=baing17sq(X2tilde_std/sqrt(N*T),kmax,gama(ishrink));
  vsout{ishrink}.Fhat=vout.Fhat; % Vhat
  vsout{ishrink}.fhat=vout.Fhat*sqrt(T); % Vhat
  vsout{ishrink}.Lamhat=vout.Lamhat;
  vsout{ishrink}.d=vout.d;
  vsout{ishrink}.ic2=vout.ic2;
  vsout{ishrink}.Vbar=mean(Xtilde2{ishrink}')';
end;

%% remove V from X1 tilde
nv=2; % number of factors in V
disp('Now estimate Fxvu');
for ishrink=1:1;
  Vhat=vsout{ishrink}.fhat;
  xmat1=Xtilde1{ishrink};
  reg=[ones(T,1) Vhat(:,1:nv)];
  xxmat1=xmat1;
  for i=1:N;
    outf=nwest(xmat1(:,i),reg,0);
    xxmat1(:,i)=outf.resid;
  end;
  xxmat1_std=standard(xxmat1);
  fxvuout=baing17sq(xxmat1_std/sqrt(N*T),kmax,gama(ishrink));
  fsxvuout{ishrink}.Fhat=fxvuout.Fhat;
  fsxvuout{ishrink}.fhat=fxvuout.Fhat*sqrt(T);
  fsxvuout{ishrink}.Lamhat=fxvuout.Lamhat;
  fsxvuout{ishrink}.d=fxvuout.d;
  fsxvuout{ishrink}.ic2=fxvuout.ic2;
end;


%% correlations and cotnributions
mdates=mdates(2:end,1);
for i=1:1;
[R2.ls{i},mR2.ls{i}]=mrsq_gls_july17(xdata_std/sqrt(N*T),lsout{i}.Fhat,lsout{i}.Lamhat,lsout{i}.ic2,lsout{i}.d,mnames,outfile4,i);
[R2.ss{i},mR2.ss{i}]=mrsq_gls_july17(xdata_std/sqrt(N*T),ssout{i}.Fhat,ssout{i}.Lamhat,ssout{i}.ic2,ssout{i}.d,mnames,outfile5,i);
[R2.vs{i},mR2.vs{i}]=mrsq_gls_july17(xdata_std/sqrt(N*T),vsout{i}.Fhat,vsout{i}.Lamhat,vsout{i}.ic2,vsout{i}.d,mnames,outfile2,i);
[R2.hs{i},mR2.hs{i}]=mrsq_gls_july17(Xdata_std/sqrt(N*T),hsout{i}.Fhat,hsout{i}.Lamhat,hsout{i}.ic2,hsout{i}.d,mnames_sq,outfile1,i);
[R2.fs{i},mR2.fs{i}]=mrsq_gls_july17(xdata_std/sqrt(N*T),fsxvuout{i}.Fhat,fsxvuout{i}.Lamhat,fsxvuout{i}.ic2,fsxvuout{i}.d,mnames,outfile3,i);
end;
save gls_HQ_0717 lsout ssout hsout vsout  fsxvuout mdates mnames;




