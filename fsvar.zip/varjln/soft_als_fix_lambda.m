function [fa,u1,d1]=soft_als_fix_lambda(xdata_std,nfac,v,d,par,lam_c);
[nt,ns]=size(xdata_std);
    Ir=eye(nfac.u);
    edata = xdata_std;
    shrink=lam_c.shrink;
    xxi=inv(diag(d).^2+shrink*Ir);

    if nfac.u > 0;
       if nfac.o > 0;
          edata = xdata_std - fa(:,1:nfac.o)*lambda(:,1:nfac.o)';
       end;
       %for t = 1:nt;
       %   tmp=packr([edata(t,:)' lambda(:,nfac.o+1:end)]);
       %   y=tmp(:,1);
       %   x=tmp(:,2:end);
       %   b=xxi*(x'*y);
       %   f(t,:) = b';
       %end; % end _t
       f=edata*v*diag(d)*xxi;
       [u1,d1,r1]=svd(f*diag(d));
       d1=sqrt(d1);
       fa=u1(:,1:nfac.u)*d1(1:nfac.u,1:nfac.u);
       d1=diag(d1);
       d1=d1(1:nfac.u);
       u1=u1(:,1:nfac.u);
       fa = f;
       if nfac.o > 0;
         fa = [wdata f];
       end;
    end;  % end nfac.u>0



