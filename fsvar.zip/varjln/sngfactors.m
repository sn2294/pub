function [Fhat0,Lambda0,Chat0,Ahat]=sngfactors(Amat,e,do_pcaT);

[T,N]=size(e);
[eu,eigval,ev1]=svd(Amat);
nfac=sum(diag(eigval) > 1e-3);
if do_pcaT==1;
Fhat0=sqrt(T)*eu(:,1:nfac);
Lambda0=e*Fhat0/T;
else;
    Lambda0=sqrt(N)*eu(:,1:nfac);
    Fhat0=e*Lambda0/N;
end;
Chat0=Fhat0*Lambda0';
if do_pcaT==1;
    Ahat=cov(Chat0');
else;
Ahat=cov(Chat0);
end;
