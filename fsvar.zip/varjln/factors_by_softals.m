function out4=factors_by_softals(X,nfac,par,lam_c,wdata);
xdata_std=standard(X);
[nt,ns]=size(X);




%% method 2, als equation by equation
it=0; maxit=100; ssr2=100; diff4=100; ssr4=100;
F4=factors_by_pca(xdata_std,nfac,wdata);   % Estimate factors using balanced panel
U4=F4(:,1:nfac.u);
D4=ones(nfac.u,1);   % initial matrix of eigenvalues
while diff4>tol & it <=maxit;          %%% alternating least squares
    ssr_old = ssr4;
    [Lam4,V4,D4]=soft_als_fix_f(xdata_std,nfac,U4,D4,par,lam_c);  % estimate lambda given f
    [F4,U4,D4]=soft_als_fix_lambda(xdata_std,nfac,V4,D4,par,lam_c);   % estimate % f given lambda
    e4= xdata_std-F4*Lam4';     % Compute residuals
    ssr4 = sum(nansum(e4.^2))/(nt*ns);
    diff4 = abs(ssr_old - ssr4);
    it=it+1;
%    if mod(it,100)==1;
%        disp(sprintf('Solving F4: %d %f', it, diff4));
%    end;
end;  % end while
%disp(sprintf('Solved F4: %d %f', it, diff4));
out4.L=Lam4;
out4.F=F4;
out4.it=it;
out4.ssr=ssr4;


