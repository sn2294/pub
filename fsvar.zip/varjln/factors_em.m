function [ehat,Fhat,lamhat,ve2,x2] = factors_em(x,kmax,jj,DEMEAN)
% =========================================================================
% DESCRIPTION
% This program estimates a set of factors for a given set of series. If
% there are missing values, this program will estimate them by taking into
% account other variables with observations during that specific date.
%
% -------------------------------------------------------------------------
% INPUT
%           x
%           kmax
%           jj
%           DEMEAN
%
% OUTPUT
%           ehat
%           Fhat
%           lamhat
%           ve2
%           x2
%
% -------------------------------------------------------------------------
% AUXILARY FUNCTIONS
%
%
% =========================================================================
% SETUP

% Maximum number of iterations
maxit=50;

% Number of time series
T=size(x,1);

% Number of observations
N=size(x,2);

% Allocate memory for array
x2=zeros(T,N);

% Locate missing values
x1=isnan(x);

% =========================================================================
% REPLACE MISSING VALUES WITH 0
% x2 is the initial dataset but with NaN replaced with 0
for i=1:T;
    for j=1:N;
        if x1(i,j)==1; 
            x2(i,j)=0;
        else x2(i,j)=x(i,j);
        end
    end;
end;

% =========================================================================

% Determine icstar

% Transform data (i.e. standardize it)
[x3,mut,sdt]=transform_data(x2,DEMEAN);


if kmax ~=99;
[ic1,lamhat,chat,Fhat]=baing(x3,kmax,jj,DEMEAN);
icstar    = ic1;
else;
    icstar=8;
    ic1=icstar;
end;
[chat,Fhat,lamhat,ve2]  = pc2(x3,icstar);
chat0=chat;
err=999;

it=0;
while err> 0.000001 & it <maxit;
it=it+1;
disp(sprintf('Iteration %d: obj %10f IC %d',it,err,icstar));

% Replace the obs that used to be NaN with chat
for t=1:T;
for j=1:N;
if x1(t,j)==1; x2(t,j)=chat(t,j)*sdt(j)+mut(t,j);    
   else x2(t,j)=x(t,j);end;
end;
end;

[x3,mut,sdt]=transform_data(x2,DEMEAN);
if kmax ~=99;
[ic1,lamhat,chat,Fhat]=baing(x3,kmax,jj,DEMEAN);
icstar    = ic1;
else;
    icstar=8;
    ic1=icstar;
end;
[chat,Fhat,lamhat,ve2]  = pc2(x3,icstar);
diff=chat-chat0;
v1=diff(:);
v2=chat0(:);
err=(v1'*v1)/(v2'*v2);
% Fix chat0
chat0=chat;
end;
% Compute ehat with chat from the last iter.
ehat = x-chat.*sdt+mut;


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% AUXILARY FUNCTIONS

function [ic1, chat,Fhat,eigval]=baing(X,kmax,jj,DEMEAN)
% =========================================================================
% DESCRIPTION
%
% -------------------------------------------------------------------------
% INPUT
%           X
%           kmax
%           jj
%           DEMEAN
%
% OUTPUT
%           ic1
%           chat
%           Fhat
%           eigval
%
% =========================================================================
% SETUP

% Number of observations per time series
T=size(X,1);

% Number of time series
N=size(X,2);

% Total number of observations
NT=N*T;

% Number of rows+columns
NT1=N+T;

% =========================================================================
% DETERMINE CT BY CASE

% Allocate memory
CT=zeros(1,kmax);

ii=1:1:kmax;

GCT=min([N;T]);

% -------------------------------------------------------------------------
% CT determined based on value of jj (integer from 1 to 8)

if jj ==1;CT(1,:)=log(NT/NT1)*ii*NT1/NT;end;

if jj==2; CT(1,:)=(NT1/NT)*log(min([N;T]))*ii;end;

if jj==3; CT(1,:)=ii*log(GCT)/GCT; end;

if jj==4; CT(1,:)=2*ii/T; end;

if jj==5; CT(1,:)=log(T)*ii/T;end;

if jj==6; CT(1,:)=2*ii*NT1/NT; end;

if jj==7; CT(1,:)=log(NT)*ii*NT1/NT;end;

if jj==8; CT(1,:)= 2*ii*(sqrt(N)+sqrt(T))^2/(NT); end;% new modified CP

% =========================================================================
IC1=zeros(size(CT,1),kmax+1);
Sigma=zeros(1,kmax+1);
if T< N;
[ev,eigval,ev1]=svd(X*X');
sumeigval=cumsum(diag(eigval))/sum(diag(eigval));
Fhat0=sqrt(T)*ev;
Lambda0=X'*Fhat0/T;
else;
[ev,eigval,ev1]=svd(X'*X);
sumeigval=cumsum(diag(eigval))/sum(diag(eigval));
Lambda0=sqrt(N)*ev;
Fhat0=X*Lambda0/N;
end;

if jj <= 8;
for i=kmax:-1:1;
Fhat=Fhat0(:,1:i);
%lambda=Fhat'*X;
lambda=Lambda0(:,1:i);
chat=Fhat*lambda';
%disp([i sumeigval(i) sum(sum(chat.*chat))/sum(sum(X.*X))]);
ehat=X-chat;
Sigma(i)=mean(sum(ehat.*ehat/T));
IC1(:,i)=log(Sigma(i))+CT(:,i);
end;
Sigma(kmax+1)=mean(sum(X.*X/T));
IC1(:,kmax+1)=log(Sigma(kmax+1));
ic1=minindc(IC1')';
ic1=ic1 .*(ic1 <= kmax);
end;
if jj==9;

  for j=1:rows(sumeigval);
    if sumeigval(j) >= .5; ic1=j; break; end;
  end;
 end;
Fhat=[];
Fhat=Fhat0(:,1:kmax);
Lambda=Lambda0(:,1:kmax);
chat=Fhat*Lambda';
eigval=diag(eigval);


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


function [chat,fhat,lambda,ss]=pc2(y,nfac);
% =========================================================================
% DESCRIPTION
%
% -------------------------------------------------------------------------
% INPUT
%
% OUTPUT
%
% =========================================================================
% FUNCTION
[bigt,bign]=size(y);
yy=y'*y;
[Fhat0,eigval,Fhat1]=svd(yy);
lambda=Fhat0(:,1:nfac)*sqrt(bign);
fhat=y*lambda/bign;
chat=fhat*lambda';
ss=diag(eigval);


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


function [ehat,fhat,lambda,ss]=pc1(y,nfac);

[bigt,bign]=size(y);
yy=y*y';
[Lhat0,eigval,Lhat1]=svd(yy);
fhat=Lhat0(:,1:nfac)*sqrt(bigt);
lambda=y'*fhat/bigt;
ehat=y-fhat*lambda';
ve2=sum(ehat'.*ehat')'/bign;
ss=diag(eigval);


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


function pos=minindc(x);
ncols=size(x,2);
nrows=size(x,1);
pos=zeros(ncols,1);
seq=seqa(1,1,nrows);
for i=1:ncols;
dum=min(x(:,i));
dum1= seq .* ( (x(:,i)-dum) ==0);
pos(i)=sum(dum1);
end;


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


function seq=seqa(a,b,c)
% =========================================================================
% DESCRIPTION
% This function creates a sequence as a column vector beginning at a, with
% interval size b, and number of elements c
%
% -------------------------------------------------------------------------
% INPUT
%           a   = starting point
%           b   = space between elements
%           c   = number of elements
%
% OUTPUT
%           seq = column vector containing the desired sequence
%
% =========================================================================
% FUNCTION
seq=(a:b:(a+b*(c-1)))';


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


function [x22,mut,sdt]=transform_data(x2,DEMEAN)
% =========================================================================
% DESCRIPTION
% This script transforms a given set of series based upon the input
% variable DEMEAN.
%
% -------------------------------------------------------------------------
% INPUT
%           x2      = set of series with missing values replaced as 0
%           DEMEAN  = switch variable determining type of transformation.
%                     It can take on the following values:
%                           0 (no transformation)
%                           1 (demean only)
%                           2 (demean and standardize)
%                           3 (recursively demean and then standardize) 
%
%
% OUTPUT
%           x22     = transformed dataset
%           mut     = matrix containing the value subtracted from each
%                     observation for each series
%           sdt     = matrix containing the value each observation of each
%                     series is divided by
%
% =========================================================================
% SETUP

% Number of rows
T=rows(x2);

% =========================================================================
% CASES

% Each series is recursively demeaned and then standardized
if DEMEAN==3; x22=x2;
    for t=2:T;
        mut(t,:)=mean(x2(1:t,:));
        x22(t,:)=x2(t,:)-mut(t,:);
    end;
sdt=std(x2);
x22=x22./repmat(sdt,T,1);    
end;            

% -------------------------------------------------------------------------
% Each series is demeaned and standardized 
if DEMEAN == 2;
    mut=repmat(mean(x2),T,1);
    sdt=repmat(std(x2),T,1);
    x22=(x2-mut)./sdt;
end

% -------------------------------------------------------------------------
% Each series is demeaned only
if DEMEAN == 1;
    mut=repmat(mean(x2),T,1);
    sdt=repmat(ones(1,N),T,1);
    x22=x2-mut;
end

% -------------------------------------------------------------------------
% No transformation
if DEMEAN == 0;
    mut=repmat(zeros(1,N),T,1);
    sdt=repmat(ones(1,N),T,1);
    x22=x2;
end

