function result=do_cvxsparse(Omega1,standardize,lam0);

n=rows(Omega1);
Omega0=Omega1;
if standardize==1;
sigma=sqrt(diag(Omega1));
omega1=sigma*sigma';
Omega0=Omega1./omega1;
end;

lambda=lam0/sqrt(n);
cvx_begin quiet
    variable L(n,n) semidefinite symmetric;
    variable Sparse(n,n) semidefinite;

    minimize norm_nuc(L) + lambda * sum(sum( abs(Sparse) ))

    subject to
        L + Sparse == Omega0;
cvx_end

[a,b,c]=svd(L);
if standardize==1;
	result.A=L.*omega1;
	result.E=Sparse.*omega1;
	result.s=diag(b);
else;
    result.A=L;
    result.E=Sparse;
    result.s=diag(b);
end;
