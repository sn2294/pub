reg=ones(T,1);
%disp('OLS');
for i=1:p;
    reg=[reg lagn(z,i)];
end;
for i=1:cols(z);
out{i}=nwest(z(p+1:end,i),reg(p+1:end,:),0);
%mymprint(([i out{i}.rsqr]));
end;



nstep=60;

steps=0:nstep-1;
c   = {'b','k','r',[0,0.5,0]};
dg  = [0.80,0.80,0.80];


% Estimate vector autoregression
[B,e,SIG] = var_only(z,p,1,1,1,tr);
P     = chol(SIG,'lower');
sigs  = diag(P);
Om    = diag(diag(P));
Ainv  = tril(P/Om);
eeold    = e*Ainv;
ee    = e*inv(Ainv');
params.Ainv = Ainv;
params.B    = B;
params.Om   = Om;
ci    = 0.6827;
for i=1:length(impulse);
shock = zeros(1,size(P,1));
shock(impulse(i))=sigs(impulse(i));
ir = var_ir_only(Ainv,B,shock,nstep,ci,tr);
IR{i}  = ir;
end;


pick=[1; 3; 6; 12; 24; 36; 48; 60];

vd = varp_vd_only(Ainv,B,Om,nstep,ci,1);
for j=1:length(impulse);
    VD{j}=[];
for i = 1:length(response);
        col      = squeeze(vd(response(i),j,:));
        VD{j}=[VD{j} col];
end
end
