function fa=als_fix_lambda(xdata_std,nfac,lambda,par,lam_c);
[nt,ns]=size(xdata_std);
Ir=eye(nfac.u);
shrink=lam_c.shrink;

    edata = xdata_std;
    if nfac.u > 0;
       if nfac.o > 0;
          edata = xdata_std - fa(:,1:nfac.o)*lambda(:,1:nfac.o)';
       end;
       for t = 1:nt;
          tmp=packr([edata(t,:)' lambda(:,nfac.o+1:end)]);
          y=tmp(:,1);
          x=tmp(:,2:end);
          xxi=inv(x'*x+shrink*Ir);
%          b = x\y;
          b=xxi*(x'*y);
          f(t,:) = b';
       end; % end _t
       fa = f;
       if nfac.o > 0;
         fa = [wdata f];
       end;
    end;  % end nfac.u>0

