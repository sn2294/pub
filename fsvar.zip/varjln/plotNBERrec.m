hold on
data_NBER_recessions;
area(NBER_recession(:,1),-(NBER_recession(:,2))*100,'FaceColor',[.8 .8 .8],'EdgeColor','none')
area(NBER_recession(:,1),(NBER_recession(:,2))*100,'FaceColor',[.8 .8 .8],'EdgeColor','none')
