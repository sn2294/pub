function lambda=als_fix_f(xdata_std,nfac,fa,est_par,lam_c);

[nt,ns]=size(xdata_std);
lambda = NaN*zeros(ns,nfac.t);
nt_min=est_par.nt_min;
Ir=eye(nfac.u);

shrink=lam_c.shrink;
    for i = 1:ns;
        tmp=packr([xdata_std(:,i) fa]);
        if size(tmp,1) >= nt_min;
           y=tmp(:,1);
           x=tmp(:,2:end);
           xxi = inv(x'*x+shrink*Ir);
           bols = xxi*(x'*y);
           b = bols;
           if lam_c.n_lc > 0;
             % Check for restrictions and impose;
             ii = lam_c.index == i;
             if sum(ii) > 0;
                 R = lam_c.R(ii==1,:);
                 r_scl = lam_c.r_scl(ii==1,:);
                 tmp1 = xxi*R';
                 tmp2 = inv(R*tmp1);
                 b = bols - tmp1*tmp2*(R*bols-r_scl);
             end;% end sum(ii)>0
           end;  % end n_lc>0
           lambda(i,:)= b';
        end; % end if size(tmp,1)>= nt_min
    end; % end i loop
