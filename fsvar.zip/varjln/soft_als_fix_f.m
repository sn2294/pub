function [lambda1,v1,d1]=soft_als_fix_f(xdata_std,nfac,u,d,est_par,lam_c);

[nt,ns]=size(xdata_std);
lambda = NaN*zeros(ns,nfac.t);
nt_min=est_par.nt_min;

fa=u*diag(d);
Ir=eye(nfac.u);
shrink=lam_c.shrink;
xxi = inv(diag(d).^2+shrink*Ir);
lambda=xdata_std'*u*diag(d)*xxi;
%    for i = 1:ns;
%        tmp=packr([xdata_std(:,i) fa]);
%        if size(tmp,1) >= nt_min;
%           y=tmp(:,1);
%           x=tmp(:,2:end);
%          bols = xxi*(x'*y);
%           b = bols;
%           lambda(i,:)= b';
%        end; % end if size(tmp,1)>= nt_min
%    end; % end i loop
[v1,d1,r1]=svd(lambda*diag(d));
d1=sqrt(d1);
lambda1=v1(:,1:nfac.u)*d1(1:nfac.u,1:nfac.u);
d1=diag(d1);
d1=d1(1:nfac.u);
v1=v1(:,1:nfac.u);

