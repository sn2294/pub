function h=do_cvxrectangle(X);

[m,n]=size(X);
g2_max = norm(X(:),inf);
g3_max = norm(X);
g2 = 0.15*g2_max;
g3 = 0.15*g3_max;
tic;
cvx_begin quiet
        cvx_precision low
        variables Vhat(m,n) Shat(m,n) Lhat(m,n)
        minimize(0.5*square_pos(norm(Vhat,'fro')) + g2*norm(Shat(:),1) + g3*norm_nuc(Lhat))
        subject to
            Vhat + Shat + Lhat == X;
cvx_end

h.cvx_toc = toc;
h.p = cvx_optval;
h.V = Vhat;
h.S = Shat;
h.L = Lhat;

Shat(abs(Shat) < 1e-4) = 0;
[u,s,v]=svd(Lhat);
h.rhat = sum(diag(s) > 1e-4);


