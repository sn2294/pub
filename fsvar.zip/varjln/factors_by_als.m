function out=factors_by_als(X,nfac,par,lam_c,wdata);
xdata_std=standard(X);
[nt,ns]=size(X);



Ir=eye(nfac.u);
it=0; maxit=500; ssr2=100; diff2=100; F2=forth;
while diff2>tol & it <=maxit;          %%% alternating least squares
    ssr_old = ssr2;
    Lam2=als_fix_f(xdata_std,nfac,F2,par,lam_c);  % estimate lambda given f
    F2=als_fix_lambda(xdata_std,nfac,Lam2,par,lam_c);   % estimate % f given lambda
    e2= xdata_std-F2*Lam2';     % Compute residuals
    ssr2 = sum(nansum(e2.^2))/(nt*ns);
    diff2 = abs(ssr_old - ssr2);
    it=it+1;
%    if mod(it,100)==1;
%        disp(sprintf('Solving F2: %d %f', it, diff2));
%    end;
end;  % end while
%disp(sprintf('Solved F2: %d %f', it, diff2));
out2.L=Lam2;
out2.F=F2;
out2.it=it;
out2.ssr=ssr2;

