function [R2,mR2] = lowrank_mrsq(Fhat,lamhat,csumev,colheaders,outfile,appendorwrite)
% -------------------------------------------------------------------------
% Compute R2 and marginal R2 from estimated factors and factor loadings
%   Input:  Fhat       = estimated factor matrix
%           lamhat     = factor loadings
%           ve2        = eigenvalues
%           colheaders = variable names
%           vartype    = variable type
%           outfile    = name of output file
%   Output: R2         = R2 for each series
%           mR2        = marginal R2 for each group
% -------------------------------------------------------------------------

% Compute values
[N ic]     = size(lamhat);
R2         = zeros(N,ic);
mR2        = zeros(N,ic);


for i = 1:ic
    R2(:,i)  = (var(Fhat(:,1:i)*lamhat(:,1:i)'))';
    mR2(:,i) = (var(Fhat(:,i:i)*lamhat(:,i:i)'))';
end

% Print to file
if appendorwrite==1;
fp          = fopen(outfile,'w');
else;
fp          = fopen(outfile,'a+');
end;
in.fid      = fp;
in.outwidth = N;
series      = [];

for i = 1:N
    series  = str2mat(series,colheaders{i});
end
series      = series(2:end,:);
fmt1        = ['\n                    ' repmat('%7d',1,ic)];
fmt         = ['\n' repmat('%4d',1,1)  ' %s' repmat('%7.3f',1,ic) ];
fprintf(fp,fmt1,(1:1:ic));
fprintf(fp,'\n R2\n');
for i = 1:N;
    fprintf(fp,fmt, i,series(i,:),R2(i,1:ic));
end;
fprintf(fp,'\n\n Marginal R2\n');

for i = 1:N;
    fprintf(fp,fmt,i,series(i,:),mR2(i,1:ic));
end;
[vals,ind] = sort(mR2,'descend');
Rsq        = csumev;
temp1=[];
temp2=[];
fprintf(fp,'\n\n Variation Explained %6.3f',sum(Rsq(1:ic)));
fprintf(fp,'\n\n By factors\n');
fprintf(fp,repmat('%6.3f & ',1,ic),cumsum(csumev'));
fprintf(fp,'\n\n Highest Marginal R2''s');
for ii = 1:ic;
    fprintf(fp,'\n\n Factor %d: total contribution = %0.4f \n',ii,Rsq(ii));
    temp1=[temp1; series(ind(1:10,ii),:)];
    temp2=[temp2; mR2(ind(1:10,ii),ii)];
    for j = 1:10;
        i = ind(j,ii);
        fprintf(fp,fmt,i,series(i,:),mR2(i,ii));
    end
end;
fprintf(fp,'\n\n');
fmt2=[ repmat('%10s& %4.3f & ',1,1) ];
k=[0 ;10 ;20 ;30];
    for j=1:10;
        for i=1:4;
            if k(i)+j<=rows(temp1);
    fprintf(fp,fmt2, temp1(k(i)+j,:),temp2(k(i)+j,:)');
end;
        end;
    fprintf(fp,'\\\\\n');
end;
k=[40; 50; 60; ];
if ic>7;
    k=[k; 70];
end;

fprintf(fp,' \n');
    for j=1:10;
        for i=1:ic-4;
    fprintf(fp,fmt2, temp1(k(i)+j,:),temp2(k(i)+j,:)');
        end;
    fprintf(fp,'\\\\\n');
end;
fprintf(fp,' \n');
fclose(fp);
end
