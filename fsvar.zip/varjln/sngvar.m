function [B,e,V] = sngvar(Y,p,tr)

[T,k]    = size(Y);                                 %data dimensions
if tr == 0; dt = ones(T,1); end;                    %constant only
if tr == 1; dt = [ones(T,1),(1:T)']; end;           %linear trend
if tr == 2; dt = [ones(T,1),(1:T)',(1:T)'.^2]; end; %quadratic trend
X        = [dt,mlag(Y,p)];                          %regressor matrix
X(1:p,:) = []; Y(1:p,:) = [];                       %truncate data
B        = X\Y;                                     %OLS estimate
e        = Y-X*B;                                   %OLS residuals
V        = e'*e./(T-k*p-1);                         %OLS cov matrix
I        = [eye(k*(p-1)),zeros(k*(p-1),k)];         %block diagonal
C        = [B(tr+2:end,:)';I];                      %companion matrix

end

function z = mlag(x,k,v)
% Create a matrix of n lags of a vector or matrix
%   Input:  x = matrix or vector, (nobs x k)
%           k = number of lags (default = 1)
%           v = (optional) initial values (default = 0)
%   Output: z = matrix (or vector) of lags (nobs x nvar*n)
if nargin ==1
k = 1;
v = 0;
elseif nargin == 2
v = 0;
end;
if nargin > 3
error('mlag: Wrong # of input arguments');
end;
[nobs, nvar] = size(x);
z = ones(nobs,nvar*k)*v;
for j = 1:k
    z(j+1:nobs,nvar*(j-1)+1:j*nvar) = x(1:nobs-j,:);
end
end
