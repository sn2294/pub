function [fa]=factors_by_pca(xdata_std,nfac,wdata);
[nt,ns]=size(xdata_std);

  if nfac.u > 0;
   xbal = packr(xdata_std')';
   [coef,score,latent]=princomp(xbal);
   f = score(:,1:nfac.u);
   fa = f;
   if nfac.o > 0;
      fa = [wdata f];
   end;
  else;
   fa = wdata;
  end;  % end nfac.u>0


la=xdata_std'*fa*inv(fa'*fa);
