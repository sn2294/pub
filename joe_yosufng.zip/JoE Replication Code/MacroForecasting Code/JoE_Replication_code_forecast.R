############################ forecast_horizon=12 ################################


##cluster functions
jobid = as.numeric(Sys.getenv("SLURM_ARRAY_TASK_ID"))

.libPaths('../rpackages')

#source('funs.r')
library(mboost)
library(glmnet)
set.seed(jobid)



## some helper functions

## creates lags of order K and pads the start of series with NAs
lagpad <- function(x, k) {
  c(rep(NA, k), x)[1 : length(x)] 
}


##kernel function

.kernel <- function(x, bw, tkernel = "Gaussian", N = 1)
{
  x <- x/(N * bw)
  value <- numeric(length(x))
  if (tkernel == "Gaussian")
  {
    value <- exp(-0.5 * x^2)/2.506628274631000241612355239340104162693023681640625 #sqrt(2*pi)
  }
  if(tkernel == "Epa")
  {
    index <- (x >= -1 & x <= 1)
    
    value[index] <- .75 * (1 - x[index]^2)
  }
  
  if(tkernel == "Unif")
  {
    index <- (x >= -1 & x <= 1)
    
    value[index] <- 1 
  }
  return(value)
  
}

## some constants to set

# size of the grid from which to select the bandwidth of the kernel
ngrid=29
## number of points in the cross validation set.
n_cv=60


## other constants 

forecast_horizon=12
## number of lags for each predictor
nlags=3

## calculate the length between the start of the training data and the test data.
train_start_date = strptime("1960-03-01", "%Y-%m-%d")
test_start_date = strptime("1971-10-01", "%Y-%m-%d")
len_diff = length(seq(from=train_start_date, to=test_start_date, by='month'))

# determines the end date of the training period of the first forecast
w1=len_diff - forecast_horizon
windows <- list()
for(i in 0:567) windows[[i+1]] <- seq(1,i+w1)

mms=c()


## load the response
response_data_all=read.csv("/rigel/home/ky2304/Data/IPl12.csv")
## load the covariates and the autoregressive term.
data2f=read.csv("/rigel/home/ky2304/Data/MacroFinal2.csv")
response_AR_all=read.csv("/rigel/home/ky2304/Data/IPl1.csv")



l=length(windows[[jobid]])
window1=l

## need to create this to get the length of the dataset for the covariates
## since we lose 3 points to creating lags. And we need to be 12 (forecast_horizon)
## points behind the response.

window2=window1-(forecast_horizon+nlags)

## need this to get the length of the response once we lose 3 points
## to creating lags.
window3=window1-nlags

## create our response.

response_data_all=response_data_all[,2]*(1200/forecast_horizon)

response=response_data_all[windows[[jobid]]]
Yfull=response[-c(1,2,3)]
Y=Yfull[c((1):(window2))]

## create our AR terms.
response_AR_all=1200*response_AR_all[,2]


## create lags of the AR term.
response_AR=response_AR_all[windows[[jobid]]]
response_ARlags=cbind(response_AR,lagpad(response_AR,1),lagpad(response_AR,2),lagpad(response_AR,3))
Xfull=response_ARlags[-c(1,2,3),]
X=as.matrix(Xfull[c((1):(window2)),])

## subset the correct window for the covariates
data2=data2f[windows[[jobid]],]

## create factors

factors_no_lags=prcomp(data2,center=TRUE,scale.=TRUE)$x[,c(1:8)]

factors_with_lags=data.frame(matrix(0,nrow=nrow(factors_no_lags),ncol=4*ncol(factors_no_lags)))


names3=c()
for(j in 1:ncol(factors_no_lags))
{

  factors_with_lags[,4*j-3]<-factors_no_lags[,j]
  factors_with_lags[,4*j-2]<-lagpad(factors_no_lags[,j],1)
  factors_with_lags[,4*j-1]<-lagpad(factors_no_lags[,j],2)
  factors_with_lags[,4*j]<-lagpad(factors_no_lags[,j],3)
  
}

factors_with_lags_full=factors_with_lags[-c(1:nlags),]
factors_with_lags_reduced=factors_with_lags[-c(1:nlags,(window1-forecast_horizon+1):window1),]


data4r=cbind(X,factors_with_lags_reduced)
data4full=cbind(Xfull,factors_with_lags_full)



#now lets create the same for the covariates without factors.

covs_with_lags = data.frame(matrix(0,nrow=nrow(data2),ncol=4*ncol(data2)))
names2=colnames(data2)

names3=c()
for(j in 1:ncol(data2))
{
  names3[4*j-3]=names2[j]
  names3[4*j-2]=paste(names2[j],"lag",1)
  names3[4*j-1]=paste(names2[j],"lag",2)
  names3[4*j]=paste(names2[j],"lag",3)
  
  covs_with_lags[,4*j-3]<-data2[,j]
  covs_with_lags[,4*j-2]<-lagpad(data2[,j],1)
  covs_with_lags[,4*j-1]<-lagpad(data2[,j],2)
  covs_with_lags[,4*j]<-lagpad(data2[,j],3)
  
}

covs_with_lags_full=covs_with_lags[-c(1:nlags),]
covs_with_lags_reduced=covs_with_lags[-c(1:nlags,(window1-forecast_horizon+1):window1),]

grid=seq(.3,1,length.out=ngrid)

## LC boost

mmsmat = matrix(0,(n_cv+1),ngrid)
for(i in jobid:(jobid+n_cv)){
  file=paste0('resultsTVP/LCh12CV_replication-',i,'.RData')
  load(file)
  mmsmat[(i-jobid+1),]=errorsFULL[[1]][[1]]^2
}
m=apply(mmsmat,2,mean,na.rm=TRUE)


bandopt=which.min(m)

grid2=(1:nrow(X))/nrow(X)
w=1-grid2

weights=.kernel(x = w, bw = grid[bandopt], tkernel = "Unif", N = 1)
index=(weights>0)

cm=apply(cbind(X,covs_with_lags_reduced),2,weighted.mean,w=weights)
m_boost=glmboost(x=scale(cbind(X,covs_with_lags_reduced),center=cm,scale=FALSE)[index,],y=Y[index],weights= weights[index],center=FALSE,control = boost_control(mstop = 100))
m_boost1=glmboost(x=scale(cbind(X,covs_with_lags_reduced),center=cm,scale=FALSE)[index,],y=Y[index],weights= weights[index],center=FALSE,control = boost_control(mstop = mstop(AIC(m_boost))))
pred_m=predict(m_boost1,newdata=scale(cbind(Xfull,covs_with_lags_full),center=cm,scale=FALSE))[window3]
mms[1]=pred_m-Yfull[window3]


## LC Factor Boost

mmsmat = matrix(0,(n_cv+1),ngrid)
for(i in jobid:(jobid+n_cv)){
  file=paste0('resultsTVP/LCh12CV_replication-',i,'.RData')
  load(file)
  mmsmat[(i-jobid+1),]=errorsFULL[[1]][[2]]^2
}
m=apply(mmsmat,2,mean,na.rm=TRUE)


bandopt=which.min(m)

grid2=(1:nrow(X))/nrow(X)
w=1-grid2

weights=.kernel(x = w, bw = grid[bandopt], tkernel = "Unif", N = 1)
index=(weights>0)
cm=apply(cbind(data4r),2,weighted.mean,w=weights)
m_boost=glmboost(x=scale(cbind(as.matrix(data4r)),center=cm,scale=FALSE)[index,],y=Y[index],weights= weights[index],center=FALSE,control = boost_control(mstop = 100))
m_boost1=glmboost(x=scale(cbind(as.matrix(data4r)),center=cm,scale=FALSE)[index,],y=Y[index],weights= weights[index],center=FALSE,control = boost_control(mstop = mstop(AIC(m_boost))))
pred_m=predict(m_boost1,newdata=scale(cbind(as.matrix(data4full)),center=cm,scale=FALSE))[window3]

mms[2]=pred_m-Yfull[window3]


## Factor model

four_factors_no_lags=factors_no_lags[,c(1:4)]
four_factors_no_lags_r=four_factors_no_lags[-c(1:nlags,(window1-forecast_horizon+1):window1),]
four_factors_no_lags_full=four_factors_no_lags[-c(1:nlags),]

autofactor= lm(Y~X+four_factors_no_lags_r)
pred=c(1,Xfull[window3,],four_factors_no_lags_full[window3,])%*%coef(autofactor)
mms[3]=pred-Yfull[window3]


## Rolling AR4

weights2=ifelse(((1:nrow(X))-nrow(X))>(-120+forecast_horizon),1,0)
index2=(weights2>0)
autor= lm(Y[index2]~X[index2,])
pred2r=c(1,Xfull[window3,])%*%coef(autor)
mms[4]=pred2r-Yfull[window3]


## Boost

weights=rep(1,nrow(X))
index=(weights>0)
cm=apply(cbind(X,covs_with_lags_reduced),2,weighted.mean,w=weights)
m_boost=glmboost(x=scale(cbind(X,covs_with_lags_reduced),center=cm,scale=FALSE)[index,],y=Y[index],weights= weights[index],center=FALSE,control = boost_control(mstop = 100))
m_boost1=glmboost(x=scale(cbind(X,covs_with_lags_reduced),center=cm,scale=FALSE)[index,],y=Y[index],weights= weights[index],center=FALSE,control = boost_control(mstop = mstop(AIC(m_boost))))
pred_m=predict(m_boost1,newdata=scale(cbind(Xfull,covs_with_lags_full),center=cm,scale=FALSE))[window3]
mms[5]=pred_m-Yfull[window3]


## Boost Factor

weights=rep(1,nrow(X))
index=(weights>0)
cm=apply(cbind(data4r),2,weighted.mean,w=weights)
m_boost=glmboost(x=scale(cbind(as.matrix(data4r)),center=cm,scale=FALSE)[index,],y=Y[index],weights= weights[index],center=FALSE,control = boost_control(mstop = 100))
m_boost1=glmboost(x=scale(cbind(as.matrix(data4r)),center=cm,scale=FALSE)[index,],y=Y[index],weights= weights[index],center=FALSE,control = boost_control(mstop = mstop(AIC(m_boost))))
pred_m=predict(m_boost1,newdata=scale(cbind(as.matrix(data4full)),center=cm,scale=FALSE))[window3]

mms[6]=pred_m-Yfull[window3]


## Lasso

model1=glmnet(as.matrix(cbind(X, covs_with_lags_reduced)),Y)
## use modified BIC to select lambda
f=(deviance(model1)/length(Y))/var(Y)
g=model1$df
BIC1=log(f)+g*(log(length(Y))/length(Y))*log(log(ncol(data4r)))
number=model1$lambda[which.min(BIC1)]
model1=glmnet(as.matrix(cbind(X, covs_with_lags_reduced)),Y,lambda=number)

pred_lasso=predict(model1,newx=as.matrix(cbind(Xfull,covs_with_lags_full)))[window3]
mms[7]=pred_lasso-Yfull[window3]


## AR 4

auto= lm(Y~X)
pred2=c(1,Xfull[window3,])%*%coef(auto)
mms[8]=pred2-Yfull[window3]



## Bandwidth values selected:

mms[9]=grid[bandopt]




mmstot=mms


############################ EMS #############################


mms=c()


nlags=3
w1=140-forecast_horizon
windows <- list()
for(i in 0:567) windows[[i+1]] <- seq(1,i+w1)

response_data_all=read.csv("/rigel/home/ky2304/Data/emsl12.csv")
data2f=read.csv("/rigel/home/ky2304/Data/MacroFinal2.csv")
response_AR_all=read.csv("/rigel/home/ky2304/Data/emsl1.csv")



l=length(windows[[jobid]])
window1=l

## need to create this to get the length of the dataset for the covariates
## since we lose 3 points to creating lags. And we need to be 12 (forecast_horizon)
## points behind the response.

window2=window1-(forecast_horizon+nlags)

## need this to get the length of the response once we lose 3 points
## to creating lags.
window3=window1-nlags

## create our response.

response_data_all=response_data_all[,2]*(1200/forecast_horizon)

response=response_data_all[windows[[jobid]]]
Yfull=response[-c(1,2,3)]
Y=Yfull[c((1):(window2))]

## create our AR terms.
response_AR_all=1200*response_AR_all[,2]


## create lags of the AR term.
response_AR=response_AR_all[windows[[jobid]]]
response_ARlags=cbind(response_AR,lagpad(response_AR,1),lagpad(response_AR,2),lagpad(response_AR,3))
Xfull=response_ARlags[-c(1,2,3),]
X=as.matrix(Xfull[c((1):(window2)),])

## subset the correct window for the covariates
data2=data2f[windows[[jobid]],]

## create factors

factors_no_lags=prcomp(data2,center=TRUE,scale.=TRUE)$x[,c(1:8)]

factors_with_lags=data.frame(matrix(0,nrow=nrow(factors_no_lags),ncol=4*ncol(factors_no_lags)))


names3=c()
for(j in 1:ncol(factors_no_lags))
{
  
  factors_with_lags[,4*j-3]<-factors_no_lags[,j]
  factors_with_lags[,4*j-2]<-lagpad(factors_no_lags[,j],1)
  factors_with_lags[,4*j-1]<-lagpad(factors_no_lags[,j],2)
  factors_with_lags[,4*j]<-lagpad(factors_no_lags[,j],3)
  
}

factors_with_lags_full=factors_with_lags[-c(1:nlags),]
factors_with_lags_reduced=factors_with_lags[-c(1:nlags,(window1-forecast_horizon+1):window1),]


data4r=cbind(X,factors_with_lags_reduced)
data4full=cbind(Xfull,factors_with_lags_full)



#now lets create the same for the covariates without factors.

covs_with_lags = data.frame(matrix(0,nrow=nrow(data2),ncol=4*ncol(data2)))
names2=colnames(data2)

names3=c()
for(j in 1:ncol(data2))
{
  names3[4*j-3]=names2[j]
  names3[4*j-2]=paste(names2[j],"lag",1)
  names3[4*j-1]=paste(names2[j],"lag",2)
  names3[4*j]=paste(names2[j],"lag",3)
  
  covs_with_lags[,4*j-3]<-data2[,j]
  covs_with_lags[,4*j-2]<-lagpad(data2[,j],1)
  covs_with_lags[,4*j-1]<-lagpad(data2[,j],2)
  covs_with_lags[,4*j]<-lagpad(data2[,j],3)
  
}

covs_with_lags_full=covs_with_lags[-c(1:nlags),]
covs_with_lags_reduced=covs_with_lags[-c(1:nlags,(window1-forecast_horizon+1):window1),]

grid=seq(.3,1,length.out=ngrid)

## LC boost

mmsmat = matrix(0,(n_cv+1),ngrid)
for(i in jobid:(jobid+n_cv)){
  file=paste0('resultsTVP/LCh12CV_replication-',i,'.RData')
  load(file)
  mmsmat[(i-jobid+1),]=errorsFULL[[2]][[1]]^2
}
m=apply(mmsmat,2,mean,na.rm=TRUE)


bandopt=which.min(m)

grid2=(1:nrow(X))/nrow(X)
w=1-grid2

weights=.kernel(x = w, bw = grid[bandopt], tkernel = "Unif", N = 1)
index=(weights>0)

cm=apply(cbind(X,covs_with_lags_reduced),2,weighted.mean,w=weights)
m_boost=glmboost(x=scale(cbind(X,covs_with_lags_reduced),center=cm,scale=FALSE)[index,],y=Y[index],weights= weights[index],center=FALSE,control = boost_control(mstop = 100))
m_boost1=glmboost(x=scale(cbind(X,covs_with_lags_reduced),center=cm,scale=FALSE)[index,],y=Y[index],weights= weights[index],center=FALSE,control = boost_control(mstop = mstop(AIC(m_boost))))
pred_m=predict(m_boost1,newdata=scale(cbind(Xfull,covs_with_lags_full),center=cm,scale=FALSE))[window3]
mms[1]=pred_m-Yfull[window3]


## LC Factor Boost

mmsmat = matrix(0,(n_cv+1),ngrid)
for(i in jobid:(jobid+n_cv)){
  file=paste0('resultsTVP/LCh12CV_replication-',i,'.RData')
  load(file)
  mmsmat[(i-jobid+1),]=errorsFULL[[2]][[2]]^2
}
m=apply(mmsmat,2,mean,na.rm=TRUE)


bandopt=which.min(m)

grid2=(1:nrow(X))/nrow(X)
w=1-grid2

weights=.kernel(x = w, bw = grid[bandopt], tkernel = "Unif", N = 1)
index=(weights>0)
cm=apply(cbind(data4r),2,weighted.mean,w=weights)
m_boost=glmboost(x=scale(cbind(as.matrix(data4r)),center=cm,scale=FALSE)[index,],y=Y[index],weights= weights[index],center=FALSE,control = boost_control(mstop = 100))
m_boost1=glmboost(x=scale(cbind(as.matrix(data4r)),center=cm,scale=FALSE)[index,],y=Y[index],weights= weights[index],center=FALSE,control = boost_control(mstop = mstop(AIC(m_boost))))
pred_m=predict(m_boost1,newdata=scale(cbind(as.matrix(data4full)),center=cm,scale=FALSE))[window3]

mms[2]=pred_m-Yfull[window3]


## Factor model

four_factors_no_lags=factors_no_lags[,c(1:4)]
four_factors_no_lags_r=four_factors_no_lags[-c(1:nlags,(window1-forecast_horizon+1):window1),]
four_factors_no_lags_full=four_factors_no_lags[-c(1:nlags),]

autofactor= lm(Y~X+four_factors_no_lags_r)
pred=c(1,Xfull[window3,],four_factors_no_lags_full[window3,])%*%coef(autofactor)
mms[3]=pred-Yfull[window3]


## Rolling AR4

weights2=ifelse(((1:nrow(X))-nrow(X))>(-120+forecast_horizon),1,0)
index2=(weights2>0)
autor= lm(Y[index2]~X[index2,])
pred2r=c(1,Xfull[window3,])%*%coef(autor)
mms[4]=pred2r-Yfull[window3]


## Boost

weights=rep(1,nrow(X))
index=(weights>0)
cm=apply(cbind(X,covs_with_lags_reduced),2,weighted.mean,w=weights)
m_boost=glmboost(x=scale(cbind(X,covs_with_lags_reduced),center=cm,scale=FALSE)[index,],y=Y[index],weights= weights[index],center=FALSE,control = boost_control(mstop = 100))
m_boost1=glmboost(x=scale(cbind(X,covs_with_lags_reduced),center=cm,scale=FALSE)[index,],y=Y[index],weights= weights[index],center=FALSE,control = boost_control(mstop = mstop(AIC(m_boost))))
pred_m=predict(m_boost1,newdata=scale(cbind(Xfull,covs_with_lags_full),center=cm,scale=FALSE))[window3]
mms[5]=pred_m-Yfull[window3]


## Boost Factor

weights=rep(1,nrow(X))
index=(weights>0)
cm=apply(cbind(data4r),2,weighted.mean,w=weights)
m_boost=glmboost(x=scale(cbind(as.matrix(data4r)),center=cm,scale=FALSE)[index,],y=Y[index],weights= weights[index],center=FALSE,control = boost_control(mstop = 100))
m_boost1=glmboost(x=scale(cbind(as.matrix(data4r)),center=cm,scale=FALSE)[index,],y=Y[index],weights= weights[index],center=FALSE,control = boost_control(mstop = mstop(AIC(m_boost))))
pred_m=predict(m_boost1,newdata=scale(cbind(as.matrix(data4full)),center=cm,scale=FALSE))[window3]

mms[6]=pred_m-Yfull[window3]


## Lasso

model1=glmnet(as.matrix(cbind(X, covs_with_lags_reduced)),Y)
## use modified BIC to select lambda
f=(deviance(model1)/length(Y))/var(Y)
g=model1$df
BIC1=log(f)+g*(log(length(Y))/length(Y))*log(log(ncol(data4r)))
number=model1$lambda[which.min(BIC1)]
model1=glmnet(as.matrix(cbind(X, covs_with_lags_reduced)),Y,lambda=number)

pred_lasso=predict(model1,newx=as.matrix(cbind(Xfull,covs_with_lags_full)))[window3]
mms[7]=pred_lasso-Yfull[window3]


## AR 4

auto= lm(Y~X)
pred2=c(1,Xfull[window3,])%*%coef(auto)
mms[8]=pred2-Yfull[window3]



## Bandwidth values selected:

mms[9]=grid[bandopt]

mmstotEMS=mms



############################ unrate #############################

mms=c()


nlags=3
w1=140-forecast_horizon
windows <- list()
for(i in 0:567) windows[[i+1]] <- seq(1,i+w1)

response_data_all=read.csv("/rigel/home/ky2304/Data/unratel12.csv")
data2f=read.csv("/rigel/home/ky2304/Data/MacroFinal2.csv")
response_AR_all=read.csv("/rigel/home/ky2304/Data/unratel1.csv")



l=length(windows[[jobid]])
window1=l

## need to create this to get the length of the dataset for the covariates
## since we lose 3 points to creating lags. And we need to be 12 (forecast_horizon)
## points behind the response.

window2=window1-(forecast_horizon+nlags)

## need this to get the length of the response once we lose 3 points
## to creating lags.
window3=window1-nlags

## create our response.

response_data_all=response_data_all[,2]*(1200/forecast_horizon)

response=response_data_all[windows[[jobid]]]
Yfull=response[-c(1,2,3)]
Y=Yfull[c((1):(window2))]

## create our AR terms.
response_AR_all=1200*response_AR_all[,2]


## create lags of the AR term.
response_AR=response_AR_all[windows[[jobid]]]
response_ARlags=cbind(response_AR,lagpad(response_AR,1),lagpad(response_AR,2),lagpad(response_AR,3))
Xfull=response_ARlags[-c(1,2,3),]
X=as.matrix(Xfull[c((1):(window2)),])

## subset the correct window for the covariates
data2=data2f[windows[[jobid]],]

## create factors

factors_no_lags=prcomp(data2,center=TRUE,scale.=TRUE)$x[,c(1:8)]

factors_with_lags=data.frame(matrix(0,nrow=nrow(factors_no_lags),ncol=4*ncol(factors_no_lags)))


names3=c()
for(j in 1:ncol(factors_no_lags))
{
  
  factors_with_lags[,4*j-3]<-factors_no_lags[,j]
  factors_with_lags[,4*j-2]<-lagpad(factors_no_lags[,j],1)
  factors_with_lags[,4*j-1]<-lagpad(factors_no_lags[,j],2)
  factors_with_lags[,4*j]<-lagpad(factors_no_lags[,j],3)
  
}

factors_with_lags_full=factors_with_lags[-c(1:nlags),]
factors_with_lags_reduced=factors_with_lags[-c(1:nlags,(window1-forecast_horizon+1):window1),]


data4r=cbind(X,factors_with_lags_reduced)
data4full=cbind(Xfull,factors_with_lags_full)



#now lets create the same for the covariates without factors.

covs_with_lags = data.frame(matrix(0,nrow=nrow(data2),ncol=4*ncol(data2)))
names2=colnames(data2)

names3=c()
for(j in 1:ncol(data2))
{
  names3[4*j-3]=names2[j]
  names3[4*j-2]=paste(names2[j],"lag",1)
  names3[4*j-1]=paste(names2[j],"lag",2)
  names3[4*j]=paste(names2[j],"lag",3)
  
  covs_with_lags[,4*j-3]<-data2[,j]
  covs_with_lags[,4*j-2]<-lagpad(data2[,j],1)
  covs_with_lags[,4*j-1]<-lagpad(data2[,j],2)
  covs_with_lags[,4*j]<-lagpad(data2[,j],3)
  
}

covs_with_lags_full=covs_with_lags[-c(1:nlags),]
covs_with_lags_reduced=covs_with_lags[-c(1:nlags,(window1-forecast_horizon+1):window1),]

grid=seq(.3,1,length.out=ngrid)

## LC boost

mmsmat = matrix(0,(n_cv+1),ngrid)
for(i in jobid:(jobid+n_cv)){
  file=paste0('resultsTVP/LCh12CV_replication-',i,'.RData')
  load(file)
  mmsmat[(i-jobid+1),]=errorsFULL[[3]][[1]]^2
}
m=apply(mmsmat,2,mean,na.rm=TRUE)


bandopt=which.min(m)

grid2=(1:nrow(X))/nrow(X)
w=1-grid2

weights=.kernel(x = w, bw = grid[bandopt], tkernel = "Unif", N = 1)
index=(weights>0)

cm=apply(cbind(X,covs_with_lags_reduced),2,weighted.mean,w=weights)
m_boost=glmboost(x=scale(cbind(X,covs_with_lags_reduced),center=cm,scale=FALSE)[index,],y=Y[index],weights= weights[index],center=FALSE,control = boost_control(mstop = 100))
m_boost1=glmboost(x=scale(cbind(X,covs_with_lags_reduced),center=cm,scale=FALSE)[index,],y=Y[index],weights= weights[index],center=FALSE,control = boost_control(mstop = mstop(AIC(m_boost))))
pred_m=predict(m_boost1,newdata=scale(cbind(Xfull,covs_with_lags_full),center=cm,scale=FALSE))[window3]
mms[1]=pred_m-Yfull[window3]


## LC Factor Boost

mmsmat = matrix(0,(n_cv+1),ngrid)
for(i in jobid:(jobid+n_cv)){
  file=paste0('resultsTVP/LCh12CV_replication-',i,'.RData')
  load(file)
  mmsmat[(i-jobid+1),]=errorsFULL[[3]][[2]]^2
}
m=apply(mmsmat,2,mean,na.rm=TRUE)


bandopt=which.min(m)

grid2=(1:nrow(X))/nrow(X)
w=1-grid2

weights=.kernel(x = w, bw = grid[bandopt], tkernel = "Unif", N = 1)
index=(weights>0)
cm=apply(cbind(data4r),2,weighted.mean,w=weights)
m_boost=glmboost(x=scale(cbind(as.matrix(data4r)),center=cm,scale=FALSE)[index,],y=Y[index],weights= weights[index],center=FALSE,control = boost_control(mstop = 100))
m_boost1=glmboost(x=scale(cbind(as.matrix(data4r)),center=cm,scale=FALSE)[index,],y=Y[index],weights= weights[index],center=FALSE,control = boost_control(mstop = mstop(AIC(m_boost))))
pred_m=predict(m_boost1,newdata=scale(cbind(as.matrix(data4full)),center=cm,scale=FALSE))[window3]

mms[2]=pred_m-Yfull[window3]


## Factor model

four_factors_no_lags=factors_no_lags[,c(1:4)]
four_factors_no_lags_r=four_factors_no_lags[-c(1:nlags,(window1-forecast_horizon+1):window1),]
four_factors_no_lags_full=four_factors_no_lags[-c(1:nlags),]

autofactor= lm(Y~X+four_factors_no_lags_r)
pred=c(1,Xfull[window3,],four_factors_no_lags_full[window3,])%*%coef(autofactor)
mms[3]=pred-Yfull[window3]


## Rolling AR4

weights2=ifelse(((1:nrow(X))-nrow(X))>(-120+forecast_horizon),1,0)
index2=(weights2>0)
autor= lm(Y[index2]~X[index2,])
pred2r=c(1,Xfull[window3,])%*%coef(autor)
mms[4]=pred2r-Yfull[window3]


## Boost

weights=rep(1,nrow(X))
index=(weights>0)
cm=apply(cbind(X,covs_with_lags_reduced),2,weighted.mean,w=weights)
m_boost=glmboost(x=scale(cbind(X,covs_with_lags_reduced),center=cm,scale=FALSE)[index,],y=Y[index],weights= weights[index],center=FALSE,control = boost_control(mstop = 100))
m_boost1=glmboost(x=scale(cbind(X,covs_with_lags_reduced),center=cm,scale=FALSE)[index,],y=Y[index],weights= weights[index],center=FALSE,control = boost_control(mstop = mstop(AIC(m_boost))))
pred_m=predict(m_boost1,newdata=scale(cbind(Xfull,covs_with_lags_full),center=cm,scale=FALSE))[window3]
mms[5]=pred_m-Yfull[window3]


## Boost Factor

weights=rep(1,nrow(X))
index=(weights>0)
cm=apply(cbind(data4r),2,weighted.mean,w=weights)
m_boost=glmboost(x=scale(cbind(as.matrix(data4r)),center=cm,scale=FALSE)[index,],y=Y[index],weights= weights[index],center=FALSE,control = boost_control(mstop = 100))
m_boost1=glmboost(x=scale(cbind(as.matrix(data4r)),center=cm,scale=FALSE)[index,],y=Y[index],weights= weights[index],center=FALSE,control = boost_control(mstop = mstop(AIC(m_boost))))
pred_m=predict(m_boost1,newdata=scale(cbind(as.matrix(data4full)),center=cm,scale=FALSE))[window3]

mms[6]=pred_m-Yfull[window3]


## Lasso

model1=glmnet(as.matrix(cbind(X, covs_with_lags_reduced)),Y)
## use modified BIC to select lambda
f=(deviance(model1)/length(Y))/var(Y)
g=model1$df
BIC1=log(f)+g*(log(length(Y))/length(Y))*log(log(ncol(data4r)))
number=model1$lambda[which.min(BIC1)]
model1=glmnet(as.matrix(cbind(X, covs_with_lags_reduced)),Y,lambda=number)

pred_lasso=predict(model1,newx=as.matrix(cbind(Xfull,covs_with_lags_full)))[window3]
mms[7]=pred_lasso-Yfull[window3]


## AR 4

auto= lm(Y~X)
pred2=c(1,Xfull[window3,])%*%coef(auto)
mms[8]=pred2-Yfull[window3]



## Bandwidth values selected:

mms[9]=grid[bandopt]

mmstotunrate=mms



############################ CivLabor #############################



mms=c()


nlags=3
w1=140-forecast_horizon
windows <- list()
for(i in 0:567) windows[[i+1]] <- seq(1,i+w1)

response_data_all=read.csv("/rigel/home/ky2304/Data/CivLaborl12.csv")
data2f=read.csv("/rigel/home/ky2304/Data/MacroFinal2.csv")
response_AR_all=read.csv("/rigel/home/ky2304/Data/CivLaborl1.csv")



l=length(windows[[jobid]])
window1=l

## need to create this to get the length of the dataset for the covariates
## since we lose 3 points to creating lags. And we need to be 12 (forecast_horizon)
## points behind the response.

window2=window1-(forecast_horizon+nlags)

## need this to get the length of the response once we lose 3 points
## to creating lags.
window3=window1-nlags

## create our response.

response_data_all=response_data_all[,2]*(1200/forecast_horizon)

response=response_data_all[windows[[jobid]]]
Yfull=response[-c(1,2,3)]
Y=Yfull[c((1):(window2))]

## create our AR terms.
response_AR_all=1200*response_AR_all[,2]


## create lags of the AR term.
response_AR=response_AR_all[windows[[jobid]]]
response_ARlags=cbind(response_AR,lagpad(response_AR,1),lagpad(response_AR,2),lagpad(response_AR,3))
Xfull=response_ARlags[-c(1,2,3),]
X=as.matrix(Xfull[c((1):(window2)),])

## subset the correct window for the covariates
data2=data2f[windows[[jobid]],]

## create factors

factors_no_lags=prcomp(data2,center=TRUE,scale.=TRUE)$x[,c(1:8)]

factors_with_lags=data.frame(matrix(0,nrow=nrow(factors_no_lags),ncol=4*ncol(factors_no_lags)))


names3=c()
for(j in 1:ncol(factors_no_lags))
{
  
  factors_with_lags[,4*j-3]<-factors_no_lags[,j]
  factors_with_lags[,4*j-2]<-lagpad(factors_no_lags[,j],1)
  factors_with_lags[,4*j-1]<-lagpad(factors_no_lags[,j],2)
  factors_with_lags[,4*j]<-lagpad(factors_no_lags[,j],3)
  
}

factors_with_lags_full=factors_with_lags[-c(1:nlags),]
factors_with_lags_reduced=factors_with_lags[-c(1:nlags,(window1-forecast_horizon+1):window1),]


data4r=cbind(X,factors_with_lags_reduced)
data4full=cbind(Xfull,factors_with_lags_full)



#now lets create the same for the covariates without factors.

covs_with_lags = data.frame(matrix(0,nrow=nrow(data2),ncol=4*ncol(data2)))
names2=colnames(data2)

names3=c()
for(j in 1:ncol(data2))
{
  names3[4*j-3]=names2[j]
  names3[4*j-2]=paste(names2[j],"lag",1)
  names3[4*j-1]=paste(names2[j],"lag",2)
  names3[4*j]=paste(names2[j],"lag",3)
  
  covs_with_lags[,4*j-3]<-data2[,j]
  covs_with_lags[,4*j-2]<-lagpad(data2[,j],1)
  covs_with_lags[,4*j-1]<-lagpad(data2[,j],2)
  covs_with_lags[,4*j]<-lagpad(data2[,j],3)
  
}

covs_with_lags_full=covs_with_lags[-c(1:nlags),]
covs_with_lags_reduced=covs_with_lags[-c(1:nlags,(window1-forecast_horizon+1):window1),]

grid=seq(.3,1,length.out=ngrid)

## LC boost

mmsmat = matrix(0,(n_cv+1),ngrid)
for(i in jobid:(jobid+n_cv)){
  file=paste0('resultsTVP/LCh12CV_replication-',i,'.RData')
  load(file)
  mmsmat[(i-jobid+1),]=errorsFULL[[4]][[1]]^2
}
m=apply(mmsmat,2,mean,na.rm=TRUE)


bandopt=which.min(m)

grid2=(1:nrow(X))/nrow(X)
w=1-grid2

weights=.kernel(x = w, bw = grid[bandopt], tkernel = "Unif", N = 1)
index=(weights>0)

cm=apply(cbind(X,covs_with_lags_reduced),2,weighted.mean,w=weights)
m_boost=glmboost(x=scale(cbind(X,covs_with_lags_reduced),center=cm,scale=FALSE)[index,],y=Y[index],weights= weights[index],center=FALSE,control = boost_control(mstop = 100))
m_boost1=glmboost(x=scale(cbind(X,covs_with_lags_reduced),center=cm,scale=FALSE)[index,],y=Y[index],weights= weights[index],center=FALSE,control = boost_control(mstop = mstop(AIC(m_boost))))
pred_m=predict(m_boost1,newdata=scale(cbind(Xfull,covs_with_lags_full),center=cm,scale=FALSE))[window3]
mms[1]=pred_m-Yfull[window3]


## LC Factor Boost

mmsmat = matrix(0,(n_cv+1),ngrid)
for(i in jobid:(jobid+n_cv)){
  file=paste0('resultsTVP/LCh12CV_replication-',i,'.RData')
  load(file)
  mmsmat[(i-jobid+1),]=errorsFULL[[4]][[2]]^2
}
m=apply(mmsmat,2,mean,na.rm=TRUE)


bandopt=which.min(m)

grid2=(1:nrow(X))/nrow(X)
w=1-grid2

weights=.kernel(x = w, bw = grid[bandopt], tkernel = "Unif", N = 1)
index=(weights>0)
cm=apply(cbind(data4r),2,weighted.mean,w=weights)
m_boost=glmboost(x=scale(cbind(as.matrix(data4r)),center=cm,scale=FALSE)[index,],y=Y[index],weights= weights[index],center=FALSE,control = boost_control(mstop = 100))
m_boost1=glmboost(x=scale(cbind(as.matrix(data4r)),center=cm,scale=FALSE)[index,],y=Y[index],weights= weights[index],center=FALSE,control = boost_control(mstop = mstop(AIC(m_boost))))
pred_m=predict(m_boost1,newdata=scale(cbind(as.matrix(data4full)),center=cm,scale=FALSE))[window3]

mms[2]=pred_m-Yfull[window3]


## Factor model

four_factors_no_lags=factors_no_lags[,c(1:4)]
four_factors_no_lags_r=four_factors_no_lags[-c(1:nlags,(window1-forecast_horizon+1):window1),]
four_factors_no_lags_full=four_factors_no_lags[-c(1:nlags),]

autofactor= lm(Y~X+four_factors_no_lags_r)
pred=c(1,Xfull[window3,],four_factors_no_lags_full[window3,])%*%coef(autofactor)
mms[3]=pred-Yfull[window3]


## Rolling AR4

weights2=ifelse(((1:nrow(X))-nrow(X))>(-120+forecast_horizon),1,0)
index2=(weights2>0)
autor= lm(Y[index2]~X[index2,])
pred2r=c(1,Xfull[window3,])%*%coef(autor)
mms[4]=pred2r-Yfull[window3]


## Boost

weights=rep(1,nrow(X))
index=(weights>0)
cm=apply(cbind(X,covs_with_lags_reduced),2,weighted.mean,w=weights)
m_boost=glmboost(x=scale(cbind(X,covs_with_lags_reduced),center=cm,scale=FALSE)[index,],y=Y[index],weights= weights[index],center=FALSE,control = boost_control(mstop = 100))
m_boost1=glmboost(x=scale(cbind(X,covs_with_lags_reduced),center=cm,scale=FALSE)[index,],y=Y[index],weights= weights[index],center=FALSE,control = boost_control(mstop = mstop(AIC(m_boost))))
pred_m=predict(m_boost1,newdata=scale(cbind(Xfull,covs_with_lags_full),center=cm,scale=FALSE))[window3]
mms[5]=pred_m-Yfull[window3]


## Boost Factor

weights=rep(1,nrow(X))
index=(weights>0)
cm=apply(cbind(data4r),2,weighted.mean,w=weights)
m_boost=glmboost(x=scale(cbind(as.matrix(data4r)),center=cm,scale=FALSE)[index,],y=Y[index],weights= weights[index],center=FALSE,control = boost_control(mstop = 100))
m_boost1=glmboost(x=scale(cbind(as.matrix(data4r)),center=cm,scale=FALSE)[index,],y=Y[index],weights= weights[index],center=FALSE,control = boost_control(mstop = mstop(AIC(m_boost))))
pred_m=predict(m_boost1,newdata=scale(cbind(as.matrix(data4full)),center=cm,scale=FALSE))[window3]

mms[6]=pred_m-Yfull[window3]


## Lasso

model1=glmnet(as.matrix(cbind(X, covs_with_lags_reduced)),Y)
## use modified BIC to select lambda
f=(deviance(model1)/length(Y))/var(Y)
g=model1$df
BIC1=log(f)+g*(log(length(Y))/length(Y))*log(log(ncol(data4r)))
number=model1$lambda[which.min(BIC1)]
model1=glmnet(as.matrix(cbind(X, covs_with_lags_reduced)),Y,lambda=number)

pred_lasso=predict(model1,newx=as.matrix(cbind(Xfull,covs_with_lags_full)))[window3]
mms[7]=pred_lasso-Yfull[window3]


## AR 4

auto= lm(Y~X)
pred2=c(1,Xfull[window3,])%*%coef(auto)
mms[8]=pred2-Yfull[window3]



## Bandwidth values selected:

mms[9]=grid[bandopt]



mmstotCivLabor=mms

############################ RPIless #############################

mms=c()



nlags=3
w1=140-forecast_horizon
windows <- list()
for(i in 0:567) windows[[i+1]] <- seq(1,i+w1)

response_data_all=read.csv("/rigel/home/ky2304/Data/RPIlessl12.csv")
data2f=read.csv("/rigel/home/ky2304/Data/MacroFinal2.csv")
response_AR_all=read.csv("/rigel/home/ky2304/Data/RPIlessl1.csv")



l=length(windows[[jobid]])
window1=l

## need to create this to get the length of the dataset for the covariates
## since we lose 3 points to creating lags. And we need to be 12 (forecast_horizon)
## points behind the response.

window2=window1-(forecast_horizon+nlags)

## need this to get the length of the response once we lose 3 points
## to creating lags.
window3=window1-nlags

## create our response.

response_data_all=response_data_all[,2]*(1200/forecast_horizon)

response=response_data_all[windows[[jobid]]]
Yfull=response[-c(1,2,3)]
Y=Yfull[c((1):(window2))]

## create our AR terms.
response_AR_all=1200*response_AR_all[,2]


## create lags of the AR term.
response_AR=response_AR_all[windows[[jobid]]]
response_ARlags=cbind(response_AR,lagpad(response_AR,1),lagpad(response_AR,2),lagpad(response_AR,3))
Xfull=response_ARlags[-c(1,2,3),]
X=as.matrix(Xfull[c((1):(window2)),])

## subset the correct window for the covariates
data2=data2f[windows[[jobid]],]

## create factors

factors_no_lags=prcomp(data2,center=TRUE,scale.=TRUE)$x[,c(1:8)]

factors_with_lags=data.frame(matrix(0,nrow=nrow(factors_no_lags),ncol=4*ncol(factors_no_lags)))


names3=c()
for(j in 1:ncol(factors_no_lags))
{
  
  factors_with_lags[,4*j-3]<-factors_no_lags[,j]
  factors_with_lags[,4*j-2]<-lagpad(factors_no_lags[,j],1)
  factors_with_lags[,4*j-1]<-lagpad(factors_no_lags[,j],2)
  factors_with_lags[,4*j]<-lagpad(factors_no_lags[,j],3)
  
}

factors_with_lags_full=factors_with_lags[-c(1:nlags),]
factors_with_lags_reduced=factors_with_lags[-c(1:nlags,(window1-forecast_horizon+1):window1),]


data4r=cbind(X,factors_with_lags_reduced)
data4full=cbind(Xfull,factors_with_lags_full)



#now lets create the same for the covariates without factors.

covs_with_lags = data.frame(matrix(0,nrow=nrow(data2),ncol=4*ncol(data2)))
names2=colnames(data2)

names3=c()
for(j in 1:ncol(data2))
{
  names3[4*j-3]=names2[j]
  names3[4*j-2]=paste(names2[j],"lag",1)
  names3[4*j-1]=paste(names2[j],"lag",2)
  names3[4*j]=paste(names2[j],"lag",3)
  
  covs_with_lags[,4*j-3]<-data2[,j]
  covs_with_lags[,4*j-2]<-lagpad(data2[,j],1)
  covs_with_lags[,4*j-1]<-lagpad(data2[,j],2)
  covs_with_lags[,4*j]<-lagpad(data2[,j],3)
  
}

covs_with_lags_full=covs_with_lags[-c(1:nlags),]
covs_with_lags_reduced=covs_with_lags[-c(1:nlags,(window1-forecast_horizon+1):window1),]

grid=seq(.3,1,length.out=ngrid)

## LC boost

mmsmat = matrix(0,(n_cv+1),ngrid)
for(i in jobid:(jobid+n_cv)){
  file=paste0('resultsTVP/LCh12CV_replication-',i,'.RData')
  load(file)
  mmsmat[(i-jobid+1),]=errorsFULL[[5]][[1]]^2
}
m=apply(mmsmat,2,mean,na.rm=TRUE)


bandopt=which.min(m)

grid2=(1:nrow(X))/nrow(X)
w=1-grid2

weights=.kernel(x = w, bw = grid[bandopt], tkernel = "Unif", N = 1)
index=(weights>0)

cm=apply(cbind(X,covs_with_lags_reduced),2,weighted.mean,w=weights)
m_boost=glmboost(x=scale(cbind(X,covs_with_lags_reduced),center=cm,scale=FALSE)[index,],y=Y[index],weights= weights[index],center=FALSE,control = boost_control(mstop = 100))
m_boost1=glmboost(x=scale(cbind(X,covs_with_lags_reduced),center=cm,scale=FALSE)[index,],y=Y[index],weights= weights[index],center=FALSE,control = boost_control(mstop = mstop(AIC(m_boost))))
pred_m=predict(m_boost1,newdata=scale(cbind(Xfull,covs_with_lags_full),center=cm,scale=FALSE))[window3]
mms[1]=pred_m-Yfull[window3]


## LC Factor Boost

mmsmat = matrix(0,(n_cv+1),ngrid)
for(i in jobid:(jobid+n_cv)){
  file=paste0('resultsTVP/LCh12CV_replication-',i,'.RData')
  load(file)
  mmsmat[(i-jobid+1),]=errorsFULL[[5]][[2]]^2
}
m=apply(mmsmat,2,mean,na.rm=TRUE)


bandopt=which.min(m)

grid2=(1:nrow(X))/nrow(X)
w=1-grid2

weights=.kernel(x = w, bw = grid[bandopt], tkernel = "Unif", N = 1)
index=(weights>0)
cm=apply(cbind(data4r),2,weighted.mean,w=weights)
m_boost=glmboost(x=scale(cbind(as.matrix(data4r)),center=cm,scale=FALSE)[index,],y=Y[index],weights= weights[index],center=FALSE,control = boost_control(mstop = 100))
m_boost1=glmboost(x=scale(cbind(as.matrix(data4r)),center=cm,scale=FALSE)[index,],y=Y[index],weights= weights[index],center=FALSE,control = boost_control(mstop = mstop(AIC(m_boost))))
pred_m=predict(m_boost1,newdata=scale(cbind(as.matrix(data4full)),center=cm,scale=FALSE))[window3]

mms[2]=pred_m-Yfull[window3]


## Factor model

four_factors_no_lags=factors_no_lags[,c(1:4)]
four_factors_no_lags_r=four_factors_no_lags[-c(1:nlags,(window1-forecast_horizon+1):window1),]
four_factors_no_lags_full=four_factors_no_lags[-c(1:nlags),]

autofactor= lm(Y~X+four_factors_no_lags_r)
pred=c(1,Xfull[window3,],four_factors_no_lags_full[window3,])%*%coef(autofactor)
mms[3]=pred-Yfull[window3]


## Rolling AR4

weights2=ifelse(((1:nrow(X))-nrow(X))>(-120+forecast_horizon),1,0)
index2=(weights2>0)
autor= lm(Y[index2]~X[index2,])
pred2r=c(1,Xfull[window3,])%*%coef(autor)
mms[4]=pred2r-Yfull[window3]


## Boost

weights=rep(1,nrow(X))
index=(weights>0)
cm=apply(cbind(X,covs_with_lags_reduced),2,weighted.mean,w=weights)
m_boost=glmboost(x=scale(cbind(X,covs_with_lags_reduced),center=cm,scale=FALSE)[index,],y=Y[index],weights= weights[index],center=FALSE,control = boost_control(mstop = 100))
m_boost1=glmboost(x=scale(cbind(X,covs_with_lags_reduced),center=cm,scale=FALSE)[index,],y=Y[index],weights= weights[index],center=FALSE,control = boost_control(mstop = mstop(AIC(m_boost))))
pred_m=predict(m_boost1,newdata=scale(cbind(Xfull,covs_with_lags_full),center=cm,scale=FALSE))[window3]
mms[5]=pred_m-Yfull[window3]


## Boost Factor

weights=rep(1,nrow(X))
index=(weights>0)
cm=apply(cbind(data4r),2,weighted.mean,w=weights)
m_boost=glmboost(x=scale(cbind(as.matrix(data4r)),center=cm,scale=FALSE)[index,],y=Y[index],weights= weights[index],center=FALSE,control = boost_control(mstop = 100))
m_boost1=glmboost(x=scale(cbind(as.matrix(data4r)),center=cm,scale=FALSE)[index,],y=Y[index],weights= weights[index],center=FALSE,control = boost_control(mstop = mstop(AIC(m_boost))))
pred_m=predict(m_boost1,newdata=scale(cbind(as.matrix(data4full)),center=cm,scale=FALSE))[window3]

mms[6]=pred_m-Yfull[window3]


## Lasso

model1=glmnet(as.matrix(cbind(X, covs_with_lags_reduced)),Y)
## use modified BIC to select lambda
f=(deviance(model1)/length(Y))/var(Y)
g=model1$df
BIC1=log(f)+g*(log(length(Y))/length(Y))*log(log(ncol(data4r)))
number=model1$lambda[which.min(BIC1)]
model1=glmnet(as.matrix(cbind(X, covs_with_lags_reduced)),Y,lambda=number)

pred_lasso=predict(model1,newx=as.matrix(cbind(Xfull,covs_with_lags_full)))[window3]
mms[7]=pred_lasso-Yfull[window3]


## AR 4

auto= lm(Y~X)
pred2=c(1,Xfull[window3,])%*%coef(auto)
mms[8]=pred2-Yfull[window3]



## Bandwidth values selected:

mms[9]=grid[bandopt]

mmstotRPIless=mms


################### CPI #########################################

mms=c()



nlags=3
w1=140-forecast_horizon
windows <- list()
for(i in 0:567) windows[[i+1]] <- seq(1,i+w1)

response_data_all=read.csv("/rigel/home/ky2304/Data/CPIl12.csv")
data2f=read.csv("/rigel/home/ky2304/Data/MacroFinal2.csv")
response_AR_all=read.csv("/rigel/home/ky2304/Data/CPIl1.csv")



l=length(windows[[jobid]])
window1=l

## need to create this to get the length of the dataset for the covariates
## since we lose 3 points to creating lags. And we need to be 12 (forecast_horizon)
## points behind the response.

window2=window1-(forecast_horizon+nlags)

## need this to get the length of the response once we lose 3 points
## to creating lags.
window3=window1-nlags

## create our response.

response_data_all=response_data_all[,2]*(1200/forecast_horizon)

response=response_data_all[windows[[jobid]]]
Yfull=response[-c(1,2,3)]
Y=Yfull[c((1):(window2))]

## create our AR terms.
response_AR_all=1200*response_AR_all[,2]


## create lags of the AR term.
response_AR=response_AR_all[windows[[jobid]]]
response_ARlags=cbind(response_AR,lagpad(response_AR,1),lagpad(response_AR,2),lagpad(response_AR,3))
Xfull=response_ARlags[-c(1,2,3),]
X=as.matrix(Xfull[c((1):(window2)),])

## subset the correct window for the covariates
data2=data2f[windows[[jobid]],]

## create factors

factors_no_lags=prcomp(data2,center=TRUE,scale.=TRUE)$x[,c(1:8)]

factors_with_lags=data.frame(matrix(0,nrow=nrow(factors_no_lags),ncol=4*ncol(factors_no_lags)))


names3=c()
for(j in 1:ncol(factors_no_lags))
{
  
  factors_with_lags[,4*j-3]<-factors_no_lags[,j]
  factors_with_lags[,4*j-2]<-lagpad(factors_no_lags[,j],1)
  factors_with_lags[,4*j-1]<-lagpad(factors_no_lags[,j],2)
  factors_with_lags[,4*j]<-lagpad(factors_no_lags[,j],3)
  
}

factors_with_lags_full=factors_with_lags[-c(1:nlags),]
factors_with_lags_reduced=factors_with_lags[-c(1:nlags,(window1-forecast_horizon+1):window1),]


data4r=cbind(X,factors_with_lags_reduced)
data4full=cbind(Xfull,factors_with_lags_full)



#now lets create the same for the covariates without factors.

covs_with_lags = data.frame(matrix(0,nrow=nrow(data2),ncol=4*ncol(data2)))
names2=colnames(data2)

names3=c()
for(j in 1:ncol(data2))
{
  names3[4*j-3]=names2[j]
  names3[4*j-2]=paste(names2[j],"lag",1)
  names3[4*j-1]=paste(names2[j],"lag",2)
  names3[4*j]=paste(names2[j],"lag",3)
  
  covs_with_lags[,4*j-3]<-data2[,j]
  covs_with_lags[,4*j-2]<-lagpad(data2[,j],1)
  covs_with_lags[,4*j-1]<-lagpad(data2[,j],2)
  covs_with_lags[,4*j]<-lagpad(data2[,j],3)
  
}

covs_with_lags_full=covs_with_lags[-c(1:nlags),]
covs_with_lags_reduced=covs_with_lags[-c(1:nlags,(window1-forecast_horizon+1):window1),]

grid=seq(.3,1,length.out=ngrid)

## LC boost

mmsmat = matrix(0,(n_cv+1),ngrid)
for(i in jobid:(jobid+n_cv)){
  file=paste0('resultsTVP/LCh12CV_replication-',i,'.RData')
  load(file)
  mmsmat[(i-jobid+1),]=errorsFULL[[6]][[1]]^2
}
m=apply(mmsmat,2,mean,na.rm=TRUE)


bandopt=which.min(m)

grid2=(1:nrow(X))/nrow(X)
w=1-grid2

weights=.kernel(x = w, bw = grid[bandopt], tkernel = "Unif", N = 1)
index=(weights>0)

cm=apply(cbind(X,covs_with_lags_reduced),2,weighted.mean,w=weights)
m_boost=glmboost(x=scale(cbind(X,covs_with_lags_reduced),center=cm,scale=FALSE)[index,],y=Y[index],weights= weights[index],center=FALSE,control = boost_control(mstop = 100))
m_boost1=glmboost(x=scale(cbind(X,covs_with_lags_reduced),center=cm,scale=FALSE)[index,],y=Y[index],weights= weights[index],center=FALSE,control = boost_control(mstop = mstop(AIC(m_boost))))
pred_m=predict(m_boost1,newdata=scale(cbind(Xfull,covs_with_lags_full),center=cm,scale=FALSE))[window3]
mms[1]=pred_m-Yfull[window3]


## LC Factor Boost

mmsmat = matrix(0,(n_cv+1),ngrid)
for(i in jobid:(jobid+n_cv)){
  file=paste0('resultsTVP/LCh12CV_replication-',i,'.RData')
  load(file)
  mmsmat[(i-jobid+1),]=errorsFULL[[6]][[2]]^2
}
m=apply(mmsmat,2,mean,na.rm=TRUE)


bandopt=which.min(m)

grid2=(1:nrow(X))/nrow(X)
w=1-grid2

weights=.kernel(x = w, bw = grid[bandopt], tkernel = "Unif", N = 1)
index=(weights>0)
cm=apply(cbind(data4r),2,weighted.mean,w=weights)
m_boost=glmboost(x=scale(cbind(as.matrix(data4r)),center=cm,scale=FALSE)[index,],y=Y[index],weights= weights[index],center=FALSE,control = boost_control(mstop = 100))
m_boost1=glmboost(x=scale(cbind(as.matrix(data4r)),center=cm,scale=FALSE)[index,],y=Y[index],weights= weights[index],center=FALSE,control = boost_control(mstop = mstop(AIC(m_boost))))
pred_m=predict(m_boost1,newdata=scale(cbind(as.matrix(data4full)),center=cm,scale=FALSE))[window3]

mms[2]=pred_m-Yfull[window3]


## Factor model

four_factors_no_lags=factors_no_lags[,c(1:4)]
four_factors_no_lags_r=four_factors_no_lags[-c(1:nlags,(window1-forecast_horizon+1):window1),]
four_factors_no_lags_full=four_factors_no_lags[-c(1:nlags),]

autofactor= lm(Y~X+four_factors_no_lags_r)
pred=c(1,Xfull[window3,],four_factors_no_lags_full[window3,])%*%coef(autofactor)
mms[3]=pred-Yfull[window3]


## Rolling AR4

weights2=ifelse(((1:nrow(X))-nrow(X))>(-120+forecast_horizon),1,0)
index2=(weights2>0)
autor= lm(Y[index2]~X[index2,])
pred2r=c(1,Xfull[window3,])%*%coef(autor)
mms[4]=pred2r-Yfull[window3]


## Boost

weights=rep(1,nrow(X))
index=(weights>0)
cm=apply(cbind(X,covs_with_lags_reduced),2,weighted.mean,w=weights)
m_boost=glmboost(x=scale(cbind(X,covs_with_lags_reduced),center=cm,scale=FALSE)[index,],y=Y[index],weights= weights[index],center=FALSE,control = boost_control(mstop = 100))
m_boost1=glmboost(x=scale(cbind(X,covs_with_lags_reduced),center=cm,scale=FALSE)[index,],y=Y[index],weights= weights[index],center=FALSE,control = boost_control(mstop = mstop(AIC(m_boost))))
pred_m=predict(m_boost1,newdata=scale(cbind(Xfull,covs_with_lags_full),center=cm,scale=FALSE))[window3]
mms[5]=pred_m-Yfull[window3]


## Boost Factor

weights=rep(1,nrow(X))
index=(weights>0)
cm=apply(cbind(data4r),2,weighted.mean,w=weights)
m_boost=glmboost(x=scale(cbind(as.matrix(data4r)),center=cm,scale=FALSE)[index,],y=Y[index],weights= weights[index],center=FALSE,control = boost_control(mstop = 100))
m_boost1=glmboost(x=scale(cbind(as.matrix(data4r)),center=cm,scale=FALSE)[index,],y=Y[index],weights= weights[index],center=FALSE,control = boost_control(mstop = mstop(AIC(m_boost))))
pred_m=predict(m_boost1,newdata=scale(cbind(as.matrix(data4full)),center=cm,scale=FALSE))[window3]

mms[6]=pred_m-Yfull[window3]


## Lasso

model1=glmnet(as.matrix(cbind(X, covs_with_lags_reduced)),Y)
## use modified BIC to select lambda
f=(deviance(model1)/length(Y))/var(Y)
g=model1$df
BIC1=log(f)+g*(log(length(Y))/length(Y))*log(log(ncol(data4r)))
number=model1$lambda[which.min(BIC1)]
model1=glmnet(as.matrix(cbind(X, covs_with_lags_reduced)),Y,lambda=number)

pred_lasso=predict(model1,newx=as.matrix(cbind(Xfull,covs_with_lags_full)))[window3]
mms[7]=pred_lasso-Yfull[window3]


## AR 4

auto= lm(Y~X)
pred2=c(1,Xfull[window3,])%*%coef(auto)
mms[8]=pred2-Yfull[window3]



## Bandwidth values selected:

mms[9]=grid[bandopt]

mmstotCPI=mms



############## Fed Funds ##################


mms=c()



nlags=3
w1=140-forecast_horizon
windows <- list()
for(i in 0:567) windows[[i+1]] <- seq(1,i+w1)

response_data_all=read.csv("/rigel/home/ky2304/Data/Fedfundsl12.csv")
data2f=read.csv("/rigel/home/ky2304/Data/MacroFinal2.csv")
response_AR_all=read.csv("/rigel/home/ky2304/Data/Fedfundsl1.csv")



l=length(windows[[jobid]])
window1=l

## need to create this to get the length of the dataset for the covariates
## since we lose 3 points to creating lags. And we need to be 12 (forecast_horizon)
## points behind the response.

window2=window1-(forecast_horizon+nlags)

## need this to get the length of the response once we lose 3 points
## to creating lags.
window3=window1-nlags

## create our response.

response_data_all=response_data_all[,2]*(1200/forecast_horizon)

response=response_data_all[windows[[jobid]]]
Yfull=response[-c(1,2,3)]
Y=Yfull[c((1):(window2))]

## create our AR terms.
response_AR_all=1200*response_AR_all[,2]


## create lags of the AR term.
response_AR=response_AR_all[windows[[jobid]]]
response_ARlags=cbind(response_AR,lagpad(response_AR,1),lagpad(response_AR,2),lagpad(response_AR,3))
Xfull=response_ARlags[-c(1,2,3),]
X=as.matrix(Xfull[c((1):(window2)),])

## subset the correct window for the covariates
data2=data2f[windows[[jobid]],]

## create factors

factors_no_lags=prcomp(data2,center=TRUE,scale.=TRUE)$x[,c(1:8)]

factors_with_lags=data.frame(matrix(0,nrow=nrow(factors_no_lags),ncol=4*ncol(factors_no_lags)))


names3=c()
for(j in 1:ncol(factors_no_lags))
{
  
  factors_with_lags[,4*j-3]<-factors_no_lags[,j]
  factors_with_lags[,4*j-2]<-lagpad(factors_no_lags[,j],1)
  factors_with_lags[,4*j-1]<-lagpad(factors_no_lags[,j],2)
  factors_with_lags[,4*j]<-lagpad(factors_no_lags[,j],3)
  
}

factors_with_lags_full=factors_with_lags[-c(1:nlags),]
factors_with_lags_reduced=factors_with_lags[-c(1:nlags,(window1-forecast_horizon+1):window1),]


data4r=cbind(X,factors_with_lags_reduced)
data4full=cbind(Xfull,factors_with_lags_full)



#now lets create the same for the covariates without factors.

covs_with_lags = data.frame(matrix(0,nrow=nrow(data2),ncol=4*ncol(data2)))
names2=colnames(data2)

names3=c()
for(j in 1:ncol(data2))
{
  names3[4*j-3]=names2[j]
  names3[4*j-2]=paste(names2[j],"lag",1)
  names3[4*j-1]=paste(names2[j],"lag",2)
  names3[4*j]=paste(names2[j],"lag",3)
  
  covs_with_lags[,4*j-3]<-data2[,j]
  covs_with_lags[,4*j-2]<-lagpad(data2[,j],1)
  covs_with_lags[,4*j-1]<-lagpad(data2[,j],2)
  covs_with_lags[,4*j]<-lagpad(data2[,j],3)
  
}

covs_with_lags_full=covs_with_lags[-c(1:nlags),]
covs_with_lags_reduced=covs_with_lags[-c(1:nlags,(window1-forecast_horizon+1):window1),]

grid=seq(.3,1,length.out=ngrid)

## LC boost

mmsmat = matrix(0,(n_cv+1),ngrid)
for(i in jobid:(jobid+n_cv)){
  file=paste0('resultsTVP/LCh12CV_replication-',i,'.RData')
  load(file)
  mmsmat[(i-jobid+1),]=errorsFULL[[7]][[1]]^2
}
m=apply(mmsmat,2,mean,na.rm=TRUE)


bandopt=which.min(m)

grid2=(1:nrow(X))/nrow(X)
w=1-grid2

weights=.kernel(x = w, bw = grid[bandopt], tkernel = "Unif", N = 1)
index=(weights>0)

cm=apply(cbind(X,covs_with_lags_reduced),2,weighted.mean,w=weights)
m_boost=glmboost(x=scale(cbind(X,covs_with_lags_reduced),center=cm,scale=FALSE)[index,],y=Y[index],weights= weights[index],center=FALSE,control = boost_control(mstop = 100))
m_boost1=glmboost(x=scale(cbind(X,covs_with_lags_reduced),center=cm,scale=FALSE)[index,],y=Y[index],weights= weights[index],center=FALSE,control = boost_control(mstop = mstop(AIC(m_boost))))
pred_m=predict(m_boost1,newdata=scale(cbind(Xfull,covs_with_lags_full),center=cm,scale=FALSE))[window3]
mms[1]=pred_m-Yfull[window3]


## LC Factor Boost

mmsmat = matrix(0,(n_cv+1),ngrid)
for(i in jobid:(jobid+n_cv)){
  file=paste0('resultsTVP/LCh12CV_replication-',i,'.RData')
  load(file)
  mmsmat[(i-jobid+1),]=errorsFULL[[7]][[2]]^2
}
m=apply(mmsmat,2,mean,na.rm=TRUE)


bandopt=which.min(m)

grid2=(1:nrow(X))/nrow(X)
w=1-grid2

weights=.kernel(x = w, bw = grid[bandopt], tkernel = "Unif", N = 1)
index=(weights>0)
cm=apply(cbind(data4r),2,weighted.mean,w=weights)
m_boost=glmboost(x=scale(cbind(as.matrix(data4r)),center=cm,scale=FALSE)[index,],y=Y[index],weights= weights[index],center=FALSE,control = boost_control(mstop = 100))
m_boost1=glmboost(x=scale(cbind(as.matrix(data4r)),center=cm,scale=FALSE)[index,],y=Y[index],weights= weights[index],center=FALSE,control = boost_control(mstop = mstop(AIC(m_boost))))
pred_m=predict(m_boost1,newdata=scale(cbind(as.matrix(data4full)),center=cm,scale=FALSE))[window3]

mms[2]=pred_m-Yfull[window3]


## Factor model

four_factors_no_lags=factors_no_lags[,c(1:4)]
four_factors_no_lags_r=four_factors_no_lags[-c(1:nlags,(window1-forecast_horizon+1):window1),]
four_factors_no_lags_full=four_factors_no_lags[-c(1:nlags),]

autofactor= lm(Y~X+four_factors_no_lags_r)
pred=c(1,Xfull[window3,],four_factors_no_lags_full[window3,])%*%coef(autofactor)
mms[3]=pred-Yfull[window3]


## Rolling AR4

weights2=ifelse(((1:nrow(X))-nrow(X))>(-120+forecast_horizon),1,0)
index2=(weights2>0)
autor= lm(Y[index2]~X[index2,])
pred2r=c(1,Xfull[window3,])%*%coef(autor)
mms[4]=pred2r-Yfull[window3]


## Boost

weights=rep(1,nrow(X))
index=(weights>0)
cm=apply(cbind(X,covs_with_lags_reduced),2,weighted.mean,w=weights)
m_boost=glmboost(x=scale(cbind(X,covs_with_lags_reduced),center=cm,scale=FALSE)[index,],y=Y[index],weights= weights[index],center=FALSE,control = boost_control(mstop = 100))
m_boost1=glmboost(x=scale(cbind(X,covs_with_lags_reduced),center=cm,scale=FALSE)[index,],y=Y[index],weights= weights[index],center=FALSE,control = boost_control(mstop = mstop(AIC(m_boost))))
pred_m=predict(m_boost1,newdata=scale(cbind(Xfull,covs_with_lags_full),center=cm,scale=FALSE))[window3]
mms[5]=pred_m-Yfull[window3]


## Boost Factor

weights=rep(1,nrow(X))
index=(weights>0)
cm=apply(cbind(data4r),2,weighted.mean,w=weights)
m_boost=glmboost(x=scale(cbind(as.matrix(data4r)),center=cm,scale=FALSE)[index,],y=Y[index],weights= weights[index],center=FALSE,control = boost_control(mstop = 100))
m_boost1=glmboost(x=scale(cbind(as.matrix(data4r)),center=cm,scale=FALSE)[index,],y=Y[index],weights= weights[index],center=FALSE,control = boost_control(mstop = mstop(AIC(m_boost))))
pred_m=predict(m_boost1,newdata=scale(cbind(as.matrix(data4full)),center=cm,scale=FALSE))[window3]

mms[6]=pred_m-Yfull[window3]


## Lasso

model1=glmnet(as.matrix(cbind(X, covs_with_lags_reduced)),Y)
## use modified BIC to select lambda
f=(deviance(model1)/length(Y))/var(Y)
g=model1$df
BIC1=log(f)+g*(log(length(Y))/length(Y))*log(log(ncol(data4r)))
number=model1$lambda[which.min(BIC1)]
model1=glmnet(as.matrix(cbind(X, covs_with_lags_reduced)),Y,lambda=number)

pred_lasso=predict(model1,newx=as.matrix(cbind(Xfull,covs_with_lags_full)))[window3]
mms[7]=pred_lasso-Yfull[window3]


## AR 4

auto= lm(Y~X)
pred2=c(1,Xfull[window3,])%*%coef(auto)
mms[8]=pred2-Yfull[window3]



## Bandwidth values selected:

mms[9]=grid[bandopt]


mmstotFF=mms


######### TB3MS ###################



mms=c()



nlags=3
w1=140-forecast_horizon
windows <- list()
for(i in 0:567) windows[[i+1]] <- seq(1,i+w1)

response_data_all=read.csv("/rigel/home/ky2304/Data/TB3MSl12.csv")
data2f=read.csv("/rigel/home/ky2304/Data/MacroFinal2.csv")
response_AR_all=read.csv("/rigel/home/ky2304/Data/TB3MSl1.csv")



l=length(windows[[jobid]])
window1=l

## need to create this to get the length of the dataset for the covariates
## since we lose 3 points to creating lags. And we need to be 12 (forecast_horizon)
## points behind the response.

window2=window1-(forecast_horizon+nlags)

## need this to get the length of the response once we lose 3 points
## to creating lags.
window3=window1-nlags

## create our response.

response_data_all=response_data_all[,2]*(1200/forecast_horizon)

response=response_data_all[windows[[jobid]]]
Yfull=response[-c(1,2,3)]
Y=Yfull[c((1):(window2))]

## create our AR terms.
response_AR_all=1200*response_AR_all[,2]


## create lags of the AR term.
response_AR=response_AR_all[windows[[jobid]]]
response_ARlags=cbind(response_AR,lagpad(response_AR,1),lagpad(response_AR,2),lagpad(response_AR,3))
Xfull=response_ARlags[-c(1,2,3),]
X=as.matrix(Xfull[c((1):(window2)),])

## subset the correct window for the covariates
data2=data2f[windows[[jobid]],]

## create factors

factors_no_lags=prcomp(data2,center=TRUE,scale.=TRUE)$x[,c(1:8)]

factors_with_lags=data.frame(matrix(0,nrow=nrow(factors_no_lags),ncol=4*ncol(factors_no_lags)))


names3=c()
for(j in 1:ncol(factors_no_lags))
{
  
  factors_with_lags[,4*j-3]<-factors_no_lags[,j]
  factors_with_lags[,4*j-2]<-lagpad(factors_no_lags[,j],1)
  factors_with_lags[,4*j-1]<-lagpad(factors_no_lags[,j],2)
  factors_with_lags[,4*j]<-lagpad(factors_no_lags[,j],3)
  
}

factors_with_lags_full=factors_with_lags[-c(1:nlags),]
factors_with_lags_reduced=factors_with_lags[-c(1:nlags,(window1-forecast_horizon+1):window1),]


data4r=cbind(X,factors_with_lags_reduced)
data4full=cbind(Xfull,factors_with_lags_full)



#now lets create the same for the covariates without factors.

covs_with_lags = data.frame(matrix(0,nrow=nrow(data2),ncol=4*ncol(data2)))
names2=colnames(data2)

names3=c()
for(j in 1:ncol(data2))
{
  names3[4*j-3]=names2[j]
  names3[4*j-2]=paste(names2[j],"lag",1)
  names3[4*j-1]=paste(names2[j],"lag",2)
  names3[4*j]=paste(names2[j],"lag",3)
  
  covs_with_lags[,4*j-3]<-data2[,j]
  covs_with_lags[,4*j-2]<-lagpad(data2[,j],1)
  covs_with_lags[,4*j-1]<-lagpad(data2[,j],2)
  covs_with_lags[,4*j]<-lagpad(data2[,j],3)
  
}

covs_with_lags_full=covs_with_lags[-c(1:nlags),]
covs_with_lags_reduced=covs_with_lags[-c(1:nlags,(window1-forecast_horizon+1):window1),]

grid=seq(.3,1,length.out=ngrid)

## LC boost

mmsmat = matrix(0,(n_cv+1),ngrid)
for(i in jobid:(jobid+n_cv)){
  file=paste0('resultsTVP/LCh12CV_replication-',i,'.RData')
  load(file)
  mmsmat[(i-jobid+1),]=errorsFULL[[8]][[1]]^2
}
m=apply(mmsmat,2,mean,na.rm=TRUE)


bandopt=which.min(m)

grid2=(1:nrow(X))/nrow(X)
w=1-grid2

weights=.kernel(x = w, bw = grid[bandopt], tkernel = "Unif", N = 1)
index=(weights>0)

cm=apply(cbind(X,covs_with_lags_reduced),2,weighted.mean,w=weights)
m_boost=glmboost(x=scale(cbind(X,covs_with_lags_reduced),center=cm,scale=FALSE)[index,],y=Y[index],weights= weights[index],center=FALSE,control = boost_control(mstop = 100))
m_boost1=glmboost(x=scale(cbind(X,covs_with_lags_reduced),center=cm,scale=FALSE)[index,],y=Y[index],weights= weights[index],center=FALSE,control = boost_control(mstop = mstop(AIC(m_boost))))
pred_m=predict(m_boost1,newdata=scale(cbind(Xfull,covs_with_lags_full),center=cm,scale=FALSE))[window3]
mms[1]=pred_m-Yfull[window3]


## LC Factor Boost

mmsmat = matrix(0,(n_cv+1),ngrid)
for(i in jobid:(jobid+n_cv)){
  file=paste0('resultsTVP/LCh12CV_replication-',i,'.RData')
  load(file)
  mmsmat[(i-jobid+1),]=errorsFULL[[8]][[2]]^2
}
m=apply(mmsmat,2,mean,na.rm=TRUE)


bandopt=which.min(m)

grid2=(1:nrow(X))/nrow(X)
w=1-grid2

weights=.kernel(x = w, bw = grid[bandopt], tkernel = "Unif", N = 1)
index=(weights>0)
cm=apply(cbind(data4r),2,weighted.mean,w=weights)
m_boost=glmboost(x=scale(cbind(as.matrix(data4r)),center=cm,scale=FALSE)[index,],y=Y[index],weights= weights[index],center=FALSE,control = boost_control(mstop = 100))
m_boost1=glmboost(x=scale(cbind(as.matrix(data4r)),center=cm,scale=FALSE)[index,],y=Y[index],weights= weights[index],center=FALSE,control = boost_control(mstop = mstop(AIC(m_boost))))
pred_m=predict(m_boost1,newdata=scale(cbind(as.matrix(data4full)),center=cm,scale=FALSE))[window3]

mms[2]=pred_m-Yfull[window3]


## Factor model

four_factors_no_lags=factors_no_lags[,c(1:4)]
four_factors_no_lags_r=four_factors_no_lags[-c(1:nlags,(window1-forecast_horizon+1):window1),]
four_factors_no_lags_full=four_factors_no_lags[-c(1:nlags),]

autofactor= lm(Y~X+four_factors_no_lags_r)
pred=c(1,Xfull[window3,],four_factors_no_lags_full[window3,])%*%coef(autofactor)
mms[3]=pred-Yfull[window3]


## Rolling AR4

weights2=ifelse(((1:nrow(X))-nrow(X))>(-120+forecast_horizon),1,0)
index2=(weights2>0)
autor= lm(Y[index2]~X[index2,])
pred2r=c(1,Xfull[window3,])%*%coef(autor)
mms[4]=pred2r-Yfull[window3]


## Boost

weights=rep(1,nrow(X))
index=(weights>0)
cm=apply(cbind(X,covs_with_lags_reduced),2,weighted.mean,w=weights)
m_boost=glmboost(x=scale(cbind(X,covs_with_lags_reduced),center=cm,scale=FALSE)[index,],y=Y[index],weights= weights[index],center=FALSE,control = boost_control(mstop = 100))
m_boost1=glmboost(x=scale(cbind(X,covs_with_lags_reduced),center=cm,scale=FALSE)[index,],y=Y[index],weights= weights[index],center=FALSE,control = boost_control(mstop = mstop(AIC(m_boost))))
pred_m=predict(m_boost1,newdata=scale(cbind(Xfull,covs_with_lags_full),center=cm,scale=FALSE))[window3]
mms[5]=pred_m-Yfull[window3]


## Boost Factor

weights=rep(1,nrow(X))
index=(weights>0)
cm=apply(cbind(data4r),2,weighted.mean,w=weights)
m_boost=glmboost(x=scale(cbind(as.matrix(data4r)),center=cm,scale=FALSE)[index,],y=Y[index],weights= weights[index],center=FALSE,control = boost_control(mstop = 100))
m_boost1=glmboost(x=scale(cbind(as.matrix(data4r)),center=cm,scale=FALSE)[index,],y=Y[index],weights= weights[index],center=FALSE,control = boost_control(mstop = mstop(AIC(m_boost))))
pred_m=predict(m_boost1,newdata=scale(cbind(as.matrix(data4full)),center=cm,scale=FALSE))[window3]

mms[6]=pred_m-Yfull[window3]


## Lasso

model1=glmnet(as.matrix(cbind(X, covs_with_lags_reduced)),Y)
## use modified BIC to select lambda
f=(deviance(model1)/length(Y))/var(Y)
g=model1$df
BIC1=log(f)+g*(log(length(Y))/length(Y))*log(log(ncol(data4r)))
number=model1$lambda[which.min(BIC1)]
model1=glmnet(as.matrix(cbind(X, covs_with_lags_reduced)),Y,lambda=number)

pred_lasso=predict(model1,newx=as.matrix(cbind(Xfull,covs_with_lags_full)))[window3]
mms[7]=pred_lasso-Yfull[window3]


## AR 4

auto= lm(Y~X)
pred2=c(1,Xfull[window3,])%*%coef(auto)
mms[8]=pred2-Yfull[window3]



## Bandwidth values selected:

mms[9]=grid[bandopt]


mmstotTB3MS=mms


mmsFULL=list(mmstot,mmstotEMS,mmstotunrate,mmstotCivLabor,mmstotRPIless,mmstotCPI,mmstotFF,mmstotTB3MS)

#save(mmsFULL,file=paste0('resultsTVP/LChK1-',randSeed,'.RData'))

save(mmsFULL,file=paste0('resultsTVP/LC12_replication-',jobid,'.RData'))
