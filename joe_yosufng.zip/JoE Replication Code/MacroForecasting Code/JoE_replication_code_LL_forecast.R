############################ forecast_horizon=12 ################################


##cluster functions
jobid = as.numeric(Sys.getenv("SLURM_ARRAY_TASK_ID"))

.libPaths('../rpackages')

#source('funs.r')
library(mboost)
library(glmnet)
set.seed(jobid)



## some helper functions

## creates lags of order K and pads start with NAs.
lagpad <- function(x, k) {
  c(rep(NA, k), x)[1 : length(x)] 
}


##kernel function

.kernel <- function(x, bw, tkernel = "Gaussian", N = 1)
{
  x <- x/(N * bw)
  value <- numeric(length(x))
  if (tkernel == "Gaussian")
  {
    value <- exp(-0.5 * x^2)/2.506628274631000241612355239340104162693023681640625 #sqrt(2*pi)
  }
  if(tkernel == "Epa")
  {
    index <- (x >= -1 & x <= 1)
    
    value[index] <- .75 * (1 - x[index]^2)
  }
  
  if(tkernel == "Unif")
  {
    index <- (x >= -1 & x <= 1)
    
    value[index] <- 1 
  }
  return(value)
  
}

## some constants to set

# size of the grid from which to select the bandwidth of the kernel
ngrid=29
## number of points in the cross validation set.
n_cv=60


## other constants 

forecast_horizon=12
## number of lags for each predictor
nlags=3

## calculate the length between the start of the training data and the test data.
train_start_date = strptime("1960-03-01", "%Y-%m-%d")
test_start_date = strptime("1971-10-01", "%Y-%m-%d")
len_diff = length(seq(from=train_start_date, to=test_start_date, by='month'))


# determines the end date of the training period of the first forecast
w1=len_diff-forecast_horizon
windows <- list()
for(i in 0:567) windows[[i+1]] <- seq(1,i+w1)

mms=c()


## load the response
response_data_all=read.csv("/rigel/home/ky2304/Data/IPl12.csv")
## load the covariates and the autoregressive term.
data2f=read.csv("/rigel/home/ky2304/Data/MacroFinal2.csv")
response_AR_all=read.csv("/rigel/home/ky2304/Data/IPl1.csv")



l=length(windows[[jobid]])
window1=l

## need to create this to get the length of the dataset for the covariates
## since we lose 3 points to creating lags. And we need to be 12 (forecast_horizon)
## points behind the response.

window2=window1-(forecast_horizon+nlags)

## need this to get the length of the response once we lose 3 points
## to creating lags.
window3=window1-nlags

## create our response.

response_data_all=response_data_all[,2]*(1200/forecast_horizon)

response=response_data_all[windows[[jobid]]]
Yfull=response[-c(1,2,3)]
Y=Yfull[c((1):(window2))]

## create our AR terms.
response_AR_all=1200*response_AR_all[,2]


## create lags of the AR term.
response_AR=response_AR_all[windows[[jobid]]]
response_ARlags=cbind(response_AR,lagpad(response_AR,1),lagpad(response_AR,2),lagpad(response_AR,3))
Xfull=response_ARlags[-c(1,2,3),]
X=as.matrix(Xfull[c((1):(window2)),])

## subset the correct window for the covariates. Remove Oilprices as 
## the start of the series has all zeroes which was causing issues.
data2=data2f[windows[[jobid]],][,-101]

## create factors

factors_no_lags=prcomp(data2,center=TRUE,scale.=TRUE)$x[,c(1:8)]

factors_with_lags=data.frame(matrix(0,nrow=nrow(factors_no_lags),ncol=4*ncol(factors_no_lags)))


names3=c()
for(j in 1:ncol(factors_no_lags))
{
  
  factors_with_lags[,4*j-3]<-factors_no_lags[,j]
  factors_with_lags[,4*j-2]<-lagpad(factors_no_lags[,j],1)
  factors_with_lags[,4*j-1]<-lagpad(factors_no_lags[,j],2)
  factors_with_lags[,4*j]<-lagpad(factors_no_lags[,j],3)
  
}

factors_with_lags_full=factors_with_lags[-c(1:nlags),]
factors_with_lags_reduced=factors_with_lags[-c(1:nlags,(window1-forecast_horizon+1):window1),]


data4r=cbind(X,factors_with_lags_reduced)
data4full=cbind(Xfull,factors_with_lags_full)


## LC Factor Boost
grid=seq(.2,1,length.out=ngrid)
mmsmat = matrix(0,(n_cv+1),ngrid)
for(i in jobid:(jobid+n_cv)){
  file=paste0('resultsTVP/LLh12CV_replication-',i,'.RData')
  load(file)
  mmsmat[(i-jobid+1),]=errorsFULL[[1]][[1]]^2
}
m=apply(mmsmat,2,mean,na.rm=TRUE)


bandopt=which.min(m)

Z2=data4full
grid2=(1:nrow(Z2))/nrow(Z2)
Z3=cbind(Z2,Z2*(grid2-1))
Z3=data.frame(Z3)
colnames(Z3)<-paste0("Z",1:ncol(Z3))

Z4=Z3[1:(nrow(Z2)-forecast_horizon),]
a=paste0("Y~",paste0(apply(matrix(1:ncol(Z4), ncol = 2, byrow = FALSE), 1, function(vec) paste0("bols(Z",vec[1],",Z",vec[2], ")")),collapse = " + "))
w=1-(1:nrow(Z4))/nrow(Z4)
weights=.kernel(x = w, bw = grid[bandopt], tkernel = "Gaussian", N = 1)
index=(weights>0)

boost_m3=gamboost(as.formula(a),weights= weights,data=Z4,control = boost_control(mstop = 100,nu=.1))


pred1=predict(boost_m3,newdata=Z3[(nrow(Z2)),])

mms[1]=pred1-Yfull[window3]


## AR 4

auto= lm(Y~X)
pred2=c(1,Xfull[window3,])%*%coef(auto)
mms[2]=pred2-Yfull[window3]


## Bandwidth values selected:

mms[3]=grid[bandopt]


mmstot=mms


############################ EMS #############################


mms=c()


nlags=3
w1=140-forecast_horizon
windows <- list()
for(i in 0:567) windows[[i+1]] <- seq(1,i+w1)

response_data_all=read.csv("/rigel/home/ky2304/Data/emsl12.csv")
data2f=read.csv("/rigel/home/ky2304/Data/MacroFinal2.csv")
response_AR_all=read.csv("/rigel/home/ky2304/Data/emsl1.csv")



l=length(windows[[jobid]])
window1=l

## need to create this to get the length of the dataset for the covariates
## since we lose 3 points to creating lags. And we need to be 12 (forecast_horizon)
## points behind the response.

window2=window1-(forecast_horizon+nlags)

## need this to get the length of the response once we lose 3 points
## to creating lags.
window3=window1-nlags

## create our response.

response_data_all=response_data_all[,2]*(1200/forecast_horizon)

response=response_data_all[windows[[jobid]]]
Yfull=response[-c(1,2,3)]
Y=Yfull[c((1):(window2))]

## create our AR terms.
response_AR_all=1200*response_AR_all[,2]


## create lags of the AR term.
response_AR=response_AR_all[windows[[jobid]]]
response_ARlags=cbind(response_AR,lagpad(response_AR,1),lagpad(response_AR,2),lagpad(response_AR,3))
Xfull=response_ARlags[-c(1,2,3),]
X=as.matrix(Xfull[c((1):(window2)),])

## subset the correct window for the covariates
data2=data2f[windows[[jobid]],][,-101]

## create factors

factors_no_lags=prcomp(data2,center=TRUE,scale.=TRUE)$x[,c(1:8)]

factors_with_lags=data.frame(matrix(0,nrow=nrow(factors_no_lags),ncol=4*ncol(factors_no_lags)))


names3=c()
for(j in 1:ncol(factors_no_lags))
{
  
  factors_with_lags[,4*j-3]<-factors_no_lags[,j]
  factors_with_lags[,4*j-2]<-lagpad(factors_no_lags[,j],1)
  factors_with_lags[,4*j-1]<-lagpad(factors_no_lags[,j],2)
  factors_with_lags[,4*j]<-lagpad(factors_no_lags[,j],3)
  
}

factors_with_lags_full=factors_with_lags[-c(1:nlags),]
factors_with_lags_reduced=factors_with_lags[-c(1:nlags,(window1-forecast_horizon+1):window1),]


data4r=cbind(X,factors_with_lags_reduced)
data4full=cbind(Xfull,factors_with_lags_full)




## LL Factor Boost
grid=seq(.3,1,length.out=ngrid)
mmsmat = matrix(0,(n_cv+1),ngrid)
for(i in jobid:(jobid+n_cv)){
  file=paste0('resultsTVP/LLh12CV_replication-',i,'.RData')
  load(file)
  mmsmat[(i-jobid+1),]=errorsFULL[[2]][[1]]^2
}
m=apply(mmsmat,2,mean,na.rm=TRUE)


bandopt=which.min(m)

m=apply(mmsmat,2,mean,na.rm=TRUE)


bandopt=which.min(m)

Z2=data4full
grid2=(1:nrow(Z2))/nrow(Z2)
Z3=cbind(Z2,Z2*(grid2-1))
Z3=data.frame(Z3)
colnames(Z3)<-paste0("Z",1:ncol(Z3))

Z4=Z3[1:(nrow(Z2)-forecast_horizon),]
a=paste0("Y~",paste0(apply(matrix(1:ncol(Z4), ncol = 2, byrow = FALSE), 1, function(vec) paste0("bols(Z",vec[1],",Z",vec[2], ")")),collapse = " + "))
w=1-(1:nrow(Z4))/nrow(Z4)
weights=.kernel(x = w, bw = grid[bandopt], tkernel = "Gaussian", N = 1)
index=(weights>0)

boost_m3=gamboost(as.formula(a),weights= weights,data=Z4,control = boost_control(mstop = 100,nu=.1))


pred1=predict(boost_m3,newdata=Z3[(nrow(Z2)),])


mms[1]=pred1-Yfull[window3]


## AR 4

auto= lm(Y~X)
pred2=c(1,Xfull[window3,])%*%coef(auto)
mms[2]=pred2-Yfull[window3]


## Bandwidth values selected:

mms[3]=grid[bandopt]
mmstotEMS=mms



############################ unrate #############################

mms=c()


nlags=3
w1=140-forecast_horizon
windows <- list()
for(i in 0:567) windows[[i+1]] <- seq(1,i+w1)

response_data_all=read.csv("/rigel/home/ky2304/Data/unratel12.csv")
data2f=read.csv("/rigel/home/ky2304/Data/MacroFinal2.csv")
response_AR_all=read.csv("/rigel/home/ky2304/Data/unratel1.csv")



l=length(windows[[jobid]])
window1=l

## need to create this to get the length of the dataset for the covariates
## since we lose 3 points to creating lags. And we need to be 12 (forecast_horizon)
## points behind the response.

window2=window1-(forecast_horizon+nlags)

## need this to get the length of the response once we lose 3 points
## to creating lags.
window3=window1-nlags

## create our response.

response_data_all=response_data_all[,2]*(1200/forecast_horizon)

response=response_data_all[windows[[jobid]]]
Yfull=response[-c(1,2,3)]
Y=Yfull[c((1):(window2))]

## create our AR terms.
response_AR_all=1200*response_AR_all[,2]


## create lags of the AR term.
response_AR=response_AR_all[windows[[jobid]]]
response_ARlags=cbind(response_AR,lagpad(response_AR,1),lagpad(response_AR,2),lagpad(response_AR,3))
Xfull=response_ARlags[-c(1,2,3),]
X=as.matrix(Xfull[c((1):(window2)),])

## subset the correct window for the covariates
data2=data2f[windows[[jobid]],][,-101]

## create factors

factors_no_lags=prcomp(data2,center=TRUE,scale.=TRUE)$x[,c(1:8)]

factors_with_lags=data.frame(matrix(0,nrow=nrow(factors_no_lags),ncol=4*ncol(factors_no_lags)))


names3=c()
for(j in 1:ncol(factors_no_lags))
{
  
  factors_with_lags[,4*j-3]<-factors_no_lags[,j]
  factors_with_lags[,4*j-2]<-lagpad(factors_no_lags[,j],1)
  factors_with_lags[,4*j-1]<-lagpad(factors_no_lags[,j],2)
  factors_with_lags[,4*j]<-lagpad(factors_no_lags[,j],3)
  
}

factors_with_lags_full=factors_with_lags[-c(1:nlags),]
factors_with_lags_reduced=factors_with_lags[-c(1:nlags,(window1-forecast_horizon+1):window1),]


data4r=cbind(X,factors_with_lags_reduced)
data4full=cbind(Xfull,factors_with_lags_full)





## LL Factor Boost
grid=seq(.3,1,length.out=ngrid)
mmsmat = matrix(0,(n_cv+1),ngrid)
for(i in jobid:(jobid+n_cv)){
  file=paste0('resultsTVP/LLh12CV_replication-',i,'.RData')
  load(file)
  mmsmat[(i-jobid+1),]=errorsFULL[[3]][[1]]^2
}
m=apply(mmsmat,2,mean,na.rm=TRUE)


bandopt=which.min(m)

Z2=data4full
grid2=(1:nrow(Z2))/nrow(Z2)
Z3=cbind(Z2,Z2*(grid2-1))
Z3=data.frame(Z3)
colnames(Z3)<-paste0("Z",1:ncol(Z3))

Z4=Z3[1:(nrow(Z2)-forecast_horizon),]
a=paste0("Y~",paste0(apply(matrix(1:ncol(Z4), ncol = 2, byrow = FALSE), 1, function(vec) paste0("bols(Z",vec[1],",Z",vec[2], ")")),collapse = " + "))
w=1-(1:nrow(Z4))/nrow(Z4)
weights=.kernel(x = w, bw = grid[bandopt], tkernel = "Gaussian", N = 1)
index=(weights>0)

boost_m3=gamboost(as.formula(a),weights= weights,data=Z4,control = boost_control(mstop = 100,nu=.1))


pred1=predict(boost_m3,newdata=Z3[(nrow(Z2)),])


mms[1]=pred1-Yfull[window3]


## AR 4

auto= lm(Y~X)
pred2=c(1,Xfull[window3,])%*%coef(auto)
mms[2]=pred2-Yfull[window3]


## Bandwidth values selected:

mms[3]=grid[bandopt]

mmstotunrate=mms



############################ CivLabor #############################



mms=c()


nlags=3
w1=140-forecast_horizon
windows <- list()
for(i in 0:567) windows[[i+1]] <- seq(1,i+w1)

response_data_all=read.csv("/rigel/home/ky2304/Data/CivLaborl12.csv")
data2f=read.csv("/rigel/home/ky2304/Data/MacroFinal2.csv")
response_AR_all=read.csv("/rigel/home/ky2304/Data/CivLaborl1.csv")



l=length(windows[[jobid]])
window1=l

## need to create this to get the length of the dataset for the covariates
## since we lose 3 points to creating lags. And we need to be 12 (forecast_horizon)
## points behind the response.

window2=window1-(forecast_horizon+nlags)

## need this to get the length of the response once we lose 3 points
## to creating lags.
window3=window1-nlags

## create our response.

response_data_all=response_data_all[,2]*(1200/forecast_horizon)

response=response_data_all[windows[[jobid]]]
Yfull=response[-c(1,2,3)]
Y=Yfull[c((1):(window2))]

## create our AR terms.
response_AR_all=1200*response_AR_all[,2]


## create lags of the AR term.
response_AR=response_AR_all[windows[[jobid]]]
response_ARlags=cbind(response_AR,lagpad(response_AR,1),lagpad(response_AR,2),lagpad(response_AR,3))
Xfull=response_ARlags[-c(1,2,3),]
X=as.matrix(Xfull[c((1):(window2)),])

## subset the correct window for the covariates
data2=data2f[windows[[jobid]],][,-101]

## create factors

factors_no_lags=prcomp(data2,center=TRUE,scale.=TRUE)$x[,c(1:8)]

factors_with_lags=data.frame(matrix(0,nrow=nrow(factors_no_lags),ncol=4*ncol(factors_no_lags)))


names3=c()
for(j in 1:ncol(factors_no_lags))
{
  
  factors_with_lags[,4*j-3]<-factors_no_lags[,j]
  factors_with_lags[,4*j-2]<-lagpad(factors_no_lags[,j],1)
  factors_with_lags[,4*j-1]<-lagpad(factors_no_lags[,j],2)
  factors_with_lags[,4*j]<-lagpad(factors_no_lags[,j],3)
  
}

factors_with_lags_full=factors_with_lags[-c(1:nlags),]
factors_with_lags_reduced=factors_with_lags[-c(1:nlags,(window1-forecast_horizon+1):window1),]


data4r=cbind(X,factors_with_lags_reduced)
data4full=cbind(Xfull,factors_with_lags_full)




## LL Factor Boost
grid=seq(.3,1,length.out=ngrid)
mmsmat = matrix(0,(n_cv+1),ngrid)
for(i in jobid:(jobid+n_cv)){
  file=paste0('resultsTVP/LLh12CV_replication-',i,'.RData')
  load(file)
  mmsmat[(i-jobid+1),]=errorsFULL[[4]][[1]]^2
}
m=apply(mmsmat,2,mean,na.rm=TRUE)


bandopt=which.min(m)

Z2=data4full
grid2=(1:nrow(Z2))/nrow(Z2)
Z3=cbind(Z2,Z2*(grid2-1))
Z3=data.frame(Z3)
colnames(Z3)<-paste0("Z",1:ncol(Z3))

Z4=Z3[1:(nrow(Z2)-forecast_horizon),]
a=paste0("Y~",paste0(apply(matrix(1:ncol(Z4), ncol = 2, byrow = FALSE), 1, function(vec) paste0("bols(Z",vec[1],",Z",vec[2], ")")),collapse = " + "))
w=1-(1:nrow(Z4))/nrow(Z4)
weights=.kernel(x = w, bw = grid[bandopt], tkernel = "Gaussian", N = 1)
index=(weights>0)

boost_m3=gamboost(as.formula(a),weights= weights,data=Z4,control = boost_control(mstop = 100,nu=.1))


pred1=predict(boost_m3,newdata=Z3[(nrow(Z2)),])


mms[1]=pred1-Yfull[window3]


## AR 4

auto= lm(Y~X)
pred2=c(1,Xfull[window3,])%*%coef(auto)
mms[2]=pred2-Yfull[window3]


## Bandwidth values selected:

mms[3]=grid[bandopt]


mmstotCivLabor=mms

############################ RPIless #############################

mms=c()



nlags=3
w1=140-forecast_horizon
windows <- list()
for(i in 0:567) windows[[i+1]] <- seq(1,i+w1)

response_data_all=read.csv("/rigel/home/ky2304/Data/RPIlessl12.csv")
data2f=read.csv("/rigel/home/ky2304/Data/MacroFinal2.csv")
response_AR_all=read.csv("/rigel/home/ky2304/Data/RPIlessl1.csv")



l=length(windows[[jobid]])
window1=l

## need to create this to get the length of the dataset for the covariates
## since we lose 3 points to creating lags. And we need to be 12 (forecast_horizon)
## points behind the response.

window2=window1-(forecast_horizon+nlags)

## need this to get the length of the response once we lose 3 points
## to creating lags.
window3=window1-nlags

## create our response.

response_data_all=response_data_all[,2]*(1200/forecast_horizon)

response=response_data_all[windows[[jobid]]]
Yfull=response[-c(1,2,3)]
Y=Yfull[c((1):(window2))]

## create our AR terms.
response_AR_all=1200*response_AR_all[,2]


## create lags of the AR term.
response_AR=response_AR_all[windows[[jobid]]]
response_ARlags=cbind(response_AR,lagpad(response_AR,1),lagpad(response_AR,2),lagpad(response_AR,3))
Xfull=response_ARlags[-c(1,2,3),]
X=as.matrix(Xfull[c((1):(window2)),])

## subset the correct window for the covariates
data2=data2f[windows[[jobid]],][,-101]

## create factors

factors_no_lags=prcomp(data2,center=TRUE,scale.=TRUE)$x[,c(1:8)]

factors_with_lags=data.frame(matrix(0,nrow=nrow(factors_no_lags),ncol=4*ncol(factors_no_lags)))


names3=c()
for(j in 1:ncol(factors_no_lags))
{
  
  factors_with_lags[,4*j-3]<-factors_no_lags[,j]
  factors_with_lags[,4*j-2]<-lagpad(factors_no_lags[,j],1)
  factors_with_lags[,4*j-1]<-lagpad(factors_no_lags[,j],2)
  factors_with_lags[,4*j]<-lagpad(factors_no_lags[,j],3)
  
}

factors_with_lags_full=factors_with_lags[-c(1:nlags),]
factors_with_lags_reduced=factors_with_lags[-c(1:nlags,(window1-forecast_horizon+1):window1),]


data4r=cbind(X,factors_with_lags_reduced)
data4full=cbind(Xfull,factors_with_lags_full)




## LL Factor Boost

mmsmat = matrix(0,(n_cv+1),ngrid)
for(i in jobid:(jobid+n_cv)){
  file=paste0('resultsTVP/LLh12CV_replication-',i,'.RData')
  load(file)
  mmsmat[(i-jobid+1),]=errorsFULL[[5]][[1]]^2
}
m=apply(mmsmat,2,mean,na.rm=TRUE)


bandopt=which.min(m)

Z2=data4full
grid2=(1:nrow(Z2))/nrow(Z2)
Z3=cbind(Z2,Z2*(grid2-1))
Z3=data.frame(Z3)
colnames(Z3)<-paste0("Z",1:ncol(Z3))

Z4=Z3[1:(nrow(Z2)-forecast_horizon),]
a=paste0("Y~",paste0(apply(matrix(1:ncol(Z4), ncol = 2, byrow = FALSE), 1, function(vec) paste0("bols(Z",vec[1],",Z",vec[2], ")")),collapse = " + "))
w=1-(1:nrow(Z4))/nrow(Z4)
weights=.kernel(x = w, bw = grid[bandopt], tkernel = "Gaussian", N = 1)
index=(weights>0)

boost_m3=gamboost(as.formula(a),weights= weights,data=Z4,control = boost_control(mstop = 100,nu=.1))


pred1=predict(boost_m3,newdata=Z3[(nrow(Z2)),])


mms[1]=pred1-Yfull[window3]


## AR 4

auto= lm(Y~X)
pred2=c(1,Xfull[window3,])%*%coef(auto)
mms[2]=pred2-Yfull[window3]


## Bandwidth values selected:

mms[3]=grid[bandopt]

mmstotRPIless=mms


################### CPI #########################################

mms=c()



nlags=3
w1=140-forecast_horizon
windows <- list()
for(i in 0:567) windows[[i+1]] <- seq(1,i+w1)

response_data_all=read.csv("/rigel/home/ky2304/Data/CPIl12.csv")
data2f=read.csv("/rigel/home/ky2304/Data/MacroFinal2.csv")
response_AR_all=read.csv("/rigel/home/ky2304/Data/CPIl1.csv")



l=length(windows[[jobid]])
window1=l

## need to create this to get the length of the dataset for the covariates
## since we lose 3 points to creating lags. And we need to be 12 (forecast_horizon)
## points behind the response.

window2=window1-(forecast_horizon+nlags)

## need this to get the length of the response once we lose 3 points
## to creating lags.
window3=window1-nlags

## create our response.

response_data_all=response_data_all[,2]*(1200/forecast_horizon)

response=response_data_all[windows[[jobid]]]
Yfull=response[-c(1,2,3)]
Y=Yfull[c((1):(window2))]

## create our AR terms.
response_AR_all=1200*response_AR_all[,2]


## create lags of the AR term.
response_AR=response_AR_all[windows[[jobid]]]
response_ARlags=cbind(response_AR,lagpad(response_AR,1),lagpad(response_AR,2),lagpad(response_AR,3))
Xfull=response_ARlags[-c(1,2,3),]
X=as.matrix(Xfull[c((1):(window2)),])

## subset the correct window for the covariates
data2=data2f[windows[[jobid]],][,-101]

## create factors

factors_no_lags=prcomp(data2,center=TRUE,scale.=TRUE)$x[,c(1:8)]

factors_with_lags=data.frame(matrix(0,nrow=nrow(factors_no_lags),ncol=4*ncol(factors_no_lags)))


names3=c()
for(j in 1:ncol(factors_no_lags))
{
  
  factors_with_lags[,4*j-3]<-factors_no_lags[,j]
  factors_with_lags[,4*j-2]<-lagpad(factors_no_lags[,j],1)
  factors_with_lags[,4*j-1]<-lagpad(factors_no_lags[,j],2)
  factors_with_lags[,4*j]<-lagpad(factors_no_lags[,j],3)
  
}

factors_with_lags_full=factors_with_lags[-c(1:nlags),]
factors_with_lags_reduced=factors_with_lags[-c(1:nlags,(window1-forecast_horizon+1):window1),]


data4r=cbind(X,factors_with_lags_reduced)
data4full=cbind(Xfull,factors_with_lags_full)




## LL Factor Boost
grid=seq(.3,1,length.out=ngrid)
mmsmat = matrix(0,(n_cv+1),ngrid)
for(i in jobid:(jobid+n_cv)){
  file=paste0('resultsTVP/LLh12CV_replication-',i,'.RData')
  load(file)
  mmsmat[(i-jobid+1),]=errorsFULL[[6]][[1]]^2
}
m=apply(mmsmat,2,mean,na.rm=TRUE)


bandopt=which.min(m)

Z2=data4full
grid2=(1:nrow(Z2))/nrow(Z2)
Z3=cbind(Z2,Z2*(grid2-1))
Z3=data.frame(Z3)
colnames(Z3)<-paste0("Z",1:ncol(Z3))

Z4=Z3[1:(nrow(Z2)-forecast_horizon),]
a=paste0("Y~",paste0(apply(matrix(1:ncol(Z4), ncol = 2, byrow = FALSE), 1, function(vec) paste0("bols(Z",vec[1],",Z",vec[2], ")")),collapse = " + "))
w=1-(1:nrow(Z4))/nrow(Z4)
weights=.kernel(x = w, bw = grid[bandopt], tkernel = "Gaussian", N = 1)
index=(weights>0)

boost_m3=gamboost(as.formula(a),weights= weights,data=Z4,control = boost_control(mstop = 100,nu=.1))


pred1=predict(boost_m3,newdata=Z3[(nrow(Z2)),])


mms[1]=pred1-Yfull[window3]

## AR 4

auto= lm(Y~X)
pred2=c(1,Xfull[window3,])%*%coef(auto)
mms[2]=pred2-Yfull[window3]


## Bandwidth values selected:

mms[3]=grid[bandopt]

mmstotCPI=mms



############## Fed Funds ##################


mms=c()



nlags=3
w1=140-forecast_horizon
windows <- list()
for(i in 0:567) windows[[i+1]] <- seq(1,i+w1)

response_data_all=read.csv("/rigel/home/ky2304/Data/Fedfundsl12.csv")
data2f=read.csv("/rigel/home/ky2304/Data/MacroFinal2.csv")
response_AR_all=read.csv("/rigel/home/ky2304/Data/Fedfundsl1.csv")



l=length(windows[[jobid]])
window1=l

## need to create this to get the length of the dataset for the covariates
## since we lose 3 points to creating lags. And we need to be 12 (forecast_horizon)
## points behind the response.

window2=window1-(forecast_horizon+nlags)

## need this to get the length of the response once we lose 3 points
## to creating lags.
window3=window1-nlags

## create our response.

response_data_all=response_data_all[,2]*(1200/forecast_horizon)

response=response_data_all[windows[[jobid]]]
Yfull=response[-c(1,2,3)]
Y=Yfull[c((1):(window2))]

## create our AR terms.
response_AR_all=1200*response_AR_all[,2]


## create lags of the AR term.
response_AR=response_AR_all[windows[[jobid]]]
response_ARlags=cbind(response_AR,lagpad(response_AR,1),lagpad(response_AR,2),lagpad(response_AR,3))
Xfull=response_ARlags[-c(1,2,3),]
X=as.matrix(Xfull[c((1):(window2)),])

## subset the correct window for the covariates
data2=data2f[windows[[jobid]],][,-101]

## create factors

factors_no_lags=prcomp(data2,center=TRUE,scale.=TRUE)$x[,c(1:8)]

factors_with_lags=data.frame(matrix(0,nrow=nrow(factors_no_lags),ncol=4*ncol(factors_no_lags)))


names3=c()
for(j in 1:ncol(factors_no_lags))
{
  
  factors_with_lags[,4*j-3]<-factors_no_lags[,j]
  factors_with_lags[,4*j-2]<-lagpad(factors_no_lags[,j],1)
  factors_with_lags[,4*j-1]<-lagpad(factors_no_lags[,j],2)
  factors_with_lags[,4*j]<-lagpad(factors_no_lags[,j],3)
  
}

factors_with_lags_full=factors_with_lags[-c(1:nlags),]
factors_with_lags_reduced=factors_with_lags[-c(1:nlags,(window1-forecast_horizon+1):window1),]


data4r=cbind(X,factors_with_lags_reduced)
data4full=cbind(Xfull,factors_with_lags_full)




## LL Factor Boost
grid=seq(.3,1,length.out=ngrid)
mmsmat = matrix(0,(n_cv+1),ngrid)
for(i in jobid:(jobid+n_cv)){
  file=paste0('resultsTVP/LLh12CV_replication-',i,'.RData')
  load(file)
  mmsmat[(i-jobid+1),]=errorsFULL[[7]][[1]]^2
}
m=apply(mmsmat,2,mean,na.rm=TRUE)


bandopt=which.min(m)

Z2=data4full
grid2=(1:nrow(Z2))/nrow(Z2)
Z3=cbind(Z2,Z2*(grid2-1))
Z3=data.frame(Z3)
colnames(Z3)<-paste0("Z",1:ncol(Z3))

Z4=Z3[1:(nrow(Z2)-forecast_horizon),]
a=paste0("Y~",paste0(apply(matrix(1:ncol(Z4), ncol = 2, byrow = FALSE), 1, function(vec) paste0("bols(Z",vec[1],",Z",vec[2], ")")),collapse = " + "))
w=1-(1:nrow(Z4))/nrow(Z4)
weights=.kernel(x = w, bw = grid[bandopt], tkernel = "Gaussian", N = 1)
index=(weights>0)

boost_m3=gamboost(as.formula(a),weights= weights,data=Z4,control = boost_control(mstop = 100,nu=.1))


pred1=predict(boost_m3,newdata=Z3[(nrow(Z2)),])


mms[1]=pred1-Yfull[window3]


## AR 4

auto= lm(Y~X)
pred2=c(1,Xfull[window3,])%*%coef(auto)
mms[2]=pred2-Yfull[window3]


## Bandwidth values selected:

mms[3]=grid[bandopt]
mmstotFF=mms


######### TB3MS ###################



mms=c()



nlags=3
w1=140-forecast_horizon
windows <- list()
for(i in 0:567) windows[[i+1]] <- seq(1,i+w1)

response_data_all=read.csv("/rigel/home/ky2304/Data/TB3MSl12.csv")
data2f=read.csv("/rigel/home/ky2304/Data/MacroFinal2.csv")
response_AR_all=read.csv("/rigel/home/ky2304/Data/TB3MSl1.csv")



l=length(windows[[jobid]])
window1=l

## need to create this to get the length of the dataset for the covariates
## since we lose 3 points to creating lags. And we need to be 12 (forecast_horizon)
## points behind the response.

window2=window1-(forecast_horizon+nlags)

## need this to get the length of the response once we lose 3 points
## to creating lags.
window3=window1-nlags

## create our response.

response_data_all=response_data_all[,2]*(1200/forecast_horizon)

response=response_data_all[windows[[jobid]]]
Yfull=response[-c(1,2,3)]
Y=Yfull[c((1):(window2))]

## create our AR terms.
response_AR_all=1200*response_AR_all[,2]


## create lags of the AR term.
response_AR=response_AR_all[windows[[jobid]]]
response_ARlags=cbind(response_AR,lagpad(response_AR,1),lagpad(response_AR,2),lagpad(response_AR,3))
Xfull=response_ARlags[-c(1,2,3),]
X=as.matrix(Xfull[c((1):(window2)),])

## subset the correct window for the covariates
data2=data2f[windows[[jobid]],][,-101]

## create factors

factors_no_lags=prcomp(data2,center=TRUE,scale.=TRUE)$x[,c(1:8)]

factors_with_lags=data.frame(matrix(0,nrow=nrow(factors_no_lags),ncol=4*ncol(factors_no_lags)))


names3=c()
for(j in 1:ncol(factors_no_lags))
{
  
  factors_with_lags[,4*j-3]<-factors_no_lags[,j]
  factors_with_lags[,4*j-2]<-lagpad(factors_no_lags[,j],1)
  factors_with_lags[,4*j-1]<-lagpad(factors_no_lags[,j],2)
  factors_with_lags[,4*j]<-lagpad(factors_no_lags[,j],3)
  
}

factors_with_lags_full=factors_with_lags[-c(1:nlags),]
factors_with_lags_reduced=factors_with_lags[-c(1:nlags,(window1-forecast_horizon+1):window1),]


data4r=cbind(X,factors_with_lags_reduced)
data4full=cbind(Xfull,factors_with_lags_full)




## LL Factor Boost
grid=seq(.3,1,length.out=ngrid)
mmsmat = matrix(0,(n_cv+1),ngrid)
for(i in jobid:(jobid+n_cv)){
  file=paste0('resultsTVP/LLh12CV_replication-',i,'.RData')
  load(file)
  mmsmat[(i-jobid+1),]=errorsFULL[[8]][[1]]^2
}
m=apply(mmsmat,2,mean,na.rm=TRUE)


bandopt=which.min(m)

Z2=data4full
grid2=(1:nrow(Z2))/nrow(Z2)
Z3=cbind(Z2,Z2*(grid2-1))
Z3=data.frame(Z3)
colnames(Z3)<-paste0("Z",1:ncol(Z3))

Z4=Z3[1:(nrow(Z2)-forecast_horizon),]
a=paste0("Y~",paste0(apply(matrix(1:ncol(Z4), ncol = 2, byrow = FALSE), 1, function(vec) paste0("bols(Z",vec[1],",Z",vec[2], ")")),collapse = " + "))
w=1-(1:nrow(Z4))/nrow(Z4)
weights=.kernel(x = w, bw = grid[bandopt], tkernel = "Gaussian", N = 1)
index=(weights>0)

boost_m3=gamboost(as.formula(a),weights= weights,data=Z4,control = boost_control(mstop = 100,nu=.1))


pred1=predict(boost_m3,newdata=Z3[(nrow(Z2)),])


mms[1]=pred1-Yfull[window3]

## AR 4

auto= lm(Y~X)
pred2=c(1,Xfull[window3,])%*%coef(auto)
mms[2]=pred2-Yfull[window3]


## Bandwidth values selected:

mms[3]=grid[bandopt]

mmstotTB3MS=mms


mmsFULL=list(mmstot,mmstotEMS,mmstotunrate,mmstotCivLabor,mmstotRPIless,mmstotCPI,mmstotFF,mmstotTB3MS)

#save(mmsFULL,file=paste0('resultsTVP/LChK1-',randSeed,'.RData'))

save(mmsFULL,file=paste0('resultsTVP/LL12_replication-',jobid,'.RData'))
