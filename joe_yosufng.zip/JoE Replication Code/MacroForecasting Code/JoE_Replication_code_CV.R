jobid = as.numeric(Sys.getenv("SLURM_ARRAY_TASK_ID"))

.libPaths('../rpackages')

#source('funs.r')
library(mboost)
library(glmnet)
set.seed(jobid)


## some helper functions

## creates lags of order K and pads the start of series with NAs

lagpad <- function(x, k) {
  c(rep(NA, k), x)[1 : length(x)] 
}


##kernel function

.kernel <- function(x, bw, tkernel = "Gaussian", N = 1)
{
  x <- x/(N * bw)
  value <- numeric(length(x))
  if (tkernel == "Gaussian")
  {
    value <- exp(-0.5 * x^2)/2.506628274631000241612355239340104162693023681640625 #sqrt(2*pi)
  }
  if(tkernel == "Epa")
  {
    index <- (x >= -1 & x <= 1)
    
    value[index] <- .75 * (1 - x[index]^2)
  }
  
  if(tkernel == "Unif")
  {
    index <- (x >= -1 & x <= 1)
    
    value[index] <- 1 
  }
  return(value)
  
}

## some constants to set

# size of the grid from which to select the bandwidth of the kernel
ngrid=29
## number of points in the cross validation set.
n_cv=60



## other constants 


forecast_horizon=12
## number of lags for each predictor
nlags=3

## calculate the length between the start of the training data and the test data.
train_start_date = strptime("1960-03-01", "%Y-%m-%d")
test_start_date = strptime("1971-10-01", "%Y-%m-%d")
len_diff = length(seq(from=train_start_date, to=test_start_date, by='month'))


# determines the end date of the training period of the first forecast in
## our cross validation period.
w1=len_diff - forecast_horizon-(forecast_horizon+n_cv)




## we now create a set of windows. Each one specifying the training period 
## for a different cross validation forecast. Runs from the beginning to the
## end.
windows <- list()
for(i in 0:(567+n_cv)) windows[[i+1]] <- seq(1,i+w1)


### Industrial Production h = 12



## load the response
response_data_all=read.csv("/rigel/home/ky2304/Data/IPl12.csv")
## load the covariates and the autoregressive term.
data2f=read.csv("/rigel/home/ky2304/Data/MacroFinal2.csv")
response_AR_all=read.csv("/rigel/home/ky2304/Data/IPl1.csv")




l=length(windows[[jobid]])
window1=l

## need to create this to get the length of the dataset for the covariates
## since we lose 3 points to creating lags. And we need to be 12 (forecast_horizon)
## points behind the response.

window2=window1-(forecast_horizon+nlags)

## need this to get the length of the response once we lose 3 points
## to creating lags.
window3=window1-nlags

## create our response.
response_data_all=response_data_all[,2]*(1200/forecast_horizon)

response=response_data_all[windows[[jobid]]]
Yfull=response[-c(1,2,3)]
Y=Yfull[c((1):(window2))]

## create our AR terms.
response_AR_all=1200*response_AR_all[,2]


## create lags of the AR term.
response_AR=response_AR_all[windows[[jobid]]]
response_ARlags=cbind(response_AR,lagpad(response_AR,1),lagpad(response_AR,2),lagpad(response_AR,3))
Xfull=response_ARlags[-c(1,2,3),]
X=as.matrix(Xfull[c((1):(window2)),])

## subset the correct window for the covariates
data2=data2f[windows[[jobid]],]

## create factors

factors_no_lags=prcomp(data2,center=TRUE,scale.=TRUE)$x[,c(1:8)];names2=colnames(data2)

factors_with_lags=data.frame(matrix(0,nrow=nrow(factors_no_lags),ncol=4*ncol(factors_no_lags)))


names3=c()
for(j in 1:ncol(factors_no_lags))
{
  names3[4*j-3]=names2[j]
  names3[4*j-2]=paste(names2[j],"lag",1)
  names3[4*j-1]=paste(names2[j],"lag",2)
  names3[4*j]=paste(names2[j],"lag",3)
  
  factors_with_lags[,4*j-3]<-factors_no_lags[,j]
  factors_with_lags[,4*j-2]<-lagpad(factors_no_lags[,j],1)
  factors_with_lags[,4*j-1]<-lagpad(factors_no_lags[,j],2)
  factors_with_lags[,4*j]<-lagpad(factors_no_lags[,j],3)
  
}

factors_with_lags_full=factors_with_lags[-c(1:nlags),]
factors_with_lags_reduced=factors_with_lags[-c(1:nlags,(window1-forecast_horizon+1):window1),]


data4r=cbind(X,factors_with_lags_reduced)
data4full=cbind(Xfull,factors_with_lags_full)



#now lets create the same for the covariates without factors.

covs_with_lags = data.frame(matrix(0,nrow=nrow(data2),ncol=4*ncol(data2)))


names3=c()
for(j in 1:ncol(data2))
{
  names3[4*j-3]=names2[j]
  names3[4*j-2]=paste(names2[j],"lag",1)
  names3[4*j-1]=paste(names2[j],"lag",2)
  names3[4*j]=paste(names2[j],"lag",3)
  
  covs_with_lags[,4*j-3]<-data2[,j]
  covs_with_lags[,4*j-2]<-lagpad(data2[,j],1)
  covs_with_lags[,4*j-1]<-lagpad(data2[,j],2)
  covs_with_lags[,4*j]<-lagpad(data2[,j],3)
  
}

covs_with_lags_full=covs_with_lags[-c(1:nlags),]
covs_with_lags_reduced=covs_with_lags[-c(1:nlags,(window1-forecast_horizon+1):window1),]


grid=seq(.3,1,length.out=ngrid)
n=length(Y)

errorLC=c()
errorLCFactor=c()
for(i in 1:length(grid)){
  
  ### LC Boost
  
  grid2=(1:nrow(X))/nrow(X)
  w=1-grid2
  weights=.kernel(x = w, bw = grid[i], tkernel = "Unif", N = 1)
  index=(weights>0)
  cm=apply(cbind(X,covs_with_lags_reduced),2,weighted.mean,w=weights)
  m_boost=glmboost(x=scale(cbind(X,covs_with_lags_reduced),center=cm,scale=FALSE)[index,],y=Y[index],weights= weights[index],center=FALSE,control = boost_control(mstop = 100))
  m_boost1=glmboost(x=scale(cbind(X,covs_with_lags_reduced),center=cm,scale=FALSE)[index,],y=Y[index],weights= weights[index],center=FALSE,control = boost_control(mstop = mstop(AIC(m_boost))))
  pred_m=predict(m_boost1,newdata=scale(cbind(Xfull,covs_with_lags_full),center=cm,scale=FALSE))[window3]
  errorLC[i]=pred_m-Yfull[window3]
  
  ## LC Factor Boost
  
  grid2=(1:nrow(X))/nrow(X)
  w=1-grid2
  weights=.kernel(x = w, bw = grid[i], tkernel = "Unif", N = 1)
  index=(weights>0)
  cm=apply(cbind(data4r),2,weighted.mean,w=weights)
  m_boost=glmboost(x=scale(cbind(as.matrix(data4r)),center=cm,scale=FALSE)[index,],y=Y[index],weights= weights[index],center=FALSE,control = boost_control(mstop = 100))
  m_boost1=glmboost(x=scale(cbind(as.matrix(data4r)),center=cm,scale=FALSE)[index,],y=Y[index],weights= weights[index],center=FALSE,control = boost_control(mstop = mstop(AIC(m_boost))))
  pred_m=predict(m_boost1,newdata=scale(cbind(as.matrix(data4full)),center=cm,scale=FALSE))[window3]
  errorLCFactor[i]=pred_m-Yfull[window3]
}

errorsIP=list(errorLC,errorLCFactor)


############################ EMS h=12 #############################

response_data_all=read.csv("/rigel/home/ky2304/Data/emsl12.csv")
#PIf12=read.csv("/rigel/home/ky2304/Data/unratelh1.csv")
data2f=read.csv("/rigel/home/ky2304/Data/MacroFinal2.csv")
response_AR_all=read.csv("/rigel/home/ky2304/Data/emsl1.csv")


l=length(windows[[jobid]])
window1=l

## need to create this to get the length of the dataset for the covariates
## since we lose 3 points to creating lags. And we need to be 12 (forecast_horizon)
## points behind the response.

window2=window1-(forecast_horizon+nlags)

## need this to get the length of the response once we lose 3 points
## to creating lags.
window3=window1-nlags

## create our response.
response_data_all=response_data_all[,2]*(1200/forecast_horizon)

response=response_data_all[windows[[jobid]]]
Yfull=response[-c(1,2,3)]
Y=Yfull[c((1):(window2))]

## create our AR terms.
response_AR_all=1200*response_AR_all[,2]


## create lags of the AR term.
response_AR=response_AR_all[windows[[jobid]]]
response_ARlags=cbind(response_AR,lagpad(response_AR,1),lagpad(response_AR,2),lagpad(response_AR,3))
Xfull=response_ARlags[-c(1,2,3),]
X=as.matrix(Xfull[c((1):(window2)),])

## subset the correct window for the covariates
data2=data2f[windows[[jobid]],]

## create factors

factors_no_lags=prcomp(data2,center=TRUE,scale.=TRUE)$x[,c(1:8)];names2=colnames(data2)

factors_with_lags=data.frame(matrix(0,nrow=nrow(factors_no_lags),ncol=4*ncol(factors_no_lags)))


names3=c()
for(j in 1:ncol(factors_no_lags))
{
  names3[4*j-3]=names2[j]
  names3[4*j-2]=paste(names2[j],"lag",1)
  names3[4*j-1]=paste(names2[j],"lag",2)
  names3[4*j]=paste(names2[j],"lag",3)
  
  factors_with_lags[,4*j-3]<-factors_no_lags[,j]
  factors_with_lags[,4*j-2]<-lagpad(factors_no_lags[,j],1)
  factors_with_lags[,4*j-1]<-lagpad(factors_no_lags[,j],2)
  factors_with_lags[,4*j]<-lagpad(factors_no_lags[,j],3)
  
}

factors_with_lags_full=factors_with_lags[-c(1:nlags),]
factors_with_lags_reduced=factors_with_lags[-c(1:nlags,(window1-forecast_horizon+1):window1),]


data4r=cbind(X,factors_with_lags_reduced)
data4full=cbind(Xfull,factors_with_lags_full)



#now lets create the same for the covariates without factors.

covs_with_lags = data.frame(matrix(0,nrow=nrow(data2),ncol=4*ncol(data2)))


names3=c()
for(j in 1:ncol(data2))
{
  names3[4*j-3]=names2[j]
  names3[4*j-2]=paste(names2[j],"lag",1)
  names3[4*j-1]=paste(names2[j],"lag",2)
  names3[4*j]=paste(names2[j],"lag",3)
  
  covs_with_lags[,4*j-3]<-data2[,j]
  covs_with_lags[,4*j-2]<-lagpad(data2[,j],1)
  covs_with_lags[,4*j-1]<-lagpad(data2[,j],2)
  covs_with_lags[,4*j]<-lagpad(data2[,j],3)
  
}

covs_with_lags_full=covs_with_lags[-c(1:nlags),]
covs_with_lags_reduced=covs_with_lags[-c(1:nlags,(window1-forecast_horizon+1):window1),]


grid=seq(.3,1,length.out=ngrid)
n=length(Y)

errorLC=c()
errorLCFactor=c()
for(i in 1:length(grid)){
  
  ### LC Boost
  
  grid2=(1:nrow(X))/nrow(X)
  w=1-grid2
  weights=.kernel(x = w, bw = grid[i], tkernel = "Unif", N = 1)
  index=(weights>0)
  cm=apply(cbind(X,covs_with_lags_reduced),2,weighted.mean,w=weights)
  m_boost=glmboost(x=scale(cbind(X,covs_with_lags_reduced),center=cm,scale=FALSE)[index,],y=Y[index],weights= weights[index],center=FALSE,control = boost_control(mstop = 100))
  m_boost1=glmboost(x=scale(cbind(X,covs_with_lags_reduced),center=cm,scale=FALSE)[index,],y=Y[index],weights= weights[index],center=FALSE,control = boost_control(mstop = mstop(AIC(m_boost))))
  pred_m=predict(m_boost1,newdata=scale(cbind(Xfull,covs_with_lags_full),center=cm,scale=FALSE))[window3]
  errorLC[i]=pred_m-Yfull[window3]
  
  ## LC Factor Boost
  
  grid2=(1:nrow(X))/nrow(X)
  w=1-grid2
  weights=.kernel(x = w, bw = grid[i], tkernel = "Unif", N = 1)
  index=(weights>0)
  cm=apply(cbind(data4r),2,weighted.mean,w=weights)
  m_boost=glmboost(x=scale(cbind(as.matrix(data4r)),center=cm,scale=FALSE)[index,],y=Y[index],weights= weights[index],center=FALSE,control = boost_control(mstop = 100))
  m_boost1=glmboost(x=scale(cbind(as.matrix(data4r)),center=cm,scale=FALSE)[index,],y=Y[index],weights= weights[index],center=FALSE,control = boost_control(mstop = mstop(AIC(m_boost))))
  pred_m=predict(m_boost1,newdata=scale(cbind(as.matrix(data4full)),center=cm,scale=FALSE))[window3]
  errorLCFactor[i]=pred_m-Yfull[window3]
}


errorsEMS=list(errorLC,errorLCFactor)


#### unrate #######################



response_data_all=read.csv("/rigel/home/ky2304/Data/unratel12.csv")
#PIf12=read.csv("/rigel/home/ky2304/Data/unratelh1.csv")
data2f=read.csv("/rigel/home/ky2304/Data/MacroFinal2.csv")
response_AR_all=read.csv("/rigel/home/ky2304/Data/unratel1.csv")


l=length(windows[[jobid]])
window1=l

## need to create this to get the length of the dataset for the covariates
## since we lose 3 points to creating lags. And we need to be 12 (forecast_horizon)
## points behind the response.

window2=window1-(forecast_horizon+nlags)

## need this to get the length of the response once we lose 3 points
## to creating lags.
window3=window1-nlags

## create our response.
response_data_all=response_data_all[,2]*(1200/forecast_horizon)

response=response_data_all[windows[[jobid]]]
Yfull=response[-c(1,2,3)]
Y=Yfull[c((1):(window2))]

## create our AR terms.
response_AR_all=1200*response_AR_all[,2]


## create lags of the AR term.
response_AR=response_AR_all[windows[[jobid]]]
response_ARlags=cbind(response_AR,lagpad(response_AR,1),lagpad(response_AR,2),lagpad(response_AR,3))
Xfull=response_ARlags[-c(1,2,3),]
X=as.matrix(Xfull[c((1):(window2)),])

## subset the correct window for the covariates
data2=data2f[windows[[jobid]],]

## create factors

factors_no_lags=prcomp(data2,center=TRUE,scale.=TRUE)$x[,c(1:8)];names2=colnames(data2)

factors_with_lags=data.frame(matrix(0,nrow=nrow(factors_no_lags),ncol=4*ncol(factors_no_lags)))


names3=c()
for(j in 1:ncol(factors_no_lags))
{
  names3[4*j-3]=names2[j]
  names3[4*j-2]=paste(names2[j],"lag",1)
  names3[4*j-1]=paste(names2[j],"lag",2)
  names3[4*j]=paste(names2[j],"lag",3)
  
  factors_with_lags[,4*j-3]<-factors_no_lags[,j]
  factors_with_lags[,4*j-2]<-lagpad(factors_no_lags[,j],1)
  factors_with_lags[,4*j-1]<-lagpad(factors_no_lags[,j],2)
  factors_with_lags[,4*j]<-lagpad(factors_no_lags[,j],3)
  
}

factors_with_lags_full=factors_with_lags[-c(1:nlags),]
factors_with_lags_reduced=factors_with_lags[-c(1:nlags,(window1-forecast_horizon+1):window1),]


data4r=cbind(X,factors_with_lags_reduced)
data4full=cbind(Xfull,factors_with_lags_full)



#now lets create the same for the covariates without factors.

covs_with_lags = data.frame(matrix(0,nrow=nrow(data2),ncol=4*ncol(data2)))


names3=c()
for(j in 1:ncol(data2))
{
  names3[4*j-3]=names2[j]
  names3[4*j-2]=paste(names2[j],"lag",1)
  names3[4*j-1]=paste(names2[j],"lag",2)
  names3[4*j]=paste(names2[j],"lag",3)
  
  covs_with_lags[,4*j-3]<-data2[,j]
  covs_with_lags[,4*j-2]<-lagpad(data2[,j],1)
  covs_with_lags[,4*j-1]<-lagpad(data2[,j],2)
  covs_with_lags[,4*j]<-lagpad(data2[,j],3)
  
}

covs_with_lags_full=covs_with_lags[-c(1:nlags),]
covs_with_lags_reduced=covs_with_lags[-c(1:nlags,(window1-forecast_horizon+1):window1),]


grid=seq(.3,1,length.out=ngrid)
n=length(Y)

errorLC=c()
errorLCFactor=c()
for(i in 1:length(grid)){
  
  ### LC Boost
  
  grid2=(1:nrow(X))/nrow(X)
  w=1-grid2
  weights=.kernel(x = w, bw = grid[i], tkernel = "Unif", N = 1)
  index=(weights>0)
  cm=apply(cbind(X,covs_with_lags_reduced),2,weighted.mean,w=weights)
  m_boost=glmboost(x=scale(cbind(X,covs_with_lags_reduced),center=cm,scale=FALSE)[index,],y=Y[index],weights= weights[index],center=FALSE,control = boost_control(mstop = 100))
  m_boost1=glmboost(x=scale(cbind(X,covs_with_lags_reduced),center=cm,scale=FALSE)[index,],y=Y[index],weights= weights[index],center=FALSE,control = boost_control(mstop = mstop(AIC(m_boost))))
  pred_m=predict(m_boost1,newdata=scale(cbind(Xfull,covs_with_lags_full),center=cm,scale=FALSE))[window3]
  errorLC[i]=pred_m-Yfull[window3]
  
  ## LC Factor Boost
  
  grid2=(1:nrow(X))/nrow(X)
  w=1-grid2
  weights=.kernel(x = w, bw = grid[i], tkernel = "Unif", N = 1)
  index=(weights>0)
  cm=apply(cbind(data4r),2,weighted.mean,w=weights)
  m_boost=glmboost(x=scale(cbind(as.matrix(data4r)),center=cm,scale=FALSE)[index,],y=Y[index],weights= weights[index],center=FALSE,control = boost_control(mstop = 100))
  m_boost1=glmboost(x=scale(cbind(as.matrix(data4r)),center=cm,scale=FALSE)[index,],y=Y[index],weights= weights[index],center=FALSE,control = boost_control(mstop = mstop(AIC(m_boost))))
  pred_m=predict(m_boost1,newdata=scale(cbind(as.matrix(data4full)),center=cm,scale=FALSE))[window3]
  errorLCFactor[i]=pred_m-Yfull[window3]
}

errorsUNRATE=list(errorLC,errorLCFactor)

################CIV Labor##############################



response_data_all=read.csv("/rigel/home/ky2304/Data/CivLaborl12.csv")
#PIf12=read.csv("/rigel/home/ky2304/Data/unratelh1.csv")
data2f=read.csv("/rigel/home/ky2304/Data/MacroFinal2.csv")
response_AR_all=read.csv("/rigel/home/ky2304/Data/CivLaborl1.csv")



l=length(windows[[jobid]])
window1=l

## need to create this to get the length of the dataset for the covariates
## since we lose 3 points to creating lags. And we need to be 12 (forecast_horizon)
## points behind the response.

window2=window1-(forecast_horizon+nlags)

## need this to get the length of the response once we lose 3 points
## to creating lags.
window3=window1-nlags

## create our response.
response_data_all=response_data_all[,2]*(1200/forecast_horizon)

response=response_data_all[windows[[jobid]]]
Yfull=response[-c(1,2,3)]
Y=Yfull[c((1):(window2))]

## create our AR terms.
response_AR_all=1200*response_AR_all[,2]


## create lags of the AR term.
response_AR=response_AR_all[windows[[jobid]]]
response_ARlags=cbind(response_AR,lagpad(response_AR,1),lagpad(response_AR,2),lagpad(response_AR,3))
Xfull=response_ARlags[-c(1,2,3),]
X=as.matrix(Xfull[c((1):(window2)),])

## subset the correct window for the covariates
data2=data2f[windows[[jobid]],]

## create factors

factors_no_lags=prcomp(data2,center=TRUE,scale.=TRUE)$x[,c(1:8)];names2=colnames(data2)

factors_with_lags=data.frame(matrix(0,nrow=nrow(factors_no_lags),ncol=4*ncol(factors_no_lags)))


names3=c()
for(j in 1:ncol(factors_no_lags))
{
  names3[4*j-3]=names2[j]
  names3[4*j-2]=paste(names2[j],"lag",1)
  names3[4*j-1]=paste(names2[j],"lag",2)
  names3[4*j]=paste(names2[j],"lag",3)
  
  factors_with_lags[,4*j-3]<-factors_no_lags[,j]
  factors_with_lags[,4*j-2]<-lagpad(factors_no_lags[,j],1)
  factors_with_lags[,4*j-1]<-lagpad(factors_no_lags[,j],2)
  factors_with_lags[,4*j]<-lagpad(factors_no_lags[,j],3)
  
}

factors_with_lags_full=factors_with_lags[-c(1:nlags),]
factors_with_lags_reduced=factors_with_lags[-c(1:nlags,(window1-forecast_horizon+1):window1),]


data4r=cbind(X,factors_with_lags_reduced)
data4full=cbind(Xfull,factors_with_lags_full)



#now lets create the same for the covariates without factors.

covs_with_lags = data.frame(matrix(0,nrow=nrow(data2),ncol=4*ncol(data2)))


names3=c()
for(j in 1:ncol(data2))
{
  names3[4*j-3]=names2[j]
  names3[4*j-2]=paste(names2[j],"lag",1)
  names3[4*j-1]=paste(names2[j],"lag",2)
  names3[4*j]=paste(names2[j],"lag",3)
  
  covs_with_lags[,4*j-3]<-data2[,j]
  covs_with_lags[,4*j-2]<-lagpad(data2[,j],1)
  covs_with_lags[,4*j-1]<-lagpad(data2[,j],2)
  covs_with_lags[,4*j]<-lagpad(data2[,j],3)
  
}

covs_with_lags_full=covs_with_lags[-c(1:nlags),]
covs_with_lags_reduced=covs_with_lags[-c(1:nlags,(window1-forecast_horizon+1):window1),]


grid=seq(.3,1,length.out=ngrid)
n=length(Y)

errorLC=c()
errorLCFactor=c()
for(i in 1:length(grid)){
  
  ### LC Boost
  
  grid2=(1:nrow(X))/nrow(X)
  w=1-grid2
  weights=.kernel(x = w, bw = grid[i], tkernel = "Unif", N = 1)
  index=(weights>0)
  cm=apply(cbind(X,covs_with_lags_reduced),2,weighted.mean,w=weights)
  m_boost=glmboost(x=scale(cbind(X,covs_with_lags_reduced),center=cm,scale=FALSE)[index,],y=Y[index],weights= weights[index],center=FALSE,control = boost_control(mstop = 100))
  m_boost1=glmboost(x=scale(cbind(X,covs_with_lags_reduced),center=cm,scale=FALSE)[index,],y=Y[index],weights= weights[index],center=FALSE,control = boost_control(mstop = mstop(AIC(m_boost))))
  pred_m=predict(m_boost1,newdata=scale(cbind(Xfull,covs_with_lags_full),center=cm,scale=FALSE))[window3]
  errorLC[i]=pred_m-Yfull[window3]
  
  ## LC Factor Boost
  
  grid2=(1:nrow(X))/nrow(X)
  w=1-grid2
  weights=.kernel(x = w, bw = grid[i], tkernel = "Unif", N = 1)
  index=(weights>0)
  cm=apply(cbind(data4r),2,weighted.mean,w=weights)
  m_boost=glmboost(x=scale(cbind(as.matrix(data4r)),center=cm,scale=FALSE)[index,],y=Y[index],weights= weights[index],center=FALSE,control = boost_control(mstop = 100))
  m_boost1=glmboost(x=scale(cbind(as.matrix(data4r)),center=cm,scale=FALSE)[index,],y=Y[index],weights= weights[index],center=FALSE,control = boost_control(mstop = mstop(AIC(m_boost))))
  pred_m=predict(m_boost1,newdata=scale(cbind(as.matrix(data4full)),center=cm,scale=FALSE))[window3]
  errorLCFactor[i]=pred_m-Yfull[window3]
}


errorsCivLabor=list(errorLC,errorLCFactor)


############## RPILess ###########################################



response_data_all=read.csv("/rigel/home/ky2304/Data/RPIlessl12.csv")
#PIf12=read.csv("/rigel/home/ky2304/Data/unratelh1.csv")
data2f=read.csv("/rigel/home/ky2304/Data/MacroFinal2.csv")
response_AR_all=read.csv("/rigel/home/ky2304/Data/RPIlessl1.csv")

l=length(windows[[jobid]])
window1=l

## need to create this to get the length of the dataset for the covariates
## since we lose 3 points to creating lags. And we need to be 12 (forecast_horizon)
## points behind the response.

window2=window1-(forecast_horizon+nlags)

## need this to get the length of the response once we lose 3 points
## to creating lags.
window3=window1-nlags

## create our response.
response_data_all=response_data_all[,2]*(1200/forecast_horizon)

response=response_data_all[windows[[jobid]]]
Yfull=response[-c(1,2,3)]
Y=Yfull[c((1):(window2))]

## create our AR terms.
response_AR_all=1200*response_AR_all[,2]


## create lags of the AR term.
response_AR=response_AR_all[windows[[jobid]]]
response_ARlags=cbind(response_AR,lagpad(response_AR,1),lagpad(response_AR,2),lagpad(response_AR,3))
Xfull=response_ARlags[-c(1,2,3),]
X=as.matrix(Xfull[c((1):(window2)),])

## subset the correct window for the covariates
data2=data2f[windows[[jobid]],]

## create factors

factors_no_lags=prcomp(data2,center=TRUE,scale.=TRUE)$x[,c(1:8)];names2=colnames(data2)

factors_with_lags=data.frame(matrix(0,nrow=nrow(factors_no_lags),ncol=4*ncol(factors_no_lags)))


names3=c()
for(j in 1:ncol(factors_no_lags))
{
  names3[4*j-3]=names2[j]
  names3[4*j-2]=paste(names2[j],"lag",1)
  names3[4*j-1]=paste(names2[j],"lag",2)
  names3[4*j]=paste(names2[j],"lag",3)
  
  factors_with_lags[,4*j-3]<-factors_no_lags[,j]
  factors_with_lags[,4*j-2]<-lagpad(factors_no_lags[,j],1)
  factors_with_lags[,4*j-1]<-lagpad(factors_no_lags[,j],2)
  factors_with_lags[,4*j]<-lagpad(factors_no_lags[,j],3)
  
}

factors_with_lags_full=factors_with_lags[-c(1:nlags),]
factors_with_lags_reduced=factors_with_lags[-c(1:nlags,(window1-forecast_horizon+1):window1),]


data4r=cbind(X,factors_with_lags_reduced)
data4full=cbind(Xfull,factors_with_lags_full)



#now lets create the same for the covariates without factors.

covs_with_lags = data.frame(matrix(0,nrow=nrow(data2),ncol=4*ncol(data2)))


names3=c()
for(j in 1:ncol(data2))
{
  names3[4*j-3]=names2[j]
  names3[4*j-2]=paste(names2[j],"lag",1)
  names3[4*j-1]=paste(names2[j],"lag",2)
  names3[4*j]=paste(names2[j],"lag",3)
  
  covs_with_lags[,4*j-3]<-data2[,j]
  covs_with_lags[,4*j-2]<-lagpad(data2[,j],1)
  covs_with_lags[,4*j-1]<-lagpad(data2[,j],2)
  covs_with_lags[,4*j]<-lagpad(data2[,j],3)
  
}

covs_with_lags_full=covs_with_lags[-c(1:nlags),]
covs_with_lags_reduced=covs_with_lags[-c(1:nlags,(window1-forecast_horizon+1):window1),]


grid=seq(.3,1,length.out=ngrid)
n=length(Y)

errorLC=c()
errorLCFactor=c()
for(i in 1:length(grid)){
  
  ### LC Boost
  
  grid2=(1:nrow(X))/nrow(X)
  w=1-grid2
  weights=.kernel(x = w, bw = grid[i], tkernel = "Unif", N = 1)
  index=(weights>0)
  cm=apply(cbind(X,covs_with_lags_reduced),2,weighted.mean,w=weights)
  m_boost=glmboost(x=scale(cbind(X,covs_with_lags_reduced),center=cm,scale=FALSE)[index,],y=Y[index],weights= weights[index],center=FALSE,control = boost_control(mstop = 100))
  m_boost1=glmboost(x=scale(cbind(X,covs_with_lags_reduced),center=cm,scale=FALSE)[index,],y=Y[index],weights= weights[index],center=FALSE,control = boost_control(mstop = mstop(AIC(m_boost))))
  pred_m=predict(m_boost1,newdata=scale(cbind(Xfull,covs_with_lags_full),center=cm,scale=FALSE))[window3]
  errorLC[i]=pred_m-Yfull[window3]
  
  ## LC Factor Boost
  
  grid2=(1:nrow(X))/nrow(X)
  w=1-grid2
  weights=.kernel(x = w, bw = grid[i], tkernel = "Unif", N = 1)
  index=(weights>0)
  cm=apply(cbind(data4r),2,weighted.mean,w=weights)
  m_boost=glmboost(x=scale(cbind(as.matrix(data4r)),center=cm,scale=FALSE)[index,],y=Y[index],weights= weights[index],center=FALSE,control = boost_control(mstop = 100))
  m_boost1=glmboost(x=scale(cbind(as.matrix(data4r)),center=cm,scale=FALSE)[index,],y=Y[index],weights= weights[index],center=FALSE,control = boost_control(mstop = mstop(AIC(m_boost))))
  pred_m=predict(m_boost1,newdata=scale(cbind(as.matrix(data4full)),center=cm,scale=FALSE))[window3]
  errorLCFactor[i]=pred_m-Yfull[window3]
}

errorsRPIless=list(errorLC,errorLCFactor)

########### CPI #######################################################


response_data_all=read.csv("/rigel/home/ky2304/Data/CPIl12.csv")
#PIf12=read.csv("/rigel/home/ky2304/Data/unratelh1.csv")
data2f=read.csv("/rigel/home/ky2304/Data/MacroFinal2.csv")
response_AR_all=read.csv("/rigel/home/ky2304/Data/CPIl1.csv")


l=length(windows[[jobid]])
window1=l

## need to create this to get the length of the dataset for the covariates
## since we lose 3 points to creating lags. And we need to be 12 (forecast_horizon)
## points behind the response.

window2=window1-(forecast_horizon+nlags)

## need this to get the length of the response once we lose 3 points
## to creating lags.
window3=window1-nlags

## create our response.
response_data_all=response_data_all[,2]*(1200/forecast_horizon)

response=response_data_all[windows[[jobid]]]
Yfull=response[-c(1,2,3)]
Y=Yfull[c((1):(window2))]

## create our AR terms.
response_AR_all=1200*response_AR_all[,2]


## create lags of the AR term.
response_AR=response_AR_all[windows[[jobid]]]
response_ARlags=cbind(response_AR,lagpad(response_AR,1),lagpad(response_AR,2),lagpad(response_AR,3))
Xfull=response_ARlags[-c(1,2,3),]
X=as.matrix(Xfull[c((1):(window2)),])

## subset the correct window for the covariates
data2=data2f[windows[[jobid]],]

## create factors

factors_no_lags=prcomp(data2,center=TRUE,scale.=TRUE)$x[,c(1:8)];names2=colnames(data2)

factors_with_lags=data.frame(matrix(0,nrow=nrow(factors_no_lags),ncol=4*ncol(factors_no_lags)))


names3=c()
for(j in 1:ncol(factors_no_lags))
{
  names3[4*j-3]=names2[j]
  names3[4*j-2]=paste(names2[j],"lag",1)
  names3[4*j-1]=paste(names2[j],"lag",2)
  names3[4*j]=paste(names2[j],"lag",3)
  
  factors_with_lags[,4*j-3]<-factors_no_lags[,j]
  factors_with_lags[,4*j-2]<-lagpad(factors_no_lags[,j],1)
  factors_with_lags[,4*j-1]<-lagpad(factors_no_lags[,j],2)
  factors_with_lags[,4*j]<-lagpad(factors_no_lags[,j],3)
  
}

factors_with_lags_full=factors_with_lags[-c(1:nlags),]
factors_with_lags_reduced=factors_with_lags[-c(1:nlags,(window1-forecast_horizon+1):window1),]


data4r=cbind(X,factors_with_lags_reduced)
data4full=cbind(Xfull,factors_with_lags_full)



#now lets create the same for the covariates without factors.

covs_with_lags = data.frame(matrix(0,nrow=nrow(data2),ncol=4*ncol(data2)))


names3=c()
for(j in 1:ncol(data2))
{
  names3[4*j-3]=names2[j]
  names3[4*j-2]=paste(names2[j],"lag",1)
  names3[4*j-1]=paste(names2[j],"lag",2)
  names3[4*j]=paste(names2[j],"lag",3)
  
  covs_with_lags[,4*j-3]<-data2[,j]
  covs_with_lags[,4*j-2]<-lagpad(data2[,j],1)
  covs_with_lags[,4*j-1]<-lagpad(data2[,j],2)
  covs_with_lags[,4*j]<-lagpad(data2[,j],3)
  
}

covs_with_lags_full=covs_with_lags[-c(1:nlags),]
covs_with_lags_reduced=covs_with_lags[-c(1:nlags,(window1-forecast_horizon+1):window1),]


grid=seq(.3,1,length.out=ngrid)
n=length(Y)

errorLC=c()
errorLCFactor=c()
for(i in 1:length(grid)){
  
  ### LC Boost
  
  grid2=(1:nrow(X))/nrow(X)
  w=1-grid2
  weights=.kernel(x = w, bw = grid[i], tkernel = "Unif", N = 1)
  index=(weights>0)
  cm=apply(cbind(X,covs_with_lags_reduced),2,weighted.mean,w=weights)
  m_boost=glmboost(x=scale(cbind(X,covs_with_lags_reduced),center=cm,scale=FALSE)[index,],y=Y[index],weights= weights[index],center=FALSE,control = boost_control(mstop = 100))
  m_boost1=glmboost(x=scale(cbind(X,covs_with_lags_reduced),center=cm,scale=FALSE)[index,],y=Y[index],weights= weights[index],center=FALSE,control = boost_control(mstop = mstop(AIC(m_boost))))
  pred_m=predict(m_boost1,newdata=scale(cbind(Xfull,covs_with_lags_full),center=cm,scale=FALSE))[window3]
  errorLC[i]=pred_m-Yfull[window3]
  
  ## LC Factor Boost
  
  grid2=(1:nrow(X))/nrow(X)
  w=1-grid2
  weights=.kernel(x = w, bw = grid[i], tkernel = "Unif", N = 1)
  index=(weights>0)
  cm=apply(cbind(data4r),2,weighted.mean,w=weights)
  m_boost=glmboost(x=scale(cbind(as.matrix(data4r)),center=cm,scale=FALSE)[index,],y=Y[index],weights= weights[index],center=FALSE,control = boost_control(mstop = 100))
  m_boost1=glmboost(x=scale(cbind(as.matrix(data4r)),center=cm,scale=FALSE)[index,],y=Y[index],weights= weights[index],center=FALSE,control = boost_control(mstop = mstop(AIC(m_boost))))
  pred_m=predict(m_boost1,newdata=scale(cbind(as.matrix(data4full)),center=cm,scale=FALSE))[window3]
  errorLCFactor[i]=pred_m-Yfull[window3]
}


errorsCPI=list(errorLC,errorLCFactor)


############ Fed Funds h=12 ############




response_data_all=read.csv("/rigel/home/ky2304/Data/Fedfundsl12.csv")
#PIf12=read.csv("/rigel/home/ky2304/Data/unratelh1.csv")
data2f=read.csv("/rigel/home/ky2304/Data/MacroFinal2.csv")
response_AR_all=read.csv("/rigel/home/ky2304/Data/Fedfundsl1.csv")


l=length(windows[[jobid]])
window1=l

## need to create this to get the length of the dataset for the covariates
## since we lose 3 points to creating lags. And we need to be 12 (forecast_horizon)
## points behind the response.

window2=window1-(forecast_horizon+nlags)

## need this to get the length of the response once we lose 3 points
## to creating lags.
window3=window1-nlags

## create our response.
response_data_all=response_data_all[,2]*(1200/forecast_horizon)

response=response_data_all[windows[[jobid]]]
Yfull=response[-c(1,2,3)]
Y=Yfull[c((1):(window2))]

## create our AR terms.
response_AR_all=1200*response_AR_all[,2]


## create lags of the AR term.
response_AR=response_AR_all[windows[[jobid]]]
response_ARlags=cbind(response_AR,lagpad(response_AR,1),lagpad(response_AR,2),lagpad(response_AR,3))
Xfull=response_ARlags[-c(1,2,3),]
X=as.matrix(Xfull[c((1):(window2)),])

## subset the correct window for the covariates
data2=data2f[windows[[jobid]],]

## create factors

factors_no_lags=prcomp(data2,center=TRUE,scale.=TRUE)$x[,c(1:8)];names2=colnames(data2)

factors_with_lags=data.frame(matrix(0,nrow=nrow(factors_no_lags),ncol=4*ncol(factors_no_lags)))


names3=c()
for(j in 1:ncol(factors_no_lags))
{
  names3[4*j-3]=names2[j]
  names3[4*j-2]=paste(names2[j],"lag",1)
  names3[4*j-1]=paste(names2[j],"lag",2)
  names3[4*j]=paste(names2[j],"lag",3)
  
  factors_with_lags[,4*j-3]<-factors_no_lags[,j]
  factors_with_lags[,4*j-2]<-lagpad(factors_no_lags[,j],1)
  factors_with_lags[,4*j-1]<-lagpad(factors_no_lags[,j],2)
  factors_with_lags[,4*j]<-lagpad(factors_no_lags[,j],3)
  
}

factors_with_lags_full=factors_with_lags[-c(1:nlags),]
factors_with_lags_reduced=factors_with_lags[-c(1:nlags,(window1-forecast_horizon+1):window1),]


data4r=cbind(X,factors_with_lags_reduced)
data4full=cbind(Xfull,factors_with_lags_full)



#now lets create the same for the covariates without factors.

covs_with_lags = data.frame(matrix(0,nrow=nrow(data2),ncol=4*ncol(data2)))


names3=c()
for(j in 1:ncol(data2))
{
  names3[4*j-3]=names2[j]
  names3[4*j-2]=paste(names2[j],"lag",1)
  names3[4*j-1]=paste(names2[j],"lag",2)
  names3[4*j]=paste(names2[j],"lag",3)
  
  covs_with_lags[,4*j-3]<-data2[,j]
  covs_with_lags[,4*j-2]<-lagpad(data2[,j],1)
  covs_with_lags[,4*j-1]<-lagpad(data2[,j],2)
  covs_with_lags[,4*j]<-lagpad(data2[,j],3)
  
}

covs_with_lags_full=covs_with_lags[-c(1:nlags),]
covs_with_lags_reduced=covs_with_lags[-c(1:nlags,(window1-forecast_horizon+1):window1),]


grid=seq(.3,1,length.out=ngrid)
n=length(Y)

errorLC=c()
errorLCFactor=c()
for(i in 1:length(grid)){
  
  ### LC Boost
  
  grid2=(1:nrow(X))/nrow(X)
  w=1-grid2
  weights=.kernel(x = w, bw = grid[i], tkernel = "Unif", N = 1)
  index=(weights>0)
  cm=apply(cbind(X,covs_with_lags_reduced),2,weighted.mean,w=weights)
  m_boost=glmboost(x=scale(cbind(X,covs_with_lags_reduced),center=cm,scale=FALSE)[index,],y=Y[index],weights= weights[index],center=FALSE,control = boost_control(mstop = 100))
  m_boost1=glmboost(x=scale(cbind(X,covs_with_lags_reduced),center=cm,scale=FALSE)[index,],y=Y[index],weights= weights[index],center=FALSE,control = boost_control(mstop = mstop(AIC(m_boost))))
  pred_m=predict(m_boost1,newdata=scale(cbind(Xfull,covs_with_lags_full),center=cm,scale=FALSE))[window3]
  errorLC[i]=pred_m-Yfull[window3]
  
  ## LC Factor Boost
  
  grid2=(1:nrow(X))/nrow(X)
  w=1-grid2
  weights=.kernel(x = w, bw = grid[i], tkernel = "Unif", N = 1)
  index=(weights>0)
  cm=apply(cbind(data4r),2,weighted.mean,w=weights)
  m_boost=glmboost(x=scale(cbind(as.matrix(data4r)),center=cm,scale=FALSE)[index,],y=Y[index],weights= weights[index],center=FALSE,control = boost_control(mstop = 100))
  m_boost1=glmboost(x=scale(cbind(as.matrix(data4r)),center=cm,scale=FALSE)[index,],y=Y[index],weights= weights[index],center=FALSE,control = boost_control(mstop = mstop(AIC(m_boost))))
  pred_m=predict(m_boost1,newdata=scale(cbind(as.matrix(data4full)),center=cm,scale=FALSE))[window3]
  errorLCFactor[i]=pred_m-Yfull[window3]
}



errorsFF=list(errorLC,errorLCFactor)



############ TB3MS ####################


response_data_all=read.csv("/rigel/home/ky2304/Data/TB3MSl12.csv")
#PIf12=read.csv("/rigel/home/ky2304/Data/unratelh1.csv")
data2f=read.csv("/rigel/home/ky2304/Data/MacroFinal2.csv")
response_AR_all=read.csv("/rigel/home/ky2304/Data/TB3MSl1.csv")


l=length(windows[[jobid]])
window1=l

## need to create this to get the length of the dataset for the covariates
## since we lose 3 points to creating lags. And we need to be 12 (forecast_horizon)
## points behind the response.

window2=window1-(forecast_horizon+nlags)

## need this to get the length of the response once we lose 3 points
## to creating lags.
window3=window1-nlags

## create our response.
response_data_all=response_data_all[,2]*(1200/forecast_horizon)

response=response_data_all[windows[[jobid]]]
Yfull=response[-c(1,2,3)]
Y=Yfull[c((1):(window2))]

## create our AR terms.
response_AR_all=1200*response_AR_all[,2]


## create lags of the AR term.
response_AR=response_AR_all[windows[[jobid]]]
response_ARlags=cbind(response_AR,lagpad(response_AR,1),lagpad(response_AR,2),lagpad(response_AR,3))
Xfull=response_ARlags[-c(1,2,3),]
X=as.matrix(Xfull[c((1):(window2)),])

## subset the correct window for the covariates
data2=data2f[windows[[jobid]],]

## create factors

factors_no_lags=prcomp(data2,center=TRUE,scale.=TRUE)$x[,c(1:8)];names2=colnames(data2)

factors_with_lags=data.frame(matrix(0,nrow=nrow(factors_no_lags),ncol=4*ncol(factors_no_lags)))


names3=c()
for(j in 1:ncol(factors_no_lags))
{
  names3[4*j-3]=names2[j]
  names3[4*j-2]=paste(names2[j],"lag",1)
  names3[4*j-1]=paste(names2[j],"lag",2)
  names3[4*j]=paste(names2[j],"lag",3)
  
  factors_with_lags[,4*j-3]<-factors_no_lags[,j]
  factors_with_lags[,4*j-2]<-lagpad(factors_no_lags[,j],1)
  factors_with_lags[,4*j-1]<-lagpad(factors_no_lags[,j],2)
  factors_with_lags[,4*j]<-lagpad(factors_no_lags[,j],3)
  
}

factors_with_lags_full=factors_with_lags[-c(1:nlags),]
factors_with_lags_reduced=factors_with_lags[-c(1:nlags,(window1-forecast_horizon+1):window1),]


data4r=cbind(X,factors_with_lags_reduced)
data4full=cbind(Xfull,factors_with_lags_full)



#now lets create the same for the covariates without factors.

covs_with_lags = data.frame(matrix(0,nrow=nrow(data2),ncol=4*ncol(data2)))


names3=c()
for(j in 1:ncol(data2))
{
  names3[4*j-3]=names2[j]
  names3[4*j-2]=paste(names2[j],"lag",1)
  names3[4*j-1]=paste(names2[j],"lag",2)
  names3[4*j]=paste(names2[j],"lag",3)
  
  covs_with_lags[,4*j-3]<-data2[,j]
  covs_with_lags[,4*j-2]<-lagpad(data2[,j],1)
  covs_with_lags[,4*j-1]<-lagpad(data2[,j],2)
  covs_with_lags[,4*j]<-lagpad(data2[,j],3)
  
}

covs_with_lags_full=covs_with_lags[-c(1:nlags),]
covs_with_lags_reduced=covs_with_lags[-c(1:nlags,(window1-forecast_horizon+1):window1),]


grid=seq(.3,1,length.out=ngrid)
n=length(Y)

errorLC=c()
errorLCFactor=c()
for(i in 1:length(grid)){
  
  ### LC Boost
  
  grid2=(1:nrow(X))/nrow(X)
  w=1-grid2
  weights=.kernel(x = w, bw = grid[i], tkernel = "Unif", N = 1)
  index=(weights>0)
  cm=apply(cbind(X,covs_with_lags_reduced),2,weighted.mean,w=weights)
  m_boost=glmboost(x=scale(cbind(X,covs_with_lags_reduced),center=cm,scale=FALSE)[index,],y=Y[index],weights= weights[index],center=FALSE,control = boost_control(mstop = 100))
  m_boost1=glmboost(x=scale(cbind(X,covs_with_lags_reduced),center=cm,scale=FALSE)[index,],y=Y[index],weights= weights[index],center=FALSE,control = boost_control(mstop = mstop(AIC(m_boost))))
  pred_m=predict(m_boost1,newdata=scale(cbind(Xfull,covs_with_lags_full),center=cm,scale=FALSE))[window3]
  errorLC[i]=pred_m-Yfull[window3]
  
  ## LC Factor Boost
  
  grid2=(1:nrow(X))/nrow(X)
  w=1-grid2
  weights=.kernel(x = w, bw = grid[i], tkernel = "Unif", N = 1)
  index=(weights>0)
  cm=apply(cbind(data4r),2,weighted.mean,w=weights)
  m_boost=glmboost(x=scale(cbind(as.matrix(data4r)),center=cm,scale=FALSE)[index,],y=Y[index],weights= weights[index],center=FALSE,control = boost_control(mstop = 100))
  m_boost1=glmboost(x=scale(cbind(as.matrix(data4r)),center=cm,scale=FALSE)[index,],y=Y[index],weights= weights[index],center=FALSE,control = boost_control(mstop = mstop(AIC(m_boost))))
  pred_m=predict(m_boost1,newdata=scale(cbind(as.matrix(data4full)),center=cm,scale=FALSE))[window3]
  errorLCFactor[i]=pred_m-Yfull[window3]
}



errorsTB3MS=list(errorLC,errorLCFactor)



errorsFULL=list(errorsIP,errorsEMS,errorsUNRATE,errorsCivLabor,errorsRPIless,errorsCPI,errorsFF,errorsTB3MS)

save(errorsFULL,file=paste0('resultsTVP/LCh12CV_replication-',jobid,'.RData'))

