jobid = as.numeric(Sys.getenv("SLURM_ARRAY_TASK_ID"))
.libPaths('../rpackages')


library(mboost)
library(glmnet)
set.seed(jobid)


## come helper functions

## creates lags of order K and pads start with NAs.
lagpad <- function(x, k) {
  c(rep(NA, k), x)[1 : length(x)] 
}


##kernel function

.kernel <- function(x, bw, tkernel = "Gaussian", N = 1)
{
  x <- x/(N * bw)
  value <- numeric(length(x))
  if (tkernel == "Gaussian")
  {
    value <- exp(-0.5 * x^2)/2.506628274631000241612355239340104162693023681640625 #sqrt(2*pi)
  }
  if(tkernel == "Epa")
  {
    index <- (x >= -1 & x <= 1)
    
    value[index] <- .75 * (1 - x[index]^2)
  }
  
  if(tkernel == "Unif")
  {
    index <- (x >= -1 & x <= 1)
    
    value[index] <- 1 
  }
  return(value)
  
}

## some constants to set

# size of the grid from which to select the bandwidth of the kernel
ngrid=29
## number of points in the cross validation set.
n_cv=60



## other constants 


forecast_horizon=12
## number of lags for each predictor
nlags=3


## calculate the length between the start of the training data and the test data.
train_start_date = strptime("1960-03-01", "%Y-%m-%d")
test_start_date = strptime("1971-10-01", "%Y-%m-%d")
len_diff = length(seq(from=train_start_date, to=test_start_date, by='month'))

# determines the end date of the training period of the first forecast in
## our cross validation period.
w1=len_diff-forecast_horizon-(forecast_horizon+n_cv)




## we now create a set of windows. Each one specifying the training period 
## for a different cross validation forecast. Runs from the beginning to the
## end.
windows <- list()
for(i in 0:(567+n_cv)) windows[[i+1]] <- seq(1,i+w1)




### Industrial Production h = 12



## load the response
response_data_all=read.csv("/rigel/home/ky2304/Data/IPl12.csv")
## load the covariates and the autoregressive term.
data2f=read.csv("/rigel/home/ky2304/Data/MacroFinal2.csv")
response_AR_all=read.csv("/rigel/home/ky2304/Data/IPl1.csv")




l=length(windows[[jobid]])
window1=l

## need to create this to get the length of the dataset for the covariates
## since we lose 3 points to creating lags. And we need to be 12 (forecast_horizon)
## points behind the response.

window2=window1-(forecast_horizon+nlags)

## need this to get the length of the response once we lose 3 points
## to creating lags.
window3=window1-nlags

## create our response.
response_data_all=response_data_all[,2]*(1200/forecast_horizon)

response=response_data_all[windows[[jobid]]]
Yfull=response[-c(1,2,3)]
Y=Yfull[c((1):(window2))]

## create our AR terms.
response_AR_all=1200*response_AR_all[,2]


## create lags of the AR term.
response_AR=response_AR_all[windows[[jobid]]]
response_ARlags=cbind(response_AR,lagpad(response_AR,1),lagpad(response_AR,2),lagpad(response_AR,3))
Xfull=response_ARlags[-c(1,2,3),]
X=as.matrix(Xfull[c((1):(window2)),])

## subset the correct window for the covariates. Remove Oilprices as 
## the start of the series has all zeroes which was causing issues.
data2=data2f[windows[[jobid]],][,-101]

## create factors

factors_no_lags=prcomp(data2,center=TRUE,scale.=TRUE)$x[,c(1:8)];names2=colnames(data2)

factors_with_lags=data.frame(matrix(0,nrow=nrow(factors_no_lags),ncol=4*ncol(factors_no_lags)))


names3=c()
for(j in 1:ncol(factors_no_lags))
{
  names3[4*j-3]=names2[j]
  names3[4*j-2]=paste(names2[j],"lag",1)
  names3[4*j-1]=paste(names2[j],"lag",2)
  names3[4*j]=paste(names2[j],"lag",3)
  
  factors_with_lags[,4*j-3]<-factors_no_lags[,j]
  factors_with_lags[,4*j-2]<-lagpad(factors_no_lags[,j],1)
  factors_with_lags[,4*j-1]<-lagpad(factors_no_lags[,j],2)
  factors_with_lags[,4*j]<-lagpad(factors_no_lags[,j],3)
  
}

factors_with_lags_full=factors_with_lags[-c(1:nlags),]
factors_with_lags_reduced=factors_with_lags[-c(1:nlags,(window1-forecast_horizon+1):window1),]


data4r=cbind(X,factors_with_lags_reduced)
data4full=cbind(Xfull,factors_with_lags_full)


grid=seq(.3,1,length.out=29)
n=length(Y)

errorLL=c()
for(i in 1:length(grid)){
  
  ### LL Boost
  Z2=data4full
  grid2=(1:nrow(Z2))/nrow(Z2)
  Z3=cbind(Z2,Z2*(grid2-1))
  Z3=data.frame(Z3)
  colnames(Z3)<-paste0("Z",1:ncol(Z3))
  
  Z4=Z3[1:(nrow(Z2)-forecast_horizon),]
  a=paste0("Y~",paste0(apply(matrix(1:ncol(Z4), ncol = 2, byrow = FALSE), 1, function(vec) paste0("bols(Z",vec[1],",Z",vec[2], ")")),collapse = " + "))
  w=1-(1:nrow(Z4))/nrow(Z4)
  weights=.kernel(x = w, bw = grid[i], tkernel = "Gaussian", N = 1)
  index=(weights>0)
  boost_m3=gamboost(as.formula(a),weights= weights,data=Z4,control = boost_control(mstop = 100,nu=.1))
  pred1=predict(boost_m3,newdata=Z3[(nrow(Z2)),])
  
  errorLL[i]=pred1-Yfull[window3]
  
}


errorsIP=list(errorLL)


############################ EMS h=12 #############################



response_data_all=read.csv("/rigel/home/ky2304/Data/emsl12.csv")
data2f=read.csv("/rigel/home/ky2304/Data/MacroFinal2.csv")
response_AR_all=read.csv("/rigel/home/ky2304/Data/emsl1.csv")




l=length(windows[[jobid]])
window1=l

## need to create this to get the length of the dataset for the covariates
## since we lose 3 points to creating lags. And we need to be 12 (forecast_horizon)
## points behind the response.

window2=window1-(forecast_horizon+nlags)

## need this to get the length of the response once we lose 3 points
## to creating lags.
window3=window1-nlags

## create our response.
response_data_all=response_data_all[,2]*(1200/forecast_horizon)

response=response_data_all[windows[[jobid]]]
Yfull=response[-c(1,2,3)]
Y=Yfull[c((1):(window2))]

## create our AR terms.
response_AR_all=1200*response_AR_all[,2]


## create lags of the AR term.
response_AR=response_AR_all[windows[[jobid]]]
response_ARlags=cbind(response_AR,lagpad(response_AR,1),lagpad(response_AR,2),lagpad(response_AR,3))
Xfull=response_ARlags[-c(1,2,3),]
X=as.matrix(Xfull[c((1):(window2)),])

## subset the correct window for the covariates
data2=data2f[windows[[jobid]],][,-101]

## create factors

factors_no_lags=prcomp(data2,center=TRUE,scale.=TRUE)$x[,c(1:8)];names2=colnames(data2)

factors_with_lags=data.frame(matrix(0,nrow=nrow(factors_no_lags),ncol=4*ncol(factors_no_lags)))


names3=c()
for(j in 1:ncol(factors_no_lags))
{
  names3[4*j-3]=names2[j]
  names3[4*j-2]=paste(names2[j],"lag",1)
  names3[4*j-1]=paste(names2[j],"lag",2)
  names3[4*j]=paste(names2[j],"lag",3)
  
  factors_with_lags[,4*j-3]<-factors_no_lags[,j]
  factors_with_lags[,4*j-2]<-lagpad(factors_no_lags[,j],1)
  factors_with_lags[,4*j-1]<-lagpad(factors_no_lags[,j],2)
  factors_with_lags[,4*j]<-lagpad(factors_no_lags[,j],3)
  
}

factors_with_lags_full=factors_with_lags[-c(1:nlags),]
factors_with_lags_reduced=factors_with_lags[-c(1:nlags,(window1-forecast_horizon+1):window1),]


data4r=cbind(X,factors_with_lags_reduced)
data4full=cbind(Xfull,factors_with_lags_full)


grid=seq(.3,1,length.out=29)
n=length(Y)

errorLL=c()
for(i in 1:length(grid)){
  
  ### LL Boost
  Z2=data4full
  grid2=(1:nrow(Z2))/nrow(Z2)
  Z3=cbind(Z2,Z2*(grid2-1))
  Z3=data.frame(Z3)
  colnames(Z3)<-paste0("Z",1:ncol(Z3))
  
  Z4=Z3[1:(nrow(Z2)-forecast_horizon),]
  a=paste0("Y~",paste0(apply(matrix(1:ncol(Z4), ncol = 2, byrow = FALSE), 1, function(vec) paste0("bols(Z",vec[1],",Z",vec[2], ")")),collapse = " + "))
  w=1-(1:nrow(Z4))/nrow(Z4)
  weights=.kernel(x = w, bw = grid[i], tkernel = "Gaussian", N = 1)
  index=(weights>0)
  boost_m3=gamboost(as.formula(a),weights= weights,data=Z4,control = boost_control(mstop = 100,nu=.1))
  pred1=predict(boost_m3,newdata=Z3[(nrow(Z2)),])
  
  errorLL[i]=pred1-Yfull[window3]
  
}



errorsEMS=list(errorLL)


#### unrate h=12 #######################

mms=c()
nmodels=12


response_data_all=read.csv("/rigel/home/ky2304/Data/unratel12.csv")
data2f=read.csv("/rigel/home/ky2304/Data/MacroFinal2.csv")
response_AR_all=read.csv("/rigel/home/ky2304/Data/unratel1.csv")


l=length(windows[[jobid]])
#window1=l-forecast_horizon
window1=l
## pre recession forecasts
#window1=434-forecast_horizon

window2=window1-(forecast_horizon+nlags)
window3=window1-nlags


response_data_all=response_data_all[,2]*(1200/forecast_horizon)

#response_data_all=response_data_all[,2]

response_AR_all=1200*response_AR_all[,2]

#response_AR_all=response_AR_all[,2]

lagpad <- function(x, k) {
  c(rep(NA, k), x)[1 : length(x)] 
}



PI=response_AR_all[windows[[jobid]]]
PILag1=lagpad(PI,1)
PILag2=lagpad(PI,2)
PILag3=lagpad(PI,3)

data2=data2f[windows[[jobid]],][,-101]
data2full=data2[-c(1:nlags),]
data2r=data2[-c(1:nlags,(window1-forecast_horizon+1):window1),]

data2=prcomp(data2,center=TRUE,scale.=TRUE)$x[,c(1:8)];names2=colnames(data2)

data3=data.frame(matrix(0,nrow=nrow(data2),ncol=4*ncol(data2)))


names3=c()
for(j in 1:ncol(data2))
{
  names3[4*j-3]=names2[j]
  names3[4*j-2]=paste(names2[j],"lag",1)
  names3[4*j-1]=paste(names2[j],"lag",2)
  names3[4*j]=paste(names2[j],"lag",3)
  
  data3[,4*j-3]<-data2[,j]
  data3[,4*j-2]<-lagpad(data2[,j],1)
  data3[,4*j-1]<-lagpad(data2[,j],2)
  data3[,4*j]<-lagpad(data2[,j],3)
  
}

data3full=data3[-c(1:nlags),]
data3r=data3[-c(1:nlags,(window1-forecast_horizon+1):window1),]

factors=prcomp(data3full,center=TRUE,scale.=TRUE)$x[,c(1:20)]
factorlags=cbind(factors[,1],factors[,2],factors[,3],factors[,4])


PIlags=cbind(PI,PILag1,PILag2,PILag3)
PIlags=PIlags[-c(1,2,3),]
PI12=response_data_all[windows[[jobid]]]
Yfull=PI12[-c(1,2,3)]
#Yfull=scale(Yfull)

Xfull=PIlags
X=as.matrix(Xfull[c((1):(window2)),])
Y=Yfull[c((1):(window2))]
factorsr=factorlags[c(1:window2),]
factorsallR=as.matrix(factors[c(1:window2),])


data4r=cbind(X,data3r)
data4full=cbind(Xfull,data3full)
##kernel function

.kernel <- function(x, bw, tkernel = "Gaussian", N = 1)
{
  x <- x/(N * bw)
  value <- numeric(length(x))
  if (tkernel == "Gaussian")
  {
    value <- exp(-0.5 * x^2)/2.506628274631000241612355239340104162693023681640625 #sqrt(2*pi)
  }
  if(tkernel == "Epa")
  {
    index <- (x >= -1 & x <= 1)
    
    value[index] <- .75 * (1 - x[index]^2) #12/11
  }
  
  if(tkernel == "Unif")
  {
    index <- (x >= -1 & x <= 1)
    
    value[index] <- 1 #12/11
  }
  return(value)
  
}

grid=seq(.3,1,length.out=29)
n=length(Y)

errorLL=c()

for(i in 1:length(grid)){
  
  ### LL Boost
  Z2=data4full
  grid2=(1:nrow(Z2))/nrow(Z2)
  Z3=cbind(Z2,Z2*(grid2-1))
  Z3=data.frame(Z3)
  colnames(Z3)<-paste0("Z",1:ncol(Z3))
  
  Z4=Z3[1:(nrow(Z2)-forecast_horizon),]
  a=paste0("Y~",paste0(apply(matrix(1:ncol(Z4), ncol = 2, byrow = FALSE), 1, function(vec) paste0("bols(Z",vec[1],",Z",vec[2], ")")),collapse = " + "))
  w=1-(1:nrow(Z4))/nrow(Z4)
  weights=.kernel(x = w, bw = grid[i], tkernel = "Gaussian", N = 1)
  index=(weights>0)
  
  boost_m3=gamboost(as.formula(a),weights= weights,data=Z4,control = boost_control(mstop = 100,nu=.1))
  
  
  pred1=predict(boost_m3,newdata=Z3[(nrow(Z2)),])
  
  errorLL[i]=pred1-Yfull[window3]
  
}


errorsunrate=list(errorLL)

################CIV Labor##############################


response_data_all=read.csv("/rigel/home/ky2304/Data/CivLaborl12.csv")
data2f=read.csv("/rigel/home/ky2304/Data/MacroFinal2.csv")
response_AR_all=read.csv("/rigel/home/ky2304/Data/CivLaborl1.csv")




l=length(windows[[jobid]])
window1=l

## need to create this to get the length of the dataset for the covariates
## since we lose 3 points to creating lags. And we need to be 12 (forecast_horizon)
## points behind the response.

window2=window1-(forecast_horizon+nlags)

## need this to get the length of the response once we lose 3 points
## to creating lags.
window3=window1-nlags

## create our response.
response_data_all=response_data_all[,2]*(1200/forecast_horizon)

response=response_data_all[windows[[jobid]]]
Yfull=response[-c(1,2,3)]
Y=Yfull[c((1):(window2))]

## create our AR terms.
response_AR_all=1200*response_AR_all[,2]


## create lags of the AR term.
response_AR=response_AR_all[windows[[jobid]]]
response_ARlags=cbind(response_AR,lagpad(response_AR,1),lagpad(response_AR,2),lagpad(response_AR,3))
Xfull=response_ARlags[-c(1,2,3),]
X=as.matrix(Xfull[c((1):(window2)),])

## subset the correct window for the covariates
data2=data2f[windows[[jobid]],][,-101]

## create factors

factors_no_lags=prcomp(data2,center=TRUE,scale.=TRUE)$x[,c(1:8)];names2=colnames(data2)

factors_with_lags=data.frame(matrix(0,nrow=nrow(factors_no_lags),ncol=4*ncol(factors_no_lags)))


names3=c()
for(j in 1:ncol(factors_no_lags))
{
  names3[4*j-3]=names2[j]
  names3[4*j-2]=paste(names2[j],"lag",1)
  names3[4*j-1]=paste(names2[j],"lag",2)
  names3[4*j]=paste(names2[j],"lag",3)
  
  factors_with_lags[,4*j-3]<-factors_no_lags[,j]
  factors_with_lags[,4*j-2]<-lagpad(factors_no_lags[,j],1)
  factors_with_lags[,4*j-1]<-lagpad(factors_no_lags[,j],2)
  factors_with_lags[,4*j]<-lagpad(factors_no_lags[,j],3)
  
}

factors_with_lags_full=factors_with_lags[-c(1:nlags),]
factors_with_lags_reduced=factors_with_lags[-c(1:nlags,(window1-forecast_horizon+1):window1),]


data4r=cbind(X,factors_with_lags_reduced)
data4full=cbind(Xfull,factors_with_lags_full)


grid=seq(.3,1,length.out=29)
n=length(Y)

errorLL=c()
for(i in 1:length(grid)){
  
  ### LL Boost
  Z2=data4full
  grid2=(1:nrow(Z2))/nrow(Z2)
  Z3=cbind(Z2,Z2*(grid2-1))
  Z3=data.frame(Z3)
  colnames(Z3)<-paste0("Z",1:ncol(Z3))
  
  Z4=Z3[1:(nrow(Z2)-forecast_horizon),]
  a=paste0("Y~",paste0(apply(matrix(1:ncol(Z4), ncol = 2, byrow = FALSE), 1, function(vec) paste0("bols(Z",vec[1],",Z",vec[2], ")")),collapse = " + "))
  w=1-(1:nrow(Z4))/nrow(Z4)
  weights=.kernel(x = w, bw = grid[i], tkernel = "Gaussian", N = 1)
  index=(weights>0)
  boost_m3=gamboost(as.formula(a),weights= weights,data=Z4,control = boost_control(mstop = 100,nu=.1))
  pred1=predict(boost_m3,newdata=Z3[(nrow(Z2)),])
  
  errorLL[i]=pred1-Yfull[window3]
  
}

errorsCivLabor=list(errorLL)


############## RPILess ###########################################


response_data_all=read.csv("/rigel/home/ky2304/Data/RPIlessl12.csv")
data2f=read.csv("/rigel/home/ky2304/Data/MacroFinal2.csv")
response_AR_all=read.csv("/rigel/home/ky2304/Data/RPIlessl1.csv")




l=length(windows[[jobid]])
window1=l

## need to create this to get the length of the dataset for the covariates
## since we lose 3 points to creating lags. And we need to be 12 (forecast_horizon)
## points behind the response.

window2=window1-(forecast_horizon+nlags)

## need this to get the length of the response once we lose 3 points
## to creating lags.
window3=window1-nlags

## create our response.
response_data_all=response_data_all[,2]*(1200/forecast_horizon)

response=response_data_all[windows[[jobid]]]
Yfull=response[-c(1,2,3)]
Y=Yfull[c((1):(window2))]

## create our AR terms.
response_AR_all=1200*response_AR_all[,2]


## create lags of the AR term.
response_AR=response_AR_all[windows[[jobid]]]
response_ARlags=cbind(response_AR,lagpad(response_AR,1),lagpad(response_AR,2),lagpad(response_AR,3))
Xfull=response_ARlags[-c(1,2,3),]
X=as.matrix(Xfull[c((1):(window2)),])

## subset the correct window for the covariates
data2=data2f[windows[[jobid]],][,-101]

## create factors

factors_no_lags=prcomp(data2,center=TRUE,scale.=TRUE)$x[,c(1:8)];names2=colnames(data2)

factors_with_lags=data.frame(matrix(0,nrow=nrow(factors_no_lags),ncol=4*ncol(factors_no_lags)))


names3=c()
for(j in 1:ncol(factors_no_lags))
{
  names3[4*j-3]=names2[j]
  names3[4*j-2]=paste(names2[j],"lag",1)
  names3[4*j-1]=paste(names2[j],"lag",2)
  names3[4*j]=paste(names2[j],"lag",3)
  
  factors_with_lags[,4*j-3]<-factors_no_lags[,j]
  factors_with_lags[,4*j-2]<-lagpad(factors_no_lags[,j],1)
  factors_with_lags[,4*j-1]<-lagpad(factors_no_lags[,j],2)
  factors_with_lags[,4*j]<-lagpad(factors_no_lags[,j],3)
  
}

factors_with_lags_full=factors_with_lags[-c(1:nlags),]
factors_with_lags_reduced=factors_with_lags[-c(1:nlags,(window1-forecast_horizon+1):window1),]


data4r=cbind(X,factors_with_lags_reduced)
data4full=cbind(Xfull,factors_with_lags_full)


grid=seq(.3,1,length.out=29)
n=length(Y)

errorLL=c()
for(i in 1:length(grid)){
  
  ### LL Boost
  Z2=data4full
  grid2=(1:nrow(Z2))/nrow(Z2)
  Z3=cbind(Z2,Z2*(grid2-1))
  Z3=data.frame(Z3)
  colnames(Z3)<-paste0("Z",1:ncol(Z3))
  
  Z4=Z3[1:(nrow(Z2)-forecast_horizon),]
  a=paste0("Y~",paste0(apply(matrix(1:ncol(Z4), ncol = 2, byrow = FALSE), 1, function(vec) paste0("bols(Z",vec[1],",Z",vec[2], ")")),collapse = " + "))
  w=1-(1:nrow(Z4))/nrow(Z4)
  weights=.kernel(x = w, bw = grid[i], tkernel = "Gaussian", N = 1)
  index=(weights>0)
  boost_m3=gamboost(as.formula(a),weights= weights,data=Z4,control = boost_control(mstop = 100,nu=.1))
  pred1=predict(boost_m3,newdata=Z3[(nrow(Z2)),])
  
  errorLL[i]=pred1-Yfull[window3]
  
}

errorsRPIless=list(errorLL)

########### CPI #######################################################

response_data_all=read.csv("/rigel/home/ky2304/Data/CPIl12.csv")
data2f=read.csv("/rigel/home/ky2304/Data/MacroFinal2.csv")
response_AR_all=read.csv("/rigel/home/ky2304/Data/CPIl1.csv")


l=length(windows[[jobid]])
window1=l

## need to create this to get the length of the dataset for the covariates
## since we lose 3 points to creating lags. And we need to be 12 (forecast_horizon)
## points behind the response.

window2=window1-(forecast_horizon+nlags)

## need this to get the length of the response once we lose 3 points
## to creating lags.
window3=window1-nlags

## create our response.
response_data_all=response_data_all[,2]*(1200/forecast_horizon)

response=response_data_all[windows[[jobid]]]
Yfull=response[-c(1,2,3)]
Y=Yfull[c((1):(window2))]

## create our AR terms.
response_AR_all=1200*response_AR_all[,2]


## create lags of the AR term.
response_AR=response_AR_all[windows[[jobid]]]
response_ARlags=cbind(response_AR,lagpad(response_AR,1),lagpad(response_AR,2),lagpad(response_AR,3))
Xfull=response_ARlags[-c(1,2,3),]
X=as.matrix(Xfull[c((1):(window2)),])

## subset the correct window for the covariates
data2=data2f[windows[[jobid]],][,-101]

## create factors

factors_no_lags=prcomp(data2,center=TRUE,scale.=TRUE)$x[,c(1:8)];names2=colnames(data2)

factors_with_lags=data.frame(matrix(0,nrow=nrow(factors_no_lags),ncol=4*ncol(factors_no_lags)))


names3=c()
for(j in 1:ncol(factors_no_lags))
{
  names3[4*j-3]=names2[j]
  names3[4*j-2]=paste(names2[j],"lag",1)
  names3[4*j-1]=paste(names2[j],"lag",2)
  names3[4*j]=paste(names2[j],"lag",3)
  
  factors_with_lags[,4*j-3]<-factors_no_lags[,j]
  factors_with_lags[,4*j-2]<-lagpad(factors_no_lags[,j],1)
  factors_with_lags[,4*j-1]<-lagpad(factors_no_lags[,j],2)
  factors_with_lags[,4*j]<-lagpad(factors_no_lags[,j],3)
  
}

factors_with_lags_full=factors_with_lags[-c(1:nlags),]
factors_with_lags_reduced=factors_with_lags[-c(1:nlags,(window1-forecast_horizon+1):window1),]


data4r=cbind(X,factors_with_lags_reduced)
data4full=cbind(Xfull,factors_with_lags_full)


grid=seq(.3,1,length.out=29)
n=length(Y)

errorLL=c()
for(i in 1:length(grid)){
  
  ### LL Boost
  Z2=data4full
  grid2=(1:nrow(Z2))/nrow(Z2)
  Z3=cbind(Z2,Z2*(grid2-1))
  Z3=data.frame(Z3)
  colnames(Z3)<-paste0("Z",1:ncol(Z3))
  
  Z4=Z3[1:(nrow(Z2)-forecast_horizon),]
  a=paste0("Y~",paste0(apply(matrix(1:ncol(Z4), ncol = 2, byrow = FALSE), 1, function(vec) paste0("bols(Z",vec[1],",Z",vec[2], ")")),collapse = " + "))
  w=1-(1:nrow(Z4))/nrow(Z4)
  weights=.kernel(x = w, bw = grid[i], tkernel = "Gaussian", N = 1)
  index=(weights>0)
  boost_m3=gamboost(as.formula(a),weights= weights,data=Z4,control = boost_control(mstop = 100,nu=.1))
  pred1=predict(boost_m3,newdata=Z3[(nrow(Z2)),])
  
  errorLL[i]=pred1-Yfull[window3]
  
}

errorsCPI=list(errorLL)


########### FedFunds #######################################################

response_data_all=read.csv("/rigel/home/ky2304/Data/Fedfundsl12.csv")
data2f=read.csv("/rigel/home/ky2304/Data/MacroFinal2.csv")
response_AR_all=read.csv("/rigel/home/ky2304/Data/Fedfundsl1.csv")


l=length(windows[[jobid]])
window1=l

## need to create this to get the length of the dataset for the covariates
## since we lose 3 points to creating lags. And we need to be 12 (forecast_horizon)
## points behind the response.

window2=window1-(forecast_horizon+nlags)

## need this to get the length of the response once we lose 3 points
## to creating lags.
window3=window1-nlags

## create our response.
response_data_all=response_data_all[,2]*(1200/forecast_horizon)

response=response_data_all[windows[[jobid]]]
Yfull=response[-c(1,2,3)]
Y=Yfull[c((1):(window2))]

## create our AR terms.
response_AR_all=1200*response_AR_all[,2]


## create lags of the AR term.
response_AR=response_AR_all[windows[[jobid]]]
response_ARlags=cbind(response_AR,lagpad(response_AR,1),lagpad(response_AR,2),lagpad(response_AR,3))
Xfull=response_ARlags[-c(1,2,3),]
X=as.matrix(Xfull[c((1):(window2)),])

## subset the correct window for the covariates
data2=data2f[windows[[jobid]],][,-101]

## create factors

factors_no_lags=prcomp(data2,center=TRUE,scale.=TRUE)$x[,c(1:8)];names2=colnames(data2)

factors_with_lags=data.frame(matrix(0,nrow=nrow(factors_no_lags),ncol=4*ncol(factors_no_lags)))


names3=c()
for(j in 1:ncol(factors_no_lags))
{
  names3[4*j-3]=names2[j]
  names3[4*j-2]=paste(names2[j],"lag",1)
  names3[4*j-1]=paste(names2[j],"lag",2)
  names3[4*j]=paste(names2[j],"lag",3)
  
  factors_with_lags[,4*j-3]<-factors_no_lags[,j]
  factors_with_lags[,4*j-2]<-lagpad(factors_no_lags[,j],1)
  factors_with_lags[,4*j-1]<-lagpad(factors_no_lags[,j],2)
  factors_with_lags[,4*j]<-lagpad(factors_no_lags[,j],3)
  
}

factors_with_lags_full=factors_with_lags[-c(1:nlags),]
factors_with_lags_reduced=factors_with_lags[-c(1:nlags,(window1-forecast_horizon+1):window1),]


data4r=cbind(X,factors_with_lags_reduced)
data4full=cbind(Xfull,factors_with_lags_full)


grid=seq(.3,1,length.out=29)
n=length(Y)

errorLL=c()
for(i in 1:length(grid)){
  
  ### LL Boost
  Z2=data4full
  grid2=(1:nrow(Z2))/nrow(Z2)
  Z3=cbind(Z2,Z2*(grid2-1))
  Z3=data.frame(Z3)
  colnames(Z3)<-paste0("Z",1:ncol(Z3))
  
  Z4=Z3[1:(nrow(Z2)-forecast_horizon),]
  a=paste0("Y~",paste0(apply(matrix(1:ncol(Z4), ncol = 2, byrow = FALSE), 1, function(vec) paste0("bols(Z",vec[1],",Z",vec[2], ")")),collapse = " + "))
  w=1-(1:nrow(Z4))/nrow(Z4)
  weights=.kernel(x = w, bw = grid[i], tkernel = "Gaussian", N = 1)
  index=(weights>0)
  boost_m3=gamboost(as.formula(a),weights= weights,data=Z4,control = boost_control(mstop = 100,nu=.1))
  pred1=predict(boost_m3,newdata=Z3[(nrow(Z2)),])
  
  errorLL[i]=pred1-Yfull[window3]
  
}

errorsFF=list(errorLL)



########### TB3MS #######################################################

response_data_all=read.csv("/rigel/home/ky2304/Data/TB3MSl12.csv")
data2f=read.csv("/rigel/home/ky2304/Data/MacroFinal2.csv")
response_AR_all=read.csv("/rigel/home/ky2304/Data/TB3MSl1.csv")


l=length(windows[[jobid]])
window1=l

## need to create this to get the length of the dataset for the covariates
## since we lose 3 points to creating lags. And we need to be 12 (forecast_horizon)
## points behind the response.

window2=window1-(forecast_horizon+nlags)

## need this to get the length of the response once we lose 3 points
## to creating lags.
window3=window1-nlags

## create our response.
response_data_all=response_data_all[,2]*(1200/forecast_horizon)

response=response_data_all[windows[[jobid]]]
Yfull=response[-c(1,2,3)]
Y=Yfull[c((1):(window2))]

## create our AR terms.
response_AR_all=1200*response_AR_all[,2]


## create lags of the AR term.
response_AR=response_AR_all[windows[[jobid]]]
response_ARlags=cbind(response_AR,lagpad(response_AR,1),lagpad(response_AR,2),lagpad(response_AR,3))
Xfull=response_ARlags[-c(1,2,3),]
X=as.matrix(Xfull[c((1):(window2)),])

## subset the correct window for the covariates
data2=data2f[windows[[jobid]],][,-101]

## create factors

factors_no_lags=prcomp(data2,center=TRUE,scale.=TRUE)$x[,c(1:8)];names2=colnames(data2)

factors_with_lags=data.frame(matrix(0,nrow=nrow(factors_no_lags),ncol=4*ncol(factors_no_lags)))


names3=c()
for(j in 1:ncol(factors_no_lags))
{
  names3[4*j-3]=names2[j]
  names3[4*j-2]=paste(names2[j],"lag",1)
  names3[4*j-1]=paste(names2[j],"lag",2)
  names3[4*j]=paste(names2[j],"lag",3)
  
  factors_with_lags[,4*j-3]<-factors_no_lags[,j]
  factors_with_lags[,4*j-2]<-lagpad(factors_no_lags[,j],1)
  factors_with_lags[,4*j-1]<-lagpad(factors_no_lags[,j],2)
  factors_with_lags[,4*j]<-lagpad(factors_no_lags[,j],3)
  
}

factors_with_lags_full=factors_with_lags[-c(1:nlags),]
factors_with_lags_reduced=factors_with_lags[-c(1:nlags,(window1-forecast_horizon+1):window1),]


data4r=cbind(X,factors_with_lags_reduced)
data4full=cbind(Xfull,factors_with_lags_full)


grid=seq(.3,1,length.out=29)
n=length(Y)

errorLL=c()
for(i in 1:length(grid)){
  
  ### LL Boost
  Z2=data4full
  grid2=(1:nrow(Z2))/nrow(Z2)
  Z3=cbind(Z2,Z2*(grid2-1))
  Z3=data.frame(Z3)
  colnames(Z3)<-paste0("Z",1:ncol(Z3))
  
  Z4=Z3[1:(nrow(Z2)-forecast_horizon),]
  a=paste0("Y~",paste0(apply(matrix(1:ncol(Z4), ncol = 2, byrow = FALSE), 1, function(vec) paste0("bols(Z",vec[1],",Z",vec[2], ")")),collapse = " + "))
  w=1-(1:nrow(Z4))/nrow(Z4)
  weights=.kernel(x = w, bw = grid[i], tkernel = "Gaussian", N = 1)
  index=(weights>0)
  boost_m3=gamboost(as.formula(a),weights= weights,data=Z4,control = boost_control(mstop = 100,nu=.1))
  pred1=predict(boost_m3,newdata=Z3[(nrow(Z2)),])
  
  errorLL[i]=pred1-Yfull[window3]
  
}

errorsTB3MS=list(errorLL)



errorsFULL=list(errorsIP,errorsEMS,errorsunrate,errorsCivLabor,errorsRPIless,errorsCPI,errorsFF,errorsTB3MS)

save(errorsFULL,file=paste0('resultsTVP/LLh12CV_replication-',jobid,'.RData'))

