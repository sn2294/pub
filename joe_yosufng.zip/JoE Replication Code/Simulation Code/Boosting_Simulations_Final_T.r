jobid = as.numeric(Sys.getenv("SLURM_ARRAY_TASK_ID"))

randSeed = as.numeric(Sys.getenv("SLURM_ARRAY_TASK_ID"))
.libPaths('../rpackages')
set.seed(jobid)

#source('funs.r')
library(energy)
library(tsDyn)
library(mgcv)
library(mnormt)
library(tvReg)
library(mboost)
library(flare)
library(glmnet)
mms=c()



# steps ahead to forecast 
forecas=1
## number of lags used
n = 3
## size of the sample after taking lags
samp=200
## size of the sample to generate before forming lags
n2 = n+samp

## rescaled time indices

t=(1:n2)/n2

## number of exogenous series
d = 100
## number of out of sample forecasts we are making. If set to one then we are only
## doing an out of sample forecast for the last observation in the sample
predsamp=1

n1=samp-predsamp

## number of lags
r = 3
## number of models evaluated
nmodels=8
## number of total predictors including r lags of the response
npreds=d*r+r



## number of relevant exogenous predictors
true.par.count=4

## Predictor series parameters.
A=outer(1:d, 1:d, f<-function(x,y){.4^(abs(x-y)+1)})
C=diag(1,d)
## multivariate T series. S represents the scale parameter, we set the distribution
## to have a population standard deviation of 1, hence the 3/5 term.

X = VAR.sim(A,innov=rmt(n2, mean=rep(0,d), S=3/5*C,df=5), n = n2, include="none")

## the time invariant part of the coefficients
# beta=c(.5,.5,.5,.5,rep(0,d-true.par.count))

## error distribution
Error=rt(n2,df=5)

##indices of true parameters in the model.
truemodel=c(1,1+r,1+2*r,1+3*r,1+4*r)

## size of validation set used to select bandwidth parameter

d1=20

## creating a kernel function

.kernel <- function(x, bw, tkernel = "Unif", N = 1)
{
  x <- x/(N * bw)
  value <- numeric(length(x))
  if (tkernel == "Gaussian")
  {
    value <- exp(-0.5 * x^2)/2.506628274631000241612355239340104162693023681640625 #sqrt(2*pi)
  }
  if(tkernel == "Epa")
  {
    index <- (x >= -1 & x <= 1)
    
    value[index] <- .75 * (1 - x[index]^2) #12/11
  }
  
  if(tkernel == "Unif")
  {
    index <- (x >= -1 & x <= 1)
    
    value[index] <- 1 #12/11
  }
  return(value)
  
}




################################# DGP 1 ###############################


mms1=matrix(0,nrow=predsamp,ncol=nmodels)



alpha1<-function(x){.6}
B1 <- function(x){.5}
B2<- function(x){.5}
B3<-function(x){.5}
B4<-function(x){.5}


Y = rep(0,n2)
Y0 = 0
Y[1] = Error[1]
for(j in 2:n2){
  Y[j] = Y[j-1]*alpha1(t[j])+X[j-1,1]*B1(t[j])+X[j-1,2]*B2(t[j])+X[j-1,3]*B3(t[j])+X[j-1,4]*B4(t[j])+Error[j]
}


Xold = X
Xwl = matrix(0, (n2-n), d*r)

sub = (n+1):n2
for(j in 1:d){
  Xwl[,(r*j-(r-1)):(r*j)] = c( Xold[sub-1,j], Xold[sub-2,j], Xold[sub-3,j])
}


Y0 = Y[sub]
Y1 = Y[sub-1]
Y2 = Y[sub-2]
Y3 = Y[sub-3]
Z=cbind(Y1,Y2,Y3,Xwl)


names1=c()
for(i in 1:ncol(Z)){
  names1[i]=paste0('Var',i)
}
colnames(Z)<-names1
Lags=cbind(Y1,Y2,Y3)



for(k in 1:predsamp)
{
  ## form a grid to select our bandwidth from
  grid=seq(.3,1,length.out=8)
  ## if doing an expanding window forecasting exercise, we need to get the right
  ## sample size. Given that we only forecast the last observation here, predsamp=1
  ## and k=1 so n1=samp which is 200
  n1=samp-predsamp+k
  #Y1=Y[1:(n-forecas)]
  #X1=X[1:(n-forecas),]
  CV=c()
  CV_a=c()
  CV_b=c()
  CV_c=c()
  for(i in 1:length(grid))
  {
    error=c()
    error_a=c()
    error_b=c()
    error_c=c()
    for(j in (forecas):(d1+forecas-1))
    {
      ## form the data needed to conduct a pseudo out of sample forecasting exercise
      ## As an example, for forecas=1, j starts from 1. We take as our training set
      ## Y0[1:(n1-2)]. And we are aiming to forecast Y0[n1-1]. We do this for each
      ## of the d1 observations in our validation set.
      
      Y1c=Y0[1:(n1-forecas-j)]
      Z1=Z[1:(n1-forecas-j),]
      Lags1=Lags[1:(n1-forecas-j),]
      grid2=(1:nrow(Z1))/nrow(Z1)
      
      w=1-grid2
      weights=.kernel(x = w, bw = grid[i], tkernel = "Unif", N = 1)
      index=(weights>0)
      
      ## LC Boost
      
      boost_m=glmboost(x=as.matrix(Z1)[index,],y=Y1c[index],weights= weights[index],center=TRUE,control = boost_control(mstop = 100,nu=.1))
      boost_m1=glmboost(x=as.matrix(Z1)[index,],y=Y1c[index],weights= weights[index],center=TRUE,control = boost_control(mstop = mstop(AIC(boost_m)),nu=.1))
      coef=coef(boost_m1,off2int=TRUE)
      
      names1=names(coef[-1])
      pred1=predict(boost_m1,newdata=Z)[n1-j]
      error_b[j-forecas+1]=abs(pred1-Y0[n1-j])^2
      
      ## LC time varying parameter model, assuming we know the relevant predictors
      
      result1 <- stats::lm.wfit(x = cbind(1,Z1[,truemodel])[index,], y = Y1c[index], w = weights[index])
      theta1 <- result1$coef
      pred1=c(1,Z[,truemodel][n1-j,])%*%theta1
      error_a[j-forecas+1]=abs(pred1-Y0[n1-j])^2
      
      
      ## LL Boost
      
      Z2=Z[1:(n1-j),]
      grid2=(1:nrow(Z2))/nrow(Z2)
      Z3=cbind(Z2,Z2*(grid2-1))
      Z3=data.frame(Z3)
      colnames(Z3)<-paste0("Z",1:ncol(Z3))
      
      Z4=Z3[1:(n1-forecas-j),]
      a=paste0("Y1c~",paste0(apply(matrix(1:ncol(Z4), ncol = 2, byrow = FALSE), 1, function(vec) paste0("bols(Z",vec[1],",Z",vec[2], ")")),collapse = " + "))
      w=1-(1:nrow(Z4))/nrow(Z4)
      weights=.kernel(x = w, bw = grid[i], tkernel = "Unif", N = 1)
      index=(weights>0)
      
      
      boost_m2=gamboost(as.formula(a),weights= weights,data=Z4,control = boost_control(mstop = 100,nu=.1))
      
      
      boost_m3=gamboost(as.formula(a),weights= weights,data=Z4, control = boost_control(mstop = mstop(AIC(boost_m2)),nu=.1))
      
      
      pred1=predict(boost_m3,newdata=Z3[(n1-j),])
      
      error_c[j-forecas+1]=abs(pred1-Y0[n1-j])^2
      print(j)
      
      
      
    }
    ## get the mean squared error for each bandwidth value
    CV_a[i]=mean(error_a)
    CV_b[i]=mean(error_b)
    CV_c[i]=mean(error_c)
    
  }
  
  ## get the optimal bandwidth for each of the TVP models
  bandopt_a=which.min(CV_a)
  bandopt_b=which.min(CV_b)
  bandopt_c=which.min(CV_c)
  
  ## an AR 4 model
  Y1f=Y0[1:(n1-forecas)]
  Z1f=Z[1:(n1-forecas),]
  Lags1f=Lags[1:(n1-forecas),]
  auto= lm(Y1f~Lags1f)
  pred1=c(1,Lags[n1,])%*%coef(auto)
  error1=pred1-Y0[n1]
  mms1[k,1]=error1
  
  
  ## LC Boost
  grid2=(1:nrow(Z1f))/nrow(Z1f)
  w=1-grid2
  weights=.kernel(x = w, bw = grid[bandopt_b], tkernel = "Unif", N = 1)
  index=(weights>0)
  
  boost_m=glmboost(x=as.matrix(Z1f)[index,],y=Y1f[index],weights= weights[index],center=TRUE,control = boost_control(mstop = 100,nu=.1))
  #AIC(boost_m)
  boost_m1=glmboost(x=as.matrix(Z1f)[index,],y=Y1f[index],weights= weights[index],center=TRUE,control = boost_control(mstop = mstop(AIC(boost_m)),nu=.1))
  
  coef=coef(boost_m1,off2int=TRUE)
  names1=names(coef[-1])
  pred2=predict(boost_m1,newdata=Z)[n1]
  error2=pred2-Y0[n1]
  mms1[k,2]=error2
  
  
  ## Boost time invariant parameters.
  
  boost_m=glmboost(x=as.matrix(Z1f),y=Y1f,center=TRUE,control = boost_control(mstop = 100,nu=.1))
  boost_m1=glmboost(x=as.matrix(Z1f),y=Y1f,center=TRUE,control = boost_control(mstop = mstop(AIC(boost_m)),nu=.1))
  
  coef=coef(boost_m1,off2int=TRUE)
  names1=names(coef[-1])
  pred3=predict(boost_m1,newdata=Z)[n1]
  error3=pred3-Y0[n1]
  mms1[k,3]=error3
  
  ## LC time varying parameter model, assuming we know the relevant predictors
  
  last=nrow(Lags1f)
  TVa= tvOLS(cbind(1,Z1f[,truemodel]),Y1f,bw=grid[bandopt_a],est="lc")
  coefs=TVa$tvcoef[last,]
  pred4=c(1,Z[,truemodel][n1,])%*%coefs
  #pred3=c(Xfull[window3,])%*%coefs
  error4=pred4-Y0[n1]
  mms1[k,4]=error4
  
  ## rolling window AR 4
  
  roll=ceiling(nrow(Z1f)/5)
  weights2=ifelse(((1:last)-last)>-roll,1,0)
  index2=(weights2>0)
  auto=lm(Y1f[index2]~Lags1f[index2,])
  pred5=c(1,Lags[n1,])%*%coef(auto)
  error5=pred5-Y0[n1]
  mms1[k,5]=error5
  
  ## Rolling window Boosting
  
  boost_m=glmboost(x=as.matrix(Z1f)[index2,],y=Y1f[index2],center=TRUE,control = boost_control(mstop = 100,nu=.1))
  boost_m1=glmboost(x=as.matrix(Z1f)[index2,],y=Y1f[index2],center=TRUE,control = boost_control(mstop = mstop(AIC(boost_m)),nu=.1))
  
  coef=coef(boost_m1,off2int=TRUE)
  names1=names(coef[-1])
  pred6=predict(boost_m1,newdata=Z)[n1]
  error6=pred6-Y0[n1]
  mms1[k,6]=error6
  
  ## LL-Boost
  
  ## first create our "pair" of predictors
  Z2f=Z[1:(n1),]
  grid2=(1:nrow(Z2f))/nrow(Z2f)
  Z3f=cbind(Z2f,Z2f*(grid2-1))
  Z3f=data.frame(Z3f)
  colnames(Z3f)<-paste0("Z",1:ncol(Z3f))
  
  Z4f=Z3f[1:(n1-forecas),]
  ## need a formula which specifies that each base learner is a bivariate regression
  a=paste0("Y1f~",paste0(apply(matrix(1:ncol(Z4f), ncol = 2, byrow = FALSE), 1, function(vec) paste0("bols(Z",vec[1],",Z",vec[2], ")")),collapse = " + "))
  w=1-(1:nrow(Z4f))/nrow(Z4f)
  weights=.kernel(x = w, bw = grid[bandopt_c], tkernel = "Unif", N = 1)
  index=(weights>0)
  
  
  boost_m2=gamboost(as.formula(a),weights= weights,data=Z4f,control = boost_control(mstop = 100,nu=.1))
  
  
  boost_m3=gamboost(as.formula(a),weights= weights,data=Z4f, control = boost_control(mstop = mstop(AIC(boost_m)),nu=.1))
  
  
  pred7=predict(boost_m3,newdata=Z3f[(n1),])
  
  error7=abs(pred7-Y0[n1])
  
  mms1[k,7]=error7
  
  ## Time invariant LASSO
  
  model1=glmnet(as.matrix(Z1f),Y1f)
  ## use BIC to select lambda
  f=(deviance(model1)/n2)/var(Y1f)
  g=model1$df
  
  BIC1=log(f)+g*(log(n2)/n2)
  
  number=model1$lambda[which.min(BIC1)]
  model1=glmnet(as.matrix(Z1f),Y1f,lambda=number)
  
  pred8=predict(model1,newx=as.matrix(Z[(1:n1),]))[n1]
  mms1[k,8]=abs(pred8-Y0[n1])
  
  
  
  
}


################################# DGP 2 ###############################




mms2=matrix(0,nrow=predsamp,ncol=nmodels)

## we have a break in the variance of the noise. Break occurs at a=.75
frac=floor(n2*.75)
frac2=n2-frac

##the first segment has a standard deviation 2.5 times larger than the second segment

Error1=2.5*rt(frac,df=5)
Error2=1*rt(frac2,df=5)
Error=c(Error1,Error2)


alpha1<-function(x){.6}
B1 <- function(x){.5}
B2<- function(x){.5}
B3<-function(x){.5}
B4<-function(x){.5}


Y = rep(0,n2)
Y0 = 0
Y[1] = Error[1]
for(j in 2:n2){
  Y[j] = Y[j-1]*alpha1(t[j])+X[j-1,1]*B1(t[j])+X[j-1,2]*B2(t[j])+X[j-1,3]*B3(t[j])+X[j-1,4]*B4(t[j])+Error[j]
}


Xold = X
Xwl = matrix(0, (n2-n), d*r)

sub = (n+1):n2
for(j in 1:d){
  Xwl[,(r*j-(r-1)):(r*j)] = c( Xold[sub-1,j], Xold[sub-2,j], Xold[sub-3,j])
}


Y0 = Y[sub]
Y1 = Y[sub-1]
Y2 = Y[sub-2]
Y3 = Y[sub-3]
Z=cbind(Y1,Y2,Y3,Xwl)


names1=c()
for(i in 1:ncol(Z)){
  names1[i]=paste0('Var',i)
}
colnames(Z)<-names1
Lags=cbind(Y1,Y2,Y3)



for(k in 1:predsamp)
{
  grid=seq(.3,1,length.out=8)
  n1=samp-predsamp+k
  #Y1=Y[1:(n-forecas)]
  #X1=X[1:(n-forecas),]
  
  CV=c()
  CV_a=c()
  CV_b=c()
  CV_c=c()
  for(i in 1:length(grid))
  {
    error=c()
    error_a=c()
    error_b=c()
    error_c=c()
    for(j in (forecas):(d1+forecas-1))
    {
      Y1c=Y0[1:(n1-forecas-j)]
      Z1=Z[1:(n1-forecas-j),]
      Lags1=Lags[1:(n1-forecas-j),]
      grid2=(1:nrow(Z1))/nrow(Z1)
      
      
      w=1-grid2
      weights=.kernel(x = w, bw = grid[i], tkernel = "Unif", N = 1)
      index=(weights>0)
      
      boost_m=glmboost(x=as.matrix(Z1)[index,],y=Y1c[index],weights= weights[index],center=TRUE,control = boost_control(mstop = 100,nu=.1))
      #AIC(boost_m)
      boost_m1=glmboost(x=as.matrix(Z1)[index,],y=Y1c[index],weights= weights[index],center=TRUE,control = boost_control(mstop = mstop(AIC(boost_m)),nu=.1))
      coef=coef(boost_m1,off2int=TRUE)
      
      names1=names(coef[-1])
      pred1=predict(boost_m1,newdata=Z)[n1-j]
      error_b[j-forecas+1]=abs(pred1-Y0[n1-j])^2
      
      
      result1 <- stats::lm.wfit(x = cbind(1,Z1[,truemodel])[index,], y = Y1c[index], w = weights[index])
      theta1 <- result1$coef
      pred1=c(1,Z[,truemodel][n1-j,])%*%theta1
      error_a[j-forecas+1]=abs(pred1-Y0[n1-j])^2
      
      
      
      
      Z2=Z[1:(n1-j),]
      grid2=(1:nrow(Z2))/nrow(Z2)
      Z3=cbind(Z2,Z2*(grid2-1))
      Z3=data.frame(Z3)
      colnames(Z3)<-paste0("Z",1:ncol(Z3))
      
      Z4=Z3[1:(n1-forecas-j),]
      a=paste0("Y1c~",paste0(apply(matrix(1:ncol(Z4), ncol = 2, byrow = FALSE), 1, function(vec) paste0("bols(Z",vec[1],",Z",vec[2], ")")),collapse = " + "))
      w=1-(1:nrow(Z4))/nrow(Z4)
      weights=.kernel(x = w, bw = grid[i], tkernel = "Unif", N = 1)
      index=(weights>0)
      
      
      boost_m2=gamboost(as.formula(a),weights= weights,data=Z4,control = boost_control(mstop = 100,nu=.1))
      
      
      boost_m3=gamboost(as.formula(a),weights= weights,data=Z4, control = boost_control(mstop = mstop(AIC(boost_m2)),nu=.1))
      
      
      pred1=predict(boost_m3,newdata=Z3[(n1-j),])
      
      error_c[j-forecas+1]=abs(pred1-Y0[n1-j])^2
      print(j)
      
    }
    #CV[i]=mean(error)
    CV_a[i]=mean(error_a)
    CV_b[i]=mean(error_b)
    CV_c[i]=mean(error_c)
    
  }
  #bandopt=which.min(CV)
  bandopt_a=which.min(CV_a)
  bandopt_b=which.min(CV_b)
  bandopt_c=which.min(CV_c)
  
  
  Y1f=Y0[1:(n1-forecas)]
  Z1f=Z[1:(n1-forecas),]
  Lags1f=Lags[1:(n1-forecas),]
  auto= lm(Y1f~Lags1f)
  pred1=c(1,Lags[n1,])%*%coef(auto)
  error1=pred1-Y0[n1]
  mms2[k,1]=error1
  
  grid2=(1:nrow(Z1f))/nrow(Z1f)
  w=1-grid2
  weights=.kernel(x = w, bw = grid[bandopt_b], tkernel = "Unif", N = 1)
  index=(weights>0)
  
  boost_m=glmboost(x=as.matrix(Z1f)[index,],y=Y1f[index],weights= weights[index],center=TRUE,control = boost_control(mstop = 100,nu=.1))
  #AIC(boost_m)
  boost_m1=glmboost(x=as.matrix(Z1f)[index,],y=Y1f[index],weights= weights[index],center=TRUE,control = boost_control(mstop = mstop(AIC(boost_m)),nu=.1))
  
  coef=coef(boost_m1,off2int=TRUE)
  names1=names(coef[-1])
  pred2=predict(boost_m1,newdata=Z)[n1]
  error2=pred2-Y0[n1]
  mms2[k,2]=error2
  
  boost_m=glmboost(x=as.matrix(Z1f),y=Y1f,center=TRUE,control = boost_control(mstop = 100,nu=.1))
  boost_m1=glmboost(x=as.matrix(Z1f),y=Y1f,center=TRUE,control = boost_control(mstop = mstop(AIC(boost_m)),nu=.1))
  
  coef=coef(boost_m1,off2int=TRUE)
  names1=names(coef[-1])
  pred3=predict(boost_m1,newdata=Z)[n1]
  error3=pred3-Y0[n1]
  mms2[k,3]=error3
  
  last=nrow(Lags1f)
  TVa= tvOLS(cbind(1,Z1f[,truemodel]),Y1f,bw=grid[bandopt_a],est="lc")
  coefs=TVa$tvcoef[last,]
  pred4=c(1,Z[,truemodel][n1,])%*%coefs
  #pred3=c(Xfull[window3,])%*%coefs
  error4=pred4-Y0[n1]
  mms2[k,4]=error4
  
  roll=ceiling(nrow(Z1f)/5)
  weights2=ifelse(((1:last)-last)>-roll,1,0)
  index2=(weights2>0)
  auto=lm(Y1f[index2]~Lags1f[index2,])
  pred5=c(1,Lags[n1,])%*%coef(auto)
  error5=pred5-Y0[n1]
  mms2[k,5]=error5
  
  
  boost_m=glmboost(x=as.matrix(Z1f)[index2,],y=Y1f[index2],center=TRUE,control = boost_control(mstop = 100,nu=.1))
  boost_m1=glmboost(x=as.matrix(Z1f)[index2,],y=Y1f[index2],center=TRUE,control = boost_control(mstop = mstop(AIC(boost_m)),nu=.1))
  
  coef=coef(boost_m1,off2int=TRUE)
  names1=names(coef[-1])
  pred6=predict(boost_m1,newdata=Z)[n1]
  error6=pred6-Y0[n1]
  mms2[k,6]=error6
  
  
  
  Z2f=Z[1:(n1),]
  grid2=(1:nrow(Z2f))/nrow(Z2f)
  Z3f=cbind(Z2f,Z2f*(grid2-1))
  Z3f=data.frame(Z3f)
  colnames(Z3f)<-paste0("Z",1:ncol(Z3f))
  
  Z4f=Z3f[1:(n1-forecas),]
  a=paste0("Y1f~",paste0(apply(matrix(1:ncol(Z4f), ncol = 2, byrow = FALSE), 1, function(vec) paste0("bols(Z",vec[1],",Z",vec[2], ")")),collapse = " + "))
  w=1-(1:nrow(Z4f))/nrow(Z4f)
  weights=.kernel(x = w, bw = grid[bandopt_c], tkernel = "Unif", N = 1)
  index=(weights>0)
  
  
  boost_m2=gamboost(as.formula(a),weights= weights,data=Z4f,control = boost_control(mstop = 100,nu=.1))
  
  
  boost_m3=gamboost(as.formula(a),weights= weights,data=Z4f, control = boost_control(mstop = mstop(AIC(boost_m)),nu=.1))
  
  
  pred7=predict(boost_m3,newdata=Z3f[(n1),])
  
  error7=abs(pred7-Y0[n1])
  
  mms2[k,7]=error7
  
  
  model1=glmnet(as.matrix(Z1f),Y1f)
  ## use BIC to select lambda
  f=(deviance(model1)/n2)/var(Y1f)
  g=model1$df
  
  BIC1=log(f)+g*(log(n2)/n2)
  
  number=model1$lambda[which.min(BIC1)]
  model1=glmnet(as.matrix(Z1f),Y1f,lambda=number)
  
  pred8=predict(model1,newx=as.matrix(Z[(1:n1),]))[n1]
  mms2[k,8]=abs(pred8-Y0[n1])
  
  
  
  
}


########################## DGP 3 ###############################

## we generate the error distribution again, since DGP 2 has a different
## distribution than the rest of the DGPs

Error=rt(n2,df=5)




mms3=matrix(0,nrow=predsamp,ncol=nmodels)

alpha1<-function(x){.6}
B1 <- function(x){.5-1*(x>.25)}
B2<- function(x){.5-1*(x>.25)}
B3<-function(x){.5-1*(x>.25)}
B4<-function(x){.5-1*(x>.25)}


Y = rep(0,n2)
Y0 = 0
Y[1] = Error[1]
for(j in 2:n2){
  Y[j] = Y[j-1]*alpha1(t[j])+X[j-1,1]*B1(t[j])+X[j-1,2]*B2(t[j])+X[j-1,3]*B3(t[j])+X[j-1,4]*B4(t[j])+Error[j]
}

Xold = X
Xwl = matrix(0, (n2-n), d*r)

sub = (n+1):n2
for(j in 1:d){
  Xwl[,(r*j-(r-1)):(r*j)] = c( Xold[sub-1,j], Xold[sub-2,j], Xold[sub-3,j])
}




Y0 = Y[sub]
Y1 = Y[sub-1]
Y2 = Y[sub-2]
Y3 = Y[sub-3]
Z=cbind(Y1,Y2,Y3,Xwl)
names1=c()
for(i in 1:ncol(Z)){
  names1[i]=paste0('Var',i)
}
colnames(Z)<-names1
Lags=cbind(Y1,Y2,Y3)




for(k in 1:predsamp)
{
  grid=seq(.3,1,length.out=8)
  n1=samp-predsamp+k
  #Y1=Y[1:(n-forecas)]
  #X1=X[1:(n-forecas),]
  CV=c()
  CV_a=c()
  CV_b=c()
  CV_c=c()
  for(i in 1:length(grid))
  {
    error=c()
    error_a=c()
    error_b=c()
    error_c=c()
    for(j in (forecas):(d1+forecas-1))
    {
      Y1c=Y0[1:(n1-forecas-j)]
      Z1=Z[1:(n1-forecas-j),]
      Lags1=Lags[1:(n1-forecas-j),]
      grid2=(1:nrow(Z1))/nrow(Z1)
      
      w=1-grid2
      weights=.kernel(x = w, bw = grid[i], tkernel = "Unif", N = 1)
      index=(weights>0)
      
      boost_m=glmboost(x=as.matrix(Z1)[index,],y=Y1c[index],weights= weights[index],center=TRUE,control = boost_control(mstop = 100,nu=.1))
      boost_m1=glmboost(x=as.matrix(Z1)[index,],y=Y1c[index],weights= weights[index],center=TRUE,control = boost_control(mstop = mstop(AIC(boost_m)),nu=.1))
      coef=coef(boost_m1,off2int=TRUE)
      
      names1=names(coef[-1])
      pred1=predict(boost_m1,newdata=Z)[n1-j]
      error_b[j-forecas+1]=abs(pred1-Y0[n1-j])^2
      
      
      result1 <- stats::lm.wfit(x = cbind(1,Z1[,truemodel])[index,], y = Y1c[index], w = weights[index])
      theta1 <- result1$coef
      pred1=c(1,Z[,truemodel][n1-j,])%*%theta1
      error_a[j-forecas+1]=abs(pred1-Y0[n1-j])^2
      
      
      
      
      Z2=Z[1:(n1-j),]
      grid2=(1:nrow(Z2))/nrow(Z2)
      Z3=cbind(Z2,Z2*(grid2-1))
      Z3=data.frame(Z3)
      colnames(Z3)<-paste0("Z",1:ncol(Z3))
      
      Z4=Z3[1:(n1-forecas-j),]
      a=paste0("Y1c~",paste0(apply(matrix(1:ncol(Z4), ncol = 2, byrow = FALSE), 1, function(vec) paste0("bols(Z",vec[1],",Z",vec[2], ")")),collapse = " + "))
      w=1-(1:nrow(Z4))/nrow(Z4)
      weights=.kernel(x = w, bw = grid[i], tkernel = "Unif", N = 1)
      index=(weights>0)
      
      
      boost_m2=gamboost(as.formula(a),weights= weights,data=Z4,control = boost_control(mstop = 100,nu=.1))
      
      
      boost_m3=gamboost(as.formula(a),weights= weights,data=Z4, control = boost_control(mstop = mstop(AIC(boost_m2)),nu=.1))
      
      
      pred1=predict(boost_m3,newdata=Z3[(n1-j),])
      
      error_c[j-forecas+1]=abs(pred1-Y0[n1-j])^2
      print(j)
      
      
    }
    #CV[i]=mean(error)
    CV_a[i]=mean(error_a)
    CV_b[i]=mean(error_b)
    CV_c[i]=mean(error_c)
    
  }
  #bandopt=which.min(CV)
  bandopt_a=which.min(CV_a)
  bandopt_b=which.min(CV_b)
  bandopt_c=which.min(CV_c)
  
  
  Y1f=Y0[1:(n1-forecas)]
  Z1f=Z[1:(n1-forecas),]
  Lags1f=Lags[1:(n1-forecas),]
  auto= lm(Y1f~Lags1f)
  pred1=c(1,Lags[n1,])%*%coef(auto)
  error1=pred1-Y0[n1]
  mms3[k,1]=error1
  
  grid2=(1:nrow(Z1f))/nrow(Z1f)
  w=1-grid2
  weights=.kernel(x = w, bw = grid[bandopt_b], tkernel = "Unif", N = 1)
  index=(weights>0)
  
  boost_m=glmboost(x=as.matrix(Z1f)[index,],y=Y1f[index],weights= weights[index],center=TRUE,control = boost_control(mstop = 100,nu=.1))
  boost_m1=glmboost(x=as.matrix(Z1f)[index,],y=Y1f[index],weights= weights[index],center=TRUE,control = boost_control(mstop = mstop(AIC(boost_m)),nu=.1))
  
  coef=coef(boost_m1,off2int=TRUE)
  names1=names(coef[-1])
  pred2=predict(boost_m1,newdata=Z)[n1]
  error2=pred2-Y0[n1]
  mms3[k,2]=error2
  
  boost_m=glmboost(x=as.matrix(Z1f),y=Y1f,center=TRUE,control = boost_control(mstop = 100,nu=.1))
  boost_m1=glmboost(x=as.matrix(Z1f),y=Y1f,center=TRUE,control = boost_control(mstop = mstop(AIC(boost_m)),nu=.1))
  
  coef=coef(boost_m1,off2int=TRUE)
  names1=names(coef[-1])
  pred3=predict(boost_m1,newdata=Z)[n1]
  error3=pred3-Y0[n1]
  mms3[k,3]=error3
  
  last=nrow(Lags1f)
  TVa= tvOLS(cbind(1,Z1f[,truemodel]),Y1f,bw=grid[bandopt_a],est="lc")
  coefs=TVa$tvcoef[last,]
  pred4=c(1,Z[,truemodel][n1,])%*%coefs
  error4=pred4-Y0[n1]
  mms3[k,4]=error4
  
  roll=ceiling(nrow(Z1f)/5)
  weights2=ifelse(((1:last)-last)>-roll,1,0)
  index2=(weights2>0)
  auto=lm(Y1f[index2]~Lags1f[index2,])
  pred5=c(1,Lags[n1,])%*%coef(auto)
  error5=pred5-Y0[n1]
  mms3[k,5]=error5
  
  
  boost_m=glmboost(x=as.matrix(Z1f)[index2,],y=Y1f[index2],center=TRUE,control = boost_control(mstop = 100,nu=.1))
  boost_m1=glmboost(x=as.matrix(Z1f)[index2,],y=Y1f[index2],center=TRUE,control = boost_control(mstop = mstop(AIC(boost_m)),nu=.1))
  
  coef=coef(boost_m1,off2int=TRUE)
  names1=names(coef[-1])
  pred6=predict(boost_m1,newdata=Z)[n1]
  error6=pred6-Y0[n1]
  mms3[k,6]=error6
  
  
  
  Z2f=Z[1:(n1),]
  grid2=(1:nrow(Z2f))/nrow(Z2f)
  Z3f=cbind(Z2f,Z2f*(grid2-1))
  Z3f=data.frame(Z3f)
  colnames(Z3f)<-paste0("Z",1:ncol(Z3f))
  
  Z4f=Z3f[1:(n1-forecas),]
  a=paste0("Y1f~",paste0(apply(matrix(1:ncol(Z4f), ncol = 2, byrow = FALSE), 1, function(vec) paste0("bols(Z",vec[1],",Z",vec[2], ")")),collapse = " + "))
  w=1-(1:nrow(Z4f))/nrow(Z4f)
  weights=.kernel(x = w, bw = grid[bandopt_c], tkernel = "Unif", N = 1)
  index=(weights>0)
  
  
  boost_m2=gamboost(as.formula(a),weights= weights,data=Z4f,control = boost_control(mstop = 100,nu=.1))
  
  
  boost_m3=gamboost(as.formula(a),weights= weights,data=Z4f, control = boost_control(mstop = mstop(AIC(boost_m)),nu=.1))
  
  
  pred7=predict(boost_m3,newdata=Z3f[(n1),])
  
  error7=abs(pred7-Y0[n1])
  
  mms3[k,7]=error7
  
  
  model1=glmnet(as.matrix(Z1f),Y1f)
  
  ## useBIC to select lambda
  f=(deviance(model1)/n2)/var(Y1f)
  g=model1$df
  
  BIC1=log(f)+g*(log(n2)/n2)
  
  number=model1$lambda[which.min(BIC1)]
  model1=glmnet(as.matrix(Z1f),Y1f,lambda=number)
  
  pred8=predict(model1,newx=as.matrix(Z[(1:n1),]))[n1]
  mms3[k,8]=abs(pred8-Y0[n1])
  
  
  
}

################################# DGP 4 ###############################

mms4=matrix(0,nrow=predsamp,ncol=nmodels)



alpha1<-function(x){.6}
B1 <- function(x){.5-1*(x>.5)}
B2<- function(x){.5-1*(x>.5)}
B3<-function(x){.5-1*(x>.5)}
B4<-function(x){.5-1*(x>.5)}


Y = rep(0,n2)
Y0 = 0
Y[1] = Error[1]
for(j in 2:n2){
  Y[j] = Y[j-1]*alpha1(t[j])+X[j-1,1]*B1(t[j])+X[j-1,2]*B2(t[j])+X[j-1,3]*B3(t[j])+X[j-1,4]*B4(t[j])+Error[j]
}

Xold = X
Xwl = matrix(0, (n2-n), d*r)

sub = (n+1):n2
for(j in 1:d){
  Xwl[,(r*j-(r-1)):(r*j)] = c( Xold[sub-1,j], Xold[sub-2,j], Xold[sub-3,j])
}




Y0 = Y[sub]
Y1 = Y[sub-1]
Y2 = Y[sub-2]
Y3 = Y[sub-3]
Z=cbind(Y1,Y2,Y3,Xwl)
names1=c()
for(i in 1:ncol(Z)){
  names1[i]=paste0('Var',i)
}
colnames(Z)<-names1
Lags=cbind(Y1,Y2,Y3)



for(k in 1:predsamp)
{
  grid=seq(.3,1,length.out=8)
  n1=samp-predsamp+k
  #Y1=Y[1:(n-forecas)]
  #X1=X[1:(n-forecas),]
  
  CV=c()
  CV_a=c()
  CV_b=c()
  CV_c=c()
  for(i in 1:length(grid))
  {
    error=c()
    error_a=c()
    error_b=c()
    error_c=c()
    for(j in (forecas):(d1+forecas-1))
    {
      Y1c=Y0[1:(n1-forecas-j)]
      Z1=Z[1:(n1-forecas-j),]
      Lags1=Lags[1:(n1-forecas-j),]
      grid2=(1:nrow(Z1))/nrow(Z1)
      
      w=1-grid2
      weights=.kernel(x = w, bw = grid[i], tkernel = "Unif", N = 1)
      index=(weights>0)
      
      boost_m=glmboost(x=as.matrix(Z1)[index,],y=Y1c[index],weights= weights[index],center=TRUE,control = boost_control(mstop = 100,nu=.1))
      boost_m1=glmboost(x=as.matrix(Z1)[index,],y=Y1c[index],weights= weights[index],center=TRUE,control = boost_control(mstop = mstop(AIC(boost_m)),nu=.1))
      coef=coef(boost_m1,off2int=TRUE)
      
      names1=names(coef[-1])
      pred1=predict(boost_m1,newdata=Z)[n1-j]
      error_b[j-forecas+1]=abs(pred1-Y0[n1-j])^2
      
      
      result1 <- stats::lm.wfit(x = cbind(1,Z1[,truemodel])[index,], y = Y1c[index], w = weights[index])
      theta1 <- result1$coef
      pred1=c(1,Z[,truemodel][n1-j,])%*%theta1
      error_a[j-forecas+1]=abs(pred1-Y0[n1-j])^2
      
      
      
      
      Z2=Z[1:(n1-j),]
      grid2=(1:nrow(Z2))/nrow(Z2)
      Z3=cbind(Z2,Z2*(grid2-1))
      Z3=data.frame(Z3)
      colnames(Z3)<-paste0("Z",1:ncol(Z3))
      
      Z4=Z3[1:(n1-forecas-j),]
      a=paste0("Y1c~",paste0(apply(matrix(1:ncol(Z4), ncol = 2, byrow = FALSE), 1, function(vec) paste0("bols(Z",vec[1],",Z",vec[2], ")")),collapse = " + "))
      w=1-(1:nrow(Z4))/nrow(Z4)
      weights=.kernel(x = w, bw = grid[i], tkernel = "Unif", N = 1)
      index=(weights>0)
      
      
      boost_m2=gamboost(as.formula(a),weights= weights,data=Z4,control = boost_control(mstop = 100,nu=.1))
      
      
      boost_m3=gamboost(as.formula(a),weights= weights,data=Z4, control = boost_control(mstop = mstop(AIC(boost_m2)),nu=.1))
      
      
      pred1=predict(boost_m3,newdata=Z3[(n1-j),])
      
      error_c[j-forecas+1]=abs(pred1-Y0[n1-j])^2
      print(j)
      
      
    }
    #CV[i]=mean(error)
    CV_a[i]=mean(error_a)
    CV_b[i]=mean(error_b)
    CV_c[i]=mean(error_c)
    
  }
  #bandopt=which.min(CV)
  bandopt_a=which.min(CV_a)
  bandopt_b=which.min(CV_b)
  bandopt_c=which.min(CV_c)
  
  
  Y1f=Y0[1:(n1-forecas)]
  Z1f=Z[1:(n1-forecas),]
  Lags1f=Lags[1:(n1-forecas),]
  auto= lm(Y1f~Lags1f)
  pred1=c(1,Lags[n1,])%*%coef(auto)
  error1=pred1-Y0[n1]
  mms4[k,1]=error1
  
  grid2=(1:nrow(Z1f))/nrow(Z1f)
  w=1-grid2
  weights=.kernel(x = w, bw = grid[bandopt_b], tkernel = "Unif", N = 1)
  index=(weights>0)
  
  boost_m=glmboost(x=as.matrix(Z1f)[index,],y=Y1f[index],weights= weights[index],center=TRUE,control = boost_control(mstop = 100,nu=.1))
  boost_m1=glmboost(x=as.matrix(Z1f)[index,],y=Y1f[index],weights= weights[index],center=TRUE,control = boost_control(mstop = mstop(AIC(boost_m)),nu=.1))
  
  coef=coef(boost_m1,off2int=TRUE)
  names1=names(coef[-1])
  pred2=predict(boost_m1,newdata=Z)[n1]
  error2=pred2-Y0[n1]
  mms4[k,2]=error2
  
  boost_m=glmboost(x=as.matrix(Z1f),y=Y1f,center=TRUE,control = boost_control(mstop = 100,nu=.1))
  boost_m1=glmboost(x=as.matrix(Z1f),y=Y1f,center=TRUE,control = boost_control(mstop = mstop(AIC(boost_m)),nu=.1))
  
  coef=coef(boost_m1,off2int=TRUE)
  names1=names(coef[-1])
  pred3=predict(boost_m1,newdata=Z)[n1]
  error3=pred3-Y0[n1]
  mms4[k,3]=error3
  
  last=nrow(Lags1f)
  TVa= tvOLS(cbind(1,Z1f[,truemodel]),Y1f,bw=grid[bandopt_a],est="lc")
  coefs=TVa$tvcoef[last,]
  pred4=c(1,Z[,truemodel][n1,])%*%coefs
  #pred3=c(Xfull[window3,])%*%coefs
  error4=pred4-Y0[n1]
  mms4[k,4]=error4
  
  roll=ceiling(nrow(Z1f)/5)
  weights2=ifelse(((1:last)-last)>-roll,1,0)
  index2=(weights2>0)
  auto=lm(Y1f[index2]~Lags1f[index2,])
  pred5=c(1,Lags[n1,])%*%coef(auto)
  error5=pred5-Y0[n1]
  mms4[k,5]=error5
  
  
  boost_m=glmboost(x=as.matrix(Z1f)[index2,],y=Y1f[index2],center=TRUE,control = boost_control(mstop = 100,nu=.1))
  boost_m1=glmboost(x=as.matrix(Z1f)[index2,],y=Y1f[index2],center=TRUE,control = boost_control(mstop = mstop(AIC(boost_m)),nu=.1))
  
  coef=coef(boost_m1,off2int=TRUE)
  names1=names(coef[-1])
  pred6=predict(boost_m1,newdata=Z)[n1]
  error6=pred6-Y0[n1]
  mms4[k,6]=error6
  
  
  
  Z2f=Z[1:(n1),]
  grid2=(1:nrow(Z2f))/nrow(Z2f)
  Z3f=cbind(Z2f,Z2f*(grid2-1))
  Z3f=data.frame(Z3f)
  colnames(Z3f)<-paste0("Z",1:ncol(Z3f))
  
  Z4f=Z3f[1:(n1-forecas),]
  a=paste0("Y1f~",paste0(apply(matrix(1:ncol(Z4f), ncol = 2, byrow = FALSE), 1, function(vec) paste0("bols(Z",vec[1],",Z",vec[2], ")")),collapse = " + "))
  w=1-(1:nrow(Z4f))/nrow(Z4f)
  weights=.kernel(x = w, bw = grid[bandopt_c], tkernel = "Unif", N = 1)
  index=(weights>0)
  
  
  boost_m2=gamboost(as.formula(a),weights= weights,data=Z4f,control = boost_control(mstop = 100,nu=.1))
  
  
  boost_m3=gamboost(as.formula(a),weights= weights,data=Z4f, control = boost_control(mstop = mstop(AIC(boost_m)),nu=.1))
  
  
  pred7=predict(boost_m3,newdata=Z3f[(n1),])
  
  error7=abs(pred7-Y0[n1])
  
  mms4[k,7]=error7
  
  
  model1=glmnet(as.matrix(Z1f),Y1f)
  ## use BIC to select lambda
  f=(deviance(model1)/n2)/var(Y1f)
  g=model1$df
  
  BIC1=log(f)+g*(log(n2)/n2)
  
  number=model1$lambda[which.min(BIC1)]
  model1=glmnet(as.matrix(Z1f),Y1f,lambda=number)
  
  pred8=predict(model1,newx=as.matrix(Z[(1:n1),]))[n1]
  mms4[k,8]=abs(pred8-Y0[n1])
  
  
  
  
}




################################# DGP 5 ###############################

mms5=matrix(0,nrow=predsamp,ncol=nmodels)

alpha1<-function(x){.6}
B1 <- function(x){.5-1*(x>.75)}
B2<- function(x){.5-1*(x>.75)}
B3<-function(x){.5-1*(x>.75)}
B4<-function(x){.5-1*(x>.75)}


Y = rep(0,n2)
Y0 = 0
Y[1] = Error[1]
for(j in 2:n2){
  Y[j] = Y[j-1]*alpha1(t[j])+X[j-1,1]*B1(t[j])+X[j-1,2]*B2(t[j])+X[j-1,3]*B3(t[j])+X[j-1,4]*B4(t[j])+Error[j]
}

Xold = X
Xwl = matrix(0, (n2-n), d*r)

sub = (n+1):n2
for(j in 1:d){
  Xwl[,(r*j-(r-1)):(r*j)] = c( Xold[sub-1,j], Xold[sub-2,j], Xold[sub-3,j])
}



Y0 = Y[sub]
Y1 = Y[sub-1]
Y2 = Y[sub-2]
Y3 = Y[sub-3]
Z=cbind(Y1,Y2,Y3,Xwl)
names1=c()
for(i in 1:ncol(Z)){
  names1[i]=paste0('Var',i)
}
colnames(Z)<-names1
Lags=cbind(Y1,Y2,Y3)



for(k in 1:predsamp)
{
  grid=seq(.3,1,length.out=8)
  n1=samp-predsamp+k
  #Y1=Y[1:(n-forecas)]
  #X1=X[1:(n-forecas),]
  CV=c()
  CV_a=c()
  CV_b=c()
  CV_c=c()
  for(i in 1:length(grid))
  {
    error=c()
    error_a=c()
    error_b=c()
    error_c=c()
    for(j in (forecas):(d1+forecas-1))
    {
      Y1c=Y0[1:(n1-forecas-j)]
      Z1=Z[1:(n1-forecas-j),]
      Lags1=Lags[1:(n1-forecas-j),]
      grid2=(1:nrow(Z1))/nrow(Z1)
      
      
      w=1-grid2
      weights=.kernel(x = w, bw = grid[i], tkernel = "Unif", N = 1)
      index=(weights>0)
      #result <- stats::lm.wfit(x = cbind(1,X1,factorsr1)[index,], y = Y1[index], w = weights[index])
      #theta <- result$coef
      #pred1=c(1,Lags[n1-j,],factors[n1-j,])%*%theta
      #error[j+1]=abs(pred1-Y0[n1-j])^2
      boost_m=glmboost(x=as.matrix(Z1)[index,],y=Y1c[index],weights= weights[index],center=TRUE,control = boost_control(mstop = 100,nu=.1))
      #AIC(boost_m)
      boost_m1=glmboost(x=as.matrix(Z1)[index,],y=Y1c[index],weights= weights[index],center=TRUE,control = boost_control(mstop = mstop(AIC(boost_m)),nu=.1))
      coef=coef(boost_m1,off2int=TRUE)
      
      names1=names(coef[-1])
      pred1=predict(boost_m1,newdata=Z)[n1-j]
      error_b[j-forecas+1]=abs(pred1-Y0[n1-j])^2
      
      
      result1 <- stats::lm.wfit(x = cbind(1,Z1[,truemodel])[index,], y = Y1c[index], w = weights[index])
      theta1 <- result1$coef
      pred1=c(1,Z[,truemodel][n1-j,])%*%theta1
      error_a[j-forecas+1]=abs(pred1-Y0[n1-j])^2
      
      
      
      
      Z2=Z[1:(n1-j),]
      grid2=(1:nrow(Z2))/nrow(Z2)
      Z3=cbind(Z2,Z2*(grid2-1))
      Z3=data.frame(Z3)
      colnames(Z3)<-paste0("Z",1:ncol(Z3))
      
      Z4=Z3[1:(n1-forecas-j),]
      a=paste0("Y1c~",paste0(apply(matrix(1:ncol(Z4), ncol = 2, byrow = FALSE), 1, function(vec) paste0("bols(Z",vec[1],",Z",vec[2], ")")),collapse = " + "))
      w=1-(1:nrow(Z4))/nrow(Z4)
      weights=.kernel(x = w, bw = grid[i], tkernel = "Unif", N = 1)
      index=(weights>0)
      
      
      boost_m2=gamboost(as.formula(a),weights= weights,data=Z4,control = boost_control(mstop = 100,nu=.1))
      
      
      boost_m3=gamboost(as.formula(a),weights= weights,data=Z4, control = boost_control(mstop = mstop(AIC(boost_m2)),nu=.1))
      
      
      pred1=predict(boost_m3,newdata=Z3[(n1-j),])
      
      error_c[j-forecas+1]=abs(pred1-Y0[n1-j])^2
      print(j)
      
      
    }
    #CV[i]=mean(error)
    CV_a[i]=mean(error_a)
    CV_b[i]=mean(error_b)
    CV_c[i]=mean(error_c)
    
  }
  #bandopt=which.min(CV)
  bandopt_a=which.min(CV_a)
  bandopt_b=which.min(CV_b)
  bandopt_c=which.min(CV_c)
  
  
  Y1f=Y0[1:(n1-forecas)]
  Z1f=Z[1:(n1-forecas),]
  Lags1f=Lags[1:(n1-forecas),]
  auto= lm(Y1f~Lags1f)
  pred1=c(1,Lags[n1,])%*%coef(auto)
  error1=pred1-Y0[n1]
  mms5[k,1]=error1
  
  grid2=(1:nrow(Z1f))/nrow(Z1f)
  w=1-grid2
  weights=.kernel(x = w, bw = grid[bandopt_b], tkernel = "Unif", N = 1)
  index=(weights>0)
  
  boost_m=glmboost(x=as.matrix(Z1f)[index,],y=Y1f[index],weights= weights[index],center=TRUE,control = boost_control(mstop = 100,nu=.1))
  #AIC(boost_m)
  boost_m1=glmboost(x=as.matrix(Z1f)[index,],y=Y1f[index],weights= weights[index],center=TRUE,control = boost_control(mstop = mstop(AIC(boost_m)),nu=.1))
  
  coef=coef(boost_m1,off2int=TRUE)
  names1=names(coef[-1])
  pred2=predict(boost_m1,newdata=Z)[n1]
  error2=pred2-Y0[n1]
  mms5[k,2]=error2
  
  boost_m=glmboost(x=as.matrix(Z1f),y=Y1f,center=TRUE,control = boost_control(mstop = 100,nu=.1))
  boost_m1=glmboost(x=as.matrix(Z1f),y=Y1f,center=TRUE,control = boost_control(mstop = mstop(AIC(boost_m)),nu=.1))
  
  coef=coef(boost_m1,off2int=TRUE)
  names1=names(coef[-1])
  pred3=predict(boost_m1,newdata=Z)[n1]
  error3=pred3-Y0[n1]
  mms5[k,3]=error3
  
  last=nrow(Lags1f)
  TVa= tvOLS(cbind(1,Z1f[,truemodel]),Y1f,bw=grid[bandopt_a],est="lc")
  coefs=TVa$tvcoef[last,]
  pred4=c(1,Z[,truemodel][n1,])%*%coefs
  #pred3=c(Xfull[window3,])%*%coefs
  error4=pred4-Y0[n1]
  mms5[k,4]=error4
  
  roll=ceiling(nrow(Z1f)/5)
  weights2=ifelse(((1:last)-last)>-roll,1,0)
  index2=(weights2>0)
  auto=lm(Y1f[index2]~Lags1f[index2,])
  pred5=c(1,Lags[n1,])%*%coef(auto)
  error5=pred5-Y0[n1]
  mms5[k,5]=error5
  
  
  boost_m=glmboost(x=as.matrix(Z1f)[index2,],y=Y1f[index2],center=TRUE,control = boost_control(mstop = 100,nu=.1))
  boost_m1=glmboost(x=as.matrix(Z1f)[index2,],y=Y1f[index2],center=TRUE,control = boost_control(mstop = mstop(AIC(boost_m)),nu=.1))
  
  coef=coef(boost_m1,off2int=TRUE)
  names1=names(coef[-1])
  pred6=predict(boost_m1,newdata=Z)[n1]
  error6=pred6-Y0[n1]
  mms5[k,6]=error6
  
  
  
  Z2f=Z[1:(n1),]
  grid2=(1:nrow(Z2f))/nrow(Z2f)
  Z3f=cbind(Z2f,Z2f*(grid2-1))
  Z3f=data.frame(Z3f)
  colnames(Z3f)<-paste0("Z",1:ncol(Z3f))
  
  Z4f=Z3f[1:(n1-forecas),]
  a=paste0("Y1f~",paste0(apply(matrix(1:ncol(Z4f), ncol = 2, byrow = FALSE), 1, function(vec) paste0("bols(Z",vec[1],",Z",vec[2], ")")),collapse = " + "))
  w=1-(1:nrow(Z4f))/nrow(Z4f)
  weights=.kernel(x = w, bw = grid[bandopt_c], tkernel = "Unif", N = 1)
  index=(weights>0)
  
  
  boost_m2=gamboost(as.formula(a),weights= weights,data=Z4f,control = boost_control(mstop = 100,nu=.1))
  
  
  boost_m3=gamboost(as.formula(a),weights= weights,data=Z4f, control = boost_control(mstop = mstop(AIC(boost_m)),nu=.1))
  
  
  pred7=predict(boost_m3,newdata=Z3f[(n1),])
  
  error7=abs(pred7-Y0[n1])
  
  mms5[k,7]=error7
  
  
  model1=glmnet(as.matrix(Z1f),Y1f)
  ## use BIC to select lambda
  f=(deviance(model1)/n2)/var(Y1f)
  g=model1$df
  
  BIC1=log(f)+g*(log(n2)/n2)
  
  number=model1$lambda[which.min(BIC1)]
  model1=glmnet(as.matrix(Z1f),Y1f,lambda=number)
  
  pred8=predict(model1,newx=as.matrix(Z[(1:n1),]))[n1]
  mms5[k,8]=abs(pred8-Y0[n1])
  
  
  
  
}










################################# DGP 6 ###############################


mms6=matrix(0,nrow=predsamp,ncol=nmodels)

alpha1<-function(x){.6}

B1=c()
B1[1]=1
for(j in 2:n2){
  B1[j] = B1[j-1]+(.5/n2^.5)*rnorm(1)
}


B2=c()
B2[1]=2
for(j in 2:n2){
  B2[j] = B2[j-1]+(.5/n2^.5)*rnorm(1)
}


B3=c()
B3[1]=.5
for(j in 2:n2){
  B3[j] = B3[j-1]+(.5/n2^.5)*rnorm(1)
}


B4=c()
B4[1]=.5
for(j in 2:n2){
  B4[j] = B4[j-1]+(.5/n2^.5)*rnorm(1)
}





Error=rt(n2,df=5)


Y = rep(0,n2)
Y0 = 0
Y[1] = Error[1]
for(j in 2:n2){
  Y[j] = Y[j-1]*alpha1(t[j])+X[j-1,1]*B1[j]+X[j-1,2]*B2[j]+X[j-1,3]*B3[j]+X[j-1,4]*B4[j]+Error[j]
}


Xold = X
Xwl = matrix(0, (n2-n), d*r)

sub = (n+1):n2
for(j in 1:d){
  Xwl[,(r*j-(r-1)):(r*j)] = c( Xold[sub-1,j], Xold[sub-2,j], Xold[sub-3,j])
}




Y0 = Y[sub]
Y1 = Y[sub-1]
Y2 = Y[sub-2]
Y3 = Y[sub-3]
Z=cbind(Y1,Y2,Y3,Xwl)



names1=c()
for(i in 1:ncol(Z)){
  names1[i]=paste0('Var',i)
}
colnames(Z)<-names1
Lags=cbind(Y1,Y2,Y3)


for(k in 1:predsamp)
{
  grid=seq(.3,1,length.out=8)
  n1=samp-predsamp+k
  #Y1=Y[1:(n-forecas)]
  #X1=X[1:(n-forecas),]
  CV=c()
  CV_a=c()
  CV_b=c()
  CV_c=c()
  for(i in 1:length(grid))
  {
    error=c()
    error_a=c()
    error_b=c()
    error_c=c()
    for(j in (forecas):(d1+forecas-1))
    {
      Y1c=Y0[1:(n1-forecas-j)]
      Z1=Z[1:(n1-forecas-j),]
      Lags1=Lags[1:(n1-forecas-j),]
      grid2=(1:nrow(Z1))/nrow(Z1)
      
      
      w=1-grid2
      weights=.kernel(x = w, bw = grid[i], tkernel = "Unif", N = 1)
      index=(weights>0)
      
      boost_m=glmboost(x=as.matrix(Z1)[index,],y=Y1c[index],weights= weights[index],center=TRUE,control = boost_control(mstop = 100,nu=.1))
      #AIC(boost_m)
      boost_m1=glmboost(x=as.matrix(Z1)[index,],y=Y1c[index],weights= weights[index],center=TRUE,control = boost_control(mstop = mstop(AIC(boost_m)),nu=.1))
      coef=coef(boost_m1,off2int=TRUE)
      
      names1=names(coef[-1])
      pred1=predict(boost_m1,newdata=Z)[n1-j]
      error_b[j-forecas+1]=abs(pred1-Y0[n1-j])^2
      
      
      result1 <- stats::lm.wfit(x = cbind(1,Z1[,truemodel])[index,], y = Y1c[index], w = weights[index])
      theta1 <- result1$coef
      pred1=c(1,Z[,truemodel][n1-j,])%*%theta1
      error_a[j-forecas+1]=abs(pred1-Y0[n1-j])^2
      
      
      
      
      Z2=Z[1:(n1-j),]
      grid2=(1:nrow(Z2))/nrow(Z2)
      Z3=cbind(Z2,Z2*(grid2-1))
      Z3=data.frame(Z3)
      colnames(Z3)<-paste0("Z",1:ncol(Z3))
      
      Z4=Z3[1:(n1-forecas-j),]
      a=paste0("Y1c~",paste0(apply(matrix(1:ncol(Z4), ncol = 2, byrow = FALSE), 1, function(vec) paste0("bols(Z",vec[1],",Z",vec[2], ")")),collapse = " + "))
      w=1-(1:nrow(Z4))/nrow(Z4)
      weights=.kernel(x = w, bw = grid[i], tkernel = "Unif", N = 1)
      index=(weights>0)
      
      
      boost_m2=gamboost(as.formula(a),weights= weights,data=Z4,control = boost_control(mstop = 100,nu=.1))
      
      
      boost_m3=gamboost(as.formula(a),weights= weights,data=Z4, control = boost_control(mstop = mstop(AIC(boost_m2)),nu=.1))
      
      
      pred1=predict(boost_m3,newdata=Z3[(n1-j),])
      
      error_c[j-forecas+1]=abs(pred1-Y0[n1-j])^2
      print(j)
      
    }
    #CV[i]=mean(error)
    CV_a[i]=mean(error_a)
    CV_b[i]=mean(error_b)
    CV_c[i]=mean(error_c)
    
  }
  #bandopt=which.min(CV)
  bandopt_a=which.min(CV_a)
  bandopt_b=which.min(CV_b)
  bandopt_c=which.min(CV_c)
  
  
  Y1f=Y0[1:(n1-forecas)]
  Z1f=Z[1:(n1-forecas),]
  Lags1f=Lags[1:(n1-forecas),]
  auto= lm(Y1f~Lags1f)
  pred1=c(1,Lags[n1,])%*%coef(auto)
  error1=pred1-Y0[n1]
  mms6[k,1]=error1
  
  grid2=(1:nrow(Z1f))/nrow(Z1f)
  w=1-grid2
  weights=.kernel(x = w, bw = grid[bandopt_b], tkernel = "Unif", N = 1)
  index=(weights>0)
  
  boost_m=glmboost(x=as.matrix(Z1f)[index,],y=Y1f[index],weights= weights[index],center=TRUE,control = boost_control(mstop = 100,nu=.1))
  boost_m1=glmboost(x=as.matrix(Z1f)[index,],y=Y1f[index],weights= weights[index],center=TRUE,control = boost_control(mstop = mstop(AIC(boost_m)),nu=.1))
  
  coef=coef(boost_m1,off2int=TRUE)
  names1=names(coef[-1])
  pred2=predict(boost_m1,newdata=Z)[n1]
  error2=pred2-Y0[n1]
  mms6[k,2]=error2
  
  boost_m=glmboost(x=as.matrix(Z1f),y=Y1f,center=TRUE,control = boost_control(mstop = 100,nu=.1))
  boost_m1=glmboost(x=as.matrix(Z1f),y=Y1f,center=TRUE,control = boost_control(mstop = mstop(AIC(boost_m)),nu=.1))
  
  coef=coef(boost_m1,off2int=TRUE)
  names1=names(coef[-1])
  pred3=predict(boost_m1,newdata=Z)[n1]
  error3=pred3-Y0[n1]
  mms6[k,3]=error3
  
  last=nrow(Lags1f)
  TVa= tvOLS(cbind(1,Z1f[,truemodel]),Y1f,bw=grid[bandopt_a],est="lc")
  coefs=TVa$tvcoef[last,]
  pred4=c(1,Z[,truemodel][n1,])%*%coefs
  error4=pred4-Y0[n1]
  mms6[k,4]=error4
  
  roll=ceiling(nrow(Z1f)/5)
  weights2=ifelse(((1:last)-last)>-roll,1,0)
  index2=(weights2>0)
  auto=lm(Y1f[index2]~Lags1f[index2,])
  pred5=c(1,Lags[n1,])%*%coef(auto)
  error5=pred5-Y0[n1]
  mms6[k,5]=error5
  
  
  boost_m=glmboost(x=as.matrix(Z1f)[index2,],y=Y1f[index2],center=TRUE,control = boost_control(mstop = 100,nu=.1))
  boost_m1=glmboost(x=as.matrix(Z1f)[index2,],y=Y1f[index2],center=TRUE,control = boost_control(mstop = mstop(AIC(boost_m)),nu=.1))
  
  coef=coef(boost_m1,off2int=TRUE)
  names1=names(coef[-1])
  pred6=predict(boost_m1,newdata=Z)[n1]
  error6=pred6-Y0[n1]
  mms6[k,6]=error6
  
  
  
  Z2f=Z[1:(n1),]
  grid2=(1:nrow(Z2f))/nrow(Z2f)
  Z3f=cbind(Z2f,Z2f*(grid2-1))
  Z3f=data.frame(Z3f)
  colnames(Z3f)<-paste0("Z",1:ncol(Z3f))
  
  Z4f=Z3f[1:(n1-forecas),]
  a=paste0("Y1f~",paste0(apply(matrix(1:ncol(Z4f), ncol = 2, byrow = FALSE), 1, function(vec) paste0("bols(Z",vec[1],",Z",vec[2], ")")),collapse = " + "))
  w=1-(1:nrow(Z4f))/nrow(Z4f)
  weights=.kernel(x = w, bw = grid[bandopt_c], tkernel = "Unif", N = 1)
  index=(weights>0)
  
  
  boost_m2=gamboost(as.formula(a),weights= weights,data=Z4f,control = boost_control(mstop = 100,nu=.1))
  
  
  boost_m3=gamboost(as.formula(a),weights= weights,data=Z4f, control = boost_control(mstop = mstop(AIC(boost_m)),nu=.1))
  
  
  pred7=predict(boost_m3,newdata=Z3f[(n1),])
  
  error7=abs(pred7-Y0[n1])
  
  mms6[k,7]=error7
  
  
  model1=glmnet(as.matrix(Z1f),Y1f)
  ## use BIC to select lambda
  f=(deviance(model1)/n2)/var(Y1f)
  g=model1$df
  
  BIC1=log(f)+g*(log(n2)/n2)
  
  number=model1$lambda[which.min(BIC1)]
  model1=glmnet(as.matrix(Z1f),Y1f,lambda=number)
  
  pred8=predict(model1,newx=as.matrix(Z[(1:n1),]))[n1]
  mms6[k,8]=abs(pred8-Y0[n1])
  
  
  
  
}

################################# DGP 7 ###############################


mms7=matrix(0,nrow=predsamp,ncol=nmodels)



B1=c()
B1[1]=1
for(j in 2:n2){
  B1[j] = B1[j-1]+(1/n2^.5)*rnorm(1)
}


B2=c()
B2[1]=2
for(j in 2:n2){
  B2[j] = B2[j-1]+(1/n2^.5)*rnorm(1)
}


B3=c()
B3[1]=.5
for(j in 2:n2){
  B3[j] = B3[j-1]+(1/n2^.5)*rnorm(1)
}


B4=c()
B4[1]=.5
for(j in 2:n2){
  B4[j] = B4[j-1]+(1/n2^.5)*rnorm(1)
}


Y = rep(0,n2)
Y0 = 0
Y[1] = Error[1]
for(j in 2:n2){
  Y[j] = Y[j-1]*alpha1(t[j])+X[j-1,1]*B1[j]+X[j-1,2]*B2[j]+X[j-1,3]*B3[j]+X[j-1,4]*B4[j]+Error[j]
}


Xold = X
Xwl = matrix(0, (n2-n), d*r)

sub = (n+1):n2
for(j in 1:d){
  Xwl[,(r*j-(r-1)):(r*j)] = c( Xold[sub-1,j], Xold[sub-2,j], Xold[sub-3,j])
}




Y0 = Y[sub]
Y1 = Y[sub-1]
Y2 = Y[sub-2]
Y3 = Y[sub-3]
Z=cbind(Y1,Y2,Y3,Xwl)


names1=c()
for(i in 1:ncol(Z)){
  names1[i]=paste0('Var',i)
}
colnames(Z)<-names1
Lags=cbind(Y1,Y2,Y3)



for(k in 1:predsamp)
{
  grid=seq(.3,1,length.out=8)
  n1=samp-predsamp+k
  #Y1=Y[1:(n-forecas)]
  #X1=X[1:(n-forecas),]
  CV=c()
  CV_a=c()
  CV_b=c()
  CV_c=c()
  for(i in 1:length(grid))
  {
    error=c()
    error_a=c()
    error_b=c()
    error_c=c()
    for(j in (forecas):(d1+forecas-1))
    {
      Y1c=Y0[1:(n1-forecas-j)]
      Z1=Z[1:(n1-forecas-j),]
      Lags1=Lags[1:(n1-forecas-j),]
      grid2=(1:nrow(Z1))/nrow(Z1)
      
      
      w=1-grid2
      weights=.kernel(x = w, bw = grid[i], tkernel = "Unif", N = 1)
      index=(weights>0)
      
      boost_m=glmboost(x=as.matrix(Z1)[index,],y=Y1c[index],weights= weights[index],center=TRUE,control = boost_control(mstop = 100,nu=.1))
      boost_m1=glmboost(x=as.matrix(Z1)[index,],y=Y1c[index],weights= weights[index],center=TRUE,control = boost_control(mstop = mstop(AIC(boost_m)),nu=.1))
      coef=coef(boost_m1,off2int=TRUE)
      
      names1=names(coef[-1])
      pred1=predict(boost_m1,newdata=Z)[n1-j]
      error_b[j-forecas+1]=abs(pred1-Y0[n1-j])^2
      
      
      result1 <- stats::lm.wfit(x = cbind(1,Z1[,truemodel])[index,], y = Y1c[index], w = weights[index])
      theta1 <- result1$coef
      pred1=c(1,Z[,truemodel][n1-j,])%*%theta1
      error_a[j-forecas+1]=abs(pred1-Y0[n1-j])^2
      
      
      
      
      Z2=Z[1:(n1-j),]
      grid2=(1:nrow(Z2))/nrow(Z2)
      Z3=cbind(Z2,Z2*(grid2-1))
      Z3=data.frame(Z3)
      colnames(Z3)<-paste0("Z",1:ncol(Z3))
      
      Z4=Z3[1:(n1-forecas-j),]
      a=paste0("Y1c~",paste0(apply(matrix(1:ncol(Z4), ncol = 2, byrow = FALSE), 1, function(vec) paste0("bols(Z",vec[1],",Z",vec[2], ")")),collapse = " + "))
      w=1-(1:nrow(Z4))/nrow(Z4)
      weights=.kernel(x = w, bw = grid[i], tkernel = "Unif", N = 1)
      index=(weights>0)
      
      
      boost_m2=gamboost(as.formula(a),weights= weights,data=Z4,control = boost_control(mstop = 100,nu=.1))
      
      
      boost_m3=gamboost(as.formula(a),weights= weights,data=Z4, control = boost_control(mstop = mstop(AIC(boost_m2)),nu=.1))
      
      
      pred1=predict(boost_m3,newdata=Z3[(n1-j),])
      
      error_c[j-forecas+1]=abs(pred1-Y0[n1-j])^2
      print(j)
      
    }
    #CV[i]=mean(error)
    CV_a[i]=mean(error_a)
    CV_b[i]=mean(error_b)
    CV_c[i]=mean(error_c)
    
  }
  #bandopt=which.min(CV)
  bandopt_a=which.min(CV_a)
  bandopt_b=which.min(CV_b)
  bandopt_c=which.min(CV_c)
  
  
  Y1f=Y0[1:(n1-forecas)]
  Z1f=Z[1:(n1-forecas),]
  Lags1f=Lags[1:(n1-forecas),]
  auto= lm(Y1f~Lags1f)
  pred1=c(1,Lags[n1,])%*%coef(auto)
  error1=pred1-Y0[n1]
  mms7[k,1]=error1
  
  grid2=(1:nrow(Z1f))/nrow(Z1f)
  w=1-grid2
  weights=.kernel(x = w, bw = grid[bandopt_b], tkernel = "Unif", N = 1)
  index=(weights>0)
  
  boost_m=glmboost(x=as.matrix(Z1f)[index,],y=Y1f[index],weights= weights[index],center=TRUE,control = boost_control(mstop = 100,nu=.1))
  #AIC(boost_m)
  boost_m1=glmboost(x=as.matrix(Z1f)[index,],y=Y1f[index],weights= weights[index],center=TRUE,control = boost_control(mstop = mstop(AIC(boost_m)),nu=.1))
  
  coef=coef(boost_m1,off2int=TRUE)
  names1=names(coef[-1])
  pred2=predict(boost_m1,newdata=Z)[n1]
  error2=pred2-Y0[n1]
  mms7[k,2]=error2
  
  boost_m=glmboost(x=as.matrix(Z1f),y=Y1f,center=TRUE,control = boost_control(mstop = 100,nu=.1))
  boost_m1=glmboost(x=as.matrix(Z1f),y=Y1f,center=TRUE,control = boost_control(mstop = mstop(AIC(boost_m)),nu=.1))
  
  coef=coef(boost_m1,off2int=TRUE)
  names1=names(coef[-1])
  pred3=predict(boost_m1,newdata=Z)[n1]
  error3=pred3-Y0[n1]
  mms7[k,3]=error3
  
  last=nrow(Lags1f)
  TVa= tvOLS(cbind(1,Z1f[,truemodel]),Y1f,bw=grid[bandopt_a],est="lc")
  coefs=TVa$tvcoef[last,]
  pred4=c(1,Z[,truemodel][n1,])%*%coefs
  #pred3=c(Xfull[window3,])%*%coefs
  error4=pred4-Y0[n1]
  mms7[k,4]=error4
  
  roll=ceiling(nrow(Z1f)/5)
  weights2=ifelse(((1:last)-last)>-roll,1,0)
  index2=(weights2>0)
  auto=lm(Y1f[index2]~Lags1f[index2,])
  pred5=c(1,Lags[n1,])%*%coef(auto)
  error5=pred5-Y0[n1]
  mms7[k,5]=error5
  
  
  boost_m=glmboost(x=as.matrix(Z1f)[index2,],y=Y1f[index2],center=TRUE,control = boost_control(mstop = 100,nu=.1))
  boost_m1=glmboost(x=as.matrix(Z1f)[index2,],y=Y1f[index2],center=TRUE,control = boost_control(mstop = mstop(AIC(boost_m)),nu=.1))
  
  coef=coef(boost_m1,off2int=TRUE)
  names1=names(coef[-1])
  pred6=predict(boost_m1,newdata=Z)[n1]
  error6=pred6-Y0[n1]
  mms7[k,6]=error6
  
  
  
  Z2f=Z[1:(n1),]
  grid2=(1:nrow(Z2f))/nrow(Z2f)
  Z3f=cbind(Z2f,Z2f*(grid2-1))
  Z3f=data.frame(Z3f)
  colnames(Z3f)<-paste0("Z",1:ncol(Z3f))
  
  Z4f=Z3f[1:(n1-forecas),]
  a=paste0("Y1f~",paste0(apply(matrix(1:ncol(Z4f), ncol = 2, byrow = FALSE), 1, function(vec) paste0("bols(Z",vec[1],",Z",vec[2], ")")),collapse = " + "))
  w=1-(1:nrow(Z4f))/nrow(Z4f)
  weights=.kernel(x = w, bw = grid[bandopt_c], tkernel = "Unif", N = 1)
  index=(weights>0)
  
  
  boost_m2=gamboost(as.formula(a),weights= weights,data=Z4f,control = boost_control(mstop = 100,nu=.1))
  
  
  boost_m3=gamboost(as.formula(a),weights= weights,data=Z4f, control = boost_control(mstop = mstop(AIC(boost_m)),nu=.1))
  
  
  pred7=predict(boost_m3,newdata=Z3f[(n1),])
  
  error7=abs(pred7-Y0[n1])
  
  mms7[k,7]=error7
  
  
  model1=glmnet(as.matrix(Z1f),Y1f)
  ## use BIC to select lambda
  f=(deviance(model1)/n2)/var(Y1f)
  g=model1$df
  
  BIC1=log(f)+g*(log(n2)/n2)
  
  number=model1$lambda[which.min(BIC1)]
  model1=glmnet(as.matrix(Z1f),Y1f,lambda=number)
  
  pred8=predict(model1,newx=as.matrix(Z[(1:n1),]))[n1]
  mms7[k,8]=abs(pred8-Y0[n1])
  
  
  
  
}

################################# DGP 8 ###############################

mms8=matrix(0,nrow=predsamp,ncol=nmodels)



alpha1<-function(x){.6}
B1 <- function(x){.5+1/(1+exp(-10*(x-.25)))}
B2<- function(x){.5+1/(1+exp(-5*(x-.25)))}
B3<-function(x){.5+1/(1+exp(-20*(x-.25)))}
B4<-function(x){.5+1/(1+exp(-10*(x-.25)))}



Y = rep(0,n2)
Y0 = 0
Y[1] = Error[1]
for(j in 2:n2){
  Y[j] = Y[j-1]*alpha1(t[j])+X[j-1,1]*B1(t[j])+X[j-1,2]*B2(t[j])+X[j-1,3]*B3(t[j])+X[j-1,4]*B4(t[j])+Error[j]
}


Xold = X
Xwl = matrix(0, (n2-n), d*r)

sub = (n+1):n2
for(j in 1:d){
  Xwl[,(r*j-(r-1)):(r*j)] = c( Xold[sub-1,j], Xold[sub-2,j], Xold[sub-3,j])
}




Y0 = Y[sub]
Y1 = Y[sub-1]
Y2 = Y[sub-2]
Y3 = Y[sub-3]
Z=cbind(Y1,Y2,Y3,Xwl)
names1=c()
for(i in 1:ncol(Z)){
  names1[i]=paste0('Var',i)
}
colnames(Z)<-names1
Lags=cbind(Y1,Y2,Y3)



for(k in 1:predsamp)
{
  grid=seq(.3,1,length.out=8)
  n1=samp-predsamp+k
  #Y1=Y[1:(n-forecas)]
  #X1=X[1:(n-forecas),]
  CV=c()
  CV_a=c()
  CV_b=c()
  CV_c=c()
  for(i in 1:length(grid))
  {
    error=c()
    error_a=c()
    error_b=c()
    error_c=c()
    for(j in (forecas):(d1+forecas-1))
    {
      Y1c=Y0[1:(n1-forecas-j)]
      Z1=Z[1:(n1-forecas-j),]
      Lags1=Lags[1:(n1-forecas-j),]
      grid2=(1:nrow(Z1))/nrow(Z1)
      
      
      w=1-grid2
      weights=.kernel(x = w, bw = grid[i], tkernel = "Unif", N = 1)
      index=(weights>0)
      
      boost_m=glmboost(x=as.matrix(Z1)[index,],y=Y1c[index],weights= weights[index],center=TRUE,control = boost_control(mstop = 100,nu=.1))
      #AIC(boost_m)
      boost_m1=glmboost(x=as.matrix(Z1)[index,],y=Y1c[index],weights= weights[index],center=TRUE,control = boost_control(mstop = mstop(AIC(boost_m)),nu=.1))
      coef=coef(boost_m1,off2int=TRUE)
      
      names1=names(coef[-1])
      pred1=predict(boost_m1,newdata=Z)[n1-j]
      error_b[j-forecas+1]=abs(pred1-Y0[n1-j])^2
      
      
      result1 <- stats::lm.wfit(x = cbind(1,Z1[,truemodel])[index,], y = Y1c[index], w = weights[index])
      theta1 <- result1$coef
      pred1=c(1,Z[,truemodel][n1-j,])%*%theta1
      error_a[j-forecas+1]=abs(pred1-Y0[n1-j])^2
      
      
      
      
      Z2=Z[1:(n1-j),]
      grid2=(1:nrow(Z2))/nrow(Z2)
      Z3=cbind(Z2,Z2*(grid2-1))
      Z3=data.frame(Z3)
      colnames(Z3)<-paste0("Z",1:ncol(Z3))
      
      Z4=Z3[1:(n1-forecas-j),]
      a=paste0("Y1c~",paste0(apply(matrix(1:ncol(Z4), ncol = 2, byrow = FALSE), 1, function(vec) paste0("bols(Z",vec[1],",Z",vec[2], ")")),collapse = " + "))
      w=1-(1:nrow(Z4))/nrow(Z4)
      weights=.kernel(x = w, bw = grid[i], tkernel = "Unif", N = 1)
      index=(weights>0)
      
      
      boost_m2=gamboost(as.formula(a),weights= weights,data=Z4,control = boost_control(mstop = 100,nu=.1))
      
      
      boost_m3=gamboost(as.formula(a),weights= weights,data=Z4, control = boost_control(mstop = mstop(AIC(boost_m2)),nu=.1))
      
      
      pred1=predict(boost_m3,newdata=Z3[(n1-j),])
      
      error_c[j-forecas+1]=abs(pred1-Y0[n1-j])^2
      print(j)
      
      
    }
    #CV[i]=mean(error)
    CV_a[i]=mean(error_a)
    CV_b[i]=mean(error_b)
    CV_c[i]=mean(error_c)
    
  }
  #bandopt=which.min(CV)
  bandopt_a=which.min(CV_a)
  bandopt_b=which.min(CV_b)
  bandopt_c=which.min(CV_c)
  
  
  Y1f=Y0[1:(n1-forecas)]
  Z1f=Z[1:(n1-forecas),]
  Lags1f=Lags[1:(n1-forecas),]
  auto= lm(Y1f~Lags1f)
  pred1=c(1,Lags[n1,])%*%coef(auto)
  error1=pred1-Y0[n1]
  mms8[k,1]=error1
  
  grid2=(1:nrow(Z1f))/nrow(Z1f)
  w=1-grid2
  weights=.kernel(x = w, bw = grid[bandopt_b], tkernel = "Unif", N = 1)
  index=(weights>0)
  
  boost_m=glmboost(x=as.matrix(Z1f)[index,],y=Y1f[index],weights= weights[index],center=TRUE,control = boost_control(mstop = 100,nu=.1))
  #AIC(boost_m)
  boost_m1=glmboost(x=as.matrix(Z1f)[index,],y=Y1f[index],weights= weights[index],center=TRUE,control = boost_control(mstop = mstop(AIC(boost_m)),nu=.1))
  
  coef=coef(boost_m1,off2int=TRUE)
  names1=names(coef[-1])
  pred2=predict(boost_m1,newdata=Z)[n1]
  error2=pred2-Y0[n1]
  mms8[k,2]=error2
  
  boost_m=glmboost(x=as.matrix(Z1f),y=Y1f,center=TRUE,control = boost_control(mstop = 100,nu=.1))
  boost_m1=glmboost(x=as.matrix(Z1f),y=Y1f,center=TRUE,control = boost_control(mstop = mstop(AIC(boost_m)),nu=.1))
  
  coef=coef(boost_m1,off2int=TRUE)
  names1=names(coef[-1])
  pred3=predict(boost_m1,newdata=Z)[n1]
  error3=pred3-Y0[n1]
  mms8[k,3]=error3
  
  last=nrow(Lags1f)
  TVa= tvOLS(cbind(1,Z1f[,truemodel]),Y1f,bw=grid[bandopt_a],est="lc")
  coefs=TVa$tvcoef[last,]
  pred4=c(1,Z[,truemodel][n1,])%*%coefs
  #pred3=c(Xfull[window3,])%*%coefs
  error4=pred4-Y0[n1]
  mms8[k,4]=error4
  
  roll=ceiling(nrow(Z1f)/5)
  weights2=ifelse(((1:last)-last)>-roll,1,0)
  index2=(weights2>0)
  auto=lm(Y1f[index2]~Lags1f[index2,])
  pred5=c(1,Lags[n1,])%*%coef(auto)
  error5=pred5-Y0[n1]
  mms8[k,5]=error5
  
  
  boost_m=glmboost(x=as.matrix(Z1f)[index2,],y=Y1f[index2],center=TRUE,control = boost_control(mstop = 100,nu=.1))
  boost_m1=glmboost(x=as.matrix(Z1f)[index2,],y=Y1f[index2],center=TRUE,control = boost_control(mstop = mstop(AIC(boost_m)),nu=.1))
  
  coef=coef(boost_m1,off2int=TRUE)
  names1=names(coef[-1])
  pred6=predict(boost_m1,newdata=Z)[n1]
  error6=pred6-Y0[n1]
  mms8[k,6]=error6
  
  
  
  Z2f=Z[1:(n1),]
  grid2=(1:nrow(Z2f))/nrow(Z2f)
  Z3f=cbind(Z2f,Z2f*(grid2-1))
  Z3f=data.frame(Z3f)
  colnames(Z3f)<-paste0("Z",1:ncol(Z3f))
  
  Z4f=Z3f[1:(n1-forecas),]
  a=paste0("Y1f~",paste0(apply(matrix(1:ncol(Z4f), ncol = 2, byrow = FALSE), 1, function(vec) paste0("bols(Z",vec[1],",Z",vec[2], ")")),collapse = " + "))
  w=1-(1:nrow(Z4f))/nrow(Z4f)
  weights=.kernel(x = w, bw = grid[bandopt_c], tkernel = "Unif", N = 1)
  index=(weights>0)
  
  
  boost_m2=gamboost(as.formula(a),weights= weights,data=Z4f,control = boost_control(mstop = 100,nu=.1))
  
  
  boost_m3=gamboost(as.formula(a),weights= weights,data=Z4f, control = boost_control(mstop = mstop(AIC(boost_m)),nu=.1))
  
  
  pred7=predict(boost_m3,newdata=Z3f[(n1),])
  
  error7=abs(pred7-Y0[n1])
  
  mms8[k,7]=error7
  
  
  model1=glmnet(as.matrix(Z1f),Y1f)
  ## use BIC to select lambda
  f=(deviance(model1)/n2)/var(Y1f)
  g=model1$df
  
  BIC1=log(f)+g*(log(n2)/n2)
  
  number=model1$lambda[which.min(BIC1)]
  model1=glmnet(as.matrix(Z1f),Y1f,lambda=number)
  
  pred8=predict(model1,newx=as.matrix(Z[(1:n1),]))[n1]
  mms8[k,8]=abs(pred8-Y0[n1])
  
  
  
  
}

################################# DGP 9 ###############################

mms9=matrix(0,nrow=predsamp,ncol=nmodels)




alpha1<-function(x){.6}
B1 <- function(x){.5+1/(1+exp(-10*(x-.75)))}
B2<- function(x){.5+1/(1+exp(-5*(x-.75)))}
B3<-function(x){.5+1/(1+exp(-20*(x-.75)))}
B4<-function(x){.5+1/(1+exp(-10*(x-.75)))}



Y = rep(0,n2)
Y0 = 0
Y[1] = Error[1]
for(j in 2:n2){
  Y[j] = Y[j-1]*alpha1(t[j])+X[j-1,1]*B1(t[j])+X[j-1,2]*B2(t[j])+X[j-1,3]*B3(t[j])+X[j-1,4]*B4(t[j])+Error[j]
}


Xold = X
Xwl = matrix(0, (n2-n), d*r)


sub = (n+1):n2
for(j in 1:d){
  Xwl[,(r*j-(r-1)):(r*j)] = c( Xold[sub-1,j], Xold[sub-2,j], Xold[sub-3,j])
}



Y0 = Y[sub]
Y1 = Y[sub-1]
Y2 = Y[sub-2]
Y3 = Y[sub-3]
Z=cbind(Y1,Y2,Y3,Xwl)
names1=c()
for(i in 1:ncol(Z)){
  names1[i]=paste0('Var',i)
}
colnames(Z)<-names1
Lags=cbind(Y1,Y2,Y3)

.kernel <- function(x, bw, tkernel = "Unif", N = 1)
{
  x <- x/(N * bw)
  value <- numeric(length(x))
  if (tkernel == "Gaussian")
  {
    value <- exp(-0.5 * x^2)/2.506628274631000241612355239340104162693023681640625 #sqrt(2*pi)
  }
  if(tkernel == "Epa")
  {
    index <- (x >= -1 & x <= 1)
    
    value[index] <- .75 * (1 - x[index]^2) #12/11
  }
  
  if(tkernel == "Unif")
  {
    index <- (x >= -1 & x <= 1)
    
    value[index] <- 1 #12/11
  }
  return(value)
  
}

for(k in 1:predsamp)
{
  grid=seq(.3,1,length.out=8)
  n1=samp-predsamp+k
  #Y1=Y[1:(n-forecas)]
  #X1=X[1:(n-forecas),]
  CV=c()
  CV_a=c()
  CV_b=c()
  CV_c=c()
  for(i in 1:length(grid))
  {
    error=c()
    error_a=c()
    error_b=c()
    error_c=c()
    for(j in (forecas):(d1+forecas-1))
    {
      Y1c=Y0[1:(n1-forecas-j)]
      Z1=Z[1:(n1-forecas-j),]
      Lags1=Lags[1:(n1-forecas-j),]
      grid2=(1:nrow(Z1))/nrow(Z1)
      
      
      w=1-grid2
      weights=.kernel(x = w, bw = grid[i], tkernel = "Unif", N = 1)
      index=(weights>0)
      
      boost_m=glmboost(x=as.matrix(Z1)[index,],y=Y1c[index],weights= weights[index],center=TRUE,control = boost_control(mstop = 100,nu=.1))
      #AIC(boost_m)
      boost_m1=glmboost(x=as.matrix(Z1)[index,],y=Y1c[index],weights= weights[index],center=TRUE,control = boost_control(mstop = mstop(AIC(boost_m)),nu=.1))
      coef=coef(boost_m1,off2int=TRUE)
      
      names1=names(coef[-1])
      pred1=predict(boost_m1,newdata=Z)[n1-j]
      error_b[j-forecas+1]=abs(pred1-Y0[n1-j])^2
      
      
      result1 <- stats::lm.wfit(x = cbind(1,Z1[,truemodel])[index,], y = Y1c[index], w = weights[index])
      theta1 <- result1$coef
      pred1=c(1,Z[,truemodel][n1-j,])%*%theta1
      error_a[j-forecas+1]=abs(pred1-Y0[n1-j])^2
      
      
      
      
      Z2=Z[1:(n1-j),]
      grid2=(1:nrow(Z2))/nrow(Z2)
      Z3=cbind(Z2,Z2*(grid2-1))
      Z3=data.frame(Z3)
      colnames(Z3)<-paste0("Z",1:ncol(Z3))
      
      Z4=Z3[1:(n1-forecas-j),]
      a=paste0("Y1c~",paste0(apply(matrix(1:ncol(Z4), ncol = 2, byrow = FALSE), 1, function(vec) paste0("bols(Z",vec[1],",Z",vec[2], ")")),collapse = " + "))
      w=1-(1:nrow(Z4))/nrow(Z4)
      weights=.kernel(x = w, bw = grid[i], tkernel = "Unif", N = 1)
      index=(weights>0)
      
      
      boost_m2=gamboost(as.formula(a),weights= weights,data=Z4,control = boost_control(mstop = 100,nu=.1))
      
      
      boost_m3=gamboost(as.formula(a),weights= weights,data=Z4, control = boost_control(mstop = mstop(AIC(boost_m2)),nu=.1))
      
      
      pred1=predict(boost_m3,newdata=Z3[(n1-j),])
      
      error_c[j-forecas+1]=abs(pred1-Y0[n1-j])^2
      print(j)
      
      
    }
    #CV[i]=mean(error)
    CV_a[i]=mean(error_a)
    CV_b[i]=mean(error_b)
    CV_c[i]=mean(error_c)
    
  }
  #bandopt=which.min(CV)
  bandopt_a=which.min(CV_a)
  bandopt_b=which.min(CV_b)
  bandopt_c=which.min(CV_c)
  
  
  Y1f=Y0[1:(n1-forecas)]
  Z1f=Z[1:(n1-forecas),]
  Lags1f=Lags[1:(n1-forecas),]
  auto= lm(Y1f~Lags1f)
  pred1=c(1,Lags[n1,])%*%coef(auto)
  error1=pred1-Y0[n1]
  mms9[k,1]=error1
  
  grid2=(1:nrow(Z1f))/nrow(Z1f)
  w=1-grid2
  weights=.kernel(x = w, bw = grid[bandopt_b], tkernel = "Unif", N = 1)
  index=(weights>0)
  
  boost_m=glmboost(x=as.matrix(Z1f)[index,],y=Y1f[index],weights= weights[index],center=TRUE,control = boost_control(mstop = 100,nu=.1))
  #AIC(boost_m)
  boost_m1=glmboost(x=as.matrix(Z1f)[index,],y=Y1f[index],weights= weights[index],center=TRUE,control = boost_control(mstop = mstop(AIC(boost_m)),nu=.1))
  
  coef=coef(boost_m1,off2int=TRUE)
  names1=names(coef[-1])
  pred2=predict(boost_m1,newdata=Z)[n1]
  error2=pred2-Y0[n1]
  mms9[k,2]=error2
  
  boost_m=glmboost(x=as.matrix(Z1f),y=Y1f,center=TRUE,control = boost_control(mstop = 100,nu=.1))
  boost_m1=glmboost(x=as.matrix(Z1f),y=Y1f,center=TRUE,control = boost_control(mstop = mstop(AIC(boost_m)),nu=.1))
  
  coef=coef(boost_m1,off2int=TRUE)
  names1=names(coef[-1])
  pred3=predict(boost_m1,newdata=Z)[n1]
  error3=pred3-Y0[n1]
  mms9[k,3]=error3
  
  last=nrow(Lags1f)
  TVa= tvOLS(cbind(1,Z1f[,truemodel]),Y1f,bw=grid[bandopt_a],est="lc")
  coefs=TVa$tvcoef[last,]
  pred4=c(1,Z[,truemodel][n1,])%*%coefs
  #pred3=c(Xfull[window3,])%*%coefs
  error4=pred4-Y0[n1]
  mms9[k,4]=error4
  
  roll=ceiling(nrow(Z1f)/5)
  weights2=ifelse(((1:last)-last)>-roll,1,0)
  index2=(weights2>0)
  auto=lm(Y1f[index2]~Lags1f[index2,])
  pred5=c(1,Lags[n1,])%*%coef(auto)
  error5=pred5-Y0[n1]
  mms9[k,5]=error5
  
  
  boost_m=glmboost(x=as.matrix(Z1f)[index2,],y=Y1f[index2],center=TRUE,control = boost_control(mstop = 100,nu=.1))
  boost_m1=glmboost(x=as.matrix(Z1f)[index2,],y=Y1f[index2],center=TRUE,control = boost_control(mstop = mstop(AIC(boost_m)),nu=.1))
  
  coef=coef(boost_m1,off2int=TRUE)
  names1=names(coef[-1])
  pred6=predict(boost_m1,newdata=Z)[n1]
  error6=pred6-Y0[n1]
  mms9[k,6]=error6
  
  
  
  Z2f=Z[1:(n1),]
  grid2=(1:nrow(Z2f))/nrow(Z2f)
  Z3f=cbind(Z2f,Z2f*(grid2-1))
  Z3f=data.frame(Z3f)
  colnames(Z3f)<-paste0("Z",1:ncol(Z3f))
  
  Z4f=Z3f[1:(n1-forecas),]
  a=paste0("Y1f~",paste0(apply(matrix(1:ncol(Z4f), ncol = 2, byrow = FALSE), 1, function(vec) paste0("bols(Z",vec[1],",Z",vec[2], ")")),collapse = " + "))
  w=1-(1:nrow(Z4f))/nrow(Z4f)
  weights=.kernel(x = w, bw = grid[bandopt_c], tkernel = "Unif", N = 1)
  index=(weights>0)
  
  
  boost_m2=gamboost(as.formula(a),weights= weights,data=Z4f,control = boost_control(mstop = 100,nu=.1))
  
  
  boost_m3=gamboost(as.formula(a),weights= weights,data=Z4f, control = boost_control(mstop = mstop(AIC(boost_m)),nu=.1))
  
  
  pred7=predict(boost_m3,newdata=Z3f[(n1),])
  
  error7=abs(pred7-Y0[n1])
  
  mms9[k,7]=error7
  
  
  model1=glmnet(as.matrix(Z1f),Y1f)
  ## use BIC to select lambda
  f=(deviance(model1)/n2)/var(Y1f)
  g=model1$df
  
  BIC1=log(f)+g*(log(n2)/n2)
  
  number=model1$lambda[which.min(BIC1)]
  model1=glmnet(as.matrix(Z1f),Y1f,lambda=number)
  
  pred8=predict(model1,newx=as.matrix(Z[(1:n1),]))[n1]
  mms9[k,8]=abs(pred8-Y0[n1])
  
  
  
  
}



####################### DGP 10 ##################################


mms10=matrix(0,nrow=predsamp,ncol=nmodels)





alpha1<-function(x){.6}
B1 <- function(x){.5+1/(1+exp(-10*(x-.9)))}
B2<- function(x){.5+1/(1+exp(-5*(x-.9)))}
B3<-function(x){.5+1/(1+exp(-20*(x-.9)))}
B4<-function(x){.5+1/(1+exp(-10*(x-.9)))}



Y = rep(0,n2)
Y0 = 0
Y[1] = Error[1]
for(j in 2:n2){
  Y[j] = Y[j-1]*alpha1(t[j])+X[j-1,1]*B1(t[j])+X[j-1,2]*B2(t[j])+X[j-1,3]*B3(t[j])+X[j-1,4]*B4(t[j])+Error[j]
}


Xold = X
Xwl = matrix(0, (n2-n), d*r)


sub = (n+1):n2
for(j in 1:d){
  Xwl[,(r*j-(r-1)):(r*j)] = c( Xold[sub-1,j], Xold[sub-2,j], Xold[sub-3,j])
}




Y0 = Y[sub]
Y1 = Y[sub-1]
Y2 = Y[sub-2]
Y3 = Y[sub-3]
Z=cbind(Y1,Y2,Y3,Xwl)
names1=c()
for(i in 1:ncol(Z)){
  names1[i]=paste0('Var',i)
}
colnames(Z)<-names1
Lags=cbind(Y1,Y2,Y3)




for(k in 1:predsamp)
{
  grid=seq(.3,1,length.out=8)
  n1=samp-predsamp+k
  #Y1=Y[1:(n-forecas)]
  #X1=X[1:(n-forecas),]
  CV=c()
  CV_a=c()
  CV_b=c()
  CV_c=c()
  for(i in 1:length(grid))
  {
    error=c()
    error_a=c()
    error_b=c()
    error_c=c()
    for(j in (forecas):(d1+forecas-1))
    {
      Y1c=Y0[1:(n1-forecas-j)]
      Z1=Z[1:(n1-forecas-j),]
      Lags1=Lags[1:(n1-forecas-j),]
      grid2=(1:nrow(Z1))/nrow(Z1)
      
      
      w=1-grid2
      weights=.kernel(x = w, bw = grid[i], tkernel = "Unif", N = 1)
      index=(weights>0)
      
      boost_m=glmboost(x=as.matrix(Z1)[index,],y=Y1c[index],weights= weights[index],center=TRUE,control = boost_control(mstop = 100,nu=.1))
      #AIC(boost_m)
      boost_m1=glmboost(x=as.matrix(Z1)[index,],y=Y1c[index],weights= weights[index],center=TRUE,control = boost_control(mstop = mstop(AIC(boost_m)),nu=.1))
      coef=coef(boost_m1,off2int=TRUE)
      
      names1=names(coef[-1])
      pred1=predict(boost_m1,newdata=Z)[n1-j]
      error_b[j-forecas+1]=abs(pred1-Y0[n1-j])^2
      
      
      result1 <- stats::lm.wfit(x = cbind(1,Z1[,truemodel])[index,], y = Y1c[index], w = weights[index])
      theta1 <- result1$coef
      pred1=c(1,Z[,truemodel][n1-j,])%*%theta1
      error_a[j-forecas+1]=abs(pred1-Y0[n1-j])^2
      
      
      
      
      Z2=Z[1:(n1-j),]
      grid2=(1:nrow(Z2))/nrow(Z2)
      Z3=cbind(Z2,Z2*(grid2-1))
      Z3=data.frame(Z3)
      colnames(Z3)<-paste0("Z",1:ncol(Z3))
      
      Z4=Z3[1:(n1-forecas-j),]
      a=paste0("Y1c~",paste0(apply(matrix(1:ncol(Z4), ncol = 2, byrow = FALSE), 1, function(vec) paste0("bols(Z",vec[1],",Z",vec[2], ")")),collapse = " + "))
      w=1-(1:nrow(Z4))/nrow(Z4)
      weights=.kernel(x = w, bw = grid[i], tkernel = "Unif", N = 1)
      index=(weights>0)
      
      
      boost_m2=gamboost(as.formula(a),weights= weights,data=Z4,control = boost_control(mstop = 100,nu=.1))
      
      
      boost_m3=gamboost(as.formula(a),weights= weights,data=Z4, control = boost_control(mstop = mstop(AIC(boost_m2)),nu=.1))
      
      
      pred1=predict(boost_m3,newdata=Z3[(n1-j),])
      
      error_c[j-forecas+1]=abs(pred1-Y0[n1-j])^2
      print(j)
      
      
      
    }
    #CV[i]=mean(error)
    CV_a[i]=mean(error_a)
    CV_b[i]=mean(error_b)
    CV_c[i]=mean(error_c)
    
  }
  #bandopt=which.min(CV)
  bandopt_a=which.min(CV_a)
  bandopt_b=which.min(CV_b)
  bandopt_c=which.min(CV_c)
  
  
  Y1f=Y0[1:(n1-forecas)]
  Z1f=Z[1:(n1-forecas),]
  Lags1f=Lags[1:(n1-forecas),]
  auto= lm(Y1f~Lags1f)
  pred1=c(1,Lags[n1,])%*%coef(auto)
  error1=pred1-Y0[n1]
  mms10[k,1]=error1
  
  grid2=(1:nrow(Z1f))/nrow(Z1f)
  w=1-grid2
  weights=.kernel(x = w, bw = grid[bandopt_b], tkernel = "Unif", N = 1)
  index=(weights>0)
  
  boost_m=glmboost(x=as.matrix(Z1f)[index,],y=Y1f[index],weights= weights[index],center=TRUE,control = boost_control(mstop = 100,nu=.1))
  #AIC(boost_m)
  boost_m1=glmboost(x=as.matrix(Z1f)[index,],y=Y1f[index],weights= weights[index],center=TRUE,control = boost_control(mstop = mstop(AIC(boost_m)),nu=.1))
  
  coef=coef(boost_m1,off2int=TRUE)
  names1=names(coef[-1])
  pred2=predict(boost_m1,newdata=Z)[n1]
  error2=pred2-Y0[n1]
  mms10[k,2]=error2
  
  boost_m=glmboost(x=as.matrix(Z1f),y=Y1f,center=TRUE,control = boost_control(mstop = 100,nu=.1))
  boost_m1=glmboost(x=as.matrix(Z1f),y=Y1f,center=TRUE,control = boost_control(mstop = mstop(AIC(boost_m)),nu=.1))
  
  coef=coef(boost_m1,off2int=TRUE)
  names1=names(coef[-1])
  pred3=predict(boost_m1,newdata=Z)[n1]
  error3=pred3-Y0[n1]
  mms10[k,3]=error3
  
  last=nrow(Lags1f)
  TVa= tvOLS(cbind(1,Z1f[,truemodel]),Y1f,bw=grid[bandopt_a],est="lc")
  coefs=TVa$tvcoef[last,]
  pred4=c(1,Z[,truemodel][n1,])%*%coefs
  #pred3=c(Xfull[window3,])%*%coefs
  error4=pred4-Y0[n1]
  mms10[k,4]=error4
  
  roll=ceiling(nrow(Z1f)/5)
  weights2=ifelse(((1:last)-last)>-roll,1,0)
  index2=(weights2>0)
  auto=lm(Y1f[index2]~Lags1f[index2,])
  pred5=c(1,Lags[n1,])%*%coef(auto)
  error5=pred5-Y0[n1]
  mms10[k,5]=error5
  
  
  boost_m=glmboost(x=as.matrix(Z1f)[index2,],y=Y1f[index2],center=TRUE,control = boost_control(mstop = 100,nu=.1))
  boost_m1=glmboost(x=as.matrix(Z1f)[index2,],y=Y1f[index2],center=TRUE,control = boost_control(mstop = mstop(AIC(boost_m)),nu=.1))
  
  coef=coef(boost_m1,off2int=TRUE)
  names1=names(coef[-1])
  pred6=predict(boost_m1,newdata=Z)[n1]
  error6=pred6-Y0[n1]
  mms10[k,6]=error6
  
  
  
  Z2f=Z[1:(n1),]
  grid2=(1:nrow(Z2f))/nrow(Z2f)
  Z3f=cbind(Z2f,Z2f*(grid2-1))
  Z3f=data.frame(Z3f)
  colnames(Z3f)<-paste0("Z",1:ncol(Z3f))
  
  Z4f=Z3f[1:(n1-forecas),]
  a=paste0("Y1f~",paste0(apply(matrix(1:ncol(Z4f), ncol = 2, byrow = FALSE), 1, function(vec) paste0("bols(Z",vec[1],",Z",vec[2], ")")),collapse = " + "))
  w=1-(1:nrow(Z4f))/nrow(Z4f)
  weights=.kernel(x = w, bw = grid[bandopt_c], tkernel = "Unif", N = 1)
  index=(weights>0)
  
  
  boost_m2=gamboost(as.formula(a),weights= weights,data=Z4f,control = boost_control(mstop = 100,nu=.1))
  
  
  boost_m3=gamboost(as.formula(a),weights= weights,data=Z4f, control = boost_control(mstop = mstop(AIC(boost_m)),nu=.1))
  
  
  pred7=predict(boost_m3,newdata=Z3f[(n1),])
  
  error7=abs(pred7-Y0[n1])
  
  mms10[k,7]=error7
  
  
  model1=glmnet(as.matrix(Z1f),Y1f)
  ## use BIC to select lambda
  f=(deviance(model1)/n2)/var(Y1f)
  g=model1$df
  
  BIC1=log(f)+g*(log(n2)/n2)
  
  number=model1$lambda[which.min(BIC1)]
  model1=glmnet(as.matrix(Z1f),Y1f,lambda=number)
  
  pred8=predict(model1,newx=as.matrix(Z[(1:n1),]))[n1]
  mms10[k,8]=abs(pred8-Y0[n1])
  
  
  
  
}










################################# DGP 11 ###############################


mms11=matrix(0,nrow=predsamp,ncol=nmodels)




alpha1<-function(x){.6}
B1 <- function(x){.5-.3*x^2}
B2<- function(x){.5+x^2}
B3<-function(x){.5-.4*x}
B4<-function(x){.5+x}



Y = rep(0,n2)
Y0 = 0
Y[1] = Error[1]
for(j in 2:n2){
  Y[j] = Y[j-1]*alpha1(t[j])+X[j-1,1]*B1(t[j])+X[j-1,2]*B2(t[j])+X[j-1,3]*B3(t[j])+X[j-1,4]*B4(t[j])+Error[j]
}


Xold = X
Xwl = matrix(0, (n2-n), d*r)


sub = (n+1):n2
for(j in 1:d){
  Xwl[,(r*j-(r-1)):(r*j)] = c( Xold[sub-1,j], Xold[sub-2,j], Xold[sub-3,j])
}




Y0 = Y[sub]
Y1 = Y[sub-1]
Y2 = Y[sub-2]
Y3 = Y[sub-3]
Z=cbind(Y1,Y2,Y3,Xwl)



names1=c()
for(i in 1:ncol(Z)){
  names1[i]=paste0('Var',i)
}
colnames(Z)<-names1
Lags=cbind(Y1,Y2,Y3)


for(k in 1:predsamp)
{
  grid=seq(.3,1,length.out=8)
  n1=samp-predsamp+k
  #Y1=Y[1:(n-forecas)]
  #X1=X[1:(n-forecas),]
  CV=c()
  CV_a=c()
  CV_b=c()
  CV_c=c()
  for(i in 1:length(grid))
  {
    error=c()
    error_a=c()
    error_b=c()
    error_c=c()
    for(j in (forecas):(d1+forecas-1))
    {
      Y1c=Y0[1:(n1-forecas-j)]
      Z1=Z[1:(n1-forecas-j),]
      Lags1=Lags[1:(n1-forecas-j),]
      grid2=(1:nrow(Z1))/nrow(Z1)
      
      
      w=1-grid2
      weights=.kernel(x = w, bw = grid[i], tkernel = "Unif", N = 1)
      index=(weights>0)
      
      boost_m=glmboost(x=as.matrix(Z1)[index,],y=Y1c[index],weights= weights[index],center=TRUE,control = boost_control(mstop = 100,nu=.1))
      #AIC(boost_m)
      boost_m1=glmboost(x=as.matrix(Z1)[index,],y=Y1c[index],weights= weights[index],center=TRUE,control = boost_control(mstop = mstop(AIC(boost_m)),nu=.1))
      coef=coef(boost_m1,off2int=TRUE)
      
      names1=names(coef[-1])
      pred1=predict(boost_m1,newdata=Z)[n1-j]
      error_b[j-forecas+1]=abs(pred1-Y0[n1-j])^2
      
      
      result1 <- stats::lm.wfit(x = cbind(1,Z1[,truemodel])[index,], y = Y1c[index], w = weights[index])
      theta1 <- result1$coef
      pred1=c(1,Z[,truemodel][n1-j,])%*%theta1
      error_a[j-forecas+1]=abs(pred1-Y0[n1-j])^2
      
      
      
      
      Z2=Z[1:(n1-j),]
      grid2=(1:nrow(Z2))/nrow(Z2)
      Z3=cbind(Z2,Z2*(grid2-1))
      Z3=data.frame(Z3)
      colnames(Z3)<-paste0("Z",1:ncol(Z3))
      
      Z4=Z3[1:(n1-forecas-j),]
      a=paste0("Y1c~",paste0(apply(matrix(1:ncol(Z4), ncol = 2, byrow = FALSE), 1, function(vec) paste0("bols(Z",vec[1],",Z",vec[2], ")")),collapse = " + "))
      w=1-(1:nrow(Z4))/nrow(Z4)
      weights=.kernel(x = w, bw = grid[i], tkernel = "Unif", N = 1)
      index=(weights>0)
      
      
      boost_m2=gamboost(as.formula(a),weights= weights,data=Z4,control = boost_control(mstop = 100,nu=.1))
      
      
      boost_m3=gamboost(as.formula(a),weights= weights,data=Z4, control = boost_control(mstop = mstop(AIC(boost_m2)),nu=.1))
      
      
      pred1=predict(boost_m3,newdata=Z3[(n1-j),])
      
      error_c[j-forecas+1]=abs(pred1-Y0[n1-j])^2
      print(j)
      
      
      
    }
    #CV[i]=mean(error)
    CV_a[i]=mean(error_a)
    CV_b[i]=mean(error_b)
    CV_c[i]=mean(error_c)
    
  }
  #bandopt=which.min(CV)
  bandopt_a=which.min(CV_a)
  bandopt_b=which.min(CV_b)
  bandopt_c=which.min(CV_c)
  
  
  Y1f=Y0[1:(n1-forecas)]
  Z1f=Z[1:(n1-forecas),]
  Lags1f=Lags[1:(n1-forecas),]
  auto= lm(Y1f~Lags1f)
  pred1=c(1,Lags[n1,])%*%coef(auto)
  error1=pred1-Y0[n1]
  mms11[k,1]=error1
  
  grid2=(1:nrow(Z1f))/nrow(Z1f)
  w=1-grid2
  weights=.kernel(x = w, bw = grid[bandopt_b], tkernel = "Unif", N = 1)
  index=(weights>0)
  
  boost_m=glmboost(x=as.matrix(Z1f)[index,],y=Y1f[index],weights= weights[index],center=TRUE,control = boost_control(mstop = 100,nu=.1))
  #AIC(boost_m)
  boost_m1=glmboost(x=as.matrix(Z1f)[index,],y=Y1f[index],weights= weights[index],center=TRUE,control = boost_control(mstop = mstop(AIC(boost_m)),nu=.1))
  
  coef=coef(boost_m1,off2int=TRUE)
  names1=names(coef[-1])
  pred2=predict(boost_m1,newdata=Z)[n1]
  error2=pred2-Y0[n1]
  mms11[k,2]=error2
  
  boost_m=glmboost(x=as.matrix(Z1f),y=Y1f,center=TRUE,control = boost_control(mstop = 100,nu=.1))
  boost_m1=glmboost(x=as.matrix(Z1f),y=Y1f,center=TRUE,control = boost_control(mstop = mstop(AIC(boost_m)),nu=.1))
  
  coef=coef(boost_m1,off2int=TRUE)
  names1=names(coef[-1])
  pred3=predict(boost_m1,newdata=Z)[n1]
  error3=pred3-Y0[n1]
  mms11[k,3]=error3
  
  last=nrow(Lags1f)
  TVa= tvOLS(cbind(1,Z1f[,truemodel]),Y1f,bw=grid[bandopt_a],est="lc")
  coefs=TVa$tvcoef[last,]
  pred4=c(1,Z[,truemodel][n1,])%*%coefs
  #pred3=c(Xfull[window3,])%*%coefs
  error4=pred4-Y0[n1]
  mms11[k,4]=error4
  
  roll=ceiling(nrow(Z1f)/5)
  weights2=ifelse(((1:last)-last)>-roll,1,0)
  index2=(weights2>0)
  auto=lm(Y1f[index2]~Lags1f[index2,])
  pred5=c(1,Lags[n1,])%*%coef(auto)
  error5=pred5-Y0[n1]
  mms11[k,5]=error5
  
  
  boost_m=glmboost(x=as.matrix(Z1f)[index2,],y=Y1f[index2],center=TRUE,control = boost_control(mstop = 100,nu=.1))
  boost_m1=glmboost(x=as.matrix(Z1f)[index2,],y=Y1f[index2],center=TRUE,control = boost_control(mstop = mstop(AIC(boost_m)),nu=.1))
  
  coef=coef(boost_m1,off2int=TRUE)
  names1=names(coef[-1])
  pred6=predict(boost_m1,newdata=Z)[n1]
  error6=pred6-Y0[n1]
  mms11[k,6]=error6
  
  
  
  Z2f=Z[1:(n1),]
  grid2=(1:nrow(Z2f))/nrow(Z2f)
  Z3f=cbind(Z2f,Z2f*(grid2-1))
  Z3f=data.frame(Z3f)
  colnames(Z3f)<-paste0("Z",1:ncol(Z3f))
  
  Z4f=Z3f[1:(n1-forecas),]
  a=paste0("Y1f~",paste0(apply(matrix(1:ncol(Z4f), ncol = 2, byrow = FALSE), 1, function(vec) paste0("bols(Z",vec[1],",Z",vec[2], ")")),collapse = " + "))
  w=1-(1:nrow(Z4f))/nrow(Z4f)
  weights=.kernel(x = w, bw = grid[bandopt_c], tkernel = "Unif", N = 1)
  index=(weights>0)
  
  
  boost_m2=gamboost(as.formula(a),weights= weights,data=Z4f,control = boost_control(mstop = 100,nu=.1))
  
  
  boost_m3=gamboost(as.formula(a),weights= weights,data=Z4f, control = boost_control(mstop = mstop(AIC(boost_m)),nu=.1))
  
  
  pred7=predict(boost_m3,newdata=Z3f[(n1),])
  
  error7=abs(pred7-Y0[n1])
  
  mms11[k,7]=error7
  
  
  model1=glmnet(as.matrix(Z1f),Y1f)
  ## use BIC to select lambda
  f=(deviance(model1)/n2)/var(Y1f)
  g=model1$df
  
  BIC1=log(f)+g*(log(n2)/n2)
  
  number=model1$lambda[which.min(BIC1)]
  model1=glmnet(as.matrix(Z1f),Y1f,lambda=number)
  
  pred8=predict(model1,newx=as.matrix(Z[(1:n1),]))[n1]
  mms11[k,8]=abs(pred8-Y0[n1])
  
  
  
  
}





mms=colMeans(mms1^2)


save(mms,file=paste0('resultsTVP/sim6_Norm-',randSeed,'.RData'))


################################# DGP 12 ###############################

mms12=matrix(0,nrow=predsamp,ncol=nmodels)

alpha1<-function(x){.6}
B1 <- function(x){.5}
B2<- function(x){.5}
B3<-function(x){.5+3*cos(2*pi*x)}
B4<-function(x){.5+2*x*sin(2*pi*x)}



Y = rep(0,n2)
Y0 = 0
Y[1] = Error[1]
for(j in 2:n2){
  Y[j] = Y[j-1]*alpha1(t[j])+X[j-1,1]*B1(t[j])+X[j-1,2]*B2(t[j])+X[j-1,3]*B3(t[j])+X[j-1,4]*B4(t[j])+Error[j]
}




Xold = X
Xwl = matrix(0, (n2-n), d*r)



sub = (n+1):n2
for(j in 1:d){
  Xwl[,(r*j-(r-1)):(r*j)] = c( Xold[sub-1,j], Xold[sub-2,j], Xold[sub-3,j])
}




Y0 = Y[sub]
Y1 = Y[sub-1]
Y2 = Y[sub-2]
Y3 = Y[sub-3]
Z=cbind(Y1,Y2,Y3,Xwl)



names1=c()
for(i in 1:ncol(Z)){
  names1[i]=paste0('Var',i)
}
colnames(Z)<-names1
Lags=cbind(Y1,Y2,Y3)




for(k in 1:predsamp)
{
  grid=seq(.3,1,length.out=8)
  n1=samp-predsamp+k
  #Y1=Y[1:(n-forecas)]
  #X1=X[1:(n-forecas),]
  CV=c()
  CV_a=c()
  CV_b=c()
  CV_c=c()
  for(i in 1:length(grid))
  {
    error=c()
    error_a=c()
    error_b=c()
    error_c=c()
    for(j in (forecas):(d1+forecas-1))
    {
      Y1c=Y0[1:(n1-forecas-j)]
      Z1=Z[1:(n1-forecas-j),]
      Lags1=Lags[1:(n1-forecas-j),]
      grid2=(1:nrow(Z1))/nrow(Z1)
      
      
      w=1-grid2
      weights=.kernel(x = w, bw = grid[i], tkernel = "Unif", N = 1)
      index=(weights>0)
      #result <- stats::lm.wfit(x = cbind(1,X1,factorsr1)[index,], y = Y1[index], w = weights[index])
      #theta <- result$coef
      #pred1=c(1,Lags[n1-j,],factors[n1-j,])%*%theta
      #error[j+1]=abs(pred1-Y0[n1-j])^2
      boost_m=glmboost(x=as.matrix(Z1)[index,],y=Y1c[index],weights= weights[index],center=TRUE,control = boost_control(mstop = 100,nu=.1))
      #AIC(boost_m)
      boost_m1=glmboost(x=as.matrix(Z1)[index,],y=Y1c[index],weights= weights[index],center=TRUE,control = boost_control(mstop = mstop(AIC(boost_m)),nu=.1))
      coef=coef(boost_m1,off2int=TRUE)
      
      names1=names(coef[-1])
      pred1=predict(boost_m1,newdata=Z)[n1-j]
      error_b[j-forecas+1]=abs(pred1-Y0[n1-j])^2
      
      
      result1 <- stats::lm.wfit(x = cbind(1,Z1[,truemodel])[index,], y = Y1c[index], w = weights[index])
      theta1 <- result1$coef
      pred1=c(1,Z[,truemodel][n1-j,])%*%theta1
      error_a[j-forecas+1]=abs(pred1-Y0[n1-j])^2
      
      
      
      
      Z2=Z[1:(n1-j),]
      grid2=(1:nrow(Z2))/nrow(Z2)
      Z3=cbind(Z2,Z2*(grid2-1))
      Z3=data.frame(Z3)
      colnames(Z3)<-paste0("Z",1:ncol(Z3))
      
      Z4=Z3[1:(n1-forecas-j),]
      a=paste0("Y1c~",paste0(apply(matrix(1:ncol(Z4), ncol = 2, byrow = FALSE), 1, function(vec) paste0("bols(Z",vec[1],",Z",vec[2], ")")),collapse = " + "))
      w=1-(1:nrow(Z4))/nrow(Z4)
      weights=.kernel(x = w, bw = grid[i], tkernel = "Unif", N = 1)
      index=(weights>0)
      
      
      boost_m2=gamboost(as.formula(a),weights= weights,data=Z4,control = boost_control(mstop = 100,nu=.1))
      
      
      boost_m3=gamboost(as.formula(a),weights= weights,data=Z4, control = boost_control(mstop = mstop(AIC(boost_m2)),nu=.1))
      
      
      pred1=predict(boost_m3,newdata=Z3[(n1-j),])
      
      error_c[j-forecas+1]=abs(pred1-Y0[n1-j])^2
      print(j)
      
      
      
    }
    #CV[i]=mean(error)
    CV_a[i]=mean(error_a)
    CV_b[i]=mean(error_b)
    CV_c[i]=mean(error_c)
    
  }
  #bandopt=which.min(CV)
  bandopt_a=which.min(CV_a)
  bandopt_b=which.min(CV_b)
  bandopt_c=which.min(CV_c)
  
  
  Y1f=Y0[1:(n1-forecas)]
  Z1f=Z[1:(n1-forecas),]
  Lags1f=Lags[1:(n1-forecas),]
  auto= lm(Y1f~Lags1f)
  pred1=c(1,Lags[n1,])%*%coef(auto)
  error1=pred1-Y0[n1]
  mms12[k,1]=error1
  
  grid2=(1:nrow(Z1f))/nrow(Z1f)
  w=1-grid2
  weights=.kernel(x = w, bw = grid[bandopt_b], tkernel = "Unif", N = 1)
  index=(weights>0)
  
  boost_m=glmboost(x=as.matrix(Z1f)[index,],y=Y1f[index],weights= weights[index],center=TRUE,control = boost_control(mstop = 100,nu=.1))
  #AIC(boost_m)
  boost_m1=glmboost(x=as.matrix(Z1f)[index,],y=Y1f[index],weights= weights[index],center=TRUE,control = boost_control(mstop = mstop(AIC(boost_m)),nu=.1))
  
  coef=coef(boost_m1,off2int=TRUE)
  names1=names(coef[-1])
  pred2=predict(boost_m1,newdata=Z)[n1]
  error2=pred2-Y0[n1]
  mms12[k,2]=error2
  
  boost_m=glmboost(x=as.matrix(Z1f),y=Y1f,center=TRUE,control = boost_control(mstop = 100,nu=.1))
  boost_m1=glmboost(x=as.matrix(Z1f),y=Y1f,center=TRUE,control = boost_control(mstop = mstop(AIC(boost_m)),nu=.1))
  
  coef=coef(boost_m1,off2int=TRUE)
  names1=names(coef[-1])
  pred3=predict(boost_m1,newdata=Z)[n1]
  error3=pred3-Y0[n1]
  mms12[k,3]=error3
  
  last=nrow(Lags1f)
  TVa= tvOLS(cbind(1,Z1f[,truemodel]),Y1f,bw=grid[bandopt_a],est="lc")
  coefs=TVa$tvcoef[last,]
  pred4=c(1,Z[,truemodel][n1,])%*%coefs
  #pred3=c(Xfull[window3,])%*%coefs
  error4=pred4-Y0[n1]
  mms12[k,4]=error4
  
  roll=ceiling(nrow(Z1f)/5)
  weights2=ifelse(((1:last)-last)>-roll,1,0)
  index2=(weights2>0)
  auto=lm(Y1f[index2]~Lags1f[index2,])
  pred5=c(1,Lags[n1,])%*%coef(auto)
  error5=pred5-Y0[n1]
  mms12[k,5]=error5
  
  
  boost_m=glmboost(x=as.matrix(Z1f)[index2,],y=Y1f[index2],center=TRUE,control = boost_control(mstop = 100,nu=.1))
  boost_m1=glmboost(x=as.matrix(Z1f)[index2,],y=Y1f[index2],center=TRUE,control = boost_control(mstop = mstop(AIC(boost_m)),nu=.1))
  
  coef=coef(boost_m1,off2int=TRUE)
  names1=names(coef[-1])
  pred6=predict(boost_m1,newdata=Z)[n1]
  error6=pred6-Y0[n1]
  mms12[k,6]=error6
  
  
  
  Z2f=Z[1:(n1),]
  grid2=(1:nrow(Z2f))/nrow(Z2f)
  Z3f=cbind(Z2f,Z2f*(grid2-1))
  Z3f=data.frame(Z3f)
  colnames(Z3f)<-paste0("Z",1:ncol(Z3f))
  
  Z4f=Z3f[1:(n1-forecas),]
  a=paste0("Y1f~",paste0(apply(matrix(1:ncol(Z4f), ncol = 2, byrow = FALSE), 1, function(vec) paste0("bols(Z",vec[1],",Z",vec[2], ")")),collapse = " + "))
  w=1-(1:nrow(Z4f))/nrow(Z4f)
  weights=.kernel(x = w, bw = grid[bandopt_c], tkernel = "Unif", N = 1)
  index=(weights>0)
  
  
  boost_m2=gamboost(as.formula(a),weights= weights,data=Z4f,control = boost_control(mstop = 100,nu=.1))
  
  
  boost_m3=gamboost(as.formula(a),weights= weights,data=Z4f, control = boost_control(mstop = mstop(AIC(boost_m)),nu=.1))
  
  
  pred7=predict(boost_m3,newdata=Z3f[(n1),])
  
  error7=abs(pred7-Y0[n1])
  
  mms12[k,7]=error7
  
  
  model1=glmnet(as.matrix(Z1f),Y1f)
  ## use BIC to select lambda
  f=(deviance(model1)/n2)/var(Y1f)
  g=model1$df
  
  BIC1=log(f)+g*(log(n2)/n2)
  
  number=model1$lambda[which.min(BIC1)]
  model1=glmnet(as.matrix(Z1f),Y1f,lambda=number)
  
  pred8=predict(model1,newx=as.matrix(Z[(1:n1),]))[n1]
  mms12[k,8]=abs(pred8-Y0[n1])
  
  
  
  
}












##### DGP 13 #######################################


mms13=matrix(0,nrow=predsamp,ncol=nmodels)


A1= outer(1:d, 1:d, f<-function(x,y){.2^(abs(x-y)+1)})

A2=outer(1:d, 1:d, f<-function(x,y){.4^(abs(x-y)+1)})
C=diag(1,d)


t=(1:n2)/n2
X=matrix(0,nrow=n2,ncol=d)
X[1,]=rmt(n=1, mean=rep(0,d), S=3/5*C,df=5)
for(j in 2:n2){
  A=((1-t[j]))*A1+(t[j])*A2
  #A=diag(.4,d)
  X[j,] = A%*%X[j-1,]+rmt(n=1, mean=rep(0,d), S=3/5*C,df=5)
}


alpha1<-function(x){.6}
B1 <- function(x){.5+1/(1+exp(-10*(x-.75)))}
B2<- function(x){.5+1/(1+exp(-5*(x-.75)))}
B3<-function(x){.5+1/(1+exp(-20*(x-.75)))}
B4<-function(x){.5+1/(1+exp(-10*(x-.75)))}


Y = rep(0,n2)
Y0 = 0
Y[1] = Error[1]
for(j in 2:n2){
  Y[j] = Y[j-1]*alpha1(t[j])+X[j-1,1]*B1(t[j])+X[j-1,2]*B2(t[j])+X[j-1,3]*B3(t[j])+X[j-1,4]*B4(t[j])+Error[j]
}








Xold = X
Xwl = matrix(0, (n2-n), d*r)

sub = (n+1):n2
for(j in 1:d){
  Xwl[,(r*j-(r-1)):(r*j)] = c( Xold[sub-1,j], Xold[sub-2,j], Xold[sub-3,j])
}




Y0 = Y[sub]
Y1 = Y[sub-1]
Y2 = Y[sub-2]
Y3 = Y[sub-3]
Z=cbind(Y1,Y2,Y3,Xwl)
names1=c()
for(i in 1:ncol(Z)){
  names1[i]=paste0('Var',i)
}
colnames(Z)<-names1
Lags=cbind(Y1,Y2,Y3)



for(k in 1:predsamp)
{
  grid=seq(.3,1,length.out=8)
  n1=samp-predsamp+k
  #Y1=Y[1:(n-forecas)]
  #X1=X[1:(n-forecas),]
  CV=c()
  CV_a=c()
  CV_b=c()
  CV_c=c()
  for(i in 1:length(grid))
  {
    error=c()
    error_a=c()
    error_b=c()
    error_c=c()
    for(j in (forecas):(d1+forecas-1))
    {
      Y1c=Y0[1:(n1-forecas-j)]
      Z1=Z[1:(n1-forecas-j),]
      Lags1=Lags[1:(n1-forecas-j),]
      grid2=(1:nrow(Z1))/nrow(Z1)
      
      w=1-grid2
      weights=.kernel(x = w, bw = grid[i], tkernel = "Unif", N = 1)
      index=(weights>0)
      
      boost_m=glmboost(x=as.matrix(Z1)[index,],y=Y1c[index],weights= weights[index],center=TRUE,control = boost_control(mstop = 100,nu=.1))
      #AIC(boost_m)
      boost_m1=glmboost(x=as.matrix(Z1)[index,],y=Y1c[index],weights= weights[index],center=TRUE,control = boost_control(mstop = mstop(AIC(boost_m)),nu=.1))
      coef=coef(boost_m1,off2int=TRUE)
      
      names1=names(coef[-1])
      pred1=predict(boost_m1,newdata=Z)[n1-j]
      error_b[j-forecas+1]=abs(pred1-Y0[n1-j])^2
      
      
      result1 <- stats::lm.wfit(x = cbind(1,Z1[,truemodel])[index,], y = Y1c[index], w = weights[index])
      theta1 <- result1$coef
      pred1=c(1,Z[,truemodel][n1-j,])%*%theta1
      error_a[j-forecas+1]=abs(pred1-Y0[n1-j])^2
      
      
      
      
      Z2=Z[1:(n1-j),]
      grid2=(1:nrow(Z2))/nrow(Z2)
      Z3=cbind(Z2,Z2*(grid2-1))
      Z3=data.frame(Z3)
      colnames(Z3)<-paste0("Z",1:ncol(Z3))
      
      Z4=Z3[1:(n1-forecas-j),]
      a=paste0("Y1c~",paste0(apply(matrix(1:ncol(Z4), ncol = 2, byrow = FALSE), 1, function(vec) paste0("bols(Z",vec[1],",Z",vec[2], ")")),collapse = " + "))
      w=1-(1:nrow(Z4))/nrow(Z4)
      weights=.kernel(x = w, bw = grid[i], tkernel = "Unif", N = 1)
      index=(weights>0)
      
      
      boost_m2=gamboost(as.formula(a),weights= weights,data=Z4,control = boost_control(mstop = 100,nu=.1))
      
      
      boost_m3=gamboost(as.formula(a),weights= weights,data=Z4, control = boost_control(mstop = mstop(AIC(boost_m2)),nu=.1))
      
      
      pred1=predict(boost_m3,newdata=Z3[(n1-j),])
      
      error_c[j-forecas+1]=abs(pred1-Y0[n1-j])^2
      print(j)
      
      
      
    }
    #CV[i]=mean(error)
    CV_a[i]=mean(error_a)
    CV_b[i]=mean(error_b)
    CV_c[i]=mean(error_c)
    
  }
  #bandopt=which.min(CV)
  bandopt_a=which.min(CV_a)
  bandopt_b=which.min(CV_b)
  bandopt_c=which.min(CV_c)
  
  
  Y1f=Y0[1:(n1-forecas)]
  Z1f=Z[1:(n1-forecas),]
  Lags1f=Lags[1:(n1-forecas),]
  auto= lm(Y1f~Lags1f)
  pred1=c(1,Lags[n1,])%*%coef(auto)
  error1=pred1-Y0[n1]
  mms13[k,1]=error1
  
  grid2=(1:nrow(Z1f))/nrow(Z1f)
  w=1-grid2
  weights=.kernel(x = w, bw = grid[bandopt_b], tkernel = "Unif", N = 1)
  index=(weights>0)
  
  boost_m=glmboost(x=as.matrix(Z1f)[index,],y=Y1f[index],weights= weights[index],center=TRUE,control = boost_control(mstop = 100,nu=.1))
  #AIC(boost_m)
  boost_m1=glmboost(x=as.matrix(Z1f)[index,],y=Y1f[index],weights= weights[index],center=TRUE,control = boost_control(mstop = mstop(AIC(boost_m)),nu=.1))
  
  coef=coef(boost_m1,off2int=TRUE)
  names1=names(coef[-1])
  pred2=predict(boost_m1,newdata=Z)[n1]
  error2=pred2-Y0[n1]
  mms13[k,2]=error2
  
  boost_m=glmboost(x=as.matrix(Z1f),y=Y1f,center=TRUE,control = boost_control(mstop = 100,nu=.1))
  boost_m1=glmboost(x=as.matrix(Z1f),y=Y1f,center=TRUE,control = boost_control(mstop = mstop(AIC(boost_m)),nu=.1))
  
  coef=coef(boost_m1,off2int=TRUE)
  names1=names(coef[-1])
  pred3=predict(boost_m1,newdata=Z)[n1]
  error3=pred3-Y0[n1]
  mms13[k,3]=error3
  
  last=nrow(Lags1f)
  TVa= tvOLS(cbind(1,Z1f[,truemodel]),Y1f,bw=grid[bandopt_a],est="lc")
  coefs=TVa$tvcoef[last,]
  pred4=c(1,Z[,truemodel][n1,])%*%coefs
  #pred3=c(Xfull[window3,])%*%coefs
  error4=pred4-Y0[n1]
  mms13[k,4]=error4
  
  roll=ceiling(nrow(Z1f)/5)
  weights2=ifelse(((1:last)-last)>-roll,1,0)
  index2=(weights2>0)
  auto=lm(Y1f[index2]~Lags1f[index2,])
  pred5=c(1,Lags[n1,])%*%coef(auto)
  error5=pred5-Y0[n1]
  mms13[k,5]=error5
  
  
  boost_m=glmboost(x=as.matrix(Z1f)[index2,],y=Y1f[index2],center=TRUE,control = boost_control(mstop = 100,nu=.1))
  boost_m1=glmboost(x=as.matrix(Z1f)[index2,],y=Y1f[index2],center=TRUE,control = boost_control(mstop = mstop(AIC(boost_m)),nu=.1))
  
  coef=coef(boost_m1,off2int=TRUE)
  names1=names(coef[-1])
  pred6=predict(boost_m1,newdata=Z)[n1]
  error6=pred6-Y0[n1]
  mms13[k,6]=error6
  
  
  
  Z2f=Z[1:(n1),]
  grid2=(1:nrow(Z2f))/nrow(Z2f)
  Z3f=cbind(Z2f,Z2f*(grid2-1))
  Z3f=data.frame(Z3f)
  colnames(Z3f)<-paste0("Z",1:ncol(Z3f))
  
  Z4f=Z3f[1:(n1-forecas),]
  a=paste0("Y1f~",paste0(apply(matrix(1:ncol(Z4f), ncol = 2, byrow = FALSE), 1, function(vec) paste0("bols(Z",vec[1],",Z",vec[2], ")")),collapse = " + "))
  w=1-(1:nrow(Z4f))/nrow(Z4f)
  weights=.kernel(x = w, bw = grid[bandopt_c], tkernel = "Unif", N = 1)
  index=(weights>0)
  
  
  boost_m2=gamboost(as.formula(a),weights= weights,data=Z4f,control = boost_control(mstop = 100,nu=.1))
  
  
  boost_m3=gamboost(as.formula(a),weights= weights,data=Z4f, control = boost_control(mstop = mstop(AIC(boost_m)),nu=.1))
  
  
  pred7=predict(boost_m3,newdata=Z3f[(n1),])
  
  error7=abs(pred7-Y0[n1])
  
  mms13[k,7]=error7
  
  
  model1=glmnet(as.matrix(Z1f),Y1f)
  ## use BIC to select lambda
  f=(deviance(model1)/n2)/var(Y1f)
  g=model1$df
  
  BIC1=log(f)+g*(log(n2)/n2)
  
  number=model1$lambda[which.min(BIC1)]
  model1=glmnet(as.matrix(Z1f),Y1f,lambda=number)
  
  pred8=predict(model1,newx=as.matrix(Z[(1:n1),]))[n1]
  mms13[k,8]=abs(pred8-Y0[n1])
  
  
  
}






################################# DGP extra ###############################

# 
# A=diag(.6,d)
# 
# 
# ## Gaussian
# #C = outer(1:d, 1:d, f<-function(x,y){.3^(abs(x-y))})
# #C=diag(1,d)
# 
# #X = TVAR.sim(A, nthresh=0, n = n2, include="none")
# 
# X = VAR.sim(A,innov=rmt(n2, mean=rep(0,d), S=3/5*C,df=5), n = n2, include="none")
# true.par.count=5
# beta=c(.5,.5,.5,.5,.5,rep(0,d-true.par.count))
# 
# 
# frac=floor(n2*.75)
# frac2=n2-frac
# Error1=rnorm(frac,0,1)
# Error2=rnorm(frac2,0,2)
# Error=c(Error1,Error2)
# 
# 
# truemodel=c(1,4,7,10,13)
# 
# 
# #Y=X%*%beta+Error
# 
# 
# ## T dist 5 df
# #X = TVAR.sim(A,innov=rmt(n2, mean=rep(0,d), S=3/5*C,df=5),nthresh=0, n = n2, include="none")
# # 
# Y = rep(0,n2)
# Y0 = 0
# Y[1] = Error[1]
# for(j in 2:n2){
#   Y[j] = X[j-1,]%*%beta + Error[j]
# }
# 
# Xold = X
# Yold = Y
# X = Xold[-(1:n),]
# Y = Yold
# Xwl = matrix(0, (n2-n), d*r)
# 
# sub = (n+1):n2
# for(j in 1:d){
#   Xwl[,(r*j-(r-1)):(r*j)] = c( Xold[sub-1,j], Xold[sub-2,j], Xold[sub-3,j])
# }
# 
# 
# Y0 = Y[sub]
# Y1 = Y[sub-1]
# Y2 = Y[sub-2]
# Y3 = Y[sub-3]
# Z=cbind(Y1,Y2,Y3,Xwl)
# 
# 
# 
# 
# 
# 
# 
# 
# 
# 
# 
# #Error=arima.sim(list(order = c(1,0,0), ar = 0.6), n = n2)
# #Error=arima.sim(model=list(ar=c(.6,0,0)),rand.gen = function(n, ...) rt(n=n2, df = 5),n=n2)
# 
# #Y=X%*%beta+Error
# 
# 
# ## T dist 5 df
# #X = TVAR.sim(A,innov=rmt(n2, mean=rep(0,d), S=3/5*C,df=5),nthresh=0, n = n2, include="none")
# # 
# # Y = rep(0,n2)
# # Y0 = 0
# # Y[1] = Error[1]
# # for(j in 2:n2){
# #   Y[j] = Y[j-1]*alpha1(t[j])+X[j-1,1]*B1(t[j])+X[j-1,2]*B2(t[j])+X[j-1,3]*B3(t[j])+X[j-1,4]*B4(t[j])+Error[j]
# # }
# 
# names1=c()
# for(i in 1:ncol(Z)){
#   names1[i]=paste0('Var',i)
# }
# colnames(Z)<-names1
# Lags=cbind(Y1,Y2,Y3)
# 
# .kernel <- function(x, bw, tkernel = "Unif", N = 1)
# {
#   x <- x/(N * bw)
#   value <- numeric(length(x))
#   if (tkernel == "Gaussian")
#   {
#     value <- exp(-0.5 * x^2)/2.506628274631000241612355239340104162693023681640625 #sqrt(2*pi)
#   }
#   if(tkernel == "Epa")
#   {
#     index <- (x >= -1 & x <= 1)
#     
#     value[index] <- .75 * (1 - x[index]^2) #12/11
#   }
#   
#   if(tkernel == "Unif")
#   {
#     index <- (x >= -1 & x <= 1)
#     
#     value[index] <- 1 #12/11
#   }
#   return(value)
#   
# }
# 
# 
# for(k in 1:predsamp)
# {
#   grid=seq(.3,1,length.out=8)
#   n1=samp-predsamp+k
#   #Y1=Y[1:(n-forecas)]
#   #X1=X[1:(n-forecas),]
#   
#   CV=c()
#   CV_a=c()
#   CV_b=c()
#   CV_c=c()
#   for(i in 1:length(grid))
#   {
#     error=c()
#     error_a=c()
#     error_b=c()
#     error_c=c()
#     for(j in (forecas):(d1+forecas-1))
#     {
#       Y1c=Y0[1:(n1-forecas-j)]
#       Z1=Z[1:(n1-forecas-j),]
#       Lags1=Lags[1:(n1-forecas-j),]
#       grid2=(1:nrow(Z1))/nrow(Z1)
#       
#       
#       w=1-grid2
#       weights=.kernel(x = w, bw = grid[i], tkernel = "Unif", N = 1)
#       index=(weights>0)
#       #result <- stats::lm.wfit(x = cbind(1,X1,factorsr1)[index,], y = Y1[index], w = weights[index])
#       #theta <- result$coef
#       #pred1=c(1,Lags[n1-j,],factors[n1-j,])%*%theta
#       #error[j+1]=abs(pred1-Y0[n1-j])^2
#       boost_m=glmboost(x=as.matrix(Z1)[index,],y=Y1c[index],weights= weights[index],center=TRUE,control = boost_control(mstop = 100,nu=.1))
#       #AIC(boost_m)
#       boost_m1=glmboost(x=as.matrix(Z1)[index,],y=Y1c[index],weights= weights[index],center=TRUE,control = boost_control(mstop = mstop(AIC(boost_m)),nu=.1))
#       coef=coef(boost_m1,off2int=TRUE)
#       
#       names1=names(coef[-1])
#       pred1=predict(boost_m1,newdata=Z)[n1-j]
#       error_b[j-forecas+1]=abs(pred1-Y0[n1-j])^2
#       
#       
#       result1 <- stats::lm.wfit(x = cbind(1,Z1[,truemodel])[index,], y = Y1c[index], w = weights[index])
#       theta1 <- result1$coef
#       pred1=c(1,Z[,truemodel][n1-j,])%*%theta1
#       error_a[j-forecas+1]=abs(pred1-Y0[n1-j])^2
#       
#       
#       
#       
#       Z2=Z[1:(n1-j),]
#       grid2=(1:nrow(Z2))/nrow(Z2)
#       Z3=cbind(Z2,Z2*(grid2-1))
#       Z3=data.frame(Z3)
#       colnames(Z3)<-paste0("Z",1:ncol(Z3))
#       
#       Z4=Z3[1:(n1-forecas-j),]
#       a=paste0("Y1c~",paste0(apply(matrix(1:ncol(Z4), ncol = 2, byrow = FALSE), 1, function(vec) paste0("bols(Z",vec[1],",Z",vec[2], ")")),collapse = " + "))
#       w=1-(1:nrow(Z4))/nrow(Z4)
#       weights=.kernel(x = w, bw = grid[i], tkernel = "Unif", N = 1)
#       index=(weights>0)
#       
#       
#       boost_m2=gamboost(as.formula(a),weights= weights,data=Z4,control = boost_control(mstop = 100,nu=.1))
#       
#       
#       boost_m3=gamboost(as.formula(a),weights= weights,data=Z4, control = boost_control(mstop = mstop(AIC(boost_m2)),nu=.1))
#       
#       
#       pred1=predict(boost_m3,newdata=Z3[(n1-j),])
#       
#       error_c[j-forecas+1]=abs(pred1-Y0[n1-j])^2
#       print(j)
#       
#       
#       #TVauto= tvLM(Y~X[,1]+X[,2]+X[,3]+X[,4],bw=grid[i])
#       # last=length(Y)
#       # coefs=TVauto$tvcoef[last,]
#       # pred1=c(1,Xfull[window3,])%*%coefs
#       # error1=abs(pred1-Yfull[window3])
#     }
#     #CV[i]=mean(error)
#     CV_a[i]=mean(error_a)
#     CV_b[i]=mean(error_b)
#     CV_c[i]=mean(error_c)
#     
#   }
#   #bandopt=which.min(CV)
#   bandopt_a=which.min(CV_a)
#   bandopt_b=which.min(CV_b)
#   bandopt_c=which.min(CV_c)
#   
#   
#   Y1f=Y0[1:(n1-forecas)]
#   Z1f=Z[1:(n1-forecas),]
#   Lags1f=Lags[1:(n1-forecas),]
#   auto= lm(Y1f~Lags1f)
#   pred1=c(1,Lags[n1,])%*%coef(auto)
#   error1=pred1-Y0[n1]
#   mms1[k,3*nmodels+1]=error1
#   
#   grid2=(1:nrow(Z1f))/nrow(Z1f)
#   w=1-grid2
#   weights=.kernel(x = w, bw = grid[bandopt_b], tkernel = "Unif", N = 1)
#   index=(weights>0)
#   
#   boost_m=glmboost(x=as.matrix(Z1f)[index,],y=Y1f[index],weights= weights[index],center=TRUE,control = boost_control(mstop = 100,nu=.1))
#   #AIC(boost_m)
#   boost_m1=glmboost(x=as.matrix(Z1f)[index,],y=Y1f[index],weights= weights[index],center=TRUE,control = boost_control(mstop = mstop(AIC(boost_m)),nu=.1))
#   
#   coef=coef(boost_m1,off2int=TRUE)
#   names1=names(coef[-1])
#   pred2=predict(boost_m1,newdata=Z)[n1]
#   error2=pred2-Y0[n1]
#   mms1[k,3*nmodels+2]=error2
#   
#   boost_m=glmboost(x=as.matrix(Z1f),y=Y1f,center=TRUE,control = boost_control(mstop = 100,nu=.1))
#   boost_m1=glmboost(x=as.matrix(Z1f),y=Y1f,center=TRUE,control = boost_control(mstop = mstop(AIC(boost_m)),nu=.1))
#   
#   coef=coef(boost_m1,off2int=TRUE)
#   names1=names(coef[-1])
#   pred3=predict(boost_m1,newdata=Z)[n1]
#   error3=pred3-Y0[n1]
#   mms1[k,3*nmodels+3]=error3
#   
#   last=nrow(Lags1f)
#   TVa= tvOLS(cbind(1,Z1f[,truemodel]),Y1f,bw=grid[bandopt_a],est="lc")
#   coefs=TVa$tvcoef[last,]
#   pred4=c(1,Z[,truemodel][n1,])%*%coefs
#   #pred3=c(Xfull[window3,])%*%coefs
#   error4=pred4-Y0[n1]
#   mms1[k,3*nmodels+4]=error4
#   
#   roll=ceiling(nrow(Z1f)/5)
#   weights2=ifelse(((1:last)-last)>-roll,1,0)
#   index2=(weights2>0)
#   auto=lm(Y1f[index2]~Lags1f[index2,])
#   pred5=c(1,Lags[n1,])%*%coef(auto)
#   error5=pred5-Y0[n1]
#   mms1[k,3*nmodels+5]=error5
#   
#   
#   boost_m=glmboost(x=as.matrix(Z1f)[index2,],y=Y1f[index2],center=TRUE,control = boost_control(mstop = 100,nu=.1))
#   boost_m1=glmboost(x=as.matrix(Z1f)[index2,],y=Y1f[index2],center=TRUE,control = boost_control(mstop = mstop(AIC(boost_m)),nu=.1))
#   
#   coef=coef(boost_m1,off2int=TRUE)
#   names1=names(coef[-1])
#   pred6=predict(boost_m1,newdata=Z)[n1]
#   error6=pred6-Y0[n1]
#   mms1[k,3*nmodels+6]=error6
#   
#   
#   
#   Z2f=Z[1:(n1),]
#   grid2=(1:nrow(Z2f))/nrow(Z2f)
#   Z3f=cbind(Z2f,Z2f*(grid2-1))
#   Z3f=data.frame(Z3f)
#   colnames(Z3f)<-paste0("Z",1:ncol(Z3f))
#   
#   Z4f=Z3f[1:(n1-forecas),]
#   a=paste0("Y1f~",paste0(apply(matrix(1:ncol(Z4f), ncol = 2, byrow = FALSE), 1, function(vec) paste0("bols(Z",vec[1],",Z",vec[2], ")")),collapse = " + "))
#   w=1-(1:nrow(Z4f))/nrow(Z4f)
#   weights=.kernel(x = w, bw = grid[bandopt_c], tkernel = "Unif", N = 1)
#   index=(weights>0)
#   
#   
#   boost_m2=gamboost(as.formula(a),weights= weights,data=Z4f,control = boost_control(mstop = 100,nu=.1))
#   
#   
#   boost_m3=gamboost(as.formula(a),weights= weights,data=Z4f, control = boost_control(mstop = mstop(AIC(boost_m)),nu=.1))
#   
#   
#   pred7=predict(boost_m3,newdata=Z3f[(n1),])
#   
#   error7=abs(pred7-Y0[n1])
#   
#   mms1[k,3*nmodels+7]=error7
#   
#   
#   model1=glmnet(as.matrix(Z1f),Y1f)
#   ## use BIC to select lambda
#   f=(deviance(model1)/n2)/var(Y1f)
#   g=model1$df
#   
#   BIC1=log(f)+g*(log(n2)/n2)
#   
#   number=model1$lambda[which.min(BIC1)]
#   model1=glmnet(as.matrix(Z1f),Y1f,lambda=number)
#   
#   pred8=predict(model1,newx=as.matrix(Z[(1:n1),]))[n1]
#   mms1[k,3*nmodels+8]=abs(pred8-Y0[n1])
#   
#   
#   
#   
# }
# 
# 
# 



################################# DGP 14 ###############################


mms14=matrix(0,nrow=predsamp,ncol=nmodels)


A1= outer(1:d, 1:d, f<-function(x,y){.2^(abs(x-y)+1)})

A2=outer(1:d, 1:d, f<-function(x,y){.4^(abs(x-y)+1)})
C=diag(1,d)


t=(1:n2)/n2
X=matrix(0,nrow=n2,ncol=d)
X[1,]=rmt(n=1, mean=rep(0,d), S=3/5*C,df=5)
for(j in 2:n2){
  A=((1-t[j]))*A1+(t[j])*A2
  #A=diag(.4,d)
  X[j,] = A%*%X[j-1,]+rmt(n=1, mean=rep(0,d), S=3/5*C,df=5)
}


alpha1<-function(x){.6}
B1 <- function(x){.5-1*(x>.75)}
B2<- function(x){.5-1*(x>.75)}
B3<-function(x){.5-1*(x>.75)}
B4<-function(x){.5-1*(x>.75)}


Y = rep(0,n2)
Y0 = 0
Y[1] = Error[1]
for(j in 2:n2){
  Y[j] = Y[j-1]*alpha1(t[j])+X[j-1,1]*B1(t[j])+X[j-1,2]*B2(t[j])+X[j-1,3]*B3(t[j])+X[j-1,4]*B4(t[j])+Error[j]
}


Xold = X
Xwl = matrix(0, (n2-n), d*r)

sub = (n+1):n2
for(j in 1:d){
  Xwl[,(r*j-(r-1)):(r*j)] = c( Xold[sub-1,j], Xold[sub-2,j], Xold[sub-3,j])
}





Y0 = Y[sub]
Y1 = Y[sub-1]
Y2 = Y[sub-2]
Y3 = Y[sub-3]
Z=cbind(Y1,Y2,Y3,Xwl)
names1=c()
for(i in 1:ncol(Z)){
  names1[i]=paste0('Var',i)
}
colnames(Z)<-names1
Lags=cbind(Y1,Y2,Y3)



for(k in 1:predsamp)
{
  grid=seq(.3,1,length.out=8)
  n1=samp-predsamp+k
  #Y1=Y[1:(n-forecas)]
  #X1=X[1:(n-forecas),]
  CV=c()
  CV_a=c()
  CV_b=c()
  CV_c=c()
  for(i in 1:length(grid))
  {
    error=c()
    error_a=c()
    error_b=c()
    error_c=c()
    for(j in (forecas):(d1+forecas-1))
    {
      Y1c=Y0[1:(n1-forecas-j)]
      Z1=Z[1:(n1-forecas-j),]
      Lags1=Lags[1:(n1-forecas-j),]
      grid2=(1:nrow(Z1))/nrow(Z1)
      
      
      w=1-grid2
      weights=.kernel(x = w, bw = grid[i], tkernel = "Unif", N = 1)
      index=(weights>0)
      
      boost_m=glmboost(x=as.matrix(Z1)[index,],y=Y1c[index],weights= weights[index],center=TRUE,control = boost_control(mstop = 100,nu=.1))
      #AIC(boost_m)
      boost_m1=glmboost(x=as.matrix(Z1)[index,],y=Y1c[index],weights= weights[index],center=TRUE,control = boost_control(mstop = mstop(AIC(boost_m)),nu=.1))
      coef=coef(boost_m1,off2int=TRUE)
      
      names1=names(coef[-1])
      pred1=predict(boost_m1,newdata=Z)[n1-j]
      error_b[j-forecas+1]=abs(pred1-Y0[n1-j])^2
      
      
      result1 <- stats::lm.wfit(x = cbind(1,Z1[,truemodel])[index,], y = Y1c[index], w = weights[index])
      theta1 <- result1$coef
      pred1=c(1,Z[,truemodel][n1-j,])%*%theta1
      error_a[j-forecas+1]=abs(pred1-Y0[n1-j])^2
      
      
      
      
      Z2=Z[1:(n1-j),]
      grid2=(1:nrow(Z2))/nrow(Z2)
      Z3=cbind(Z2,Z2*(grid2-1))
      Z3=data.frame(Z3)
      colnames(Z3)<-paste0("Z",1:ncol(Z3))
      
      Z4=Z3[1:(n1-forecas-j),]
      a=paste0("Y1c~",paste0(apply(matrix(1:ncol(Z4), ncol = 2, byrow = FALSE), 1, function(vec) paste0("bols(Z",vec[1],",Z",vec[2], ")")),collapse = " + "))
      w=1-(1:nrow(Z4))/nrow(Z4)
      weights=.kernel(x = w, bw = grid[i], tkernel = "Unif", N = 1)
      index=(weights>0)
      
      
      boost_m2=gamboost(as.formula(a),weights= weights,data=Z4,control = boost_control(mstop = 100,nu=.1))
      
      
      boost_m3=gamboost(as.formula(a),weights= weights,data=Z4, control = boost_control(mstop = mstop(AIC(boost_m2)),nu=.1))
      
      
      pred1=predict(boost_m3,newdata=Z3[(n1-j),])
      
      error_c[j-forecas+1]=abs(pred1-Y0[n1-j])^2
      print(j)
      
      
      
    }
    #CV[i]=mean(error)
    CV_a[i]=mean(error_a)
    CV_b[i]=mean(error_b)
    CV_c[i]=mean(error_c)
    
  }
  #bandopt=which.min(CV)
  bandopt_a=which.min(CV_a)
  bandopt_b=which.min(CV_b)
  bandopt_c=which.min(CV_c)
  
  
  Y1f=Y0[1:(n1-forecas)]
  Z1f=Z[1:(n1-forecas),]
  Lags1f=Lags[1:(n1-forecas),]
  auto= lm(Y1f~Lags1f)
  pred1=c(1,Lags[n1,])%*%coef(auto)
  error1=pred1-Y0[n1]
  mms14[k,1]=error1
  
  grid2=(1:nrow(Z1f))/nrow(Z1f)
  w=1-grid2
  weights=.kernel(x = w, bw = grid[bandopt_b], tkernel = "Unif", N = 1)
  index=(weights>0)
  
  boost_m=glmboost(x=as.matrix(Z1f)[index,],y=Y1f[index],weights= weights[index],center=TRUE,control = boost_control(mstop = 100,nu=.1))
  #AIC(boost_m)
  boost_m1=glmboost(x=as.matrix(Z1f)[index,],y=Y1f[index],weights= weights[index],center=TRUE,control = boost_control(mstop = mstop(AIC(boost_m)),nu=.1))
  
  coef=coef(boost_m1,off2int=TRUE)
  names1=names(coef[-1])
  pred2=predict(boost_m1,newdata=Z)[n1]
  error2=pred2-Y0[n1]
  mms14[k,2]=error2
  
  boost_m=glmboost(x=as.matrix(Z1f),y=Y1f,center=TRUE,control = boost_control(mstop = 100,nu=.1))
  boost_m1=glmboost(x=as.matrix(Z1f),y=Y1f,center=TRUE,control = boost_control(mstop = mstop(AIC(boost_m)),nu=.1))
  
  coef=coef(boost_m1,off2int=TRUE)
  names1=names(coef[-1])
  pred3=predict(boost_m1,newdata=Z)[n1]
  error3=pred3-Y0[n1]
  mms14[k,3]=error3
  
  last=nrow(Lags1f)
  TVa= tvOLS(cbind(1,Z1f[,truemodel]),Y1f,bw=grid[bandopt_a],est="lc")
  coefs=TVa$tvcoef[last,]
  pred4=c(1,Z[,truemodel][n1,])%*%coefs
  #pred3=c(Xfull[window3,])%*%coefs
  error4=pred4-Y0[n1]
  mms14[k,4]=error4
  
  roll=ceiling(nrow(Z1f)/5)
  weights2=ifelse(((1:last)-last)>-roll,1,0)
  index2=(weights2>0)
  auto=lm(Y1f[index2]~Lags1f[index2,])
  pred5=c(1,Lags[n1,])%*%coef(auto)
  error5=pred5-Y0[n1]
  mms14[k,5]=error5
  
  
  boost_m=glmboost(x=as.matrix(Z1f)[index2,],y=Y1f[index2],center=TRUE,control = boost_control(mstop = 100,nu=.1))
  boost_m1=glmboost(x=as.matrix(Z1f)[index2,],y=Y1f[index2],center=TRUE,control = boost_control(mstop = mstop(AIC(boost_m)),nu=.1))
  
  coef=coef(boost_m1,off2int=TRUE)
  names1=names(coef[-1])
  pred6=predict(boost_m1,newdata=Z)[n1]
  error6=pred6-Y0[n1]
  mms14[k,6]=error6
  
  
  
  Z2f=Z[1:(n1),]
  grid2=(1:nrow(Z2f))/nrow(Z2f)
  Z3f=cbind(Z2f,Z2f*(grid2-1))
  Z3f=data.frame(Z3f)
  colnames(Z3f)<-paste0("Z",1:ncol(Z3f))
  
  Z4f=Z3f[1:(n1-forecas),]
  a=paste0("Y1f~",paste0(apply(matrix(1:ncol(Z4f), ncol = 2, byrow = FALSE), 1, function(vec) paste0("bols(Z",vec[1],",Z",vec[2], ")")),collapse = " + "))
  w=1-(1:nrow(Z4f))/nrow(Z4f)
  weights=.kernel(x = w, bw = grid[bandopt_c], tkernel = "Unif", N = 1)
  index=(weights>0)
  
  
  boost_m2=gamboost(as.formula(a),weights= weights,data=Z4f,control = boost_control(mstop = 100,nu=.1))
  
  
  boost_m3=gamboost(as.formula(a),weights= weights,data=Z4f, control = boost_control(mstop = mstop(AIC(boost_m)),nu=.1))
  
  
  pred7=predict(boost_m3,newdata=Z3f[(n1),])
  
  error7=abs(pred7-Y0[n1])
  
  mms14[k,7]=error7
  
  
  model1=glmnet(as.matrix(Z1f),Y1f)
  ## use BIC to select lambda
  f=(deviance(model1)/n2)/var(Y1f)
  g=model1$df
  
  BIC1=log(f)+g*(log(n2)/n2)
  
  number=model1$lambda[which.min(BIC1)]
  model1=glmnet(as.matrix(Z1f),Y1f,lambda=number)
  
  pred8=predict(model1,newx=as.matrix(Z[(1:n1),]))[n1]
  mms14[k,8]=abs(pred8-Y0[n1])
  
  
  
}


###combine all the errors into one vector

mmstot=c(mms1,mms2,mms3,mms4,mms5,mms6,mms7,mms8,mms9,mms10,mms11,mms12,mms13,mms14)


mms=mmstot^2


save(mms,file=paste0('resultsTVP/simtot_T-',randSeed,'.RData'))





