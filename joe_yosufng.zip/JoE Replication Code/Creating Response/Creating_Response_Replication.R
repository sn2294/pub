

## creating response variable and lags

############## horizon 12 months #################


##IP


IPreg=read.csv("INDPRO.csv",header=TRUE)
IPreg=IPreg[,2]
IPlog=log(IPreg)
IPlog1=diff(IPlog,1)
d=length(IPlog)
h=12


IPlog12=c()

for(i in (h+2):d)
{
  IPlog12[(i-13)]=IPlog[i]-IPlog[(i-12)]
  
  
}


IPl12=cbind(IPlog12)

IPl1=cbind(IPlog1)

write.csv(IPl1,"IPl1.csv")

write.csv(IPl12,"IPl12.csv")


### RPI Less transfer


RPIlessreg=read.csv("RPIless.csv",header=TRUE)
RPIlessreg=RPIlessreg[,2]
RPIlesslog=log(RPIlessreg)
RPIlesslog1=diff(RPIlesslog,1)

RPIlesslog12=c()

for(i in (h+2):d)
{
  RPIlesslog12[(i-13)]=RPIlesslog[i]-RPIlesslog[(i-12)]
  
  
}


RPIlessl12=cbind(RPIlesslog12)


RPIlessl1=cbind(RPIlesslog1)

write.csv(RPIlessl1,"RPIlessl1.csv")

write.csv(RPIlessl12,"RPIlessl12.csv")



### Number of non-farm employees

emsreg=read.csv("PAYEMS.csv",header=TRUE)
emsreg=emsreg[,2]
emslog=log(emsreg)
emslog1=diff(emslog,1)

emslog12=c()

for(i in (h+2):d)
{
  emslog12[(i-13)]=emslog[i]-emslog[(i-12)]
  
  
}

emsl12=cbind(emslog12)


emsl1=cbind(emslog1)

write.csv(emsl1,"emsl1.csv")

write.csv(emsl12,"emsl12.csv")


### Unemployment Rate


unratereg=read.csv("UNRATE.csv",header=TRUE)
unratereg=unratereg[,2]
unratelog=unratereg
unratelog1=diff(unratelog,1)

unratelog12=c()

for(i in (h+2):d)
{
  unratelog12[(i-13)]=unratelog[i]-unratelog[(i-12)]
  
  
}


unratel12=cbind(unratelog12)


unratel1=cbind(unratelog1)

write.csv(unratel1,"unratel1.csv")

write.csv(unratel12,"unratel12.csv")




## civilian labor force


h=12

CivLaborreg=read.csv("CivLaborReg.csv",header=TRUE)
CivLaborreg=CivLaborreg[,2]
CivLaborlog=log(CivLaborreg)
CivLaborlog1=diff(CivLaborlog,1)

CivLaborlog12=c()

for(i in (h+2):d)
{
  CivLaborlog12[(i-h-1)]=CivLaborlog[i]-CivLaborlog[(i-h)]
  
  
}


CivLaborl12=cbind(CivLaborlog12)


CivLaborl1=cbind(CivLaborlog1)

write.csv(CivLaborl1,"CivLaborl1.csv")

write.csv(CivLaborl12,"CivLaborl12.csv")



## Fed Funds rate


h=12

Fedfundsreg=read.csv("FEDFUNDS.csv",header=TRUE)
Fedfundsreg=Fedfundsreg[,2]
Fedfundslog=Fedfundsreg
Fedfundslog1=diff(Fedfundslog,1)

Fedfundslog12=c()

for(i in (h+2):d)
{
  Fedfundslog12[(i-h-1)]=Fedfundslog[i]-Fedfundslog[(i-h)]
  
  
}


Fedfundsl12=cbind(Fedfundslog12)


Fedfundsl1=cbind(Fedfundslog1)

write.csv(Fedfundsl1,"Fedfundsl1.csv")

write.csv(Fedfundsl12,"Fedfundsl12.csv")


## 3 month Tbill


h=12

TB3MSreg=read.csv("TB3MS.csv",header=TRUE)
TB3MSreg=TB3MSreg[,2]
TB3MSlog=TB3MSreg
TB3MSlog1=diff(TB3MSlog,1)

TB3MSlog12=c()

for(i in (h+2):d)
{
  TB3MSlog12[(i-h-1)]=TB3MSlog[i]-TB3MSlog[(i-h)]
  
  
}


TB3MSl12=cbind(TB3MSlog12)


TB3MSl1=cbind(TB3MSlog1)

write.csv(TB3MSl1,"TB3MSl1.csv")

write.csv(TB3MSl12,"TB3MSl12.csv")


###################  horizon = 6 months ######################




##now for industrial production

h=6
IPreg=read.csv("INDPRO.csv",header=TRUE)
IPreg=IPreg[,2]
IPlog=log(IPreg)
IPlog1=diff(IPlog,1)

IPlog6=c()

for(i in (h+2):d)
{
  IPlog6[(i-h-1)]=IPlog[i]-IPlog[(i-h)]
  
  
}


IPl6=cbind(IPlog6)

IPl1=cbind(IPlog1)

#write.csv(IPl1,"IPl1.csv")

write.csv(IPl6,"IPl6.csv")



# real personal income less transfers

h=6
RPIlessreg=read.csv("RPIless.csv",header=TRUE)
RPIlessreg=RPIlessreg[,2]
RPIlesslog=log(RPIlessreg)
RPIlesslog1=diff(RPIlesslog,1)

RPIlesslog6=c()


for(i in (h+2):d)
{
  RPIlesslog6[(i-h-1)]=RPIlesslog[i]-RPIlesslog[(i-h)]
  
  
}


RPIlessl6=cbind(RPIlesslog6)


RPIlessl1=cbind(RPIlesslog1)

#write.csv(RPIlessl1,"RPIlessl1.csv")

write.csv(RPIlessl6,"RPIlessl6.csv")



## non-farm employment
h=6
emsreg=read.csv("PAYEMS.csv",header=TRUE)
emsreg=emsreg[,2]
emslog=log(emsreg)
emslog1=diff(emslog,1)

emslog6=c()

for(i in (h+2):d)
{
  emslog6[(i-h-1)]=emslog[i]-emslog[(i-h)]
}

emsl6=cbind(emslog6)


emsl1=cbind(emslog1)

#write.csv(emsl1,"emsl1.csv")

write.csv(emsl6,"emsl6.csv")


## unemployment rate
h=6

unratereg=read.csv("UNRATE.csv",header=TRUE)
unratereg=unratereg[,2]
unratelog=unratereg
unratelog1=diff(unratelog,1)

unratelog6=c()

for(i in (h+2):d)
{
  unratelog6[(i-h-1)]=unratelog[i]-unratelog[(i-h)]
  
  
}


unratel6=cbind(unratelog6)


unratel1=cbind(unratelog1)

#write.csv(unratel1,"unratel1.csv")

write.csv(unratel6,"unratel6.csv")

## civilian labor force


h=6

CivLaborreg=read.csv("CivLaborReg.csv",header=TRUE)
CivLaborreg=CivLaborreg[,2]
CivLaborlog=log(CivLaborreg)
CivLaborlog1=diff(CivLaborlog,1)

CivLaborlog6=c()

for(i in (h+2):d)
{
  CivLaborlog6[(i-h-1)]=CivLaborlog[i]-CivLaborlog[(i-h)]
  
  
}


CivLaborl6=cbind(CivLaborlog6)


CivLaborl1=cbind(CivLaborlog1)

#write.csv(CivLaborl1,"CivLaborl1.csv")

write.csv(CivLaborl6,"CivLaborl6.csv")

## Fed Funds


h=6

Fedfundsreg=read.csv("FEDFUNDS.csv",header=TRUE)
Fedfundsreg=Fedfundsreg[,2]
Fedfundslog=Fedfundsreg
Fedfundslog1=diff(Fedfundslog,1)

Fedfundslog6=c()

for(i in (h+2):d)
{
  Fedfundslog6[(i-h-1)]=Fedfundslog[i]-Fedfundslog[(i-h)]
  
  
}


Fedfundsl6=cbind(Fedfundslog6)


Fedfundsl1=cbind(Fedfundslog1)

#write.csv(Fedfundsl1,"Fedfundsl1.csv")

write.csv(Fedfundsl6,"Fedfundsl6.csv")

## TB3MS

h=6

TB3MSreg=read.csv("TB3MS.csv",header=TRUE)
TB3MSreg=TB3MSreg[,2]
TB3MSlog=TB3MSreg
TB3MSlog1=diff(TB3MSlog,1)

TB3MSlog6=c()

for(i in (h+2):d)
{
  TB3MSlog6[(i-h-1)]=TB3MSlog[i]-TB3MSlog[(i-h)]
  
  
}


TB3MSl6=cbind(TB3MSlog6)


TB3MSl1=cbind(TB3MSlog1)

#write.csv(TB3MSl1,"TB3MSl1.csv")

write.csv(TB3MSl6,"TB3MSl6.csv")






############### Horizon == 1 month #####################


##now for industrial production

h=1
IPreg=read.csv("INDPRO.csv",header=TRUE)
IPreg=IPreg[,2]
IPlog=log(IPreg)
IPlog1=diff(IPlog,1)

IPlog1h=c()

for(i in (h+2):d)
{
  IPlog1h[(i-h-1)]=IPlog[i]-IPlog[(i-h)]
  
  
}


IPlh1=cbind(IPlog1h)

IPl1=cbind(IPlog1)

#write.csv(IPl1,"IPl1.csv")

write.csv(IPlh1,"IPlh1.csv")


## Employment Non farm payrolls


h=1
emsreg=read.csv("PAYEMS.csv",header=TRUE)
emsreg=emsreg[,2]
emslog=log(emsreg)
emslog1=diff(emslog,1)

emslog1h=c()

for(i in (h+2):d)
{
  emslog1h[(i-h-1)]=emslog[i]-emslog[(i-h)]
  
  
}


emslh1=cbind(emslog1h)

emsl1=cbind(emslog1)

#write.csv(emsl1,"emsl1.csv")

write.csv(emslh1,"emslh1.csv")

## Unemployment Rate

h=1
unratereg=read.csv("unrate.csv",header=TRUE)
unratereg=unratereg[,2]
unratelog=unratereg
unratelog1=diff(unratelog,1)

unratelog1h=c()

for(i in (h+2):d)
{
  unratelog1h[(i-h-1)]=unratelog[i]-unratelog[(i-h)]
  
  
}


unratelh1=cbind(unratelog1h)

unratel1=cbind(unratelog1)

#write.csv(unratel1,"unratel1.csv")

write.csv(unratelh1,"unratelh1.csv")


##RPIless

h=1
RPIlessreg=read.csv("RPIless.csv",header=TRUE)
RPIlessreg=RPIlessreg[,2]
RPIlesslog=log(RPIlessreg)
RPIlesslog1=diff(RPIlesslog,1)

RPIlesslog1h=c()

for(i in (h+2):d)
{
  RPIlesslog1h[(i-h-1)]=RPIlesslog[i]-RPIlesslog[(i-h)]
  
  
}


RPIlesslh1=cbind(RPIlesslog1h)

RPIlessl1=cbind(RPIlesslog1)

#write.csv(RPIlessl1,"RPIlessl1.csv")

write.csv(RPIlesslh1,"RPIlesslh1.csv")


## Civilian Labor Force

h=1
CivLaborreg=read.csv("CivLaborreg.csv",header=TRUE)
CivLaborreg=CivLaborreg[,2]
CivLaborlog=log(CivLaborreg)
CivLaborlog1=diff(CivLaborlog,1)

CivLaborlog1h=c()

for(i in (h+2):d)
{
  CivLaborlog1h[(i-h-1)]=CivLaborlog[i]-CivLaborlog[(i-h)]
  
  
}


CivLaborlh1=cbind(CivLaborlog1h)

CivLaborl1=cbind(CivLaborlog1)

#write.csv(CivLaborl1,"CivLaborl1.csv")

write.csv(CivLaborlh1,"CivLaborlh1.csv")

## Fed Funds



h=1
Fedfundsreg=read.csv("FEDFUNDS.csv",header=TRUE)
Fedfundsreg=Fedfundsreg[,2]
Fedfundslog=Fedfundsreg
Fedfundslog1=diff(Fedfundslog,1)

Fedfundslog1h=c()

for(i in (h+2):d)
{
  Fedfundslog1h[(i-h-1)]=Fedfundslog[i]-Fedfundslog[(i-h)]
  
  
}


Fedfundslh1=cbind(Fedfundslog1h)

Fedfundsl1=cbind(Fedfundslog1)

#write.csv(Fedfundsl1,"Fedfundsl1.csv")

write.csv(Fedfundslh1,"Fedfundslh1.csv")

### TB3MS



h=1
TB3MSreg=read.csv("TB3MS.csv",header=TRUE)
TB3MSreg=TB3MSreg[,2]
TB3MSlog=TB3MSreg
TB3MSlog1=diff(TB3MSlog,1)

TB3MSlog1h=c()

for(i in (h+2):d)
{
  TB3MSlog1h[(i-h-1)]=TB3MSlog[i]-TB3MSlog[(i-h)]
  
  
}


TB3MSlh1=cbind(TB3MSlog1h)

TB3MSl1=cbind(TB3MSlog1)

#write.csv(TB3MSl1,"TB3MSl1.csv")

write.csv(TB3MSlh1,"TB3MSlh1.csv")





#################### Forecast Horizon h=3 ####################



h=3
IPreg=read.csv("INDPRO.csv",header=TRUE)
IPreg=IPreg[,2]
IPlog=log(IPreg)
IPlog1=diff(IPlog,1)

IPlog3h=c()

for(i in (h+2):d)
{
  IPlog3h[(i-h-1)]=IPlog[i]-IPlog[(i-h)]
  
  
}


IPl3=cbind(IPlog3h)

IPl1=cbind(IPlog1)

#write.csv(IPl1,"IPl1.csv")

write.csv(IPl3,"IPl3.csv")


## Employment Non farm payrolls


h=3
emsreg=read.csv("PAYEMS.csv",header=TRUE)
emsreg=emsreg[,2]
emslog=log(emsreg)
emslog1=diff(emslog,1)

emslog3h=c()

for(i in (h+2):d)
{
  emslog3h[(i-h-1)]=emslog[i]-emslog[(i-h)]
  
  
}


emsl3=cbind(emslog3h)

emsl1=cbind(emslog1)

#write.csv(emsl1,"emsl1.csv")

write.csv(emsl3,"emsl3.csv")

## Unemployment Rate

h=3
unratereg=read.csv("unrate.csv",header=TRUE)
unratereg=unratereg[,2]
unratelog=unratereg
unratelog1=diff(unratelog,1)

unratelog3h=c()

for(i in (h+2):d)
{
  unratelog3h[(i-h-1)]=unratelog[i]-unratelog[(i-h)]
  
  
}


unratel3=cbind(unratelog3h)

unratel1=cbind(unratelog1)

#write.csv(unratel1,"unratel1.csv")

write.csv(unratel3,"unratel3.csv")



##RPIless

h=3
RPIlessreg=read.csv("RPIless.csv",header=TRUE)
RPIlessreg=RPIlessreg[,2]
RPIlesslog=log(RPIlessreg)
RPIlesslog1=diff(RPIlesslog,1)

RPIlesslog3h=c()

for(i in (h+2):d)
{
  RPIlesslog3h[(i-h-1)]=RPIlesslog[i]-RPIlesslog[(i-h)]
  
  
}


RPIlessl3=cbind(RPIlesslog3h)

RPIlessl1=cbind(RPIlesslog1)

#write.csv(RPIlessl1,"RPIlessl1.csv")

write.csv(RPIlessl3,"RPIlessl3.csv")


## Civilian Labor Force

h=3
CivLaborreg=read.csv("CivLaborreg.csv",header=TRUE)
CivLaborreg=CivLaborreg[,2]
CivLaborlog=log(CivLaborreg)
CivLaborlog1=diff(CivLaborlog,1)

CivLaborlog3h=c()

for(i in (h+2):d)
{
  CivLaborlog3h[(i-h-1)]=CivLaborlog[i]-CivLaborlog[(i-h)]
  
  
}


CivLaborl3=cbind(CivLaborlog3h)

CivLaborl1=cbind(CivLaborlog1)

#write.csv(CivLaborl1,"CivLaborl1.csv")

write.csv(CivLaborl3,"CivLaborl3.csv")


## Fed Funds

h=3
Fedfundsreg=read.csv("FEDFUNDS.csv",header=TRUE)
Fedfundsreg=Fedfundsreg[,2]
Fedfundslog=Fedfundsreg
Fedfundslog1=diff(Fedfundslog,1)

Fedfundslog3h=c()

for(i in (h+2):d)
{
  Fedfundslog3h[(i-h-1)]=Fedfundslog[i]-Fedfundslog[(i-h)]
  
  
}


Fedfundsl3=cbind(Fedfundslog3h)

Fedfundsl1=cbind(Fedfundslog1)

#write.csv(Fedfundsl1,"Fedfundsl1.csv")

write.csv(Fedfundsl3,"Fedfundsl3.csv")


#### TB3MS



h=3
TB3MSreg=read.csv("TB3MS.csv",header=TRUE)
TB3MSreg=TB3MSreg[,2]
TB3MSlog=TB3MSreg
TB3MSlog1=diff(TB3MSlog,1)

TB3MSlog3h=c()

for(i in (h+2):d)
{
  TB3MSlog3h[(i-h-1)]=TB3MSlog[i]-TB3MSlog[(i-h)]
  
  
}


TB3MSl3=cbind(TB3MSlog3h)

TB3MSl1=cbind(TB3MSlog1)

#write.csv(TB3MSl1,"TB3MSl1.csv")

write.csv(TB3MSl3,"TB3MSl3.csv")

### GS10


h=3
GS10reg=read.csv("GS10.csv",header=TRUE)
GS10reg=GS10reg[,2]
GS10log=GS10reg
GS10log1=diff(GS10log,1)

GS10log3h=c()

for(i in (h+2):d)
{
  GS10log3h[(i-h-1)]=GS10log[i]-GS10log[(i-h)]
  
  
}


GS10l3=cbind(GS10log3h)

GS10l1=cbind(GS10log1)

#write.csv(GS10l1,"GS10l1.csv")

write.csv(GS10l3,"GS10l3.csv")



######################## CPI ##################################

###  CPI h=12

CPIreg=read.csv("CPI.csv",header=TRUE)
CPIreg=CPIreg[,2][-1]
#CPIreg=CPIreg[,2]

CPIlog=log(CPIreg)
CPIlog1=diff(CPIlog,differences=1)
CPIlog2=diff(CPIlog,differences=2)
d=length(CPIlog)
h=12


CPIlog12=c()

for(i in (h+2):d)
{
  
  
  #CPIlog12[(i-h-1)]=(1200/h)*log(CPIreg[i]/CPIreg[i-h])-1200*log(CPIreg[i-h]/CPIreg[i-h-1])
  
  CPIlog12[(i-h-1)]=(1200/h)*log(CPIreg[i]/CPIreg[i-h])
  
  
}


CPIl12=cbind(CPIlog12)

CPIl1=cbind(CPIlog1)

write.csv(CPIl1,"CPIl1.csv")

write.csv(CPIl12,"CPIl12.csv")




##CPI h=6


CPIreg=read.csv("CPI.csv",header=TRUE)
CPIreg=CPIreg[,2][-1]
CPIlog=log(CPIreg)
CPIlog1=diff(CPIlog,differences=1)
CPIlog2=diff(CPIlog,differences=2)
d=length(CPIlog)
h=6


CPIlog6=c()

for(i in (h+2):d)
{
  #CPIlog6[(i-h-1)]=(1200/h)*log(CPIreg[i]/CPIreg[i-h])-1200*log(CPIreg[i-h]/CPIreg[i-h-1])
  
  CPIlog6[(i-h-1)]=(1200/h)*log(CPIreg[i]/CPIreg[i-h])
  
  
  
}


CPIl6=cbind(CPIlog6)

CPIl1=cbind(CPIlog1)

#write.csv(CPIl1,"CPIl1.csv")

write.csv(CPIl6,"CPIl6.csv")


##CPI h=3


CPIreg=read.csv("CPI.csv",header=TRUE)
CPIreg=CPIreg[,2][-1]
CPIlog=log(CPIreg)
CPIlog1=diff(CPIlog,differences=1)
CPIlog2=diff(CPIlog,differences=2)
d=length(CPIlog)
h=3


CPIlog3=c()

for(i in (h+2):d)
{
  #CPIlog3[(i-h-1)]=(1200/h)*log(CPIreg[i]/CPIreg[i-h])-1200*log(CPIreg[i-h]/CPIreg[i-h-1])
  CPIlog3[(i-h-1)]=(1200/h)*log(CPIreg[i]/CPIreg[i-h])
  
  
}


CPIl3=cbind(CPIlog3)

CPIl1=cbind(CPIlog1)

#write.csv(CPIl1,"CPIl1.csv")

write.csv(CPIl3,"CPIl3.csv")


##CPI h=1


CPIreg=read.csv("CPI.csv",header=TRUE)
CPIreg=CPIreg[,2][-1]
CPIlog=log(CPIreg)
CPIlog1=diff(CPIlog,differences=1)
CPIlog2=diff(CPIlog,differences=2)
d=length(CPIlog)
h=1


CPIlog1h=c()

for(i in (h+2):d)
{
  #CPIlog1h[(i-h-1)]=(1200/h)*log(CPIreg[i]/CPIreg[i-h])-1200*log(CPIreg[i-h]/CPIreg[i-h-1])
  CPIlog1h[(i-h-1)]=(1200/h)*log(CPIreg[i]/CPIreg[i-h])
}


CPIlh1=cbind(CPIlog1h)

CPIl1=cbind(CPIlog1)

#CPIl2=cbind(CPIlog1[2:703])


#write.csv(CPIl1,"CPIl1.csv")

write.csv(CPIlh1,"CPIlh1.csv")



















