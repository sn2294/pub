function obj=AR0a_obj(init,p1,p2,data_coef,W,u)
theta=init(1); sig=init(2); l3=init(3); l4=init(4);
A=1./(1+l3)-1./(1+l4);
B=1./(1+2*l3)+1./(1+2*l4)-2*beta(1+l3,1+l4);
l2=sqrt(B-A.^2);
l1=-A./l2;
sim_coef=[];
for it=1:cols(u);
    eps=l1+(u(:,it).^l3-(1-u(:,it)).^l4)./l2;
    e=sig.*eps;
    y=filter([1 theta],1,e);
    out=AR0a(y,p1,p2);
    sim_coef=[sim_coef; out'];
end;
if cols(u)==1;
    sim=sim_coef';
else
    sim=mean(sim_coef)';
end;
d=data_coef-sim;
obj=d'*W*d;
%obj=d'*W*d + 999*(theta<0) + 999*(theta>3) + 999*(sig<0.1) + 999*(sig>2);



