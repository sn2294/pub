MATLAB codes for the empirical application (Table 4) in the paper
"Minimum Distance Estimation of Possibly Non-Invertible Moving Average Models"
by Nikolay Gospodinov and Serena Ng, 
forthcoming in Journal of Business and Economic Statistics (2014)

main MATLAB program for replicating Table 4 in the paper
appl_Table4.m

Data file
FF25.txt (25 Fama-French portfolio returns)

Supplemental MATLAB functions for SMM and SMD estimation
AR0a.m and aux_mom1.m (auxiliary regression for SMD estimator)
AR0a_obj.m and AR0a_obj_jac.m (objective function and Jacobian for SMD estimator)
momsmm.m and aux_momsmm.m (moments for SMM estimator)
objsmm.m and objsmm_jac.m (objective function and Jacobian for SMM estimator)

Supplemental MATLAB codes (utilities)
nw.m, cols.m, rows.m, lagn.m, trimr.m
