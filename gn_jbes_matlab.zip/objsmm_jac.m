function sim=objsmm_jac(param,u)
theta=param(1); sig=param(2); l3=param(3); l4=param(4);
A=1./(1+l3)-1./(1+l4);
B=1./(1+2*l3)+1./(1+2*l4)-2*beta(1+l3,1+l4);
l2=sqrt(B-A.^2);
l1=-A./l2;
sim_coef=[];
for it=1:cols(u);
    eps=l1+(u(:,it).^l3-(1-u(:,it)).^l4)./l2;
    e=sig.*eps;
    ysim=filter([1 theta],1,e);
    out=momsmm(ysim);
    sim_coef=[sim_coef; out'];
end;
if cols(u)==1;
    sim=sim_coef';
else
    sim=mean(sim_coef)';
end;