function dm=momsmm(y)
T=rows(y);
ysq=y.^2;
ycub=y.^3;

p=4;
reg=[];
for i=1:p;
    reg=[reg lagn(y,i)];
end;
y1=trimr(y,p,0);
reg=trimr(reg,p,0);
param=inv(reg'*reg)*(reg'*y1);
e=y1-reg*param;
stdres=e./std(e);

dm=zeros(11,1);
dm(1)=mean(y(2:T).*y(1:T-1));
dm(2)=mean(ysq(2:T).*y(1:T-1));
dm(3)=mean(y(2:T).*ysq(1:T-1));
dm(4)=mean(y.^2);
dm(5)=mean(y.^3);
dm(6)=mean(ycub(2:T).*y(1:T-1));
dm(7)=mean(y(2:T).*ycub(1:T-1));
dm(8)=mean(ysq(2:T).*ysq(1:T-1));
dm(9)=mean(y.^4);
dm(10)=mean(stdres.^3);
dm(11)=mean(stdres.^4);







