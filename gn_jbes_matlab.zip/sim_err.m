function u=sim_err(T,H,Nsim,seed1)
rand('state',seed1);
u=[];
if Nsim==1
    u=rand(T*H,1);
else
    for i=1:Nsim
        u(:,i)=rand(T,1);
    end
end

