% appl_Table4.m
% Estimation of MA(1) model for 25FF porfolio returns by QMLE, SMM and SMD
% Table 4 in the paper
% Note: GARCHSET (used for QMLE of MA(1)) has been removed in Matlab R2014a

clear;
load FF25.txt
fp=fopen('appl_Table4.out','w');
fprintf(fp,'\n');
fclose(fp);
R = FF25(307:end,:)/100; % monthly data, 1952:01 - 2013:08
N = size(R,2);
TT=rows(R);
p1=4;             % lag order for conditional mean (AR) of auxiliary model
p2=1;             % lag order for conditional variance of auxiliary model 
seed=555;
Nsim=1;
H=20;
optW=1;
lag=-1;
options=optimset('Display','off','TolX',1e-8,'TolFun',1e-8,'MaxIter',500);
Spec = garchset('R', 0, 'M', 1, 'Display', 'off');

for ii=1:N;
    rand('state',888+ii);
    y=R(:,ii);
    yy=(y-mean(y))./std(y);
    mu3=mean(yy.^3);
    mu4=mean(yy.^4);
    T=rows(y);
    data_coef=AR0a(y,p1,p2);  
    x1=data_coef;
    scorev=aux_mom1(x1,y,p1,p2);
    hess=zeros(rows(data_coef),rows(data_coef));
    small=1e-3;
    for i=1:rows(data_coef);
        x0=x1; x2=x1;
        x0(i,1)=x1(i,1)+ small;
        coef0=aux_mom1(x0,y,p1,p2);
        x2(i,1)=x1(i,1)-small;
        coef2=aux_mom1(x2,y,p1,p2);
        hess(:,i)=-mean((coef0-coef2)/(2*small));
    end;
    V=nw(scorev,lag);
    Wopt=hess'*inv(V)*hess;
    if optW==1;
        W=Wopt;
    else
        W=eye(p1+2*p2+4);
    end
    errors=sim_err(T,H,Nsim,seed);  
    data_coef_smm=momsmm(y);
    mom=aux_momsmm(y);
    Vsmm=nw(mom,lag);
    Wsmm=inv(Vsmm);
    
    fx1=[]; fx2=[];
    init_grid=[0.2; 0.4; 0.8; 1.2; 1.6; 2];
    for jj=1:6;
        theta_init = [init_grid(jj)];
        init = [theta_init; sqrt(var(y)/(1+theta_init^2)); 0.134915; 0.134915];
        [x1,f1,rcode1]=fminsearch(@AR0a_obj,init,options,p1,p2,data_coef,W,errors);
        fx1(jj,:) = [f1 x1'];
        init = [theta_init; 1; 0.134915; 0.134915];
        [x3,f3,rcode3]=fminsearch(@objsmm,init,options,data_coef_smm,Wsmm,errors);
        fx2(jj,:) = [f3 x3'];
    end
    
    % SMD estimation
    [C1,Ind1] = min(fx1(:,1));
    x1=fx1(Ind1,2:end)';
    init2 = [1/x1(1); 1/(x1(2)^2); x1(3); x1(4)];
    [x2,f2,rcode2]=fminsearch(@AR0a_obj,init2,options,p1,p2,data_coef,W,errors);
    fx1 = [fx1; f2 x2'];
    [C1,Ind1] = min(fx1(:,1));
    x1=fx1(Ind1,2:end)';
    theta_smd=fx1(Ind1,2);
    % Constructing standard errors and t-statistics
    jac=zeros(rows(data_coef),rows(init));
    small=1e-3;
    for i=1:rows(init);
        x0=x1; x2=x1;
        x0(i,1)=x1(i,1)+ small;
        coef0=AR0a_obj_jac(x0,p1,p2,errors);
        x2(i,1)=x1(i,1)-small;
        coef2=AR0a_obj_jac(x2,p1,p2,errors);
        jac(:,i)=(coef0-coef2)/(2*small);
    end;
    if optW==1;
        Vtheta=inv(jac'*Wopt*jac)*((1+1/(H*Nsim))/T);
    else
        V1=inv(jac'*W*jac);
        V2=jac'*W*inv(Wopt)*W*jac;
        Vtheta=V1*V2*V1*((1+1/(H*Nsim))/T);
    end
    se_smd=sqrt(diag(Vtheta));
    
    % SMM estimation
    [C2,Ind2] = min(fx2(:,1));
    x3=fx2(Ind2,2:end)';
    init3 = [1/x3(1); 1/x3(2); x3(3); x3(4)];
    [x4,f4,rcode4]=fminsearch(@objsmm,init3,options,data_coef_smm,Wsmm,errors);
    fx2 = [fx2; f4 x4'];
    [C2,Ind2] = min(fx2(:,1));
    x3=fx2(Ind2,2:end)';
    theta_smm=fx2(Ind2,2);
    % Constructing standard errors and t-statistics
    jac_smm=zeros(rows(data_coef_smm),rows(init));
    small=1e-3;
    for i=1:rows(init);
        x0=x3; x02=x3;
        x0(i,1)=x3(i,1)+ small;
        coef0=objsmm_jac(x0,errors);
        x02(i,1)=x3(i,1)-small;
        coef2=objsmm_jac(x02,errors);
        jac_smm(:,i)=(coef0-coef2)/(2*small);
    end;
    Vtheta_smm=inv(jac_smm'*Wsmm*jac_smm)*((1+1/(H*Nsim))/T);
    se_smm=sqrt(diag(Vtheta_smm));
    
    % Gaussian QML estimation
    [Coeffs, Errs, LLF, Innovs, Sigs, Summ] = garchfit(Spec, y);
    theta_ml = garchget(Coeffs, 'MA');
    se_ml = garchget(Errs, 'MA');
    
    % Output
    disp([ii theta_ml theta_smm theta_smd se_ml se_smm(1) se_smd(1)])
    temp1=[mu3 mu4 theta_ml theta_smm theta_smd se_ml se_smm(1) se_smd(1)];
    fmt=['%3d ', repmat(' & %6.3f',1,cols(temp1)) ' \\\\ \n'];
    fp=fopen('appl_Table4.out','a+');
    temp=[ii  temp1];
    fprintf(fp,fmt,temp);
    fclose(fp);

end