function gt=aux_momsmm(y)
T=rows(y);
ysq=y.^2;
ycub=y.^3;
gt1=y(5:T).*y(4:T-1);
gt2=ysq(5:T).*y(4:T-1);
gt3=y(5:T).*ysq(4:T-1);
gt4=y(5:T).^2;
gt5=y(5:T).^3;
gt6=ycub(5:T).*y(4:T-1);
gt7=y(5:T).*ycub(4:T-1);
gt8=ysq(5:T).*ysq(4:T-1);
gt9=y(5:T).^4;

p=4;
reg=[];
for i=1:p;
    reg=[reg lagn(y,i)];
end;
y1=trimr(y,p,0);
reg=trimr(reg,p,0);
param=inv(reg'*reg)*(reg'*y1);
e=y1-reg*param;
stderr=e./std(e);
gt=[gt1 gt2 gt3 gt4 gt5 gt6 gt7 gt8 gt9 stderr.^3 stderr.^4];
