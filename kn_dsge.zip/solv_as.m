% SOLV_AS.M           05-31-2011        code by: Komunjer and Ng
% This program solves An and Schorfheide (Econ. Reviews 2007) model by
% using GENSYS by Sims (2002).
%
% Input: 
%   theta = deep parameter value at which the model is solved
% Outputs:
%   G1, C, impact, eu = gensys outputs
%   Sigma = covariance matrix of the innovations

function [G1,C,impact,eu,Sigma] = solv_as(theta)

if size(theta,1)==13;
tau = theta(1);
beta = theta(2);
nu = theta(3);
phi = theta(4);
pist = theta(5);
psi1 = theta(6);
psi2 = theta(7);
rhor = theta(8);
rhog = theta(9);
rhoz = theta(10);
sig2r = theta(11);
sig2g = theta(12);
sig2z = theta(13);
kap = tau*(1-nu)/(nu*phi*pist^2);
end;

if size(theta,1)==11;
tau = theta(1);
beta = theta(2);
kap = theta(3);
psi1 = theta(4);
psi2 = theta(5);
rhor = theta(6);
rhog = theta(7);
rhoz = theta(8);
sig2r = theta(9);
sig2g = theta(10);
sig2z = theta(11);
end;

Sigma=[ sig2z 0 0 ; 0 sig2g 0 ; 0 0 sig2r];


n_eqs=8;
n_eps=3;
n_eta=2;

z_pos=1; g_pos=2; r_pos=3; y_pos=4; pi_pos=5; c_pos=6; Epi_pos=7; Ey_pos=8;
ez_pos=1; eg_pos=2; er_pos=3;
eta_pi_pos=1; eta_y_pos=2;
Gam0=zeros(n_eqs,n_eqs); Gam1=zeros(n_eqs,n_eqs); Gam2=zeros(n_eqs,n_eps); Gam3=zeros(n_eqs,n_eta);
Gam0(z_pos,z_pos)=1;
Gam0(g_pos,g_pos)=1;
Gam0(r_pos,g_pos)=(1-rhor)*psi2;
Gam0(r_pos,r_pos)=1;
Gam0(r_pos,y_pos)= - (1-rhor)*psi2;
Gam0(r_pos,pi_pos) = -(1-rhor)*psi1;
Gam0(y_pos,g_pos)=-kap;
Gam0(y_pos,y_pos)= kap;
Gam0(y_pos,pi_pos)=-1;
Gam0(y_pos,Epi_pos)=beta;
Gam0(pi_pos,z_pos)=  rhoz/tau;
Gam0(pi_pos,g_pos)= 1-rhog;
Gam0(pi_pos,r_pos)= -1/tau;
Gam0(pi_pos,y_pos)= -1;
Gam0(pi_pos,Epi_pos)= 1/tau;
Gam0(pi_pos,Ey_pos)=1;
Gam0(Epi_pos,pi_pos)=1;
Gam0(Ey_pos,y_pos)=1;

Gam1(z_pos,z_pos)=rhoz;
Gam1(g_pos,g_pos)=rhog;
Gam1(r_pos,r_pos)=rhor;
Gam1(c_pos,g_pos)=-1;
Gam1(c_pos,y_pos)=1;
Gam1(c_pos,c_pos)=-1;
Gam1(Epi_pos,Epi_pos)=1;
Gam1(Ey_pos,Ey_pos)=1;


Gam2(z_pos,ez_pos)=1; Gam2(g_pos,eg_pos)=1; Gam2(r_pos,er_pos)=1;
Gam3(Epi_pos,eta_pi_pos)=1; Gam3(Ey_pos,eta_y_pos)=1;


cons=zeros(8,1);
  [G1,C,impact,dum1,dum2,dum3,dum4,eu]=gensys(Gam0,Gam1,cons,Gam2,Gam3);


