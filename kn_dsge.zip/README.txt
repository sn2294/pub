README.TEX

The replication files for Dynamic Identification of DSGE models: Komunjer and Ng (2011)

AN_SCORFHEIDE.M file replicates the values in Table 1, as well as the
left panels of Tables 2 and 3. This program
can be modified to analyze singular or square models (number of shcoks
less than or equal to the number of observables). 

AN_SCORFHEIDE_NS.M file replicates the values in the right panels of
Tables 2 and 3. This program can be modified
to analyze   non-singular  models with more shocks  than observables
(such as due to measurement errors). 


The structure of the programs is as follows:

1. define theta_0:  the parameter vector at which identification is to be evaluated

2. solve the model:  [A_0,TC,B_0,RC,Sigma] = solve_as(theta_0) 
            we use gensys by Chris Sims, but this can be replaced

3. put system into minimal form: 

            [n_X,minA,minB,minC,minD] = reduce2minimal(A_0,B_0,C_0,minS,maxS)  
  for nonsingular models, an additional filtering step is needed to obtain the K and Sig_a matrices:
            [KK, Sig_a] = dare_kn(minA,minB,minC,minD,Sig_all,10e-6);

4. compute the Delta matrices:
     Proposition 2-S (singular case) 
 [Delta_0,Delta_L,Delta_T,Delta_U] = delta_as(theta_0,minA,minB,minC,minD,Sigma,C_0) 

   Proposition 2-NS (nonsingular case):
            [Delta_0,Delta_L,Delta_T] = delta_as_ns(theta_0,par_v,C_0) 

 (optional: check the rank condition before putting the model into minimal form)

5. set a tolerance range and perform rank tests:

     table0 = rank_test(Delta_0,n_theta,n_x,n_eps,n_y,print_details,tol0,steps) (singular case)
     table0 = rank_test_ns(Delta_0,n_theta,n_x,n_y,print_details,tol0,steps)   (nonsingular case)

6. use the null space of Delta_L to find the parameters that are not identified:
   singular case:
         badL{itheta} = find_badL(Delta_L,n_theta,tol1);
         [bad_L{itheta},bad_LT{itheta},bad_LU{itheta},bad_LTU{itheta}]
          = find_bad(Delta_0,n_theta,n_x,n_eps,tol1) 
   non-singular case:
         [bad_L{itheta},bad_LT{itheta}] = find_bad_ns(Delta_0,n_theta,n_x,tol1) 


7. use the above results to help set up the restrictions in the matrix Rmat.
 Test conditional identification. In the An Schorfheide example, we test 11 sets of restrictions.

            table2 = Crank_test(Delta_0,n_theta,n_x,n_eps,n_y,tol1,Rmat) (singular case)
            table2 = Crank_test_ns(Delta_0,n_theta,n_x,n_y,tol1,Rmat)   (nonsingular case)


Note: The model specific inputs are
a) solve_as.m
b) delta_as.m and delta_as_ns.m (only to the extent that they call up solve_as.m to
compute numerical derivatives)
c) the Rmat matrix of restrictions


Suggestion for Step 6: start with a low tolerance to get parameters are
unidentifiable and gradually increase the tolerance. If we start with
a high tolerance, Matlab returns the position of the problematic
parameters in numerical order, rather than in order of identifiability.
