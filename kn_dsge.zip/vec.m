% VEC.M            05-31-2011          code by: Komunjer and Ng
% This function computes the vec of a matrix

function v = vec(A)

v = reshape(A, size(A,1)*size(A,2),1);