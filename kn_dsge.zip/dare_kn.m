function [K,S] = dare_kn(A,B,C,D,Sigma,TolCV)
% dare_kn.m
%  This program solves the Riccati matrix difference equations associated
%  with the Kalman filter by iterating until the tolerance TolCV is reached.
%  Inputs:  A is n x n, B is n_y x n_e, C is n_y x n, D is n_y x n_e, TolCV
%  is a scalar.
%  Outputs: steady state Kalman gain K is n_y x n_y, stationary covariance 
%           matrix S of the one-step ahead errors a(t+1) in forecasting y(t+1)
%           is n_y x n_y.
%  The program creates the Kalman filter for the following system:
%       x(t+1) = A*x(t) + B*e(t+1)
%       y(t+1) = C*x(t) + D*e(t+1)
%  The program creates an innovations representation:
%        xx(t+1) = A*xx(t) + K*a(t+1)
%         y(t+1) = C*xx(t) + a(t+1),
%  where K is the (steady state) Kalman gain, S is the covariance matrix of 
%  the one-step-ahead forecast error S = E[a(t)*a(t)'], and
%  a(t+1) = y(t+1) - E[y(t+1)| y(t), y(t-1), ... ], and xx(t)=E[x(t)|y(t),...].

% Initialization
Q = B*Sigma*B'; % Q is n x n
R = D*Sigma*D'; % R is n_y x n_y
P = B*Sigma*D';
g0 = Q;
dd = 1;
% Iterating until steady state
it=1; maxit=5000;
while dd > TolCV  & it < maxit;
    b0 = A*g0*C' + P;
    s0 = C*g0*C' + R;
    k0 = b0/s0;
    g1 = A*g0*A' + Q - k0*s0*k0';
    b1 = A*g1*C' + P;
    s1 = C*g1*C' + R;
    k1 = b1/s1;
    dd=max(max(abs(k1-k0)));
    g0=g1;
    it=it+1;
end;
if it >= maxit; disp(sprintf('DARE not converging: %15g',dd)); end;
K=k1;
S=s1;
