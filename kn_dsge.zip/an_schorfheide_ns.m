% AN_SCHORFHEIDE_NS.M      05-31-2011   code by: Komunjer and Ng
% This program checks the local identifiability of the parameter theta
% in An and Schorfeide (Econ. Reviews 2007) model in which the observables 
% are further assumed to be measured with error. The values at which local
% identification is checked are specified in PAR_VALUES.M file.
% The model is solved using GENSYS.M by Sims (2002).

clear;

% loads the values of the deep parameter
xtheta{1}=par_values(1,13);         % Table 1 in Komunjer and Ng (2011) 
xtheta{2}=par_values(1,11);         % Table 2 in Komunjer and Ng (2011)
xtheta{3}=par_values(4,11);
xtheta{4}=par_values(6,11);
xtheta{5}=par_values(8,11);         % Table 3 in Komunjer and Ng (2011)
% defines the variances of measurement errors. In this version of the model 
% we assume there are only 3 observables (c.f. Table 2 in Komunjer and Ng,
% 2011). If more observables are added, par_v can be expanded to include
% the measurement errors on the additional observables. 
par_v = [(0.2/100)^2; (0.2/100)^2; (0.2/100)^2]; 

delete('model_as_ns.out');
% ouput file
diary('model_as_ns.out');

for itheta=2;
    theta_0=xtheta{itheta};
    disp(sprintf('Theta: set %d',itheta));
    disp(sprintf('%6.4f ',theta_0));
    
    % solves the model using GENSYS
    [A_0,TC,B_0,RC,Sigma] = solv_as(theta_0);
    
    % selects the observed variables: g_pos=2; r_pos=3; y_pos=4; pi_pos=5; c_pos=6;
    varind = [3; 4; 5];
    C_0 = zeros(rows(varind),rows(A_0));
    for i = 1:rows(varind);
        C_0(i,varind(i)) = 1;
    end;

    % transforms the system into a minimal state and checks the rank condition.
    % minS is the minimal number of states we tolerate. It usually equals the number of shocks.
    minS = 3; maxS = minS + 3;
    [n_X,minA,minB,minC,minD] = reduce2minimal(A_0,B_0,C_0,minS,maxS);
    
    % adds measurement errors to the minimal ABCD system
    F = eye(size(minC,1)); % all variables are mismeasured
    Sigma_v = zeros(size(minC,1),size(minC,1));
    Sigma_v(1,1) = par_v(1); 
    Sigma_v(2,2) = par_v(2); 
    Sigma_v(3,3) = par_v(3); 
    Sig_all = [Sigma, zeros(size(minB,2), size(minC,1));
                zeros(size(minB,2), size(minC,1))', Sigma_v];
    % concatenates B and D to form B and D for mismeasured data
    minB = [minB, zeros(size(minA,1),size(minC,1))];
    minD = [minD, F];

    % constructs the innovations representation by soving DARE
    RR = minD*Sig_all*minD';
    GG = minD*Sig_all*minB';
    QQ = minB*Sig_all*minB';
    FF = minA';
    HH = minC';
    [KK, Sig_a] = dare_kn(minA,minB,minC,minD,Sig_all,10e-6);

    % checks full rank of Sig_a and minimality of the AKC system
    rank_OK = (det(Sig_a)~= 0)
    [CC,OO,indCC,indOO,indmin] = minimalstate(minA,KK,minC,0);

    lambda = [vec(minA);  vec(KK); vec(minC); vec(Sig_a)];
    theta_ns = [theta_0; par_v];
    [Delta_0,Delta_L,Delta_T] = delta_as_ns(theta_0,par_v,C_0);

    n_x = size(minA,1);
    n_y = size(minC,1);
    n_theta=size(theta_ns,1);
    print_details=0;

    tol0=1e-2;
    tol1=1e-3;
    steps=10;
    % prints the results in a table for a range of tolerance levels 
    table0 = rank_test_ns(Delta_0,n_theta,n_x,n_y,print_details,tol0,steps);
    
    % searches for the components of theta that are responsible for
    % identification failure. Tolerance level is set by tol2: the lower the
    % level the more candidate components of theta at which identification
    % fails.
     % start with a low tolerance
    disp('Problematic Parameters:');
    tol2 = 1e-0;
    [bad_L{itheta},bad_LT{itheta}] = find_bad_ns(Delta_0,n_theta,n_x,tol2);
    disp(bad_LT{itheta});
    tol2 = 1e-9;
    [bad_L{itheta},bad_LT{itheta}] = find_bad_ns(Delta_0,n_theta,n_x,tol2);
    disp(bad_LT{itheta});

    % checks conditional identification under restrictions defined in Rmat
    Rmata=[]; Rmatb=[]; Rmat=[];
    Rmata{1}=3; Rmata{2}=[3 4]; Rmata{3}=[4 5]; Rmata{4}=[3 5]; Rmata{5}=[2 4];Rmata{6}=[4 9]; 
    Rmata{7}=[2 3 4 ];Rmata{8}=[2 6 7];Rmata{9}=[3 4 6]; Rmata{10}=[3 4 7];  Rmata{11}=[1 6 7];

    Rmatb{1}=1; Rmatb{2}=2; Rmatb{3}=3; Rmatb{4}=4; Rmatb{5}=5; Rmatb{6}=6; Rmatb{7}=7; Rmatb{8}=8;
    Rmatb{9}=9; Rmatb{10}=10; Rmatb{11}=11;
    
    if size(theta_0,1) == 13; 
        Rmat = Rmata; 
    else
        Rmat = Rmatb;
    end;
    tol1=1e-3;
    % prints the results in a table for all the restrictions in Rmat 
    % tolerance is set to tol1
    table2 = Crank_test_ns(Delta_0,n_theta,n_x,n_y,tol1,Rmat);
end; 

diary off;
