% AN_SCHORFHEIDE.M      05-31-2011   code by: Komunjer and Ng
% This program checks the local identifiability of the  parameter theta
% in An and Schorfeide (Econ. Reviews 2007) model. The values at which local
% identification is checked are specified in PAR_VALUES.M file.
% The model is solved using GENSYS.M by Sims (2002).

clear;

% loads the values of the deep parameter
xtheta{1}=par_values(1,13);     % Table 1 in Komunjer and Ng (2011)
xtheta{2}=par_values(1,11);     % Table 2 in Komunjer and Ng (2011)
xtheta{3}=par_values(4,11);
xtheta{4}=par_values(6,11);
xtheta{5}=par_values(8,11);     % Table 3 in Komunjer and Ng (2011)
delete('model_as.out');
% ouput file
diary('model_as.out');

% selects the value at which identification is checked
for itheta=1;
    theta_0=xtheta{itheta};
    disp(sprintf('Theta: set %d',itheta));
    disp(sprintf('%6.4f ',theta_0));

    % solves the model using GENSYS
    [A_0,TC,B_0,RC,Sigma] = solv_as(theta_0);

    % selects the observed variables: g_pos=2; r_pos=3; y_pos=4; pi_pos=5; c_pos=6;
    varind = [3; 4; 5; 6];
    C_0 = zeros(rows(varind),rows(A_0));
    for i = 1:rows(varind);
        C_0(i,varind(i)) = 1;
    end;

    % transforms the system into a minimal state and checks the rank condition
    % minS is the minimal number of states we tolerate. It usually equals the number of shocks
    minS = 3; maxS = minS + 3;
    [n_X,minA,minB,minC,minD] = reduce2minimal(A_0,B_0,C_0,minS,maxS);
    [Delta_0,Delta_L,Delta_T,Delta_U] = delta_as(theta_0,minA,minB,minC,minD,Sigma,C_0);
    n_x = size(minA,1);
    n_eps = size(minB,2);
    n_y = size(minC,1);
    n_theta = size(theta_0,1);
    print_details = 0;
    tol0 = 1e-2;
    tol1 = 1e-3;
    steps = 10;
    % prints the results in a table for a range of tolerance levels 
    table0 = rank_test(Delta_0,n_theta,n_x,n_eps,n_y,print_details,tol0,steps);

    % searches for the components of theta that are responsible for
    % identification failure. Tolerance level is set by tol2: the lower the
    % level the more candidate components of theta at which identification
    % fails.
    % start with a low tolerance
    disp('Problematic Parameters:');
    tol2 = 1e-3;
    [bad_L{itheta},bad_LT{itheta},bad_LU{itheta},bad_LTU{itheta}] =...
              find_bad(Delta_0,n_theta,n_x,n_eps,tol2);
    disp(bad_LTU{itheta});
    tol2 = 1e-8;
    [bad_L{itheta},bad_LT{itheta},bad_LU{itheta},bad_LTU{itheta}] =...
              find_bad(Delta_0,n_theta,n_x,n_eps,tol2);
     disp(bad_LTU{itheta});
     
    % checks conditional identification under restrictions defined in Rmat
    Rmata=[]; Rmatb=[]; Rmat=[];
    Rmata{1}=3; Rmata{2}=[3 4]; Rmata{3}=[4 5]; Rmata{4}=[3 5]; Rmata{5}=[2 4];Rmata{6}=[4 9]; 
    Rmata{7}=[2 3 4 ];Rmata{8}=[2 6 7];Rmata{9}=[3 4 6]; Rmata{10}=[3 4 7];  Rmata{11}=[1 6 7];

    Rmatb{1}=1; Rmatb{2}=2; Rmatb{3}=3; Rmatb{4}=4; Rmatb{5}=5; Rmatb{6}=6; Rmatb{7}=7; Rmatb{8}=8;
    Rmatb{9}=9; Rmatb{10}=10; Rmatb{11}=11;
    if size(theta_0,1) == 13; 
        Rmat = Rmata; 
    else 
        Rmat = Rmatb; 
    end;
    tol1 = 1e-3;
    % prints the results in a table for all the restrictions in Rmat 
    % tolerance is set to tol1
    table2 = Crank_test(Delta_0,n_theta,n_x,n_eps,n_y,tol1,Rmat);
end;
diary off;
