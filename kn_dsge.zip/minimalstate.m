% MINIMALSTATE.M        05-31-2011       code by: Komunjer and Ng
% This function computes the controllability and the observability matrices
% of the ABCD system and checks if the system is minimal state
function [CC,OO,indCC,indOO,indmin] = minimalstate(A,B,C,iprint)

n = size(A,1);
CC = B; 
OO = C;
if n >= 2
    for indn = 1:1:n-1
    CC = [CC, (A^indn)*B];
    OO = [OO; C*(A^indn)];
    end
end
indCC = (rank(CC)==n);
indOO = (rank(OO)==n);
indmin = indCC&indOO;
disp('Check Minimality');
mymprint([ n indCC indOO indmin]);

if iprint==1;
    disp('Rank of CC and OO');
    mymprint([rank(CC) rank(OO)]);
    disp('Size of CC and OO');
    mymprint([size(CC) size(OO)]);

    disp('Size of A,B,C, CC,OO');
    mymprint([ size(A) size(B) size(C) ]);
end;



