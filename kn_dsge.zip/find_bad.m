% FIND_BAD.M       05-31-2011       code by: Komunjer and Ng
% This function finds the combinations of theta components that are
% responsible for full rank failure of Delta matrix in Proposition 2-S (SINGULAR CASE)

function [tableL,tableLT, tableLU,tableLTU]=find_bad(Delta_0,n_theta,n_x,n_eps,tol1)

% defines submatrices of the Delta matrix in Proposition 2-S of Komunjer and
% Ng (2011)
Delta_L = Delta_0(:,1:n_theta);
Delta_T = Delta_0(:,n_theta+1:n_theta+n_x^2);
Delta_U = Delta_0(:,n_theta+n_x^2+1:end);
Delta_LT = [Delta_L Delta_T];
Delta_LU = [Delta_L Delta_U];
Delta_LTU = [Delta_L Delta_T Delta_U];
% computes rank deficiencies
n_slack_L = n_theta-rank(Delta_L,tol1);
n_slack_LT = n_theta+n_x ^2-rank(Delta_LT,tol1);
n_slack_LU = n_theta+n_eps^2-rank(Delta_LU,tol1);
n_slack_LTU = n_theta+n_x^2+n_eps^2-rank(Delta_0,tol1);
% initializes tables of results
tableL = [];  tableLT = []; tableLU = []; tableLTU = [];

% checks rank failures of Delta_L
if n_slack_L> 0;
    temp=null(Delta_L,n_slack_L+1);
    if cols(temp)>1;
        temp1=sum(abs(temp)')';
        tableL=find(temp1 > tol1)';
    else
        tableL=find(abs(temp) > tol1)';
    end;
end;
% checks rank failures of Delta_LT  
if n_slack_LT> 0;
    temp=null(Delta_LT,n_slack_LT+1);
    if cols(temp)>1;
        tableLT=find(sum(abs(temp)')'> tol1 )';
    else
        tableLT=find(abs(temp) > tol1)';
    end;
end;
% checks rank failures of Delta_LU
if n_slack_LU> 0;
    temp=null(Delta_LU,n_slack_LU+1);
    if cols(temp)>1;
        tableLU=find(sum(abs(temp)')'> tol1 )';
    else
        tableLU=find(abs(temp) > tol1)';
    end;
end;
% checks rank failures of the entire Delta matrix
if n_slack_LTU> 0;
    temp=null(Delta_LTU,n_slack_LTU+1);
    if cols(temp)>1;
        tableLTU=find(sum(abs(temp)')'> tol1 )';
    else
        tableLTU=find(abs(temp) > tol1)';
    end;
end;
