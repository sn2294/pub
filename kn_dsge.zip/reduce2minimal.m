% REDUCE2MINIMAL.M            05-31-2011     code by: Komunjer and Ng
% This gives the minimal state representation of the ABCD solution

function [n_X,minA,minB,minC,minD]=reduce2minimal(A_0,B_0,C_0,minS,maxS)

disp(sprintf('\n ******************'));
disp(sprintf('Original Model: A(%d,%d), B(%d,%d), C(%d,%d)', size(A_0), size(B_0), size(C_0)));

[CC,OO,dum1,dum2,indmin] = minimalstate(A_0,B_0,C_0,0);

if indmin==1;
    done=1; 
    n_X=rows(A_0);
    [minA,minB,minC,minD]=put2minimal(n_X,A_0,B_0,C_0);
else
    done=0; 
    n_X=maxS;
end;

while done==0 & n_X>= minS;
    [minA,minB,minC,minD]=put2minimal(n_X,A_0,B_0,C_0);
    [CC,OO,dum1,dum2,indmin] = minimalstate(minA,minB,minC,0);
    if indmin==1; 
        done=1; 
        break;
    else
        n_X=n_X-1; 
    end;
end;

[minCC,minOO,dum1,dum2,indmin] = minimalstate(minA,minB,minC,0);

disp(sprintf('\n *************'));
disp(sprintf('Found n_X = %d rank(CC)= %d rank(OO)=%d',n_X,rank(CC),rank(OO)));
disp(sprintf('Transformed Model: A(%d,%d), B(%d,%d), C(%d,%d)',size(minA), size(minB), size(minC)));

eigC = eig(minCC*minCC');
eigO = eig(minOO'*minOO);

