function row=rows(x);
[row,col]=size(x);
