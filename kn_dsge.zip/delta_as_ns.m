% DELTA_AS_ERR.M            05-31-2011         code by: Komunjer and Ng
% This function computes the delta matrix in Proposition 2-NS (NONSINGULAR 
% CASE) of Komunjer and Ng (2011). The derivatives are computed numerically.

function [Delta,lambda_grad,T_grad] = delta_as_ns(theta,par_v,C_0)

n_x = 3; n_y = size(C_0,1);

% computes Delta_theta
lambda_grad = [];
theta_ns = [theta;par_v];
n_theta = size(theta,1); 

for i=1:1:size(theta_ns,1)
    delta_theta_ns = zeros(size(theta_ns)); 
    delta_theta_ns(i) = theta_ns(i)*1e-3;
    if delta_theta_ns(i)==0; delta_theta_ns(i) = 1e-3; end;
    % computations for theta_p
    theta_ns_p = theta_ns + delta_theta_ns;
    theta_p = theta_ns(1:n_theta);
    [A_0,TC,B_0,RC,Sigma]=solv_as(theta_p);
    [minA,minB,minC,minD]=put2minimal(n_x,A_0,B_0,C_0);
    % adds measurement errors
    F = eye(size(minC,1)); % all variables are mismeasured
    par_v_p = theta_ns_p(n_theta+1:end);
    Sigma_v = zeros(size(minC,1),size(minC,1));
    Sigma_v(1,1) = par_v_p(1); 
    Sigma_v(2,2) = par_v_p(2); 
    Sigma_v(3,3) = par_v_p(3);  
    Sig_all = [Sigma, zeros(size(minB,2), size(minC,1));
                zeros(size(minB,2), size(minC,1))', Sigma_v];
    % concatenates B and D to form B and D for mismeasured data
    minB = [minB, zeros(size(minA,1),size(minC,1))];
    minD = [minD, F];
    % constructs the innovations representation by solving DARE
    [KK, Sig_a] = dare_kn(minA,minB,minC,minD,Sig_all,10e-6);

    lambda_p = [vec(minA); vec(KK); vec(minC); vec(Sig_a)];
    
    % computations for theta_m
    theta_ns_m = theta_ns - delta_theta_ns; 
    theta_m = theta_ns_m(1:n_theta);
    [A_0,TC,B_0,RC,Sigma] = solv_as(theta_m);
    [minA,minB,minC,minD] = put2minimal(n_x,A_0,B_0,C_0);
    % adds measurement errors
    F = eye(size(minC,1)); % all variables are mismeasured
    par_v_m = theta_ns_m(n_theta+1:end);
    Sigma_v = zeros(size(minC,1),size(minC,1));
    Sigma_v(1,1) = par_v_m(1); 
    Sigma_v(2,2) = par_v_m(2); 
    Sigma_v(3,3) = par_v_m(3); 
    Sig_all = [Sigma, zeros(size(minB,2), size(minC,1));
                zeros(size(minB,2), size(minC,1))', Sigma_v];
    % concatenates B and D to form B and D for mismeasured data
    minB = [minB, zeros(size(minA,1),size(minC,1))];
    minD = [minD, F];
    % constructs the innovations representation by solving DARE
    [KK, Sig_a] = dare_kn(minA,minB,minC,minD,Sig_all,10e-6);
    
    lambda_m = [vec(minA); vec(KK);vec(minC);  vec(Sig_a)];

    lambda_grad = [lambda_grad, (lambda_p - lambda_m)/(2*delta_theta_ns(i))];
end;

% computes Delta_T
[A_0,TC,B_0,RC,Sigma] = solv_as(theta);
[minA,minB,minC,minD] = put2minimal(n_x,A_0,B_0,C_0);
% adds measurement errors
F = eye(size(minC,1)); % all variables are mismeasured
Sigma_v = zeros(size(minC,1),size(minC,1));
Sigma_v(1,1) = par_v(1); 
Sigma_v(2,2) = par_v(2); 
Sigma_v(3,3) = par_v(3);
Sig_all = [Sigma, zeros(size(minB,2), size(minC,1));
            zeros(size(minB,2), size(minC,1))', Sigma_v];
% concatenates B and D to form B and D for mismeasured data
minB = [minB, zeros(size(minA,1),size(minC,1))];
minD = [minD, F];
% constructs the innovations representation by solving DARE
[KK, Sig_a] = dare_kn(minA,minB,minC,minD,Sig_all,10e-6);

% computes Delta_T
T_grad = [kron(minA',eye(n_x)) - kron(eye(n_x),minA);
          kron(KK',eye(n_x));
          -1*kron(eye(n_x),minC);
          zeros(n_y^2,n_x^2)];


 Delta = [lambda_grad  T_grad];

