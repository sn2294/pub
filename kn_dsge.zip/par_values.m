% PAR_VALUES.M         05-31-2011          code by: Komunjer and Ng (2011)
% This function defines the deep parameter configurations. The latter are
% taken from Tables 3 and 2 in An and Schorfheide (Econ. Reviews 2007, p.
% 130 and 129)

function theta = par_values(choice,npar);

% CONFIGURATIONS WITH 13 PARAMETERS -- VALUES TAKEN FROM TABLE 3
% theta_0 = [tau_0; beta_0; nu_0; phi_0; pist_0; psi1_0; psi2_0; rhor_0; rhog_0; rhoz_0; sig2r_0; sig2g_0; sig2z_0];

% DGP from Table 3, p 130
if choice == 1;
    tau_0  = 2.00;
    kap_0  = 0.33;
    nu_0   = 0.10;
    rA_0   = 1.00;
    piA_0  = 3.20;
    psi1_0 = 1.50;
    psi2_0 = 0.125;
    rhor_0 = 0.75;
    rhog_0 = 0.95;
    rhoz_0 = 0.90;
    sig2r_0= (0.20/100)^2;
    sig2g_0= (0.60/100)^2;
    sig2z_0= (0.30/100)^2;
    beta_0 = 1/exp(rA_0/400);       % computed from the formula on p.122
    pist_0 = exp(piA_0/400);        % computed from the formula on p.122
    phi_0  = tau_0*(1-nu_0)/nu_0/kap_0/pist_0^2;        % imputed from Eq 32 on p. 120
end;

% prior 1 (means) from Table 3, p 130
if choice == 2;
    tau_0  = 2.00;
    kap_0  = 0.3;
    nu_0   = 0.10;
    rA_0   = 0.8;
    piA_0  = 4;
    psi1_0 = 1.50;
    psi2_0 = 0.5;
    rhor_0 = 0.5;
    rhog_0 = 0.8;
    rhoz_0 = 0.66;
    sig2r_0= (0.30/100)^2;
    sig2g_0= (0.40/100)^2;
    sig2z_0= (0.40/100)^2;
    beta_0 = 1/exp(rA_0/400);       % computed from the formula on p.122
    pist_0 = exp(piA_0/400);        % computed from the formula on p.122
    phi_0  = tau_0*(1-nu_0)/nu_0/kap_0/pist_0^2;        % imputed from Eq 32 on p. 120
end;

% prior 2 (standard deviations) from Table 3, p. 130
if choice==3;
    tau_0  = 0.5;
    kap_0  = 0.2;
    nu_0   = 0.05;
    rA_0   = 0.5;
    piA_0  = 2;
    psi1_0 = 0.25;
    psi2_0 = 0.25;
    rhor_0 = 0.2;
    rhog_0 = 0.1;
    rhoz_0 = 0.15;
    sig2r_0= (4/100)^2;
    sig2g_0= (4/100)^2;
    sig2z_0= (4/100)^2;
    beta_0 = 1/exp(rA_0/400);       % computed from the formula on p.122
    pist_0 = exp(piA_0/400);        % computed from the formula on p.122
    phi_0  = tau_0*(1-nu_0)/nu_0/kap_0/pist_0^2;        % imputed from Eq 32 on p. 120
end;

% CONFIGURATIONS WITH 11 PARAMETERS -- VALUES TAKEN FROM TABLE 2
% theta_0 = [tau_0; beta_0; kap_0; psi1_0; psi2_0; rhor_0; rhog_0; rhoz_0; sig2r_0; sig2g_0; sig2z_0];

% DGP from Table 2, p. 129
if choice==4;
    tau_0  = 2;
    kap_0  = 0.15;
    rA_0   = 0.4;
    piA_0  = 4;
    psi1_0 = 1.5;
    psi2_0 = 1;
    rhor_0 = 0.60;
    rhog_0 = 0.95;
    rhoz_0 = 0.65;
    sig2r_0= (0.2/100)^2;
    sig2g_0= (0.8/100)^2;
    sig2z_0= (0.45/100)^2;
    beta_0 = 1/exp(rA_0/400);   % computed from the formula on p.122
end;

% prior 1 (means) from Table 2, p. 129
if choice==5;
    tau_0  = 2;
    kap_0  = 0.2;
    rA_0   = 0.5;
    piA_0  = 7;
    psi1_0 = 1.5;
    psi2_0 = 0.5;
    rhor_0 = 0.50;
    rhog_0 = 0.50;
    rhoz_0 = 0.80;
    sig2r_0= (0.4/100)^2;
    sig2g_0= (1/100)^2;
    sig2z_0= (0.5/100)^2;
    beta_0 = 1/exp(rA_0/400);   % computed from the formula on p.122
end;

% prior 2 (standard deviations) from Table 2, p. 129
if choice ==6;
    tau_0  = 0.5; 
    kap_0  = 0.1; 
    rA_0   = 0.5;
    piA_0  = 2;
    psi1_0 = 0.25;
    psi2_0 = 0.25;
    rhor_0 = 0.20;
    rhog_0 = 0.10;
    rhoz_0 = 0.15;
    sig2r_0= (4/100)^2;
    sig2g_0= (4/100)^2;
    sig2z_0= (4/100)^2;
    beta_0 = 1/exp(rA_0/400);   % computed from the formula on p.122
end;

% Posterior mode taken from Figure 1 p.134 for the DGP in Table 2, p. 129
if choice == 7;
    tau_0  = 1.75;
    kap_0  = 0.15;
    rA_0   = 0.44;
    piA_0  = 4;
    psi1_0 = 1.6; 
    psi2_0 = 0.75;
    rhor_0 = 0.60;
    rhog_0 = 0.80;
    rhoz_0 = 0.70;
    sig2r_0= (2/100)^2;
    sig2g_0= (8/100)^2;
    sig2z_0= (5/100)^2;
    beta_0 = 1/exp(rA_0/400);   % computed from the formula on p.122
end;

% hybrid -- same as choice 1 but with lower rho_g and rho_z
if choice == 8;
    tau_0  = 2.00;
    kap_0  = 0.33;
    nu_0   = 0.10;
    rA_0   = 1.00;
    piA_0  = 3.20;
    psi1_0 = 1.50;
    psi2_0 = 0.125;
    rhor_0 = 0.75;
    rhog_0 = 0.15;
    rhoz_0 = 0.1;
    sig2r_0= (0.2/100)^2;
    sig2g_0= (0.6/100)^2; 
    sig2z_0= (0.3/100)^2;
    beta_0 = 1/exp(rA_0/400);       % computed from the formula on p.122
end;


if npar==13;
theta=[tau_0; beta_0; nu_0; phi_0; pist_0; psi1_0; psi2_0; rhor_0; rhog_0; ...
       rhoz_0; sig2r_0; sig2g_0; sig2z_0]; 
end;
if npar==11;
theta=[tau_0; beta_0; kap_0; psi1_0; psi2_0; rhor_0; rhog_0; ...
       rhoz_0; sig2r_0; sig2g_0; sig2z_0]; 
end;
