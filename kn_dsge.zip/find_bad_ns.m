% FIND_BAD_ERR.M       05-31-2011       code by: Komunjer and Ng
% This function finds the combinations of theta components that are
% responsible for full rank failure of Delta matrix in Proposition 2-NS (NONSINGULAR CASE)

function [tableL,tableLT] = find_bad_ns(Delta_0,n_theta,n_x,tol1)

% defines submatrices of the Delta matrix in Proposition 2-NS of Komunjer and
% Ng (2011)
Delta_L = Delta_0(:,1:n_theta);
Delta_T = Delta_0(:,n_theta+1:n_theta+n_x^2);
Delta_LT = [Delta_L Delta_T];
% computes rank deficiencies
n_slack_L = n_theta-rank(Delta_L,tol1);
n_slack_LT = n_theta+n_x^2-rank(Delta_LT,tol1);
% initializes tables of results
tableL=[];  tableLT=[]; 

% checks rank failures of Delta_L
if n_slack_L> 0;
    temp = null(Delta_L,n_slack_L+1);
    if cols(temp)>1;
        tableL = find(sum(abs(temp)')'> tol1 )';
    else
        tableL = find(abs(temp) > tol1)';
    end;
end;

% checks rank failures of Delta_LT  
if n_slack_LT> 0;
    temp = null(Delta_LT,n_slack_LT+1);
    if cols(temp)>1;
        tableLT = find(sum(abs(temp)')'> tol1 )';
    else
        tableLT = find(abs(temp) > tol1)';
    end;
end;

