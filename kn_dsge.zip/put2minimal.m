% PUT2MINIMAL.M             05-31-2011        code by: Komunjer and Ng
% This function gives the minimal representation of the ABCD solution by
% removing the unnecessary states. The procedure is described in Komunjer
% and Ng (2011).

function [minA,minB,minC,minD]=put2minimal(n_X,A_0,B_0,C_0)

% removes unnecessary states
A_1 = A_0(1:n_X,1:n_X);  A_2 = A_0(n_X+1:end,1:n_X);
B_1 = B_0(1:n_X,:); B_2 = B_0(n_X+1:end,:);
C_1 = C_0(:,1:n_X); C_2 = C_0(:,n_X+1:end);
minA = A_1; 
minB = B_1;
minC = C_1*A_1 + C_2*A_2; 
minD = C_1*B_1 + C_2*B_2;


