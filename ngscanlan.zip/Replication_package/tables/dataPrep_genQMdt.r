# This code generates the outfile "QMdt.csv" from the FRED-MD (2021-12.csv) and 
# Michigan Consumer Sentiment (UMCSENTQ.csv) csv files
# Author: Serena Ng (serena.ng@columbia.edu), Susannah Scanlan (ss5605@columbia.edu)


rm(list=ls())
library(dplyr)
library(lubridate)
library(readr)
library(fbi)

# Run these lines in order to download fbi package
#install.packages("remotes")
#remotes::install_github("cykbennie/fbi")



fred<-fredmd("data/2021-12.csv",date_start=as.Date("1960-01-01"),
                           date_end=as.Date("2019-12-01"),
                           transform=TRUE)


qt=read.csv("data/UMCSENTQ.csv",na.strings=c("."))
names(qt)=c('date','cs')
qt$year=year(qt$date)
qt$month=month(qt$date)
keep=(qt$year>=1960) & (qt$year<=2019)
fred$cs=qt$cs[keep]
dt1=fred[,-1]
data.table::fwrite(dt1,file="data/QMdt.csv")


