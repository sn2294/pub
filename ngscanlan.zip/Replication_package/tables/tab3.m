%% tab3
% This script generates table 3. It references tables/out folder.

%Inputs: data/QMdt.csv,
%Outputs: out/t3_text.txt, out/pltdata.mat

% Authors: Serena Ng (serena.ng@columbia.edu), Susannah Scanlan (ss5605@columbia.edu)

% Note: This script should be run from the /tables folder.

clear;
close all;

addpath('../functions')
seed=1234;
rng(seed,'twister');
%% data generated from QMcsent.r
dum=importdata("data/QMdt.csv");
X0.dum=dum.data;
series=dum.textdata;
clear dum;
delay=0;
dates=(1960+1/12:1/12:2020)';
Tpick=217+delay:rows(X0.dum);

Npick=1:cols(X0.dum);
date=(datetime(1960,1,1):calmonths(1):datetime(2019,12,30))';
date=date(Tpick);
dates=dates(Tpick);
Year=year(date);
Month=month(date);
Quarter=quarter(date);
r=3;
p=0;
q=0;
M=1;  % was 50

dt1=X0.dum(Tpick,Npick);
bad=find(isnan(mean(dt1)));
dt1(:,bad)=[];
series(bad)=[];
keep=dt1(:,end);  % the true series
dt1(:,end)=NaN;
mpoints=(2:3:length(date))';
dt1(mpoints,end)=keep(mpoints,end);
tpoints=find(isnan(dt1(:,end))==1);

[T,N]=size(dt1);
mu.X0=nanmean(dt1);
sd.X0=nanstd(dt1);
dt1_std=(dt1-repmat(mu.X0,T,1))./repmat(sd.X0,T,1);
Iw.true=(keep-mu.X0(end))/sd.X0(end);
Im=dt1_std(:,end);
missing=isnan(dt1_std);
n=cols(dt1_std);

%% TP

ff=repmat(1/6,1,6);

TP0=do_fbiTP(dt1_std,r,missing,2,'decomp',missing);
IwS{1}=TP0.data(:,end);
resid0=TP0.ehat(mpoints,end);
resid0=[resid0; -resid0];

CL=do_ChowLin(dt1_std(:,end),TP0.Fhat);
IwS{9}=CL.Yhat3;


%% Estimating new SSKS1
[EM_ksm, ~]=genKSM(dt1_std,r,r,1,50,1e-4,0,1);
SSKS1 = EM_ksm.chi(:,end);

%% SW
[~,SW.Fhat,SW.Lamhat,ve1,x21]=factors_em(dt1_std,r,2,0);
SW.Chat=SW.Fhat*SW.Lamhat';
IwS{2}=dt1_std(:,end);
IwS{2}(tpoints)=SW.Chat(tpoints,end);


inity=[];
for mtt=1:length(mpoints);
    t=mpoints(mtt);    
    YY=year(date(t));
    QQ=quarter(date(t));
    mm=find((Year==YY) & (Quarter==QQ));
    inity(mm,1)=dt1_std(t,end);
end;
inity=TP0.data(:,end);
nlagsF=1;
nlagsY=1;
[newy.TP1,beta.TP1]=iterStock(inity,TP0.Fhat,nlagsF,nlagsY,mpoints,tpoints,'TP1');
IwS{5}=newy.TP1;

[newy.TP1,beta.TP1]=iterStock(inity,TP0.Fhat,0,0,mpoints,tpoints,'TP1');
TP1.IwSF0Y0=newy.TP1;
[newy.TP1,beta.TP1]=iterStock(inity,TP0.Fhat,1,0,mpoints,tpoints,'TP1');
TP1.IwSF1Y0=newy.TP1;
[newy.TP1,beta.TP1]=iterStock(inity,TP0.Fhat,0,1,mpoints,tpoints,'TP1');
TP1.IwSF0Y1=newy.TP1;
IwTP1=[TP1.IwSF0Y0 TP1.IwSF1Y0 TP1.IwSF0Y1 IwS{5}];


dt2_std=dt1_std(:,1:end-1);
p=1;
%% Barigozzi-Luciani
[KS,PCA]=BL_Estimate(dt2_std,r,r,p,50,1e-4,0);
KS.Fhat=KS.F;
[newy.KS,beta.KS]=iterStock(inity,KS.Fhat,nlagsF,0,mpoints,tpoints,'KS');
IwS{4}=newy.KS;

p=0;q=1;
[MLE0,AA0,GG0]=do_FAbyQMLE(dt2_std,r,p,q,TP0.cov(1:end-1,1:end-1),[],[]);
MLE0.Fhat=MLE0.Fgls;
[newy.MLE0,beta.MLE0]=iterStock(inity,MLE0.Fhat,0,0,mpoints,tpoints,'MLE');
IwS{3}=newy.MLE0;
[newy.MLE1,beta.MLE1]=iterStock(inity,MLE0.Fhat,nlagsF,nlagsY,mpoints,tpoints);
IwS{6}=newy.MLE1;

[PCgls.Fhat,PCgls.Lmahat,PCgls.iter]=PCGLS_iter(dt2_std,r,2);
[newy.PCgls,beta.PCgls]=iterStock(inity,PCgls.Fhat,nlagsF,nlagsY,mpoints,tpoints,'pcGLS');
IwS{7}=newy.PCgls;
IwS{8}=SSKS1;

Stock=cell2mat(IwS);

table.Stock=[1 T ];
table.Flow=[1 T ];
for j=1:cols(Stock);
    table.Stock=[table.Stock norm(Stock(tpoints,j)-Iw.true(tpoints),'fro')];
end;

xt1=[1   ; 73; 199; 277 ; 349; 397];
xt2=[72 ; 198; 276; 348 ; 396; T];
clear temp;
for i=1:length(xt1);
temp.Stock=[]; 
t1t2=intersect(xt1(i):xt2(i),tpoints);
for j=1:cols(Stock);
    temp.Stock=[temp.Stock norm(Stock(t1t2,j)-Iw.true(t1t2),'fro')];
end;
table.Stock=[table.Stock;xt1(i) xt2(i) temp.Stock];
end;
fmt=['%10s & %10s & '  repmat('%7.3f &',1,cols(table.Stock)-4) '%7.3f \\\\'];


fileName1 = "out/t3_text.txt";
fileID = fopen(fileName1,'w');
L1 = '\\ start & end & TP & MLE-h & KS & TP$^*$ & MLE$^*$  & PC-GLS$^*$ & KS$^*$ & CL\\\\ \\hline ';
fprintf(fileID,L1);
fprintf(fileID,'\n');
for i=1:rows(table.Stock)
    tmpDate = date(table.Stock(i,1:2));
    tmpDate.Format = 'MMM-yyy';
    fprintf(fileID,fmt,tmpDate,table.Stock(i,[3,5:end]));
    fprintf(fileID,'\n');
end;
L2 = '\\hline';
fprintf(fileID,L2);

STOCK=cell2mat(IwS);
Stock=standard(Stock);
Stock=STOCK;

varnames{1}="TP0";
varnames{2}="SW";
varnames{3}='MLE-h';
varnames{4}="KS";
varnames{5}="TP1*";
varnames{6}='MLE*';
varnames{7}="PCgls*";
varnames{8}="KS*";
varnames{9}="Chow-Lin";
gray=[.7 .7 .7];


save("out/pltdata.mat","Stock","Iw","dates","mpoints","tpoints","delay");
