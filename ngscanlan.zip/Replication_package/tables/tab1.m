%% tab1.m
% This script runs the monte carlo simulations under the first data
% generating process: T = 720, N = 122, r = 3. The resulting table 2 text
% files are saved to the /tables/out folder. Simulation results saved in
% out/mc0ar1.mat.

% Inputs: data/QMmc0.mat
% Outputs: out/t1a.txt, out/t1a.txt , out/mc0ar1.mat

% Authors: Serena Ng (serena.ng@columbia.edu), Susannah Scanlan (ss5605@columbia.edu)

% Note: This script should be run from the /tables folder.


clear;
addpath('../functions')

warning off;
calibrate_mle=0;
infile=['data/QMmc' num2str(calibrate_mle)];
load(infile);
Missing=missing;
maxit=1000;
NN=length(rho0);
    xNsim=[10 20 30 40 50 75 NN];
    Tsim=TT;


store=[]; bad.gls=[]; store1=[]; store2=[]; store3=[];

outfile=['data/mc' num2str(calibrate_mle) 'ar1'];
delete(outfile);
rng('default');

for iN=1:length(xNsim);
    Nsim=xNsim(iN);
    store{iN}=[]; bad.gls(iN)=0;
    for it=1:maxit;
        nn1=round(.4*Nsim); NN1=round(.4*NN);
        nn2=round(.3*Nsim); NN2=round(.3*NN);
        nn3=Nsim-nn1-nn2;   NN3=NN-NN1-NN2;
        if Nsim<NN;
        npick=[randperm(NN1,nn1) NN1+randperm(NN2,nn2) NN1+NN2+  randperm(NN3,nn3)];
        else;
        npick=1:NN;
        end;
    [Xsim,Xdata,fsim]=genr_dfmdata(Tsim,Nsim,r,p,1,A0,Sig2uF0,...
                               rho0(npick),sig2eps0(npick),...
                               L0(npick,:),Missing(1:Tsim,npick),it);

    fsim=demean(fsim);
    Csim=fsim*L0(npick,:)';
    [T,N]=size(Xdata);
    muX=repmat(mean(Xdata),T,1);
    sdX=repmat(std(Xdata),T,1);
    xstd=(Xdata-muX)./sdX;
    [T,N]=size(xstd);
    missing=isnan(xstd);

    TP0=do_fbiTP(xstd,r,missing,2,'decomp',missing);
    TP0cov=TP0.cov;

    [apcglsh,checkapcglsh]=get_apcglsh(xstd,TP0.Fhat,TP0.Lamhat, ...
                                            3);
    [pcgls.Fhat,pcgls.Lamhat,pcgls.iter]=PCGLS_iter(xstd,r,3);

    [EM,PCA]=BL_Estimate(xstd,r,r,p,50,1e-4,0);

    pp=0; qq=0; 
    [MLE0,AA,GG]=do_FAbyQMLE(xstd,r,pp,qq,TP0cov,[],[]);

    out0=[];    out1=[];     out2=[];     out3=[];
    out4=[];
    keep=[];
    one =ones(rows(fsim)-1,1);
    for i=1:r;
      out0{i}=nwest(fsim(2:end,i),[one TP0.Fhat(2:end,:)],0);
      out1{i}=nwest(fsim(2:end,i),[one MLE0.Fgls(2:end,:)],0);
      out2{i}=nwest(fsim(2:end,i),[one EM.F(2:end,:)],0);
      if sum(isnan(mean(apcglsh.Fhat)))==0;
      out3{i}=nwest(fsim(2:end,i),[one apcglsh.Fhat(2:end,:)],0);
      else; out3{i}.rsqr=NaN;
      end;
      if sum(isnan(mean(pcgls.Fhat)))==0;
      out4{i}=nwest(fsim(2:end,i),[one pcgls.Fhat(2:end,:)],0);
      else;
          out4{i}.rsqr=NaN;
      end;    
      
    keep=[out0{i}.rsqr out1{i}.rsqr out3{i}.rsqr out4{i}.rsqr out2{i}.rsqr];
    store{iN}(it,i,:)=keep;
    end; 
    dum01=inv(TP0.Fhat'*TP0.Fhat);
    dum02=trace((fsim'*TP0.Fhat)*dum01*(TP0.Fhat'*fsim))/trace(fsim'* fsim);
    
    dum11=inv(MLE0.Fgls'*MLE0.Fgls);
    dum12=trace((fsim'*MLE0.Fgls)*dum11*(MLE0.Fgls'*fsim))/trace(fsim'*fsim);

    dum21=inv(EM.F'*EM.F);
    dum22=trace((fsim'*EM.F)*dum21*(EM.F'*fsim))/trace(fsim'*fsim);

    dum31=inv(apcglsh.Fhat'*apcglsh.Fhat);
    dum32=trace((fsim'*apcglsh.Fhat)*dum31*(apcglsh.Fhat'*fsim))/trace(fsim'*fsim);

    dum41=inv(pcgls.Fhat'*pcgls.Fhat);
    dum42=trace((fsim'*pcgls.Fhat)*dum41*(pcgls.Fhat'*fsim))/trace(fsim'*fsim);

    
     store1{iN}(it,:)=[dum02 dum12 dum32 dum42 dum22];
     store2{iN}(it,:)=[mean(abs(diag(corr(Csim,TP0.Fhat*TP0.Lamhat')))),...
                       mean(abs(diag(corr(Csim,MLE0.Fgls*MLE0.L')))),...
                       mean(abs(diag(corr(Csim,pcgls.Fhat*pcgls.Lamhat')))),...
                       mean(abs(diag(corr(Csim,apcglsh.Fhat*apcglsh.Lhat')))),...
                       mean(abs(diag(corr(Csim,EM.F*EM.Lambda(:,1:r)'))))];

     store3{iN}(it,:)=[norm(Csim-(TP0.Fhat*TP0.Lamhat').*sdX+muX,'fro'),...
                  norm(Csim-(MLE0.Fgls*MLE0.L').*sdX+muX,'fro'),...
                  norm(Csim-(pcgls.Fhat*pcgls.Lamhat').*sdX+muX,'fro'),...
                  norm(Csim-(apcglsh.Fhat*apcglsh.Lhat').*sdX+muX,'fro'),...
                  norm(Csim-(EM.F*EM.Lambda(:,1:r)').*sdX+muX,'fro')];

    end; %% end maxi
    save(outfile,'store','store1','store2','store3');
end; % end iN

table=[];table1=[];
for iN=1:length(store);
    dum=squeeze(nanmean(store{iN},1));
    table=[table; vec(dum')' ];
    dum1=nanmean(store1{iN},1);
    table1=[table1; dum1];
end;

% Creating tables
ordVar = {'PC','MLE-h','PC-GLS-h','PC-GLS-har','KS'};
trTable1 = table1';
fmt=[repmat('%7.3f & ',1,size(table1,1)-1) '%7.3f \\\\'];

fileName3a = "out/t1a_text.txt";
fileID = fopen(fileName3a,'w');

L1 = ' Nsim & 10 & 20 & 30 & 40 & 50 & 75 & 122 \\\\ \\hline ';
fprintf(fileID,L1);
fprintf(fileID,'\n');
for ii = 1:length(ordVar)
    strHold = strcat(ordVar{ii},' & ');
    fprintf(fileID,'%15s',strHold);
    fprintf(fileID,fmt,trTable1(ii,:));
    fprintf(fileID,'\n');
end
L3 = ' \\hline ';
fprintf(fileID,L3);
fprintf(fileID,'\n');
fclose('all');

%%% Second table
fileName3b = "out/t1b_text.txt";
fileID = fopen(fileName3b,'w');
L1 = 'Nsim & 10 & 20 & 30 & 40 & 50 & 75 & 122 \\\\ \\hline ';
fprintf(fileID,L1);
fprintf(fileID,'\n');
for jj = 1:r
    L2 = [' $R^2: j=$' int2str(jj) '\\\\ \\hline '];
    fprintf(fileID,L2);
    fprintf(fileID,'\n');
    tmpInd = [5*(jj-1)+1:jj*5];
    tmpTable = table(:,tmpInd)';
    for ii = 1:length(ordVar)
        strHold = strcat(ordVar{ii},' & ');
        fprintf(fileID,'%15s',strHold);
        fprintf(fileID,fmt,tmpTable(ii,:));
        fprintf(fileID,'\n');
    end
    L3 = ' \\hline ';
    fprintf(fileID,L3);
    fprintf(fileID,'\n');
end

fclose('all');



