%% dataPrep_QM_calibrate.m
% This code prepares the simulated data used in the monte carlo simulations.
% Outputted data (QMmc0.mat and QMmc1.mat) are saved in the t1_t2/data
% folder.

% Inputs: data/QMdt.csv
% Outputs: data/QMmc0.mat, data/QMmc1.mat

% Authors: Serena Ng (serena.ng@columbia.edu), Susannah Scanlan (ss5605@columbia.edu)

% Note: This script should be run from the t1_t2 folder.


clear;
close all;
addpath('../functions')


for calibrate_mle = 1:-1:0
    clearvars -except calibrate_mle
    xIn=importdata("data/QMdt.csv");
    X0.dum=xIn.data(:,1:end-1);

    if calibrate_mle==1;
        r=2; p=2; q=0;
        Npick=[1:50];
        Tpick=301:rows(X0.dum);
        X0.raw=X0.dum(:,Npick);
        missing=isnan(X0.raw);
        %% use the complete  sample to calibrate data
        mu.X0=nanmean(X0.raw(Tpick,:));
        sd.X0=nanstd(X0.raw(Tpick,:));
        x0.raw=standard(X0.raw(Tpick,:));
        missing_x0=isnan(x0.raw);
        [TT,N]=size(x0.raw);
        TP0=do_fbiTP(x0.raw,r,missing_x0,2,'decomp',missing_x0);
        TP0.phi2=std(TP0.ehat).^2;
        [MLE0,AA0,GG0]=do_FAbyQMLE(x0.raw,r,p,q,cov(x0.raw),[],[]);
        F0=MLE0.Fgls;
        L0=MLE0.L;
        C0=F0*L0';
        bad=find(MLE0.phi2<.01);
        L0(bad,1)=L0(bad,1)+0.2;
        Tsim=TT;
        %check=[MLE0.phi2 sig2eps0./(1-rho0.^2)];
    end;
    
    if calibrate_mle==0;   % calibrate by MLE
        r=3; p=2; q=0;
        
        Npick=1:cols(X0.dum);
        Tpick=1:rows(X0.dum);
        X0.raw=X0.dum(Tpick,Npick);
        bad=find(isnan(mean(X0.raw)));
        X0.raw(:,bad)=[];
        missing=isnan(X0.raw);
        mu.X0=nanmean(X0.raw);
        sd.X0=nanstd(X0.raw);
        x0.raw=(X0.raw-repmat(mu.X0,rows(X0.raw),1))./repmat(sd.X0,rows(X0.raw),1);
        missing_x0=isnan(x0.raw);
        [TT,N]=size(x0.raw);
        TP0=do_fbiTP(x0.raw,r,missing_x0,2,'decomp',missing_x0);
        [TP0.BigAhat,TP0.Ahat,TP0.BigGhat,TP0.Ghat0]= getbigGamFhat(TP0.Fhat',TT,r,p);
        [TT,N]=size(x0.raw);
        AA0=TP0.Ahat;
        F0=TP0.Fhat;
        L0=TP0.Lamhat;
        C0=TP0.Fhat*TP0.Lamhat';
        TP0.phi2=(nanstd(x0.raw-C0).^2)';
        phi20=TP0.phi2;
        x0.raw=TP0.data;     % use imputed data for calibration
        Tsim=TT;
    end;
    goodN=find(sum(missing)==0);
    [uu0,dd0,vv0]=svd(x0.raw);
    DD0=diag(dd0.^2);
    DD0=DD0/sum(DD0);
    
    
    
    %% calibrate shocks to F
    yy=F0';
    uF0=yy*0; A0=[];
    for j=1:p;
           j1=(j-1)*r+1;
           j2=j*r;
           A0{j}=AA0(1:r,j1:j2);
    end;
        
    for t=p+1:TT;
       uF0(:,t)=yy(:,t);
       for j=1:p;
           uF0(:,t)=uF0(:,t)-A0{j}*yy(:,t-j);
       end;
    end;
    uF0=uF0';
    Sig2uF0=cov(uF0);
    mu.uF=mean(uF0);
    
    
    
    %% calibrate persistence of idiosyncratic shocks
    
    ehat0=x0.raw-F0*L0';
    rho0=zeros(N,1);
    sig2eps0=zeros(N,1);
    for i=1:N;
        temp=nwest(ehat0(2:end,i),[ones(TT-1,1) ehat0(1:end-1,i)],0);
        rho0(i,1)=temp.beta(2);
        sig2eps0(i,1)=std(temp.resid)^2;
    end;    
    
    
    %% simulate data
    
    randn('state',123);
    rand('state',456);
    Sig.F0=chol(Sig2uF0);
    e.F=randn(Tsim,r)*Sig.F0;
    e.F=demean(e.F)';
    
    
    fsim=e.F*0;
    fsim(:,1)=e.F(:,1);
    fsim(:,2)=A0{1}(1:r,1:r)*fsim(:,1)+e.F(:,2);
    for t=3:Tsim;
        fsim(:,t)=A0{1}(1:r,1:r)*fsim(:,t-1)+e.F(:,t);
        if p==2;
            fsim(:,t)=fsim(:,t)+A0{2}(1:r,1:r)*fsim(:,t-2);
            end;
    end;
    fsim=fsim';
    
    
    Sig.eps=diag(sqrt(sig2eps0));
    eps=randn(Tsim,N)*Sig.eps;
    esim=eps;
    for t=2:Tsim;
        esim(t,:)=esim(t-1,:).*rho0'+eps(t,:);
    end;    
    
    
    esim=demean(esim);
    Lsim=L0;
    Csim=fsim*Lsim';
    xdata=fsim*Lsim'+esim;
    xsim=xdata;
    xsim(missing(1:Tsim,:))=NaN;
    
    [uu,dd,vv]=svd(xdata);
    DD=diag(dd.^2);
    DD=DD/sum(DD);
    
    outfile=['data/QMmc' num2str(calibrate_mle)];
    save(outfile,'TT','r','p','A0','rho0','Sig2uF0','sig2eps0','L0','DD','DD0','missing');

end

