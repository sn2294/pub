## MWlf.r
# This script generates the MWlf.csv file which contains transformed weekly data and CFNAI data used to make Figures 4 and 5.
# Inputs: data/wrds/wDatRealLev.csv, data/wrds/wDatFinLev.csv, data/CFNAI.csv
# Outputs: data/MWlf.csv
#
# Authors: Serena Ng (serena.ng@columbia.edu), Susannah Scanlan (ss5605@columbia.edu)
#
# Script should be run from f4_f5 folder

 
#rm(list=ls())
library(tidyverse)
library(fbi)
library(ggplot2)
library(lubridate)
library(reshape2)
library(R.matlab)

graphics.off()

# Function to detrend raw weekly data.
preparedata<-function(){
  infile5='data/CFNAI.csv'
  
  dum.m=read.csv('data/wrds/wDatRealLev.csv')
  dum.f=read.csv('data/wrds/wDatFinLev.csv')
  datew=seq(as.Date('1990/1/1'),as.Date('2019/12/30'),by='week',format="%y%m%d")
  
  names(dum.m)[1]='date'
  tcodem=dum.m[1,]
  tcodef=dum.f[1,]
  dum.m=dum.m[-1,]
  dum.f=dum.f[-1,]
  ## only use data up to 2019:12, ie. 1:1566
  
  dum.m=dum.m[1:1566,]
  dum.f=dum.f[1:1566,]
  dum.m$date=datew
  spreads=dum.f[,11:15]
  
  for (i in 1:ncol(spreads)) 
    spreads[,i]=spreads[,i]-dum.f[,16]
  money=cbind(dum.f[,8]/dum.f[,3],dum.f[,23]/dum.f[,3])
  wt.m=cbind(dum.m,dum.f[,c(9,11,12,22)])
  wt.m$fm83=money[,1]
  wt.m$fm233=money[,2]
  
  ## 14 series from dum.m
  clist=c(2:5,7,8,10,11,13,14)
  for (j in clist){
    wt.m[,j]=detrend(log(dum.m[,j]),2)
  }
  
  wt.m[,6]=detrend(dum.m[,6],0)
  wt.m[,9]=detrend(dum.m[,9],1)
  wt.m[,12]=detrend(log(dum.m[,12]),1)
  
  
  
  for (j in (15:18)) {
    good=which(is.na(wt.m[,j])==FALSE)
    wt.m[good,j]=detrend(log(wt.m[good,j]),1);
  }
  
  
  
  wt.m=cbind(wt.m)
  wt.m$week=week(wt.m$date)
  wt.m$year=year(wt.m$date)
  wt.m$day=day(wt.m$date)
  wt.m$month=month(wt.m$date)
  wt.m$weekinmonth= ceiling(as.numeric(format(wt.m$date,"%d"))/7)
  wt.m$CFNAI=NaN
  
  dt.cal=data.frame(wt.m$year,wt.m$month,wt.m$week)
  
  datem=seq(as.Date('1960/7/1'),as.Date('2021/06/1'),by='month',format="y%m%d")
  dumCFNAI=read.csv(infile5);
  datecfnai=seq(as.Date('1967/3/1'),as.Date('2022/4/1'),by='month',format="y%m%d")
  
  
  
  mt = dumCFNAI
  mt$week=week(mt$DATE)
  mt$year=year(mt$DATE)
  mt$month=month(mt$DATE)
  
  weekinmonth=4 #change month to target
  
  wt.m$CFNAI=NaN
  for (t in (1:nrow(mt))) {
    YY=mt$year[t]
    WW=weekinmonth
    MM=mt$month[t]
    n=which((wt.m$year==YY) & (wt.m$month==MM) &(wt.m$weekinmonth==WW))
    wt.m$CFNAI[n]=mt$CFNAI[t]
  }    
  
  
  print(dim(wt.m))
  dt=wt.m
  dt$year=NULL
  dt$weekinmonth=NULL
  dt$day=NULL
  dt$week=NULL
  dt$date=NULL
  dt$month=NULL
  ## dt is the weekly data matrix
  print(dim(wt.m))
  out=list()
  out$dt=dt
  out$date=wt.m$date
  out$cal=dt.cal
  return(out)
}


# This function projects out a trend (and trend^2 if degree = 2)
detrend<-function(yy,degree){
  good=which(is.na(yy)==0)
  bad=which(is.na(yy)==1)
  y=yy[good]
  n=length(y)
  trend=1:n
  trend2=trend*trend
  c=rep(1,n)
  if (degree==0)     out=lm(y~c)
  if (degree==1)     out=lm(y~c+trend)
  if (degree==2)     out=lm(y~c+trend+trend2)
  
  e=rep(NA,length(yy))
  e[good]=resid(out)
  return(e)
}    



out=preparedata()
dt=out$dt
date=out$date
dt.cal=out$cal
T0=nrow(dt)

data.table::fwrite(dt,file="data/wrds/MWlf.csv")


