%% makeCFNAIfigs()
% This function creates figures 4 and 5 and saves them to the figures/out
% folder.

% Authors: Serena Ng (serena.ng@columbia.edu), Susannah Scanlan (ss5605@columbia.edu)

function makeCFNAIfigs(Stock,Im,datesIn,mpoints,tpoints)
gray=[.7 .7 .7];
col_tp = [0.64,0.08,0.18];
col_tps = [1 0.410 0.16];
mark_tp = "+";
mark_tps = "square";

col_kss = [0.1, 1, 1];
col_ks = 'b';
mark_ks = "*";
mark_kss = "o";

dates = n2dDates(datesIn);

tp = Stock(tpoints,1);
tps = Stock(tpoints,4);
ks = Stock(tpoints,6);
kss = Stock(tpoints,8);

% Static vs. dynamic factors: Weekly data

% First plot: TP vs. TP*
figure
bar(dates(mpoints),Im(mpoints),'FaceColor',gray);
hold on;
plot(dates(tpoints),tp,'Color',col_tp,'Marker',mark_tp,'MarkerSize',3,'MarkerFaceColor',col_tp,'LineStyle','None');
plot(dates(tpoints),tps,'Color',col_tps,'Marker',mark_tps,'MarkerSize',3,'MarkerFaceColor',col_tps,'LineStyle','None');
[h,icons] = legend({'Data','TP','TP^*'},'Location','northeast','FontSize',16);
legend boxoff 
hold off
% Find the 'line' objects
icons = findobj(icons,'Type','line');
% Find lines that use a marker
icons = findobj(icons,'Marker','none','-xor');
% Resize the marker in the legend
set(icons,'MarkerSize',8);

a = get(gca,'XTickLabel');
set(gca,'XTickLabel',a,'FontSize',14)
set(gca,'XTickLabelMode','auto')

ylabel('Chicago Fed National Activity Index, Actual and Imputed','FontSize',14)

ylim([-3,2])
yticks([-3:1:2])
print('out/fig4a','-dpng');


% Second plot: KS vs. KS*
bar(dates(mpoints),Im(mpoints),'FaceColor',gray);
hold on;
plot(dates(tpoints),ks,'Color',col_ks,'Marker',mark_ks,'MarkerSize',3,'MarkerFaceColor',col_ks,'LineStyle','None');
plot(dates(tpoints),kss,'Color',col_kss,'Marker',mark_kss,'MarkerSize',3,'MarkerFaceColor',col_kss,'LineStyle','None');
[h,icons] = legend({'Data','KS','KS^*'},'Location','northeast','FontSize',16);
legend boxoff 
hold off
% Find the 'line' objects
icons = findobj(icons,'Type','line');
% Find lines that use a marker
icons = findobj(icons,'Marker','none','-xor');
% Resize the marker in the legend
set(icons,'MarkerSize',8);

a = get(gca,'XTickLabel');
set(gca,'XTickLabel',a,'FontSize',14)
set(gca,'XTickLabelMode','auto')
ylabel('Chicago Fed National Activity Index, Actual and Imputed','FontSize',14)

ylim([-3,2])
yticks([-3:1:2])
print('out/fig4b','-dpng');


mpDates = dates(mpoints);
tpDates = dates(tpoints);

mIm = Im(mpoints);
pTPs =Stock(tpoints,4);
pKSs = Stock(tpoints,8);
yWind = 5;

count = 0;
for yy = 1995:yWind:2020
    count = count+1;
    indM = find((year(mpDates) < yy).*(year(mpDates) >= yy - yWind) == 1);
    indT = find((year(tpDates) < yy).*(year(tpDates) >= yy - yWind) == 1);
end


indM = find((year(mpDates) < 2020).*(year(mpDates) >= 2011) == 1);
indT = find((year(tpDates) < 2020).*(year(tpDates) >= 2011) == 1);

figure

bar(mpDates(indM),mIm(indM),'FaceColor',gray);
hold on;
plot(tpDates(indT),pTPs(indT),'Color',col_tps,'Marker',mark_tps,'MarkerFaceColor',col_tps,'MarkerSize',10,'LineStyle','None');
hold off;
lgd = legend({'Data','TP^*'}, 'Location','southwest','FontSize',16,'Box','on');
lgd.NumColumns = 3;
legend boxoff 
title(['TP^* Years: 2011-2019'],'FontSize',20);
xticks
a = get(gca,'XTickLabel');
set(gca,'XTickLabel',a,'FontSize',14);
set(gca,'XTickLabelMode','auto');
ylabel('Chicago Fed National Activity Index, Actual and Imputed','FontSize',14)
ylim([-1,1])

print(['out/fig5'],'-dpng'); 


