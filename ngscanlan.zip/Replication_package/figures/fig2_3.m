%% fig2_3.m
% This code generates Figures 2, 3, which are saved in figures/out

%Inputs: tables/out/pltdata.mat
%Outputs: out/fig2.png, out/fig3a.png, out/fig3b.png

% Authors: Serena Ng (serena.ng@columbia.edu), Susannah Scanlan (ss5605@columbia.edu)

% Note: This script should be run from the /figures folder.


clear;
load ../tables/out/pltdata;

gray=[.7 .7 .7];
col_tp = [0.64,0.08,0.18];
col_tps = [1 0.410 0.16];

mark_tp = "+";
mark_tps = "square";

col_kss = [0.1, 1, 1];
col_ks = 'b';
mark_ks = "*";
mark_kss = "o";

% Figure 2
figure(2);
bar(dates(mpoints),Iw.true(mpoints),'FaceColor',gray);
hold on;
plot(dates(tpoints),Stock(tpoints,4),'Color',col_ks,'Marker',mark_ks,'MarkerSize',5,'MarkerFaceColor',col_ks,'LineStyle','None');
hold on;
plot(dates(tpoints),Stock(tpoints,2),'Color',col_tp,'Marker',mark_tp,'MarkerSize',6,'MarkerFaceColor',col_tp,'LineStyle','None');
hold on;
[h,icons] =legend({'Data','KS','TP'},'Location','northeast','FontSize',10); %,'EM'
icons = findobj(icons,'Type','line');
icons = findobj(icons,'Marker','none','-xor');
set(icons,'MarkerSize',6);
legend boxoff;
axis([1978+delay/12 2020 -3.5 2.5]);
%a = get(gca,'XTickLabel');
%set(gca,'XTickLabel',a,'FontSize',14)
ylabel('Normalized Consumer Confidence, Actual and Imputed','FontSize',10)
ylim([-3,3])
print('out/fig2','-dpng');


%% Figure 3 top (a) and bottom (b) panels

% Figure 3a
figure(31);
bar(dates(mpoints),Iw.true(mpoints),'FaceColor',gray);
hold on;
plot(dates(tpoints),Stock(tpoints,1),'Color',col_tp,'Marker',mark_tp,'MarkerSize',4,'MarkerFaceColor',col_tp,'LineStyle','None');
hold on;
plot(dates(tpoints),Stock(tpoints,5),'Color',col_tps,'Marker',mark_tps,'MarkerSize',3,'MarkerFaceColor',col_tps,'LineStyle','None');
hold off;
[h,icons] = legend({'Data','TP','TP^*'}, 'Location','northeast', 'FontSize',10);
icons = findobj(icons,'Type','line');
icons = findobj(icons,'Marker','none','-xor');
set(icons,'MarkerSize',6);
legend boxoff;
axis([1978+delay/12 2020 -3.5 2.5]);
%a = get(gca,'XTickLabel');
%set(gca,'XTickLabel',a,'FontSize',12)
ylabel('Normalized Consumer Confidence, Actual and Imputed','FontSize',10)
ylim([-3,3])
print('out/fig3a','-dpng');



% Figure 3b
figure(32);
bar(dates(mpoints),Iw.true(mpoints),'FaceColor',gray);
hold on;
plot(dates(tpoints),Stock(tpoints,4),'Color',col_ks,'Marker',mark_ks,'MarkerSize',4,'MarkerFaceColor',col_ks,'LineStyle','None');
hold on;
plot(dates(tpoints),Stock(tpoints,8),'Color',col_kss,'Marker',mark_kss,'MarkerSize',3,'MarkerFaceColor',col_kss,'LineStyle','None');
hold off;
[h,icons] = legend({'Data','KS','KS^*'}, 'Location','northeast','FontSize',10);
icons = findobj(icons,'Type','line');
icons = findobj(icons,'Marker','none','-xor');
set(icons,'MarkerSize',6);
legend boxoff;
axis([1978+delay/12 2020 -3.5 2.5]);
%a = get(gca,'XTickLabel');
%set(gca,'XTickLabel',a,'FontSize',14)
ylabel('Normalized Consumer Confidence, Actual and Imputed','FontSize',10)
ylim([-3,3])
print('out/fig3b','-dpng');




