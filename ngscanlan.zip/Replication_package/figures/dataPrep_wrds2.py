#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Fri Jul  2 16:46:06 2021

@author: Susannah Scanlan, ss5605@columbia.edu

This script takes the output from "dataPrep_wrds1.py" and produces level and differenced data. 
"""

# Directory should be f4_f5

import numpy as np
import pandas as pd
from pandas import Series


df_raw = pd.read_csv('data/wrds/data_out_all_raw.csv')


def aggregate(dataset,window = 7):
    agg = list()
    for ii in range(0,len(dataset),window):
        value = dataset[ii:ii+window]
        if all(pd.isna(value)):
            agg.append(np.nan)            
        else:
            agg.append(value.sum(axis=0))
    return pd.DataFrame(agg)



date = Series('Transform:')
date = date._append(df_raw.date.iloc[::7])
df_week = pd.DataFrame(index = date)
raw_col_names = df_raw.columns

for jj in range(1,df_raw.shape[1]):
    tmpCode = 1
    dataIn = df_raw[raw_col_names[jj]]
    tmpAgg = aggregate(dataIn)
    tmpDat = pd.DataFrame([tmpCode])
    tmpDat = tmpDat._append(tmpAgg)    
    tmpDat.set_index(date)
    df_week = pd.merge(df_week,tmpDat,'outer',on=date)
    df_week = df_week.rename(columns = {"key_0":"date"})
    df_week = df_week.set_index(date)
    df_week = df_week.drop(['date'],axis=1)
    df_week = df_week.rename(columns={0: raw_col_names[jj]})
     
               
wDatReal = df_week[["eleout",	"rawste",	"rttotc",	"rtc1in",	"rigcou",	"uiinit",	"uicont",	"redboo",	"wtioil",	"crbcom",	"altot1",	"indmar",	"usfuel"]]
wDatReal.to_csv('data/wrds/wDatRealLev.csv',index='date')


wDatFin = df_week[["fm1",	"fm2",	"fmscu",	"fmrra",	"fmrnba",	"fclnbw",	"fclbmc",	"ccinrv",	"fyff",	"cp90",	"fygm3",	"fygm6",	"fygt1",	"fygt5",	"fygt10",	"exrus",	"exrsw",	"exrjan",	"exruk",	"exrcan",	"fspcom",	"fspin"]]
wDatFin.to_csv('data/wrds/wDatFinLev.csv',index='date')














