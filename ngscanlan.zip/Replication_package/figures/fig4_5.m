%% fig4_5.m
% This code generates Figures 4, 5. Figures 4 and 5 show the imputed
% values of the CFNAI. It references the function "makeCFNAIfigs.m"

% Note that the labels on Figure 5 were inputted by hand and are not
% generated using this code. This code generates the data underlying Figure
% 5 only.

%Inputs: data/WEI.csv, data/MWlf.csv, data/wrds/wDatRealLev.csv
%Outputs: fig4a.png, fig4b.png, fig5.png

% Authors: Serena Ng (serena.ng@columbia.edu), Susannah Scanlan (ss5605@columbia.edu)

% Note: This script should be run from the /figures folder.


clear;
close all;
addpath('../functions')

%% Importing weekly data
dum=importdata("data/wrds/MWlf.csv");
X0.dum=dum.data(1:1566,:);
series=dum.textdata(1,:);


% Replacing train series with the log change in the level data (as opposed
% to the detrended series from data/MWlf.csv.
dumLev=importdata("data/wrds/wDatRealLev.csv");
tmpRail = log(dumLev.data(2:end,3:4)) - lagmatrix(log(dumLev.data(2:end,3:4)),1);
tmpRail(2,:) = nan;

X0.dum(:,3:4) = tmpRail(1:1566,:);

Npick=1:cols(X0.dum);
Tpick=1:rows(X0.dum);
nlags=3;
r=3;
p=0;
q=0;
dt0=X0.dum(Tpick,Npick);
%loc.F=cols(dt0)-3;
%loc.U=cols(dt0)-2;
%loc.CS=cols(dt0)-1;
loc.CFNAI=cols(dt0);
base=dt0(:,1:loc.CFNAI-1);
names=series(1:loc.CFNAI-1);


dt1=base;
for i=1:nlags;
    dt1=[dt1 lagn(base,i)];
    names=[names series(1:loc.CFNAI-1)];
end;
dt1=[dt1 dt0(:,loc.CFNAI)];
names=[names series(loc.CFNAI)];
dt1=trimr(dt1,nlags,0);

mpoints0=find(isnan(dt1(:,end))==0); 
tpoints0=find(isnan(dt1(:,end))==1); 

date=(datetime(1990,1,1):calweeks(1):datetime(2019,12,30))';
date=trimr(date,nlags,0);
Month=month(date);
Year=year(date);
Week=week(date);
dates=(1:1:length(date))';

Years=unique(Year);
WeekinMonth=zeros(length(Year),1);

for t=1:length(Years);
     yy=find(Year==Years(t));
     dates(yy)=Year(yy)+Week(yy)/max(Week(yy));
     for mm=1:12;
         mm=find(Year==Years(t) & Month==mm);
     WeekinMonth(mm)=round(length(mm));
     end;
end;

%% CFNAI is observed last week of the month
for tt=1:length(mpoints0);
    t=mpoints0(tt);
    if Month(t)==Month(t+1);
        dt1(t+1,end)=dt1(t,end);
        dt1(t,end)=NaN;
    end;
end;    
mpoints=find(isnan(dt1(:,end))==0); 
tpoints=find(isnan(dt1(:,end))==1); 

[T,N]= size(dt1);
mu.X0=nanmean(dt1);
sd.X0=nanstd(dt1);

dt1_std=(dt1-repmat(mu.X0,T,1))./repmat(sd.X0,T,1);


Im_std=dt1_std(:,end);
Im=Im_std*sd.X0(end)+mu.X0(end);


missing=isnan(dt1_std);
missn=sum(missing==0);
n=cols(dt1_std);
TP0=do_fbiTP(dt1_std,r,missing,2,'decomp',missing);
IwS{1}=TP0.data(:,end);

%% chow-lin
CL=do_ChowLin(dt1_std(:,end),TP0.Fhat);
IwS{9}=CL.Yhat3;


%% SW
[~,SW.Fhat,SW.Lamhat,ve1,x21]=factors_em(dt1_std,r,2,0);
SW.Chat=SW.Fhat*SW.Lamhat';
IwS{2}=dt1_std(:,end);
IwS{2}(tpoints)=SW.Chat(tpoints,end);


%% TP*
dt2_std=standard(TP0.data(:,1:end-1));


inity=[];
for mtt=1:length(mpoints);
    t=mpoints(mtt);    
    YY=year(date(t));
    MM=month(date(t));
    mm=find((Year==YY) & (Month==MM));
    inity(mm,1)=dt1_std(t,end);
end;

nlagsF=1;
nlagsY=1;
[newy.TP1,beta.TP1,tstat.TP1]=iterStock(inity,TP0.Fhat,nlagsF,nlagsY,mpoints,tpoints,'TP1');
IwS{4}=newy.TP1;
[newy.TP1,beta.TP1,tstat.TP1]=iterStock(inity,TP0.Fhat,0,0,mpoints,tpoints,'TP1');
TP1.IwSF0Y0=newy.TP1;
[newy.TP1,beta.TP1,tstat.TP1]=iterStock(inity,TP0.Fhat,1,0,mpoints,tpoints,'TP1');
TP1.IwSF1Y0=newy.TP1;
[newy.TP1,beta.TP1,tstat.TP1]=iterStock(inity,TP0.Fhat,0,1,mpoints,tpoints,'TP1');
TP1.IwSF0Y1=newy.TP1;
IwTP1=[TP1.IwSF0Y0 TP1.IwSF1Y0 TP1.IwSF0Y1 IwS{4}];

%% Barigozzi-Luciani
p=1;
[KS,PCA]=BL_Estimate(dt2_std,r,r,p,50,1e-4,0);
KS.Fhat=KS.F;
[newy.KS,beta.KS,tstat.KS]=iterStock(inity,KS.Fhat,0,0,mpoints,tpoints,'KS');
KS.IwSF0Y0=newy.KS;
[newy.KS,beta.KS,tstat.KS]=iterStock(inity,KS.Fhat,1,0,mpoints,tpoints,'KS');
KS.IwSF1Y0=newy.KS;
[newy.KS,beta.KS,tstat.KS]=iterStock(inity,KS.Fhat,0,1,mpoints,tpoints,'KS');
KS.IwSF0Y1=newy.KS;
[newy.KS,beta.KS,tstat.KS]=iterStock(inity,KS.Fhat,nlagsF,nlagsY,mpoints,tpoints,'KS');
IwS{6}= KS.IwSF1Y0;
IwKS=[KS.IwSF0Y0 KS.IwSF1Y0 KS.IwSF0Y1 IwS{6}];


%% KS*
xks = x21;
xks(:,end) = dt1_std(:,end);
[KSM,~]=genKSM(xks,r,r,p,50,1e-4,0,1);
KSs.Fhat = KSM.F(:,1:r);
KSs.KS = KSM.chi(:,end);
IwS{8}=KSs.KS;

p=0;q=1;
[MLE0,AA0,GG0]=do_FAbyQMLE(dt2_std,r,p,q,TP0.cov(1:end-1,1:end-1),[],[]);
MLE0.Fhat=MLE0.Fgls;
[newy.MLE0,beta.MLE0,tstat.MLE0]=iterStock(inity,MLE0.Fhat,0,0,mpoints,tpoints,'MLE');
IwS{3}=newy.MLE0;

[newy.MLE1,beta.MLE1,tstat.MLE1]=iterStock(inity,MLE0.Fhat,nlagsF,nlagsY,mpoints,tpoints,'MLE');
IwS{5}=newy.MLE1;

[PCgls.Fhat,PCgls.Lamhat,PCgls.iter]=PCGLS_iter(dt2_std,r,2);
[newy.PCgls,beta.PCgls,tstat.PCgls]=iterStock(inity,PCgls.Fhat,nlagsF,nlagsY,mpoints,tpoints,'PCgls');
IwS{7}=newy.PCgls;


STOCK=[cell2mat(IwS) ]*sd.X0(end)+mu.X0(end);

varnames{1}="TP";
varnames{2}="SW";
varnames{3}="MLE-h";
varnames{4}="TP*";
varnames{5}='MLE';
varnames{6}="KS";
varnames{7}="pcGLS*";
varnames{8}="KS*";
varnames{9}="Chow-Lin";


Im_std=dt1_std(:,end);
Im=Im_std*sd.X0(end)+mu.X0(end);
makeCFNAIfigs(STOCK,Im,dates,mpoints,tpoints)



