#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Wed May 19 17:39:03 2021

@author: Susannah Scanlan, ss5605@columbia.edu

This script imports WRDS data and EIA for weekly imputation of the CFNAI.
"""


import os
# Put your working directory to 
os.chdir('Your Directory Here')

import pandas as pd
import wrds
import requests



db = wrds.Connection(wrds_username='Your WRDS Username here')


parm = {'var_names':('W_110150171', 'W_14584699', 'W_17358952', 'W_110151114',
        'W_135554502', 'W_14586913', 'W_14586914', 'W_14587618',
        'W_15183685', 'W_115034346', 'W_14585988',
        'W_12736746', 'W_110150111', 'W_110150112', 'W_110150114',
        'W_117959458', 'W_110150194', 'W_110150195', 'W_161219995',
        'W_161220187', 'W_161220098', 'W_110150192', 'W_15361092',
        'W_14388434', 'W_14388435', 'W_14388939', 'W_14388942',
        'W_14388944', 'W_15291400', 'W_14388605', 'W_14388603',
        'W_14388606', 'W_14388602', 'W_14388953', 'W_14389036')}



# This command pulls in the desired data.
df = db.raw_sql("SELECT series_name,datavalue,date FROM ginsight.series_data WHERE series_name in %(var_names)s AND date >= '1990-01-01';",  params=parm,  date_cols =['date'])


db.close()

# Reformatting the data and changing the names to mneumonics
## Importing csv file
mneuMatch = pd.read_csv('data/mneuMatch.csv')

mneuMatch = mneuMatch.set_index('wrds')


def translate(var):
    return mneuMatch.loc[var,'mneu']


df.mapping([('series_name', 'translated', translate)], inplace=True).mapped

df_wrds = df.pivot(index='date',columns='translated',values='datavalue')


## Making a specific datetime frame
import datetime
startDate = datetime.datetime(1990, 1, 1)
startDate2 = datetime.date(1990,1,1)
endDate = datetime.datetime.today()
delta = endDate - startDate

dateList = []
dateList2 = []
for x in range (0, delta.days):
    dateList.append(startDate + datetime.timedelta(days = x))
    dateList2.append(startDate2 + datetime.timedelta(days = x))
from pandas import DataFrame

df_date = DataFrame (dateList, columns = ['date'])
df_merge1 = pd.merge(df_date,df_wrds,how = 'outer',on='date')


## Downloading eia data (US Product Supplied of Petroleum Products) directly from website
XLS_URL = 'https://www.eia.gov/dnav/pet/hist_xls/WRPUPUS2w.xls'
req = requests.get(XLS_URL)
url_content = req.content
xls_file = open('eia.xls', 'wb')
xls_file.write(url_content)
xls_file.close()


df_eia = pd.read_excel('eia.xls',sheet_name='Data 1',skiprows=(0,1))
df_eia  = df_eia.rename(columns ={"Date":"date","Weekly U.S. Product Supplied of Petroleum Products  (Thousand Barrels per Day)":"usfuel"})
df_eia = df_eia.set_index('date')
df_merge2 = pd.merge(df_merge1,df_eia,how='outer',on = 'date')
df_merge2 = df_merge2.set_index('date')
df_merge2.to_csv('/data/wrds/data_out_all_raw.csv',index='dates')









