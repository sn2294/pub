function self = all_cov(Chat, ehat, missing)
% Calculates systematic, idiosyncratic and total covariance matrices
% given common component (Chat), idiosyncratic component (egat) and the missingness
% structure (missing)

  % Systematic Covariance
  self.sys_cov = cov(Chat);
    
  % Idiosyncratic Covariance (ues only the available values
  N = size(Chat,2);
  idio_var = zeros(N,1);
  for g = 1:N
    mg = missing(:,g);
    use_ehat_g = ehat(mg == 0,g);
    idio_var(g) = var(use_ehat_g);
  end
  self.idio_cov = diag(idio_var);
    
  % Total Covariance
  self.cov = self.sys_cov + self.idio_cov;
  
end