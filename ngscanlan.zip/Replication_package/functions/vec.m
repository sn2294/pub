function y=vec(X) 
y=X(:);
