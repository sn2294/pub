function [xsim,xdata,fsim]=genr_dfmdata(Tsim,N,r,p,q,...
                                   A0,Sig2uF,rho,Sig2eps,L0,missing,it);

randn('state',123+it);
rand('state',456-it);
Sig.F=chol(Sig2uF);
e.F=randn(Tsim,r)*Sig.F;
e.F=demean(e.F)';


fsim=e.F*0;
fsim(:,1)=e.F(:,1);
fsim(:,2)=A0{1}(1:r,1:r)*fsim(:,1)+e.F(:,2);
for t=3:Tsim;
    fsim(:,t)=A0{1}(1:r,1:r)*fsim(:,t-1)+e.F(:,t);
    if p==2;
        fsim(:,t)=fsim(:,t)+A0{2}(1:r,1:r)*fsim(:,t-2);
        end;
end;
fsim=fsim';


Sig.eps=diag(sqrt(Sig2eps));
eps=randn(Tsim,N)*Sig.eps;
esim=eps;
for t=2:Tsim;
    esim(t,:)=esim(t-1,:).*rho'+eps(t,:);
end;    


esim=demean(esim);
Lsim=L0;
Csim=fsim*Lsim';
xdata=fsim*Lsim'+esim;
xsim=xdata;
xsim(missing(1:Tsim,:))=NaN;


