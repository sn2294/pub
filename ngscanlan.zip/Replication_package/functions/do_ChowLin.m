function self=do_ChowLin(zz,x);

[T,K]=size(x);
mpoints=find(~isnan(zz));
tpoints=find(isnan(zz));
y=zz(:,end);
y(tpoints)=0;


TT.H=T; 
TT.L=length(mpoints);
C=zeros(TT.L,TT.H);
    for t=1:TT.L;
        C(t,mpoints(t))=1;
    end;    

    reg=[ones(TT.H,1)  x  ];

    Reg=C*reg;
    Y=C*y;

    out2=nwest(Y,Reg,0);  %% OLS

    hat.e=out2.resid;
    out3=nwest(hat.e(2:end),[ones(TT.L-1,1) hat.e(1:TT.L-1,1)],0);
    hat.rho=out3.beta(2);
    Vvec2=1;
    Vvec3=1;
    for t=2:TT.H;
        Vvec2=[Vvec2 0];
        Vvec3=[Vvec3 hat.rho^(t-1)];
    end;
    Vhat2.H=toeplitz(Vvec2);
    Vhat3.H=toeplitz(Vvec3);
    Vhat2.L=C*Vhat2.H*C';
    Vhat3.L=C*Vhat3.H*C';
    hat.gls2=inv(Reg'*inv(Vhat2.L)*Reg)*Reg'*inv(Vhat2.L)*Y;
    hat.gls3=inv(Reg'*inv(Vhat3.L)*Reg)*Reg'*inv(Vhat3.L)*Y;
    adj2=Vhat2.H*C'*inv(C*Vhat2.H*C')*hat.e;
    adj3=Vhat3.H*C'*inv(C*Vhat3.H*C')*hat.e;
    adj2=zeros(TT.H,1);
    adj2(mpoints)=hat.e;
    self.Yhat2=reg*hat.gls2+adj2;
    self.Yhat3=reg*hat.gls3+adj3;


    	

