function [gls,check]=get_apcglsh(z,Fhat,Lhat,it0);
% GLS estimates of factors and loadings, only controls for
% heteroskedasticity (not serial correlation)
%
% Follows method from:
% "GLS Estimation of Dynamic Factor Models" by Jörg Breitung and Jörn Tenhofen
% Journal of the American Statistical Association, 106(495): 1150-1166

[T,N]=size(z);
r=cols(Fhat);
ehat=z-Fhat*Lhat';
phi2= std(ehat).^2;
iSig=inv(diag(phi2));
old.rho=zeros(N,1);
old.f=Fhat;
old.l=Lhat;
old.phi2=phi2;
old.rho=zeros(N,1);
old.iSig=iSig;
old.ee=ehat;
old.c=old.f*old.l';
new.rho=zeros(N,1);
new.l=zeros(N,r);

done=0;
gls.Fhat=ones(T,r)*NaN;
gls.Lhat=ones(N,r)*NaN;
gls.flag=0;
it=1;
maxit=1000;
one=ones(T-1,1);
while done ==0 && it <=maxit;
for i=1:N;
    reg=old.f(2:end,:) ;
    dum=reg\z(2:end,i);
    new.l(i,:)=dum(1:r);
end;
    [qq,rr]=qr(new.l(1:r,1:r)');
    new.l=new.l*qq;
    new.f=z*old.iSig*new.l*inv(new.l'*old.iSig*new.l);
    new.c=new.f*new.l';
    new.ee=z-new.c;
    new.phi2=std(new.ee).^2;
    toosmall=find(new.phi2< 0.001);
    check.f=norm(new.f-old.f);
    check.l=norm(new.l-old.l);
    check.p=norm(new.phi2-old.phi2)/norm(old.phi2);
    check.c=norm(new.c-old.c)/norm(old.c);
    check.min=min(new.phi2);
    %      mymprint([it checkc checkr checkp]);
    if (check.c < 1e-3)  || it==it0;
        done=1;
        gls.flag=1;
        %     disp(sprintf('apcgls converged in %d iterations',it));
    else;
        old.l=new.l;
        old.f=new.f;
        old.phi2=new.phi2;;
        %        old.phi2(toosmall)=new.phi2(toosmall)+0.001;
        old.c=new.c;
        old.iSig=inv(diag(new.phi2));
        it=it+1;
    end;    
end;

if done==1;
    yhat = old.f*old.l';            % Impose B&N normalization
    Sig  =(yhat*yhat')/N;
    [evec,eval] = eigs(Sig); 
    gls.Fhat=evec(:,1:r);
    gls.Lhat=z'*gls.Fhat;
    ee=z-gls.Fhat*gls.Lhat';
    gls.phi2=std(ee).^2;
else;
    disp(sprintf('apcglsh failed to converge in iteration, %5d %7.5f %7.5f %7.5f %d',...
                 it0,check.c,check.p,min(new.phi2),length(toosmall)));
end;