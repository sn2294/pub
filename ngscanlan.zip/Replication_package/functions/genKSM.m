% BL_Estimate -  Estimate DFM with EM algorithm
% 
% [EM, PCA]=BL_Estimate(x,r,q,p,iter,tresh,s01)
% 
%  EM - Structure containing EM estimates
%  PCA - Structure containing PCA estimate
%  x - data
%  r - number of factors
%  q - number of shocks
%  p - number of lags in the VAR, note that code only works for p = 1
%  (After adjustments made by Scanlan)
%
%  iter - number of iterations EM
%  tresh - threshold for stopping rule EM 
%  s01 - s01== 1 --> standardize the data prior to estimation
% 
% REFERENCE:  "Quasi Maximum Likelihood Estimation and Inference of 
%   Large Approximate Dynamic Factor Models via the EM algorithm" 
%   arXiv:1910.03821vXXX, 2021, by Matteo Barigozzi and Matteo Luciani
%
% Originally Written by Matteo Luciani (matteoluciani@yahoo.it)
%
% Modified by Susannah Scanlan (ss5605@columbia.edu)
%
% References for modifications: B. Jungbacker, S.J. Koopman, and M. van der 
% Wel. 2011. "Maximum likelihood estimation for dynamic
% factor models with missing data". Journal of Economic Dynamics and
% Control.
%

function [EM, PCA]=genKSM(x,r,q,p,iter,tresh,s01,SC)

% SC is serial correlation indicator
% SC = 0, no serial correlation, no quasi differencing
% SC = 1, serial correlation, quasi differencing
% SC = 2, serial corerlation, no quasi differencing
% SC = 3, no serial correlation, quasi differencing
if nargin < 8
    SC = 1;
end

if p~=1
    error('The genKSM script only works for p=1')
end

[T,N]=size(x);
pr=p*r;


if s01==1                                                                   % Determines whether to standardize ...
    [xx,mx,sx]=ML_Standardize(x);                                           % ... the data prior to estimation ...
else                                                                        % 
    xx=x; mx=zeros(1,N); sx=ones(1,N);                                      % ... or not
end                                                                         %
MX=repmat(mx,T,1); SX=repmat(sx,T,1);                                       % Useful objects

%%% ======================================== %%%
%%% Adding indicator to locate missing values
%%% ======================================== %%%

% Assumption is that ONLY THE LAST COLUMN HAS MISSING DATA
indMiss = find(ismissing(xx(:,N)));
indThere = find(ismissing(xx(:,N)) == 0);


%%% ======================================== %%%
%%%  Estimate factors and loadings with PCA  %%%
%%% ======================================== %%%
Gamma=cov(xx);                                                        % covariance matrix of the standardize data

if isempty(indMiss) == 0
    xTmp = xx(indThere,:);
    tmpGam = cov(xTmp);
    Gamma(N,:) = tmpGam(N,:);
    Gamma(:,N) = tmpGam(:,N);
end

[W,M] = eigs(Gamma, r,'LM'); W=W*diag(sign(W(1,:))');                       % eigenvalue-eigenvectors
L0=W*sqrt(M);                                                               % estimate factor loadings
%f0=xx*W/sqrt(M);                                                   % estimate common factors
f0=xx(:,1:N-1)*W(1:N-1,:)/sqrt(M);
f0(indThere,:)=xx(indThere,:)*W/sqrt(M);

e0=xx-f0*L0'; % "residual" PCA
e0(indMiss,N) = 0; % filling in missing value error with 0;
[~, uu0,AL0]=ML_VAR(f0,p,0);                                                % VAR on the Static Factors
[~, G0]=ML_edynfactors2(uu0,q);                                             % Common Shocks
chi0=MX+(f0*L0').*SX;                                                       % common component PCA
xi0=x-chi0;                                                               % idiosyncratic component PCA

% Initial guess for rho
rho0 = zeros(N,1);

if SC == 0 || SC == 2
    for ii = 1:N-1
        rho0(ii,1) = regress(xi0(2:T,ii),xi0(1:T-1,ii));
    end
end

% Initial estimate for autoregression in u_N (edit)
[rhoN0,~,tmpRes] = regress(xi0(indThere(2:end),N),xi0(indThere(1:end-1),N));
if rhoN0 > 0
    rhoN = rhoN0^(1/4);
else
    rhoN = rhoN0;
end
qN = nanvar(tmpRes);

%%% ==================================== %%%
%%%  Expectation Maximization Algorithm  %%%
%%% ==================================== %%%
AL0b=cat(3,AL0,zeros(r,r));                                                 % add one lag to avoid computing PtTm
[F0a,lambda0a,A0a,P0a,Q0a,R0a]=ML_SS_DFM_I0(f0,L0,AL0b,G0,e0,N,p+1,r);            % State-Space representation

% Adjusting the initialization to account for serial correlation in last
% variable (edit)
F0 = [F0a;0];
P0 = zeros(2*r+1);
P0(1:2*r,1:2*r) = P0a;
P0(2*r+1,2*r+1) = 1;
A0 = zeros(2*r+1);
A0(1:2*r,1:2*r) = A0a;
A0(2*r+1,2*r+1) = rhoN;
R0 = R0a;
Q0 = zeros(2*r+1);
Q0(1:2*r,1:2*r) = Q0a;
Q0(2*r+1,2*r+1) = qN;
lambda0 = [zeros(size(lambda0a)),[zeros(N-1,1);1]];

if SC == 0 || SC == 3
    lambda0 = [zeros(size(lambda0a)),[zeros(N-1,1);0]];
end

lambda0(:,1:2*r) = lambda0a;
lambda0(:,r+1:2*r) = (-1)*diag(rho0)*lambda0(:,1:r);

[xitT,PtT1,~,~,~,~,A1,L1,R1,Q1,G1,rho]=...                                      % EM algorithm
    ML_efactorML4c3(xx,F0,P0,A0,lambda0,R0,Q0,rho0,r,q,p,iter,tresh,0,SC);          % ------------
PtT1=PtT1(1:pr,1:pr,:);A1=A1(1:pr,1:pr); Q1=Q1(1:pr,1:pr);                  % Eliminate the extra lag
f1=xitT;
L1=L1;
chi1=MX+(f1*L1').*SX; 
xi1=x-chi1;                                                                 % idiosyncratic component


%%% ==================== %%%
%%%  Saves coefficients  %%%
%%% ==================== %%%
PCA.F=f0;
PCA.Lambda=L0;
PCA.chi=chi0;
PCA.xi=xi0;
PCA.R=R0;
PCA.G=G0;
PCA.A=A0;
PCA.Q=Q0;
PCA.P=P0;

EM.F=f1;
EM.Lambda=L1;
EM.chi=chi1;
EM.xi=xi1;
EM.R=R1;
EM.G=G1;
EM.A=A1;
EM.Q=Q1;
EM.PtT=PtT1;
EM.xitT=xitT;
EM.rho = rho;
EM.y = xx;


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%  ML_SS_DFM_I0 - Build State-Space representation of stationary DFM
% 

function [F0,lambda0,A0,P0,Q0,R0]=ML_SS_DFM_I0(f0,L0,AL0,G0,xi0,N,p,r,IDEN)

if nargin <9; IDEN=1; end 
pr=p*r;
Q0 = zeros(pr,pr); Q0(1:r,1:r)=G0*G0';                                      % Variance of the VAR residuals
lambda0 = [L0 zeros(N,r*(p-1))];                                            % Loadings
R0 = diag(diag(cov(xi0)));                                                  % covariance idio
F0=[]; for pp=1:p; F0=cat(1,F0,f0(p+1-pp,:)'); end                          % initial conditions factors
A0=ML_VAR_companion_matrix(AL0);                                            % VAR companion form aka VAR(1)

if IDEN==1; P0=eye(pr);                                                     % Impose initial variance = identity matrix
else; P0 = reshape(inv(eye(pr^2)-kron(A0,A0))*Q0(:),pr,pr);                 % initial variance
end


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% ML_efactorML4c - ML estimation I0 DFM, straight EM no initialization, P00=I (for simulations)
% 
% [xitT,PtT,PtTm,xitt,xittm,Ptt,Pttm,A,Lambda,R,Q]=...
%     ML_efactorML4(y,F0,P0,A,Lambda,R,Q,q,p,maxiter,tresh,cc)% 
% 
%       Y - data with deterministic component
%      F0 - initial values for the states
%      P0 - initial variance for the states
%       A - VAR(1) for the states
%  Lambda - Loadings
%       R - covariance matrix errors
%       Q - covariance matrix shocks
%       r - number of factors
%       q - number of shocks
%       p - number of lags VAR factors
% maxiter - max number iterations
%   tresh - threshold for stopping algorithm
%      cc - # of obs eliminated before estimating parameters
% 


function [xitT,PtT,xitt,xittm,Ptt,Pttm,A,Lambda,R,Q,G,rho]=...
    ML_efactorML4c3(y,F0,P0,A,Lambda,R,Q,rho0,r,q,p,maxiter,tresh,cc,SC)

if nargin < 15
    SC = 1;
end

OPTS.disp = 0;
[T, N]=size(y);                                                             % size of the panel
pr=p*r; pr1=(p+1)*r;

indThere = find(ismissing(y(:,N)) == 0);

%%% =================== %%%
%%%  Start with E-Step  %%%
%%% =================== %%%
[xitt,xittm,Ptt,Pttm,loglik]=ML_KalmanFilter2(F0,P0,y,A,Lambda,R,Q);        % Kalman Filter
[xitT,PtT]=ML_KalmanSmoother3(y,A,xitt',xittm',Ptt,Pttm,Lambda,R);          % Kalman Smoother
F00=xitT(1,:)'; P00=eye(pr1+1);                                               % initial conditions  
F=xitT(:,1:r);                                                              % factors
loglik1=loglik;                                                             % likelihood

rho = rho0;

if SC == 0 || SC == 2
    rho = zeros(N,1);
end

for jj=1:maxiter         
    
    %%%% ======================== %%%%
    %%%% ====                ==== %%%%
    %%%% ====    M - Step    ==== %%%%
    %%%% ====                ==== %%%%
    %%%% ======================== %%%%
    
    %%% =========================== %%%
    %%% 1: Estimate factor Loadings %%%
    %%% =========================== %%%
    yy=ML_center(y)';                                                       % endogenous variables,     
    xx=ML_center(F)';                                                       % exogenous variables, aka the factors        
    Lhold = zeros(N,r);
    %num=zeros(N,r);                                          % preallocates
    for ii = 1:N-1
        den=zeros(r,r);
        num=zeros(1,r);
        for tt=cc+2:T  % ------------------------------------------------------ % \sum_{t=1}^T
        %num = num + yy(:,tt)*xx(:,tt)';                                         % y_t F_{t|T}'        
        %den=den+xx(:,tt)*xx(:,tt)'+PtT(1:r,1:r,tt);                         % F_{t|T}F_{t|T}'+P_{t|T}
        
        % Rewriting numerator and denominator to allow for autocorrelation
            num = num + (yy(ii,tt) - rho(ii,1)*yy(ii,tt-1))*(xx(:,tt)' - rho(ii,1)*xx(:,tt-1)');
            den=den + (xx(:,tt)*xx(:,tt)'+PtT(1:r,1:r,tt) - ...
                rho(ii,1)*(xx(:,tt-1)*xx(:,tt)'+ PtT(1:r,r+1:pr1,tt)) - ...
                rho(ii,1)*(xx(:,tt)*xx(:,tt-1)'+ PtT(1:r,r+1:pr1,tt))' +...
                rho(ii,1)^2*(xx(:,tt-1)*xx(:,tt-1)'+ PtT(1:r,1:r,tt-1)));
        end
        %L=num/den;
        Lhold(ii,:) = num/den;
    end
    
    % Estimating loadings for last variable.
    den=zeros(r,r);
    num=zeros(1,r);
    for tt = indThere'
        num = num + yy(N,tt)*xx(:,tt)';
        den=den+xx(:,tt)*xx(:,tt)'+PtT(1:r,1:r,tt);
    end
    Lhold(N,:) = num/den;
    %L=num/den;                                                              % factor loadings
    Lambda(1:N,1:r) = Lhold;                                                    % store factor loadings

    %%% ====================================== %%%
    %%% 1b: Estimate Autoregressive Parameters %%%
    %%% ====================================== %%%
    % Edits made by Susannah Scanlan
    rho = zeros(N,1);
    for ii = 1:N-1
        num = 0;
        den = 0;
        for tt = cc+2:T
            den = den + yy(ii,tt-1).^2 - 2*yy(ii,tt-1)*Lambda(ii,1:r)*xx(:,tt-1) ...
                + Lambda(ii,1:r)*(xx(:,tt-1)*xx(:,tt-1)' + PtT(1:r,1:r,tt-1))*Lambda(ii,1:r)';
            num = num + yy(ii,tt).*yy(ii,tt-1) - yy(ii,tt)*Lambda(ii,1:r)*xx(:,tt-1)...
                - yy(ii,tt-1)*Lambda(ii,1:r)*xx(:,tt) ...
                + Lambda(ii,1:r)*(xx(:,tt)*xx(:,tt-1)' + PtT(1:r,r+1:pr1,tt-1))*Lambda(ii,1:r)';
        end
        rho(ii,1) = num/den;
    end
    if SC == 0 || SC == 2
        rho = zeros(N,1);
    end
    
    %%% ======================================================= %%%
    %%% 2: Estimate parameters for law of motion of the Factors %%%
    %%% ======================================================= %%%  
    yy=cat(2,zeros(r,1),F(2:T,:)');                                         % F_t
    xx=cat(2,ML_lag(xitT(:,1:pr),1)',zeros(pr,1));                          % F_{t-1}
    EF1=zeros(r,pr); EF1F1=zeros(pr,pr); EF=zeros(r,r);                     % initialize
    for tt=cc+2:T  % ------------------------------------------------------ % \sum_{t=1}^T
        EF1=EF1+yy(:,tt)*xx(:,tt-1)'+PtT(1:r,r+1:pr1,tt);                   % E(F_t F_{t-1})
        EF1F1=EF1F1+xx(:,tt-1)*xx(:,tt-1)'+PtT(1:pr,1:pr,tt-1);             % E(F_{t-1} F_{t-1})
        EF=EF+yy(:,tt)*yy(:,tt)'+PtT(1:r,1:r,tt);                           % E(F_t F_t)
    end   
    
    A(1:r,1:pr)=EF1/EF1F1;                                                  % parameter VAR factors        
    Q(1:r,1:r) = (EF - A(1:r,1:pr)*EF1') / (T-cc);                          % covariance
    if r>q; [P,M] = eigs(Q(1:r,1:r),q,'lm',OPTS); Q(1:r,1:r) = P*M*P'; end  % in case the factors are singular
    
    % Estimating new autocovariance of u_N
    % Edit by Susannah Scanlan
    tmpY = y(:,N);
    tmpE = (tmpY' - Lambda(N,1:r)*yy)';
    [tmpRho,~,tmpRes] = regress(tmpE(indThere(2:end,:)),tmpE(indThere(1:end-1,:)));
    if tmpRho > 0 %&& tmpRho < 1
        shareObs = sum(ismissing(y(:,N)) == 0)/(size(y(:,N),1));
        newRho = tmpRho^shareObs;
    else
        newRho = tmpRho; %A(2*r+1,2*r+1);
    end
    A(2*r+1,2*r+1) = newRho;
    Q(2*r+1,2*r+1) = nanvar(tmpRes);
    
    %%% ============================== %%%
    %%% 3: Covariance Prediction Error %%%
    %%% ============================== %%%
    %yy=y';
    %xx=xitT';
    %R=zeros(N,N);                                                           % preallocates
    %for tt=cc+1:T  % ------------------------------------------------------ % \sum_{t=1}^T
    %    eta=yy(:,tt)-Lambda*xx(:,tt);                                       % prediction error
    %    R = R+ eta*eta'+ Lambda*PtT(:,:,tt)*Lambda';                        % E(eta_t eta_t')
    %end
    %R = diag(diag(R/(T-cc)));
    
    % Rewriting the idiosyncratic covariance matrix to take into account serial
    % correlation
    yy=y';
    xx=xitT(:,1:r)';
    R=zeros(N,N);

    % Edits made by Susannah Scanlan
    for ii = 1:N-1
        lam_i = Lambda(ii,1:r);
        rHold = 0;
        for tt = cc+2:T
            y_star = yy(ii,tt) - rho(ii,1)*yy(ii,tt-1);
            rHold = rHold + y_star.^2 - 2*y_star*lam_i*xx(:,tt) ...
                + 2*rho(ii,1)*y_star*lam_i*xx(:,tt-1) ...
                + (1+rho(ii,1)^2)*lam_i*(xx(:,tt)*xx(:,tt)' + PtT(1:r,1:r,tt))*lam_i'...
                - 2*rho(ii,1)*lam_i*(xx(:,tt)*xx(:,tt-1)'+ PtT(1:r,r+1:pr1,tt-1))*lam_i';
        end
        R(ii,ii) = rHold/(T-cc-1);
    end
    
    rN = tmpRes'*tmpRes;
    tmpSum = 0;
    for tt = indThere'
        tmpSum = tmpSum + Lambda(N,1:r)*PtT(1:r,1:r,tt)*Lambda(N,1:r)';
    end
    R(N,N) = (rN+tmpSum)/length(indThere);
    
    if SC == 0 || SC == 3
        A(2*r+1,2*r+1) = 0;
        Q(2*r+1,2*r+1) = 0;
    end
    
    
    %%%% ======================== %%%%
    %%%% ====                ==== %%%%
    %%%% ====    E - Step    ==== %%%%
    %%%% ====                ==== %%%%
    %%%% ======================== %%%%
    
    
    %[xitt,xittm,Ptt,Pttm,loglik]=ML_KalmanFilter2(F00,P00,y,A,Lambda,R,Q);  % Kalman Filter
    %[xitT,PtT]=ML_KalmanSmoother3(y,A,xitt',xittm',Ptt,Pttm,Lambda,R);      % Kalman SMoother    
    % Adjusting the factor loadings and state space
    LambdaSC = Lambda;
    LambdaSC(:,r+1:2*r) = (-1)*diag(rho)*Lambda(:,1:r);
    ySC = zeros(size(y));
    ySC(2:T,1:N-1) = y(2:T,1:N-1) - y(1:T-1,1:N-1)*diag(rho(1:N-1,1));
    ySC(:,N) = y(:,N);
    
    Lambda = LambdaSC;
    
    [xitt,xittm,Ptt,Pttm,loglik]=ML_KalmanFilter2(F00,P00,ySC,A,Lambda,R,Q);

    [xitT,PtT]=ML_KalmanSmoother3(ySC,A,xitt',xittm',Ptt,Pttm,Lambda,R);      % Kalman SMoother
    F=xitT(:,1:r);                                                          % jj-th step factors            
    F00=xitT(1,:)'; P00=eye(pr1+1);                                           % initial conditions    
    %F00(end,1) = 0;
    
    %%%% ================================= %%%%
    %%%% ====                         ==== %%%%
    %%%% ====    Check convergence    ==== %%%%
    %%%% ====                         ==== %%%%
    %%%% ================================= %%%%
    delta_loglik = abs(loglik - loglik1);                                   % |logL(t) - logL(t-1)|
    avg_loglik = (abs(loglik) + abs(loglik1) + 10^(-3))/2;                  % avg = (|logL(t)| + |logL(t-1)|)/2
    if (delta_loglik / avg_loglik) < tresh; break; end                      % convergence if |f(t) - f(t-1)| / avg < threshold
    if jj>1; if loglik - loglik1<0; break; end; end                         % stop algorithm in case likelihood decrease 
    loglik1=loglik;                                                         % store log-likelihood    
end

if r>q; G = P*sqrt(M); else; G=eye(r); end 


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% ML_KalmanFilter2 - Kalman Filter Estimation of a Factor Model
% 
%  THE MODEL
% 
%   X_t = beta1 + beta2*t + C S_t + e_t,        e_t ~ N(0,R), R is diagonal
%   S_t = mu + A S_{t-1} + u_t,                 u_t ~ N(0,Q)
% 
%       S_t|X^{t-1} ~ N( S_{t|t-1} , P_{t|t-1} )
%       X_t|X^{t-1} ~ N( X_{t|t-1} , H_{t|t-1} )
% 
% 
%  THE PROCEDURE
% 
% [xitt,xittm,Ptt,Pttm,loglik]=ML_KalmanFilter(initx,initV,x,A,C,R,Q,mu,beta)
% 
% INPUTS:
%   x - the data
%   C - the observation matrix 
%   A - the system matrix
%   Q - the system covariance 
%   R - the observation covariance
%   initx - the initial state (column) vector 
%   initV - the initial state covariance 
%   mu   - constant in transition equation (optional)
%   beta - constant and linear trend in observation equation (optional)
% OUTPUTS:
%   xittm = S_{t|t-1}
%    Pttm = P_{t|t-1}
%    xitt = S_{t|t} 
%     Ptt = P_{t|t}
%  loglik = value of the log-likelihood
% 
% Matteo Luciani (matteoluciani@yahoo.it)

function [xitt,xittm,Ptt,Pttm,loglik]=ML_KalmanFilter2(initx,initV,x,A,C,R,Q,mu,beta)

%Replace initial missing values with 0
if sum(ismissing(x(1,:))) > 0
    x(1,find(ismissing(x(1,:)))) = 0;
end

T=size(x,1);                                                                % Number of Observations
r=size(A,1);                                                                % Number of states
xittm=[initx zeros(r,T)];                                                   % S_{t|t-1}
xitt=zeros(r,T);                                                            % S_{t|t} 
Pttm=cat(3,initV,zeros(r,r,T));                                             % P_{t|t-1}
Ptt=zeros(r,r,T);                                                           % P_{t|t}
loglik=0;                                                                   % Initialize the log-likelihood
y=x';                                                                       % transpose for convenience

if nargin<8; mu=zeros(r,1); end
if nargin<9; beta=zeros(1,2); end

% missing indicator for when to set prediction error to 0
missInd = find(ismissing(y(end,:)))';

for jj=1:T
    
    %%% ============= %%%
    %%% Updating Step %%%
    %%% ============= %%%   
    X=C*xittm(:,jj) + beta*[1;jj];                                            % X_{t|t-1} - Prediction
    iterR = R;
    if sum(jj == missInd) == 0
        iterR(end,end) = 0;
    end
    H=C*Pttm(:,:,jj)*C'+iterR;                                                   % H_{t|t-1} - Conditional Variance of the Observable   
    Hinv = inv(H);    
    e = y(:,jj) - X;                                                         % error (innovation)
    if sum(jj == missInd) == 1
        e(end,1) = 0;
    end
    xitt(:,jj)=xittm(:,jj)+Pttm(:,:,jj)*C'*Hinv*e;                             % S_{t|t}
    Ptt(:,:,jj)=Pttm(:,:,jj)-Pttm(:,:,jj)*C'*Hinv*C*Pttm(:,:,jj);               % P_{t|t}   

    %%% =============== %%%
    %%% Prediction Step %%%
    %%% =============== %%%
    xittm(:,jj+1)=mu+A*xitt(:,jj);                                            % S_{t|t-1} - States
    Pttm(:,:,jj+1)=A*Ptt(:,:,jj)*A'+Q;                                        % P_{t|t-1} - Conditional Variance of the State 
    loglik = loglik + 0.5*(log(det(Hinv))  - e'*Hinv*e);                    % Log Likelihood   
    
end

xitt=xitt';
xittm=xittm';


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% ML_KalmanSmoother3 - Kalman Smoother for a Factor Model
% 
%  THE MODEL
%  
%   X_t = C S_t + e_t,              e_t ~ N(0,R), R is diagonal
%   S_t = A S_{t-1} + u_t,          u_t ~ N(0,Q)
% 
%   S_t|X^{t-1} ~ N( S_{t|t-1} , P_{t|t-1} )
%   X_t|X^{t-1} ~ N( X_{t|t-1} , H_{t|t-1} )
% 
%  
%  THE PROCEDURE
%  
% [xitT,PtT,PtTm]=ML_KalmanSmoother3(x,A,xitt,xittm,Ptt,Pttm,C,R)
% 
% INPUTS:
%       A - the system matrix
%    xitt - S_{t|t}
%   xittm - S_{t|t-1}
%     Ptt - P_{t|t}
%    Pttm - P_{t,t-1|t-1}
%       C - the observation matrix 
%       R - the observation covariance
% OUTPUTS:
%    xitT = S_{t|T}
%     PtT = P_{t|T} 
%    PtTm = P_{t,t-1|T} 
%     
% This use the formulas in Chapter 4 of Durbin and Koopman "Time Series Analysis by
% State Space Methods" (second edition)
% Matteo Luciani (matteoluciani@yahoo.it)

function [xitT,PtT]=ML_KalmanSmoother3(x,A,xitt,xittm,Ptt,Pttm,C,R)

[T]=size(xitt,2);                                                           % Number of Observations
[n, r]=size(C);                                                             % Number of Variables and Number of States
Pttm=cat(3,zeros(r,r,1),Pttm(:,:,1:end-1));                                 % P_{t|t-1}, remove the last observation because it has dimension T+1
xittm=[zeros(r,1) xittm(:,1:end-1)];                                        % S_{t|t-1}, remove the last observation because it has dimension T+1
xitT=[zeros(r,T)  xitt(:,T)];                                               % S_{t|T} 
PtT=cat(3,zeros(r,r,T),Ptt(:,:,T));                                         % P_{t|T} 
y=[zeros(n,1) x'];                                                          % transpose for convenience
missInd = find(ismissing(y(end,:)) == 1);


rr=zeros(r,T+1); N=zeros(r,r,T+1); L=zeros(r,r,T+1);                        % Preallocates

CPCR = C*Pttm(:,:,T+1)*C'+R;                                                % useful matrices
iCPCR = eye(n)/CPCR;                                                        % ---------------
CiCPCRC = C'*iCPCR *C;                                                      % ---------------
L(:,:,T+1) = A - A*Pttm(:,:,T+1)*CiCPCRC;                                   % ---------------

for tt = T:-1:2    
    
    iterR = R;
    if sum(tt == missInd) == 0
        iterR(end,end) = 0;
    end
    
    CPCR = C*Pttm(:,:,tt)*C'+iterR;                                             % useful matrices
    iCPCR = eye(n)/CPCR;                                                    % ---------------
    CiCPCRC = C'*iCPCR *C;                                                  % ---------------    
    
    v = y(:,tt) - C*xittm(:,tt);
    if sum(tt == missInd) == 1
        v(end,1) = 0;
    end
    rr(:,tt-1) = C'*iCPCR * ( v ) + L(:,:,tt)'*rr(:,tt);    
    N(:,:,tt-1) = CiCPCRC + L(:,:,tt)'*N(:,:,tt)*L(:,:,tt);    
    L(:,:,tt) = A - A*Pttm(:,:,tt)*CiCPCRC;             
    xitT(:,tt) = xittm(:,tt) + Pttm(:,:,tt)*rr(:,tt-1);                     % state        
    PtT(:,:,tt) = Pttm(:,:,tt) - Pttm(:,:,tt)*N(:,:,tt-1)*Pttm(:,:,tt);     % covariance of the state 
end

PtT(:,:,1)=[];
xitT=xitT(:,2:end)';





%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% ML_Standardize - Standardize Variables
%
% [y M s] = ML_Standardize(x)
%
% Written by Matteo Luciani (matteoluciani@yahoo.it)

function [y, M, s] = ML_Standardize(x)

T=size(x,1);
s = nanstd(x);
M = nanmean(x);
ss = ones(T,1)*s;
MM = ones(T,1)*M;
y = (x-MM)./ss;


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% ML_center - Demean variables
% CENTER XC = center(X)
%	Centers each column of X.
%	J. Rodrigues 26/IV/97, jrodrig@ulb.ac.be
function XC = ML_center(X)
T = size(X,1);
XC = X - ones(T,1)*(nansum(X)/T); % Much faster than MEAN with a FOR loop

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% ML_lag - Given x(t) produces x(t-j0) .... x(t-k)
%
% xx=ML_lag(x,k,j0)
% by default j0 is 1
%
% eg x=[x1 x2]
% xx=ML_lag(x,2)=[x1_{t-1} x1_{t-2} x2_{t-1} x2_{t-2}]
%
% Matteo Luciani (matteoluciani@yahoo.it)

function xx=ML_lag(x,k,j0)
[T, N] = size(x);

if nargin<3; j0=1; end;    
n=1;

if N*(k+1-j0)==0
    xx=[];
elseif T==1
    xx=x;
else
    xx=zeros(T-k,N*(k+1-j0));
    for i=1:N
        for j=j0:k
            xx(:,n)=x(k+1-j:T-j,i);
            n=n+1;
        end;
    end;
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% ML_VAR - Estimates a VAR(k) for a vector of variables y
% if y is a single variable it estimates an AR model with OLS
%
% [A,u,AL,CL]=ML_VAR(y,det,jj);
%   y  = vector of endogenous variables
%   k  = number of lags
%   det = 0 no constant
%   det = 1 constant
%   det = 2 time trend
%   det = 3 constant + time trend
%   A  = Matrix of coefficients for the reduced form 
%   u  = Vector of Residuals
%
%  y_t=A(L)y_{t-1}+u_t
%  y_t=C(L)u_t
% 
% written by Matteo Luciani (matteoluciani@yahoo.it)

function [A,u,AL,CL,C1]=ML_VAR(y,k,det,s)
[T, N] = size(y);

%%% Building Up the vector for OLS regression %%%
yy=y(k+1:T,:);
xx=NaN(T-k,N*k);
for ii=1:N    
    for jj=1:k
        xx(:,k*(ii-1)+jj)=y(k+1-jj:T-jj,ii);
    end
end

%%% OLS Equation-By-Equation %%%
if det==0; ll=0; elseif  det==3; ll=2; else; ll=1; end
A=NaN(N*k+ll,N); u=NaN*yy;
for ii=1:N
    [A(:,ii),u(:,ii)]=ML_ols(yy(:,ii),xx,det);
end

At=A; if det==3; At(1:2,:)=[]; elseif det==1||det==2; At(1,:)=[]; end
AL=NaN(N,N,k); for kk=1:k; AL(:,:,kk)=At(1+kk-1:k:end,:)'; end  


%%% Impulse Responses %%%
if nargin<4;s=20; end
CL(:,:,1) = eye(N);
for ss=2:s
    CL(:,:,ss) = 0;
    for ii = 1:min(ss-1,k)        
        temp3=AL(:,:,ii)*CL(:,:,ss-ii);        
        CL(:,:,ss)=CL(:,:,ss)+temp3;
    end
end

C1=eye(N); for ii=1:k; C1=C1-AL(:,:,ii); end; C1=inv(C1);                     % Long Run Multipliers


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% ML_ols - OLS Estimation
% 
% [beta,u,v,esu,r2,espqr]=ML_ols(y,x,det);
%   Inputs:
%       y   = Endogenous Variable (vector)
%       x   = Exogenous Variables (matrix)
%       det = 0 no constant
%       det = 1 constant
%       det = 2 time trend
%       det = 3 constant + time trend
%   Outputs:
%       beta  = estimated coefficient
%       u     = residuals
%       v     = varcov matrix of the estimates
%       esu   = Residual Variance
%       r2    = R-Squared
%       espqr = estimates standard errors
%
% Written by Matteo Luciani (matteoluciani@yahoo.it)
% This is a modified version of the codes available on Fabio Canova webpage

function [beta,u,v,esu,r2,espar,yhat]=ML_ols(y,x,det)
T = size(x,1);

cons=ones(T,1); trend=(1:1:T)';
if      det==1; x=[cons x];
elseif  det==2; x=[trend x];
elseif  det==3; x=[cons trend x];
end;
k=size(x,2);                                                                % number of parameters
xx=eye(k)/(x'*x);                                                           % inv(x'x)
beta=xx*x'*y;                                                               % ols coeff
yhat=x*beta;                                                                % fitted values
u=y-yhat;                                                                   % residuals
uu=u'*u;                                                                    % SSR
esu=uu/(T-k);                                                               % Residual Variance
yc=y-mean(y);                                                               % Centered variables
r2=1-(uu)/(yc'*yc);                                                         % R2
v=esu*xx;                                                                   % varcov matrix of the estimates
espar=sqrt(diag(v));                                                        % Standard errors


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% ML_edynfactors2 - Estimation of Dynamic Factors Innovation 
% 
% Principal Components of the Residuals of a VAR(p) estimated on r Static Factors
% Refined version of ML_edynfactors in which svd rather than eigs is used
% [etahat, G]=ML_edynfactors2(y,q)
% The Model:
%       X(t) = lambda*F(t) + xsi(t)
%       F(t) = A(L)*F(t-1) + epsilon
%       epsilon = G*eta
%       where G is r by q
% Outputs:
%       etahat = estimates of dynamic Factors Innovations
%       G = estimates of G
% Inputs:
%       y = epsilon
%       q = number of dynamic factors
%

% Written by Matteo Luciani (matteoluciani@yahoo.it)

function [eta, G]=ML_edynfactors2(y,q)
opt.disp=0;
N=size(y,2);
sigma=cov(y);                                                               % Variance Covariance Matrix of VAR Residuals
if q<N; [P,M]=eigs(sigma,q,'LM',opt); else [P,M]=eig(sigma); end            % Eigenvalue eigenvectors decomposition
eta=y*P*(M^-.5);                                                            % Dynamic Factor Innovations            
G=P(:,1:q)*(M^.5);



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% ML_VAR_companion_matrix - build the companion matrix for a VAR
% PHI=ML_VAR_companion_matrix(AL,det);
% Y(t)=AL(:,:,1)*Y(t-1)+...+AL(:,:,p)*Y(t-p)+u(t)
% For a VAR(3) with k variables:
% | AL(:,:,1)   AL(:,:,2)   AL(:,:,3)   |
% | eye(k,k)    zeros(k,k)  zeros(k,k) |
% | zeros(k,k)  eye(k,k)    zeros(k,k) |
%

% Written by Matteo Luciani (matteoluciani@yahoo.it)

function PHI=ML_VAR_companion_matrix(A)

s=size(A);
if length(s)==1; PHI=A;                             % AR(1)
elseif length(s)==2;                        
    if s(2)==1; p=s(1,1);                           % Autoregressive model
        if  p==2; PHI=[A'; 1 0];                    % AR(2)   
        else PHI=diag(ones(1,p-1),-1); PHI(1,:)=A'; % AR(p)
        end
    else PHI=A; end                                 % VAR(1)
else    
    k=s(1,1); p=s(1,3);
    PHI=[];
    for i=1:p; PHI=[PHI A(:,:,i)]; end;
    PHI=[PHI;eye(k*(p-1),k*(p-1)) zeros(k*(p-1),k)];
end
