%% multiple imputation if M>1. Otherwise the same as iterstock

function [yimp,beta]=MI(inity,Fhat,nlagsF,nlagsY,mpoints,tpoints, model,M,e0,seed);


T=rows(Fhat);
lagF=[ones(T,1) Fhat];
y=inity;
for j=1:nlagsF;
          lagF=[lagF lagn(Fhat(:,1),j) ];
end;
lagy=[];

for j=1:nlagsY;
    lagy=[lagy lagn(y,j) ];
end;    
reg=[lagF lagy];

done=0; it=1; maxit=200;

while done==0 & it<=maxit;
    out0=nwest(y,reg,0);
    err=y-out0.yhat;
    if norm(err(tpoints))<=1e-4; 
        done=1;
    else;
        y(tpoints)=out0.yhat(tpoints); 
        lagy=[];
        for j=1:nlagsY;
        lagy=[lagy lagn(y,j)];
        end;
        reg=[lagF lagy];
        %                mymprint([it norm(err(tpoints))]);
        it=it+1;
    end;    
end;    
beta=out0.beta;
tstat=out0.tstat;
if it>=maxit; disp(sprintf('%s   did not converge %f',model,norm(err(tpoints))));end;

if M==1; yimp=y; end;  %% this is the same as iterstock.m
if M>1;
yhat=repmat(y,1,M);
for m=1:M;
    noise=datasample(e0, length(tpoints));
    yhat(tpoints,m)=yhat(tpoints,m)+noise;
end;
yimp=mean(yhat,2);
end;