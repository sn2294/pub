function [bigAhat, Ahat,bigGhat,Ghat0]=getbigGamFhat(y,T,r,p);

%% OLS estimation of VAR for F=y
Y=y(:,p:T);
for t=1:p-1;
    Y=[Y; y(:,p-t:T-t)];
end;
X=[ones(1,T-p); Y(:,1:T-p)];
out1=nwest(Y(1,2:T-p+1)',X',0);
Y=Y(:,2:T-p+1);
Ahat0=(Y*X')/(X*X');
Uhat0=Y-Ahat0*X;
Sigma_U=Uhat0*Uhat0'/(T-p-p*r-1);

nu=Ahat0(:,1);
Ahat=Ahat0;
Ahat(:,1)=[];


temp=zeros(r*p,r*p);
for i=1:p;
    temp((i-1)*p+1:(i-1)*p+r,(i-1)*p+1:(i-1)*p+r)=eye(r);
end;

bigAhat=[Ahat(1:r,:); temp(1:r*(p-1),:)];

J=zeros(r,r*p);
J(1:r,1:r)=eye(r);



Sig2Uhat=zeros(r*p,r*p);
dum=cov(Uhat0');
Sig2Uhat(1:r,1:r)=dum(1:r,1:r);
Ghat00=reshape(inv(eye((r*p)^2)-kron(bigAhat,bigAhat))*vec(Sig2Uhat),r*p,r*p);
Ghat0=[];
Ghat0{1}=J*Ghat00;
AAhat0=[];
bigGhat=Ghat0{1}(1:r,1:r);
for i=1:p;
    Ghat0{i+1}=J*bigAhat^i *Ghat00;
    bigGhat=[bigGhat Ghat0{i+1}(1:r,1:r)];
end;    
for t=p+1:T-1;
    Ghat0{t+1}=J*bigAhat^t*Ghat00;
    bigGhat=[bigGhat Ghat0{t+1}(1:r,1:r)];
end;    

for t=2:T;
    temp2=bigGhat(1:r,1:end-r*(t-1));
    temp1=[];
    for s=t-1:-1:1;
        temp1=[temp1 bigGhat(1:r,s*r+1:(s+1)*r)'];
    end;
    bigGhat=[bigGhat; temp1 temp2];
end;    
