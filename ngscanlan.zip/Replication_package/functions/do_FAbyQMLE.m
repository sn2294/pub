function [mle,Ahat,Ghat0]=do_FAbyQMLE(X0,r,p,q,SZZ,L_init,P_init);
[T,N]=size(X0);
z=demean(X0)';
if length(SZZ)>0;
    Szz=SZZ;
else;    
Szz=z*z'/T;
end;

randn('state',999);
rand('state',888);
if length(L_init)==0;
    old.L=randn(N,r); 
else
    old.L=L_init;
end;
if length(P_init)==0;
    old.Sig=2.0+rand(N,1);
else ;
    old.Sig=P_init;
end;    

done=0;
it=1;
maxit=5000;
while done==0 & it<=maxit;
    old.Sigzz=old.L*old.L'+diag(old.Sig);
    inv_old.Sigzz=inv(old.Sigzz);
    Eff=old.L'*inv_old.Sigzz*Szz*inv_old.Sigzz*old.L...
          +eye(r)-old.L'*inv_old.Sigzz*old.L;
    Ezf=Szz*inv_old.Sigzz*old.L;
    new.L=Ezf*inv(Eff);
    new.Sig=diag(Szz-old.L*old.L'*inv_old.Sigzz*Szz);
    
    err1=norm(new.L-old.L); 
    err2=norm(new.Sig-old.Sig);
    err3=find(new.Sig<.05);
    if err1 < 1e-5 & err2<1e-5 ;
        done=1;
        %        disp(sprintf('do_FAbyQMLE converged  %d  interations',it));
    else;
        old.L=new.L;
        old.Sig=new.Sig;
        % disp(sprintf("%d %8.6f %8.6f",it,err1,err2));
        it=it+1;
    end;
end;    
if done==0 & it>=maxit; disp(sprintf("do_FAbyQMLE Failed to converge in iteration %d %7.3f %7.3f %7.3f",...
                                     err1,err2,err3));
end;

%% normalize to be lower triangular
iSig=inv(diag(new.Sig));
mle.L=new.L;


LPhiL=mle.L'*iSig*mle.L;
mle.Fgls=demean(z'*iSig*mle.L*inv(LPhiL));
Sff=mle.Fgls'*mle.Fgls/T;

mle.Fmle=z'*iSig*mle.L*inv(Sff+LPhiL);
mle.phi2=new.Sig;
Phi.mle=diag(mle.phi2);


Ahat=[]; Ghat0=[]; MLE.Fks=[];
if p>0;
[BigAhat,Ahat,BigGhat,Ghat0]=getbigGamFhat(mle.Fgls',T,r,p);
Chat_cov=kron(eye(T),mle.L)*BigGhat*kron(eye(T),mle.L)';
Xhat_cov=Chat_cov+kron(eye(T),Phi.mle);

bot=inv(BigGhat)+kron(eye(T),LPhiL);
top=kron(eye(T),mle.L'*inv(Phi.mle));    %% rT x NT
FF.ks=inv(bot)*top*vec(X0');
mle.Fks=reshape(FF.ks,r,T)';
end;

%% persistence in idiosyncratic errors
MLE.Far=[]; MLE.Lar=[];
if q>0;
ehat0=z-mle.L*mle.Fgls';
old.rho=zeros(N,1);
old.f=mle.Fgls;
old.l=mle.L;
old.phi2=mle.phi2;
old.rho=zeros(N,1);
old.iSig=iSig;
old.ee=ehat0;
old.c=old.l*old.f';
new.rho=zeros(N,1);
new.l=zeros(N,r);

done=0;
mle.Far=old.f*NaN;
mle.Lar=old.l*NaN;
it=1;
maxit=3;
while done ==0 && it <=maxit;
for i=1:N;

    reg=[old.f(2:end,:) old.f(1:end-1,:)  z(i,1:end-1)' ];
    dum=reg\z(i,2:end)';
    new.l(i,:)=dum(1:r);
    new.rho(i)=dum(end);
end;
    new.f=z'*old.iSig*new.l*inv(new.l'*old.iSig*new.l);
    new.ee=z-new.l*new.f';
    new.phi2=(std(new.ee').^2)';
    new.c=new.l*new.f';
    checkf=norm(new.f-old.f);
    checkl=norm(new.l-old.l);
    checkr=norm(new.rho-old.rho);
    checkp=norm(new.phi2-old.phi2);
    checkc=norm(new.c-old.c);
   
    if ((checkc < 1e-3) &  (checkp<1e-4) & (checkr<1e-4)) || it==maxit;
        done=1;
        mle.Far=new.f;
        mle.Lar=new.L;
    else;
        old.l=new.l;
        old.f=new.f;
        old.rho=new.rho;
        old.phi2=new.phi2;;
        old.c=new.c;
        %        old.iSig=diag(1.0./old.phi2);
        it=it+1;
    end;    
end;
end;

