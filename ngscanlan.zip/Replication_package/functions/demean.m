function deX = demean(X)

deX = X - nanmean(X);




end