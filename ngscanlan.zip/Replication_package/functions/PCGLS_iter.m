function [f,lam,iter] = PCGLS_iter(y,r,it0) 
% GLS estimates of factors and loadings, controls for both
% heteroskedasticity and serially correlated residuals.
%
% Follows method from:
% "GLS Estimation of Dynamic Factor Models" by Jörg Breitung and Jörn Tenhofen
% Journal of the American Statistical Association, 106(495): 1150-1166


%   INPUT:  y is TxN data matrix
%           r is the number of factors
%   Output: f is Txr  matrix of factors
%           lam is Nxr matrix of loadings
%           iter is the number of iterations
%   Note:   Lag order is p=1 

    [T,N] = size(y);
    y  = y-ones(T,1)*mean(y);  % demeaning y  
    y0 = y(2:end,:);           % current y
    y1 = y(1:end-1,:);         % lagged y
    
    rho = zeros(N,1);  % starting value for rho
    c = y'*y/T;        % Covariance matrix of y 
                       %    [evec,eval] = eigrs2(c); % compute eigenvalues / -vectors
    [evec,eval] = eigs(c); % compute eigenvalues / -vectors
    v = evec(:,1:r);   
    f=y*v;             % PC factors
    lam=v;             % PC loadings
    f0=f(2:end,:);
    f1=f(1:end-1,:);
    e0 = 100000;
    e1 = 1000;
    iter=0;
    maxit=1000;
    while abs(e0/e1-1) > 0.000001 & iter<it0;    
        e0 = e1;
        x=f*lam';                % Common components
        y0star = y0 - x(2:T,:);  % Computing residuals + lags
        y1star = y1 - x(1:T-1,:);  
        rho = diag(y0star'*y1star)./diag(y1star'*y1star);        % estimate new rhos with ols        
            ustar = y0star - y1star.*kron(ones(T-1,1),rho');     % white noise residuals
            sig2 = diag(ustar'*ustar./(T-1));                    % computing residual variances
            sig2 = ones(N,1)./sig2;
            sig2 = diag(sig2);                                   % inverse of the covariance matrix 
        ygls = y0 - y1.*kron(ones(T-1,1),rho');                  % GLS transformation of y

        f0   = f(2:end,:);
        f1   = f(1:end-1,:);
        fgls = kron(ones(1,N),f0) - kron(rho',f1);               % GLS transformed factors  
        lam=[];
        for i=1:N                                                % Update loadings
            lam_temp = ygls(:,i)'*fgls(:,(i-1)*r+1:i*r)*inv(fgls(:,(i-1)*r+1:i*r)'*fgls(:,(i-1)*r+1:i*r));
            lam      = [lam; lam_temp];
        end
        
        fgls_a=[];        
        for j=1:N
            fgls_temp = fgls(:,(j-1)*r+1:j*r)*lam(j,:)';
            fgls_a    = [fgls_a fgls_temp];               %  GLS common components 
        end
        
        ugls = ygls - fgls_a;            %  GLS residuals
        
            u  = y-f*lam';
            om = diag(u'*u./T);
            om = ones(N,1)./om;
            om = diag(om);               %  inverse of cross-corr. matrix
       
        f = y*om*lam*inv(lam'*om*lam);   %  updated factors
        
        e1 = sum(diag(ugls'*ugls))/N/T;  %  Least-squares criterion
        iter=iter+1;

    end
    if iter>=maxit; f=f*NaN; lam=lam*NaN; disp(sprintf(['PCGLS did ' ...
        'not converge: %d %d %d %f'],N,T,it0,abs(e0/e1-1)));
    else;    
    yhat = f*lam';            % Impose B&N normalization
    Sig  =(yhat*yhat')/N;
    [evec,eval] = eigs(Sig); 
    v    = evec(:,1:r);   
    lam  = y'*v;               
    f    = v;                 % f'f = I
    end;
end
    

