function dDates = n2dDates(nDates)

T = size(nDates,1);

yr = floor(nDates);
dLeft = nDates - yr;
%dInY = 365*ones(T,1) + (floor((yr/4 + 1)) - (yr/4) == 1);
%check = [yr,dInY];
dofy = floor(dLeft.*365); 

dofy(dofy == 0) = 365;

% What month

[y,m,d] = datevec(datenum(yr,1,dofy));

dDates = datetime(y,m,d);

end