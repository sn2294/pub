
%function self = FBI(xm,r,do_std, covopt)
function self = do_fbiTP(xm,r,missing,do_std, covopt,missing0)

%
%% mynanstd is replaced by nanstd    
% This version of FBI uses "ALL" the observations in a given column X_i while regressing 
% X_i on Fhat_t. This way Lambdahat_i is estimated more accurately.

%% INPUTS:
% xm = missing data set
% r = number of factors (assumed to be known) => we can also estimate it via BN (2003?) 
% do_std = 0 => demean & standardize xm 
%        = 1 => demean but DON'T standardize
%        = 2 => DON'T demean & DON'T standardize
% covopt = covariance option. For direct sample (total) covariance calculation, use "sample"
%                             For decomposed total covariance calculation (ie, total = sys + idio), use "decomp"  

%% OUTPUTS
% Fhat = estimated factors
% Lamhat = estimated loadings
% Chat = estimated common component
% Xhat = imputed data set 
% mu1 = initial mean estimate for each columns
% sd1 = initial std estimate for each columns
% missing = missingness map of xm

%% NOTE:
% xm is structured so that teh first Na columns are available (observed), and the next Nm columns have missingness


  %% Parameters & Variables
  %gama0 = 0;  % fix gama0 = 0; used in baing17, deprecated now 
  [T,N] = size(xm);
  missing = isnan(xm);
  goodN = find(sum(missing)==0); % complete columns
  N1 = length(goodN);
  mu1 = repmat(nanmean(xm),T,1);
  sd1 = repmat(nanstd(xm),T,1);
  
  
     
  %% do_std = 0
  if do_std == 0
      
    % Demean & Standardize the entire xm
    xm_ds = (xm - mu1)./sd1 ;
 
    % Determine the full (tall) part of xm_ds
    Z = xm_ds(:,goodN) ; % Z = XT in BN
    
    % Extract Fz
    %bnZ = baing17(Z,r,gama0);   % DEPRECATED
    bnZ = do_APC(Z,r);           %# estimate factor model from Z
    Fz = bnZ.Fhat;               %# Factor estimates    %# Txr  (Fz = Fn)
    Lamz = zeros(N,r);           %# Initiate an empty Loading matrix  (Lamz = Lamhat)
    
    %# --- Estimate Loadings  --- #%
    Reg = Fz;
    P = inv(Reg'*Reg)*Reg';  %# P matrix of factors from TALL (NOT projection matrix)  %# rxT
    
    % Estimate Loadings in "complete" columns 1:N1
    for i = 1:N1
         Lamz(i,:) = P*Z(:,i); 
    end          %# uses these Lamhat to calculate the CC for the entire data  
    
    %# Estimate Loadings in the "missing" columns (N1+1):N
    for k = N1+1:N
      datak = [Fz xm_ds(:,k)];                      %# bind the factor and the series Xk 
      datak(any(isnan(datak),2),:) = [];         %# eliminate rows with missing values
      xm_dsk  = datak(:,end);                       %# "all" available observations in column k 
      Regk = datak(:,1:r);                       %# Part of Fz corresponding to column k
      Pk   = inv(Regk'*Regk)*Regk'; 
      Lamz(k,:) = Pk*xm_dsk;                        %# Estimate the loadings (regression coefficients)
    end
    
    %# Calculate CC
    Chat_ds = (Fz*Lamz');       % demeaned & standardized version of Chat
    Chat = Chat_ds.*sd1 + mu1;
  end

  
  %% do_std = 1
  if do_std==1
    % Demean xm  
    xm_d = xm - mu1;  % Only demean, DONT standardize
    
    % Determine the full (tall) part of xm_ds
    Z = xm_d(:,goodN) ;
    
    % Extract Fz
    %bnZ = baing17(Z,r,gama0);  % DEPRECATED
    bnZ = do_APC(Z,r);
    Fz = bnZ.Fhat;
    Lamz = zeros(N,r);
    
    Reg = Fz;
    P = inv(Reg'*Reg)*Reg';
    for i=1:N1
       Lamz(i,:)=P*Z(:,i);
    end
    
    %# --- Estimate Loadings in the "missing" columns (N1+1):N --- #%
    for k = N1+1:N
      datak = [bnZ.Fhat xm_d(:,k)];
      datak(any(isnan(datak),2),:) = [];  %# Eliminate rows with missing values
      xm_dk  = datak(:,end);                %# "all" available observations in column k 
      Regk = datak(:,1:r);                %# estimated factor observations corresponding to column k  
      Pk   = inv(Regk'*Regk)*Regk'; 
      Lamz(k,:) = Pk*xm_dk;
    end
    
    % Calculate the Common Component
    Chat = Fz*Lamz'+ mu1;
  end

  
  %% do_std =2
  if do_std == 2                % DON'T demean & DON'T standardize => simply use xm as it is 
    % Determine the full (tall) part of xm_ds
    Z = xm(:,goodN) ;  % Z == XT in do_fbiAPC
      
    % Extract Fz
    %bnZ = baing17(Z,r,gama0);  % DEPRECATED
    bnZ = do_APC(Z,r);
    Fz = bnZ.Fhat;
    Lamz = zeros(N1,r+1);   % Lamz == Lamhat in do_fbiAPC
    Reg = [ones(T,1) Fz];       %# When there is no demeaning, we use intercept in the regression !!!
    P = inv(Reg'*Reg)*Reg';
    for i = 1:N1
       Lamz(i,:) = P*Z(:,i);
    end
    
    %# --- Estimate Loadings for the "missing" columns (N1+1):N --- #%
    for k = (N1+1):N
      %datak = [bnZ.Fhat xm(:,k)];
      datak = [Fz xm(:,k)];
      datak(any(isnan(datak),2),:) = [];       %# Eliminate rows with missing values
      T_usei = size(datak,1);
      
      xmk  = datak(:,end);                     %# "all" available observations in column k (and add a column of ones)
      Regk = [ones(T_usei,1) datak(:,1:r)];    %# estimated factor observations corresponding to column k
      Pk   = inv(Regk'*Regk)*Regk'; 
      Lamz(k,:) = Pk * xmk;
    end
   
    % Calculate the Common Component
    Chat=[ones(T,1) Fz]*Lamz';
  end

  
  
  %% Impute Missing Data & Return
  xhat = xm;                      % Imputed data
  xhat(missing) = Chat(missing);  %# Adjust mean and std 
    
  % Return
  self.Fz   = Fz;
  self.Lamz = Lamz;
  self.Chat = Chat;
  self.data = xhat;
  self.ehat = xhat - Chat;
  self.Fhat = self.Fz;
  self.Lamhat=self.Lamz(:,end-r+1:end);
  self.Dhat=diag(bnZ.d);
  %self.cov = cov(xhat);   
  self.missing = missing;
  %self.mu1 = mu1;
  %self.sd1 = sd1;
  
  
  %% CALCULATE COVARIANCE MATRIX
  if covopt == 'sample'
    % Calculate Sample Covariance Matrix directly
    self.cov = cov(self.data);
        
  elseif covopt == 'decomp'
    % Calculate Covariance Matrix vis Sstematic + Idiosyncratic Decomposition
    allcovs = all_cov(self.Chat, self.ehat, missing0);
    self.sys_cov  = allcovs.sys_cov;
    self.idio_cov = allcovs.idio_cov;
    self.cov      = allcovs.cov;

  end

end


        
        
        
        
        
        
        
        
        
        
        
        
        








