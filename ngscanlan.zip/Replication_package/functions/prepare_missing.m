function yt   = prepare_missing(rawdata,tcode,h,h_type)
% =========================================================================
% DESCRIPTION: 
% This function transforms raw data based on each series' transformation
% code.
%
% -------------------------------------------------------------------------
% INPUT:
%           rawdata     = raw data 
%           tcode       = transformation codes for each series
%           h           = # of weeks for transformation
%           h_type      = 'avg' or 'eop' for average log change or
%                         end-of-period log change
%
% OUTPUT: 
%           yt          = transformed data
%
% -------------------------------------------------------------------------
% SUBFUNCTION:
%           transxf:    transforms a single series as specified by a 
%                       given transfromation code
%
% =========================================================================
% The h input was added at a late stage (12/8/2020) in order to accomodate
% alternate transformations for weekly data. If no input, will ignore that
% transformation.
if nargin < 3
    h = 0;
    h_type = '';
end
% APPLY TRANSFORMATION:
% Initialize output variable
yt        = [];                                     

% Number of series kept
N = size(rawdata,2);                         

% Perform transformation using subfunction transxf (see below for details)
for i = 1:N
    dum = transxf(rawdata(:,i),tcode(i),h,h_type);
    yt    = [yt, dum];
end

end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% SUBFUNCTION

function y=transxf(x,tcode,h,h_type)
% =========================================================================
% DESCRIPTION:
% This function transforms a single series (in a column vector)as specified
% by a given transfromation code.
%
% -------------------------------------------------------------------------
% INPUT:
%           x       = series (in a column vector) to be transformed
%           tcode   = transformation code (1-7)
%           h           = # of weeks for transformation
%           h_type      = 'avg' or 'eop' for average log change or
%                         end-of-period log change
%
% OUTPUT:   
%           y       = transformed series (as a column vector)
%
% =========================================================================
% SETUP:
% Number of observations (including missing values)
n=size(x,1);
 
% Value close to zero 
small=1e-6;

% Allocate output variable
y=NaN*ones(n,1);

% =========================================================================
% TRANSFORMATION: 
% Determine case 1-7 by transformation code
switch(tcode);
    
  case 1, % Level (i.e. no transformation): x(t)
    y=x;

  case 2, % First difference: x(t)-x(t-1)
    y(2:n)=x(2:n,1)-x(1:n-1,1);
  
  case 3, % Second difference: (x(t)-x(t-1))-(x(t-1)-x(t-2))
    y(3:n)=x(3:n)-2*x(2:n-1)+x(1:n-2);

  case 4, % Natural log: ln(x)
    if min(x) < small; 
        y=NaN; 
    else
        y=log(x);
    end;
  
  case 5, % First difference of natural log: ln(x)-ln(x-1)
    if min(x) > small;
        x=log(x);
        y(2:n)=x(2:n)-x(1:n-1);
    end;
  
  case 6, % Second difference of natural log: (ln(x)-ln(x-1))-(ln(x-1)-ln(x-2))
    if min(x) > small;
        x=log(x);
        y(3:n)=x(3:n)-2*x(2:n-1)+x(1:n-2);
    end;
  
  case 7, % First difference of percent change: (x(t)/x(t-1)-1)-(x(t-1)/x(t-2)-1)
    y1(2:n)=(x(2:n)-x(1:n-1))./x(1:n-1);
    y(3:n)=y1(3:n)-y1(2:n-1);
    
  case 8, % 52-wk % change
      y(53:n) = 100*(x(53:n)-x(1:n-52))./x(1:n-52);
      
  case 9, % 52-wk change
      y(53:n) = x(53:n)-x(1:n-52);
      
  case 10, % h-wk % change
      if h > 0
          if h_type == 'avg'
            y(h+1:n) = 100*(movmean(x(h+1:n),h)-movmean(x(1:n-h),h))./movmean(x(1:n-h),h);
          elseif h_type == 'eop'
            y(h+1:n) = 100*(x(h+1:n)-x(1:n-h))./x(1:n-h);
          end
      else
          error('Need to input positive integer for h, for # of week difference')
      end
      
  case 11, % h-wk change
      if h > 0
          if h_type == 'avg'
            y(h+1:n) = movmean(x(h+1:n),h)-movmean(x(1:n-h),h);            
          elseif h_type == 'eop'
            y(h+1:n) = x(h+1:n)-x(1:n-h);
          end
      else
          error('Need to input positive integer for h, for # of week difference')
      end
end;

end
