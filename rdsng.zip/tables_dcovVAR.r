rm(list=ls())
library(ggplot2)
library(gridExtra)
library(knitr)
inrda=list()
inrda[[1]]='mc_dcovVAR1.RData'
inrda[[2]]='mc_dcovVAR2.RData'
outfile="mc_dcovVAR.tex"
outfig='fig/mc_dcovVAR'
source("mymprint.r")

IRF_mu=list()
LP_mu=list()
IRF_sd=list()
LP_sd=list()
nnoise=length(inrda)
load(inrda[[1]])
ncases=dim(AHAT)[2]
n=dim(IRFhat)[3]
nstep=dim(IRFhat)[2]-1
maxit=dim(AHAT)[1]


AA.true=array(0,c(ncases,nnoise,n*n))
BB.true=array(0,c(ncases,nnoise,n*n))
AA.hat=array(0,c(ncases,nnoise,n*n))
BB.hat=array(0,c(ncases,nnoise,n*n))
Ptest=array(0,c(ncases,nnoise,8))
Amari=array(0,c(ncases,nnoise,8))
Ahat=list()
Bhat=list()

for (inoise in (1:nnoise)){
    PTest=array(0,c(maxit,ncases,3))
    load(inrda[[inoise]])
    Ahat[[inoise]]=AHAT
    Bhat[[inoise]]=BHAT
    for (icase in (1:ncases)){
    AA.true[icase,inoise,]=as.vector(A0)
    BB.true[icase,inoise,]=as.vector(B.true[[icase]])
    AA.hat[icase,inoise,]=apply(AHAT[,icase,],2,mean)
    BB.hat[icase,inoise,]=apply(BHAT[,icase,],2,mean)
    Ptest[icase,inoise,]=apply(PTEST[,icase,]<0.1,2,mean)
    Amari[icase,inoise,]=apply(AMARI[,icase,],2,mean)
    }
}


sink(outfile,append=FALSE)

dumP=matrix(0,1,10)
dumW=matrix(0,1,10)

for (inoise in (1:nnoise)){
    for (icase in (1:ncases)){
        dumP=rbind(dumP,c(icase,inoise,Ptest[icase,inoise,]))
        dumW=rbind(dumW,c(icase,inoise,Amari[icase,inoise,]))
    }
}
dum=cbind(dumP,dumW[,3:5])
print('Ptest')
print(kable(dumP,'latex',booktabs=T,digits=3))
print("Amari")
print(kable(dumW,'latex',booktabs=T,digits=3))


for (icase in (1:ncases)) {
for (inoise in (1:nnoise)){
    print(c('A(case,noise)',icase,inoise))
    print(kable(matrix(AA.true[icase,inoise,],n,n),'latex',booktabs=T,digits=3))
    print(kable(matrix(AA.hat[icase,inoise,],n,n),'latex',booktabs=T,digits=3))
   }
}


for (icase in (1:ncases)) {
for (inoise in (1:nnoise)){
    print(c('B(case,noise)',icase,inoise))
    print(kable(matrix(BB.true[icase,inoise,],n,n),'latex',booktabs=T,digits=3))
    print(kable(t(matrix(BB.hat[icase,inoise,],n,n)),'latex',booktabs=T,digits=3))
   }
}

sink()
nstep=9
IRF_mu=array(0,c(nnoise,ncases,nstep+1,n))
LP_mu=array(0,c(nnoise,ncases,nstep+1,n))
IRF_sd=array(0,c(nnoise,ncases,nstep+1,n))
LP_sd=array(0,c(nnoise,ncases,nstep+1,n))

for (inoise in (1:nnoise)){
    load(inrda[[inoise]])
    ncases=dim(AHAT)[2]
    n=dim(IRFhat)[3]
    for (icase in (1:ncases)){
        for (i in (1:(n))){
            for (h in (1:(nstep+1))){
                IRF_mu[inoise,icase,h,i]=mean(IRFhat[,h,i])
                IRF_sd[inoise,icase,h,i]=sd(IRFhat[,h,i])
                LP_mu[inoise,icase,h,i]=mean(LPhat[,h,i])
                LP_sd[inoise,icase,h,i]=sd(LPhat[,h,i])
            }
        }
    }
}

IRF_mu=list()
LP_mu=list()
IRF_sd=list()
LP_sd=list()

for  (inoise in (1:2)) {
    load(inrda[[inoise]])
    ncases=dim(AHAT)[2]
    n=dim(IRFhat)[3]
    nstep=dim(IRFhat)[2]-1
    maxit=dim(AHAT)[1]
#print( c('case',2))
for (icase in (1:ncases)){
    IRF_mu[[icase]]=matrix(0,nstep+1,n)
    LP_mu[[icase]]=matrix(0,nstep+1,n)
    IRF_sd[[icase]]=matrix(0,nstep+1,n)
    LP_sd[[icase]]=matrix(0,nstep+1,n)

for (i in (1:(n))){
    for (h in (1:(nstep+1))){
    IRF_mu[[icase]][h,i]=mean(IRFhat[,h,i])
    LP_mu[[icase]][h,i]=mean(LPhat[,h,i])
    IRF_sd[[icase]][h,i]=sd(IRFhat[,h,i])
    LP_sd[[icase]][h,i]=sd(LPhat[,h,i])
    } ## end h
  } ## end i
 } ## end icase
} ## end inoise    

params=c(1,5)
imodel=1
Aplot=array(0,c(maxit,nnoise,n*n))
Aplot[,1,]=Ahat[[1]][,imodel,]  
Aplot[,2,]=Ahat[[2]][,imodel,]  

pname=c('A11','A22')
for (iparam in 1:2){
    X=data.frame(Aplot[,,params[iparam]])
    if (iparam==1) names(X)=c('HL','LL')
    else names(X)=c('HL','LL')
    x_range=range(X)
    pdf(file=paste0(outfig,'A',params[iparam],'.pdf'))
    dum1=c(apply(X,2,mean),apply(X,2,sd))
    dum2=round(dum1,digits=3)
    x_title=paste0(pname[iparam],": Mean:=(",dum2[1],dum2[2],"),SD=(",dum2[3],dum2[4],")")
    dens=apply(X,2,density)
    plot(NA, xlim=range(sapply(dens, "[", "x")), ylim=range(sapply(dens, "[", "y")),main=x_title)
    mapply(lines, dens, col=1:length(dens))
    legend("topright", legend=names(X), fill=1:length(dens))
    dev.off()
}

params=c(2,5)
imodel=1
Bplot=array(0,c(maxit,nnoise,n*n))
Bplot[,1,]=Bhat[[1]][,imodel,]  
Bplot[,2,]=Bhat[[2]][,imodel,]  


pname=c("B21","B22")
for (iparam in 1:2){
    X=data.frame(Bplot[,,params[iparam]])
    names(X)=c('HL','LL')
    x_range=range(X)
    pdf(file=paste0(outfig,'B',params[iparam],'.pdf'))
    dum1=c(apply(X,2,mean),apply(X,2,sd))
    dum2=round(dum1,digits=3)
    x_title=paste0(pname[iparam],": Mean:=(",dum2[1],dum2[2],"),SD=(",dum2[3],dum2[4],")")
    dens=apply(X,2,density)
    plot(NA, xlim=range(sapply(dens, "[", "x")), ylim=range(sapply(dens, "[", "y")),main=x_title)
    mapply(lines, dens, col=1:length(dens))
    legend("topright", legend=names(X), fill=1:length(dens))
    dev.off()
}







