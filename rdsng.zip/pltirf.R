pltirf<-function(df0,dfu,dfl,title,legend){ 
n=ncol(df0)	
pltlist<-list()
for (i in 1:n) {
df<-data.frame(df0[,i],dfu[,i],dfl[,i])
names(df)<-c('z','zu','zl')	
df$steps<-0:(nrow(df0)-1)
fig=ggplot(df,aes(x=steps,y=z))+geom_line()+ylab(legend[i])+ggtitle(title)
fig=fig+geom_line(aes(y=zu),linetype='dotted')
fig=fig+geom_line(aes(y=zl),linetype='dotted')
fig=fig+scale_x_continuous(breaks=c(0,2,5,10,20))
fig=fig+theme(plot.title=element_text(size=8))

pltlist[[legend[i]]]<-fig
}
#return(list('fig1'=fig11,'fig2'=fig12,'fig3'=fig13,'fig4'=fig14))
return(pltlist)
}
