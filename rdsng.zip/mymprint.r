mymprint <-function(M,fmt='%8.3f') {
    nrows=nrow(M)
    ncol=ncol(M)

    cat(sprintf('\n'))
    for (i in (1:nrows)) {
        print(as.numeric(sprintf(fmt,M[i,])))
#        cat(sprintf('\n'))
        }
    cat(sprintf('\n'))
}

myvprint<-function(V,fmt='%8.3f') {
    print(as.numeric(sprintf(fmt,as.vector(V))))
    cat(sprintf('\n'))
}
