rm(list=ls())
library(moments)
library(steadyICA)
library(R.matlab)
#indir="/home/sng/Dropbox/prog/sydney/ucc/AEJmacro_Sub_April2019/Publication_files/Replication_Files/"
#infile="Replication_Data.xlsx"
## file saved in csv form
source("mw_detrend.r")
source("renormalize.r")
#dum=read.csv("lmn.csv")
#UF=dum[,2]
#UR=dum[,4]
#IP=dum[,6]
#UM=dum[,3]
dumF=read.csv('data/UF.csv')
dumM=read.csv('data/UM.csv')
dumI=read.csv('data/INDPRO.csv')
IP=log(dumI$INDPRO)
dip=rep(NA,nrow(dumI))
dip[13:nrow(dumI)]=diff(IP,differences=12)

UF=dumF[,2]
UM=dumM[,2]
IP=dip[499:1212]


dt1=data.frame(UM,IP,UF)
names(dt1)=c('Y1','Y2','Y3')
varname=c('Y1','Y2','Y3')

## transform data
do_detrend=0
p=6
if (do_detrend==1){
    zz1=mw_detrend(dt1$Y1,12)
    zz2=mw_detrend(dt1$Y2,12)
    zz3=mw_detrend(dt1$Y3,12)
    dt2=data.frame(zz1$chat,zz2$chat,zz3$chat)
}
if (do_detrend==2) {
    zz2=mw_detrend(dt1$Y2,12)
    zz3=mw_detrend(dt1$Y3,12)
    dt2=data.frame(dt1$Y1,zz2$chat,zz3$chat)
}
if (do_detrend==0)  dt2=dt1
    names(dt2)=names(dt1)

## estimate VAR
    y=as.matrix(dt2)
    T=nrow(y)
     n=ncol(y)
    Y=y[(p+1):T,]
    reg=rep(1,(T-p))
    for (i in (1:p)){
       reg=cbind(reg,y[(p-i+1):(T-i),])
    }
    reg=as.matrix(reg)
    Y=as.matrix(Y)
    OLS= solve(t(reg) %*% reg) %*% t(reg) %*% Y
    ahat_OLS=OLS[-1,]
    chat_OLS=OLS[1,]
    ehat_OLS=Y-reg %*% OLS
    cov_OLS=t(ehat_OLS) %*% ehat_OLS/(T-p-p*n-1)
    # prewhitening	
    P_OLS=chol(cov_OLS)
    B_OLS=t(P_OLS)
    uhat_OLS=ehat_OLS %*% solve(P_OLS)
    sigs_OLS=diag(P_OLS)
    H_OLS=B_OLS %*% solve(diag(sigs_OLS))

    # do ICA
    x0=uhat_OLS
    out5=steadyICA(x0,whiten=FALSE,maxit=100)

    dum5=renormalize(ehat_OLS,out5$S,out5$M,P_OLS)
    dum5$Bscaled=solve(dum5$Sig.W) %*% dum5$B
    check =ehat_OLS-dum5$S %*% solve(dum5$Sig.W) %*% dum5$B
    check1 = ehat_OLS-dum5$S %*% dum5$Bscaled

    uhat_ica=dum5$S
    B_ica=t(dum5$Bscaled)
    sigs_ica=diag(B_ica)
    H_ica=B_ica %*% solve(diag(sigs_ica))

    ehat_raw=ehat_OLS
    temp=order(kurtosis(ehat_raw),decreasing=TRUE)
    ehat_OLS=ehat_raw

nstep=9
source('do_varirf.r')
MYIRF=do_varirf(ehat_OLS,ahat_OLS,uhat_ica,H_ica,sigs_ica,p,nstep)
irfica_raw=MYIRF[[1]]
irfica_orth=MYIRF[[2]]

MYIRF=do_varirf(ehat_OLS,ahat_OLS,uhat_OLS,H_OLS,sigs_OLS,p,nstep)
irfchol_raw=MYIRF[[1]]
irfchol_orth=MYIRF[[2]]



## IRF_VAR_orth$irf should match irfchol_orth[[1]]
Chat=chat_OLS

Ahat=list()
for (j in (1:p)){
    t1=(j-1)*n+1
    t2= j*n
    Ahat[[j]]=ahat_OLS[t1:t2,]
    
}
data=list()
data$y=y
data$Ahat=Ahat
data$Chat=Chat
data$ehat=ehat_OLS
data$uhat=uhat_ica
data$Hat=H_ica
data$Bhat=B_ica
data$sigs=sigs_ica
data$irfica=irfica_orth
data$irfchol=irfchol_orth

save(data,file="do_lmn2.RData")


pairs=matrix(0,6,3)
pairs[1,]=c(1,2,3)
pairs[2,]=c(2,1,3)
pairs[3,]=c(3,1,2)
pairs[4,]=c(2,3,1)
pairs[5,]=c(3,2,1)
pairs[6,]=c(1,3,2)
print('Permutation Test')
for (j in 1:6){
    e.try=ehat_OLS[,pairs[j,]]
    P.try=chol((t(e.try) %*% e.try)/(T-n*p-1))
    B.try=t(P.try)
    x.try=e.try %*% solve(P.try)
    outS=steadyICA(x.try,whiten=FALSE,maxit=100)
    test.try=c(permTest(x.try),permTest(outS$S))
    print(c(j,test.try,kurtosis(outS$S)))
}



