# modified from ica-yw2.r
rm(list=ls())
graphics.off()
library(vars)
library(steadyICA)
library(ggplot2)
library(gridExtra)
library(moments)
library(lubridate)
library(tidyverse)
library(knitr)
source('mw_detrend.r')

source("mymprint.r")
source('~/Dropbox/common/R/Rfiles/pltirf.R')
source("renormalize.r")

dum=read.csv(file="WTISPLC.csv")
oil=log(dum$WTISPLC)
doil=rep(NA,nrow(dum))
doil[13:nrow(dum)]=diff(oil,differences=12)
dum$doil=doil
dum$oil=oil

dum=read.csv(file="CLF16OV.csv")
L=dum$CLF16OV


dum=dum[409:888,]
dt=read.csv(file='data_var.csv',sep=',',header=TRUE,na.strings='')
names(dt)=c('date','UF','UM','IP','FD','Cost','Death','Claims','SIE')
#dt$date=as.Date(parse_date_time(dt$date,"%m/%d/%y"))
dt$Oil=dum$oil
dt$doil=dum$doil
dt$Cost=dt$Cost/1e3
dt$Claims=dt$Claims/1e3
dt$UM=dt$UM*1000
dt$IP=log(dt$IP)*100
dt$L=log(L)
dt$SIE=log(dt$SIE)-dt$SIE
p=6

do_detrend=1

dt1 = dt %>% select(Cost,Claims,UM)
names(dt1)=c('Y1','Y2','Y3')
varname=c('Y1','Y2','Y3')
if (do_detrend==1){
    zz1=mw_detrend(dt1$Y1,12)
    zz2=mw_detrend(dt1$Y2,12)
    zz3=mw_detrend(dt1$Y3,12)
    dt2=data.frame(zz1$chat,zz2$chat,zz3$chat)
}
if (do_detrend==2) {
    zz2=mw_detrend(dt1$Y2,12)
    zz3=mw_detrend(dt1$Y3,12)
    dt2=data.frame(dt1$Y1,zz2$chat,zz3$chat)
}
if (do_detrend==0)  dt2=dt1
    names(dt2)=names(dt1)


y=as.matrix(dt2)
T=nrow(y)
n=ncol(y)
model0=VAR(y,2)    

Y=y[(p+1):T,]
reg=rep(1,(T-p))
for (i in (1:p)){
    reg=cbind(reg,y[(p-i+1):(T-i),])
}
reg=as.matrix(reg)
Y=as.matrix(Y)

OLS= solve(t(reg) %*% reg) %*% t(reg) %*% Y
ahat_OLS=OLS[-1,]
chat_OLS=OLS[1,]
ehat_OLS=Y-reg %*% OLS
cov_OLS=t(ehat_OLS) %*% ehat_OLS/(T-p-p*n-1)

    P_OLS=chol(cov_OLS)
    B_OLS=t(P_OLS)
    uhat_OLS=ehat_OLS %*% solve(P_OLS)
    sigs_OLS=diag(P_OLS)
    H_OLS=B_OLS %*% solve(diag(sigs_OLS))

    x0=uhat_OLS
    out5=steadyICA(x0,whiten=FALSE,maxit=100)

    dum5=renormalize(ehat_OLS,out5$S,out5$M,P_OLS)
    dum5$Bscaled=solve(dum5$Sig.W) %*% dum5$B
    check =ehat_OLS-dum5$S %*% solve(dum5$Sig.W) %*% dum5$B
    check1 = ehat_OLS-dum5$S %*% dum5$Bscaled

    uhat_ica=dum5$S
    B_ica=t(dum5$Bscaled)
    sigs_ica=diag(B_ica)
    H_ica=B_ica %*% solve(diag(sigs_ica))

    H=H_ica
    uhat=uhat_ica
    print(kable(H_OLS,'latex',booktabs=T,digits=3))
    print(kable(H_ica,'latex',booktabs=T,digits=3))

# rearrange A matrix for IRF
sumA=matrix(0,n,n)
Ahat=list()
for (j in (1:p)){
    t1=(j-1)*n+1
    t2= j*n
    Ahat[[j]]=t(ahat_OLS[t1:t2,])
    sumA=sumA+Ahat[[j]]
}



nstep=9
source('do_varirf.r')
MYIRF=do_varirf(ehat_OLS,ahat_OLS,uhat_ica,H_ica,sigs_ica,p,nstep)
irfica_raw=MYIRF[[1]]
irfica_orth=MYIRF[[2]]
MYIRF=do_varirf(ehat_OLS,ahat_OLS,uhat_OLS,H_OLS,sigs_OLS,p,nstep)
irfchol_raw=MYIRF[[1]]
irfchol_orth=MYIRF[[2]]



## IRF_VAR_orth$irf should match irfchol_orth[[1]]
model0=VAR(dt2,p,type='const')
IRF_VAR_orth=irf(model0,impulse=c('Y1'),response=varname,boot=TRUE,nstep,orth=TRUE)

Chat=chat_OLS

Ahat=list()
for (j in (1:p)){
    t1=(j-1)*n+1
    t2= j*n
    Ahat[[j]]=ahat_OLS[t1:t2,]
    
}
data=list()
data$y=y
data$Ahat=Ahat
data$Chat=Chat
data$ehat=ehat_OLS
data$uhat=uhat_ica
data$Hat=H_ica
data$Bhat=B_ica
data$Bchol=B_OLS
data$sigs=sigs_ica
data$sumA=sumA
data$irfica=irfica_orth[[1]]
data$irfchol=irfchol_orth[[1]]
save(data,file="do_disaster.RData")
#save(y,Ahat,Chat,ehat_OLS,uhat_ica,B_ica,myirf_orth,file='do_disaster.RData')

X=data.frame(uhat_ica[,1])
names(X)='uhat'

# brk=quantile(X,seq(0,1,by=.1))
h=ggplot(X,aes(x=uhat),color='lightgray')+geom_density(aes(y=..density..))+ggtitle('uhat_ica')
h=h+geom_histogram(aes(y=..density..),position='identity',binwidth=.1)
h=h+ggtitle(paste0("Density of Costly Disaster Shocks: kurtosis=",round(kurtosis(uhat_ica[,1]),digits=2)))
h=h+theme(plot.title=element_text(size=16,face='bold'))
ggsave('fig/hist_udisaster.png',h)
plot(h)

xxx

source("~/Dropbox/common/R/Rfiles/pltirf.R")


plt.irf=IRF_VAR_orth$irf$Y1
plt.up=IRF_VAR_orth$Upper[[1]]
plt.dn=IRF_VAR_orth$Lower[[1]]
irf0=pltirf(plt.irf,plt.up,plt.dn,'IRF',varname)
outfig='fig/choleski_disaster.png'
h=grid.arrange(irf0[[1]],irf0[[2]],irf0[[3]])
ggsave(outfig,h)



row1=IRF_VAR_orth[[1]]$Y1[1,]
row2=IRF_VAR_orth[[1]]$Y2[1,]
row3=IRF_VAR_orth[[1]]$Y3[1,]
P_VAR=rbind(row1,row2,row3)
#print(P_VAR)
#print(P_OLS)



test1=c(permTest(ehat_OLS),permTest(x0),permTest(uhat_ica))



kappa=kurtosis(uhat)
bad=which(kappa == max(kappa))

print('myirf-raw')
print(irfica_raw[[bad]],digits=3)
print('myirf_orth')
print(irfica_orth[[bad]],digits=3)

print(sprintf('big kappa %d',bad))

Umat=list()
Pmat=list()
Xmat=list()
pairs=matrix(0,6,3)
pairs[1,]=c(1,2,3)
pairs[2,]=c(2,1,3)
pairs[3,]=c(3,1,2)
pairs[4,]=c(2,3,1)
pairs[5,]=c(3,2,1)
pairs[6,]=c(1,3,2)

print('Permutation Test')
for (j in 1:nrow(pairs)){
    e.try=ehat_OLS[,pairs[j,]]
    P.try=chol((t(e.try) %*% e.try/(T-p*n-1)))
    B.try=t(P.try)
    x.try=e.try %*% solve(P.try)
    outS=steadyICA(x.try,whiten=FALSE,maxit=100)
    test.try=c(permTest(x.try),permTest(outS$S))
    print(c(j,outS$convergence,test.try))
    Umat[[j]]=outS$S
    Pmat[[j]]=P.try
    Xmat[[j]]=x.try
}





