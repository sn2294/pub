# MC with 3 variables
rm(list=ls())
library(vars)
#library(ggplot2)
library(moments)
library(lpirfs)
library(PearsonDS)
#library(gridExtra)
#library(knitr)
#library(kableExtra)
library(stabledist)
library(ProDenICA)
library(steadyICA)

set.seed(12345)
source('renormalize.r')
outrda='mc_dcovVAR1.RData'

alpha0=1.1
nstep=9
maxit=1000
ncases=2
nlags=1
n=3
T=400
Ta=T^(1/alpha0-1/2)
A0=diag(c(.2,.6,.8),3,3)
A0[2,1]=.3;
A0[3,1]=.4;
A0[3,2]=.3;
B.true=list()
B.raw=list()
B.raw[[1]]=diag(n)
B.raw[[1]][1,2]=3
B.raw[[1]][2,1]=1
B.raw[[2]]=diag(c(2,3,1))
B.raw[[2]][2,1]=1.5
B.raw[[2]][3,1]=2
B.raw[[2]][3,2]=0.5

seed=12345
count=0
varname=c('Y1','Y2','Y3')
CONV=matrix(0,maxit,ncases)
TSTAT=array(0,c(maxit,ncases,n*n))
AHAT=array(0,c(maxit,ncases,n*n))
WHAT=array(0,c(maxit,ncases,n*n))
BHAT=array(0,c(maxit,ncases,n*n))
KHAT=array(0,c(maxit,ncases,2*n))
PTEST=array(0,c(maxit,ncases,8))
AMARI=array(0,c(maxit,ncases,8))
for (icase in (1:ncases)) {
    B0=B.raw[[icase]]
    count=0
    W0=solve(B0)

    for (i in (1:n)){
        W0[i,]=W0[i,]/sqrt(sum(W0[i,]^2))
    }    

    B0=solve(W0)
    B00=t(B0)
    W00=t(W0)
    W11=W00[c(2,3,1),]
    B11=solve(W11)
    B.true[[icase]]=B0
    
    IRFhat=array(NA,c(maxit,nstep+1,n))
    LPhat=array(NA,c(maxit,nstep+1,n))
    it=1
    bad=0
    while (it <=maxit){
        set.seed(seed+it+count+bad)
        u=matrix(0,T,n) 
        done=0
       while(done==0){
           u[,1]=rstable(T,alpha=alpha0, beta=0)
           u[,2]=rt(T,df=5)
           u[,3]=rt(T,df=10)
           test=order(kurtosis(u))-c(3,2,1)
           if (sum(abs(test))<0.001)
               {done=1}
              else {count=count+1}
        }

        y=matrix(0,T,n)
        e = u %*% t(B0)

        y[1,]=e[1,]
        for (t in (2:T)){
            y[t,]=y[t-1,] %*% t(A0) +e[t,]
         }    # end t loop
        Y=data.frame(y)
        names(Y)=varname
   
        out=VAR(Y,p=nlags,type="const")
        AA=Bcoef(out)
        AA=AA[1:n,1:n]
        ehat0=resid(out)
        covehat0=t(ehat0) %*% ehat0/(T-nlags-n*nlags-1)
        P0=chol(covehat0)
#        P0=chol(cov(ehat0))
        xchol0=ehat0 %*% solve(P0)
        ehat1=ehat0[,c(2,3,1)]
       covehat1=t(ehat1) %*% ehat1/(T-nlags-n*nlags-1)
        P1=chol(covehat1)
        xchol1=ehat1 %*% solve(P1)
        sx=svd(covehat0)
        Psvd=sx$u%*% diag(sqrt(sx$d)) %*% t(sx$u)
        xsvd=ehat0 %*% solve(Psvd)
        white0=whitener(ehat0)
        out3=steadyICA(white0$Z,whiten=FALSE,maxit=100)
        dum3=renormalize(ehat0,out3$S,out3$M,solve(white0$whitener))

        out5=steadyICA(xchol0,whiten=FALSE,maxit=100)
        if (out5$convergence==1) {
        dum5=renormalize(ehat0,out5$S,out5$M,P0)
        Bhat.ica=dum5$B
        What.ica=dum5$W
        uhat.ica=dum5$S
        out6=steadyICA(xchol1,whiten=FALSE,maxit=100)
        out7=steadyICA(xsvd,whiten=FALSE,maxit=100)
        dum6=renormalize(ehat1,out6$S,out6$M,P1)
        dum7=renormalize(ehat0,out7$S,out7$M,Psvd)


    AHAT[it,icase,]=as.vector(AA)
    BHAT[it,icase,]=as.vector(Bhat.ica)
    WHAT[it,icase,]=as.vector(What.ica)
    KHAT[it,icase,]=c(kurtosis(u),kurtosis(uhat.ica))
    PTEST[it,icase,]=c(permTest(xchol0),permTest(xchol1),permTest(xsvd),permTest(white0$Z),
                       permTest(out5$S),permTest(out6$S),
                       permTest(out7$S),permTest(out3$S))
        
#    tmp=c(summary(out$varresult$Y1)$coefficients[1:n,3],
#          summary(out$varresult$Y2)$coefficients[1:n,3],
#          summary(out$varresult$Y3)$coefficients[1:n,3])
#    TSTAT[it,icase,]=tmp*(AHAT[it,icase,]-as.vector(t(A0)))/AHAT[it,icase,]
    AMARI[it,icase,]=c(amari(abs(B00),abs(dum5$B)),
                        amari(abs(B11),abs(dum6$B)),
                        amari(abs(B00),abs(dum7$B)),
                        amari(abs(B00),abs(dum3$B)),
                        amari(abs(W00),abs(dum5$W)),
                        amari(abs(W11),abs(dum6$W)),
                        amari(abs(W00),abs(dum7$W)),
                        amari(abs(W00),abs(dum3$W)))


                       
    lp.endog=data.frame(Y[-(1:nlags),])
    lp.out=lp_lin_iv(endog_data=lp.endog,lags_endog_lin=nlags,
                 shock=data.frame(uhat.ica[,1]),trend=0,
                 confint=1.96,hor=nstep+1)
    LP=t(as.matrix(lp.out$irf_lin_mean))
    IRF=irf(out,impulse=c('Y1'),response=varname,boot=FALSE,nstep,orth=TRUE)
    IRFhat[it,,1:n]=IRF$irf$Y1[,1:n]
    LPhat[it,,1:n]=LP[,1:n]
    ehat=resid(out)
     print(c(it,count,out5$convergence))
        it=it+1
     }
     else {
         bad=bad+1
         print(c(it,count,out5$convergence,bad))
         }
        
        
 } # end it loop


} # end icase

save(AHAT,BHAT,WHAT,KHAT,PTEST,AMARI,A0,B.true,IRFhat,LPhat,file=outrda)


