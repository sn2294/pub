renormalize<-function(X,SS,BBB,P){
    BB=BBB %*% P
    kappa=kurtosis(SS)    
    bad=rev(order(kappa))
    Permute=diag(0,n)
    for (j in (1:n)){
        Permute[j,bad[j]]=1
    }    

    B.permute=Permute%*% BB
    D=diag(sign(diag(B.permute)))
    S.raw=SS %*% t(Permute) %*% t(D)
    B.raw=D%*% Permute %*%BB
    W.raw=solve(B.raw)

    Sig.W=diag(sqrt(apply(W.raw^2,2,sum)))
    W.new=W.raw %*% solve(Sig.W)
    S.new=X %*% W.new %*% Sig.W


    B.new=solve(W.new)
    Sig.B=diag(diag(abs(B.new)))
    B.adj=B.new %*% solve(Sig.B)


#    B.temp=solve(Sig.W) %*% B.new %*% Sig.B
#    Sig.temp=diag(diag(abs(B.temp)))
#    B.temp=B.temp %*% solve(Sig.temp)
    
out1=list()
out1$S=S.new
out1$B=B.new
out1$Badj=B.adj    
out1$W=W.new
out1$Sig.W=Sig.W
out1$Sig.B=Sig.B    
 return(out1) 
}               
