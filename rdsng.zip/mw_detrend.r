mw_detrend<-function(y,q) {
T=length(y)
fvec=pi*seq(1,q)
ym=mean(y)
tvec=seq(0.5,T,by=1)/T
tmat=as.matrix(tvec,length(tvec),1)
fmat=as.matrix(fvec,length(fvec),1)
psi=(sqrt(2)/T)*cos(tmat %*% t(fmat))
ydm=as.matrix(y-ym)
psi=as.matrix(psi)
y_cos=as.matrix(t(psi) %*% ydm)
y_proj=psi %*% (solve(t(psi) %*% psi)) %*% y_cos
y_proj_m=y_proj+ym
z=data.frame(y_proj_m,y-y_proj_m)
names(z)=c('tau','chat')
return(z)
}
