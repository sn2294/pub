function [rhohat,ic,ttest]=interact_08(X,nfac,p);
  % critval values are for T=10, 20; 50; 100, > 100
    T=rows(X);
 TM1 = [1 -.5 -.46;
	1 -.5 -.47;
	1 -.5 -.49;
	1 -.5  -.49;
	1 -.5  -.5]; 
 TA1 = [2.72 5.32 15.71;
	2.30 4.05 9.50;
	2.10 3.40 5.75;
	2.01 3.19 4.62;
	2.0 3.0  15/4] ;   
 TB1= [1/1.09 1/.81 1/1.05;
       1/1.04 1/.64 1/.62;
       1/1.00 1/.55 1/.37;
       1/.98 1/.52 1/.30
       1  2  4];
if T<=10; tt=1; end;
if T>10 & T<=20; tt=2; end;
if T>20 & T<=50; tt=3; end;
if T>50 & T<=100; tt=4; end;
if T> 100; tt=5;end;
finite=0;
if finite==0; tt=5; end;
     M1=TM1(tt,p+2);    A1=TA1(tt,p+2);  B1=TB1(tt,p+2);

     % this is original MP
rhohat=[];  ttest=[];
    [T,N]=size(X);
  scale=sqrt(N)*T;
  switch(p);
    case -1
   x=X;
   case 0
    one=ones(T,1);
    Q_T=eye(T)-one*one'/T;
    x=Q_T*X;
   case 1
    one=[ones(T,1) (1:1:T)'];
    Q_T=eye(T)-one*inv(one'*one)*one';
    x=Q_T*X;
   end;
    lagx=trimr(lagn(x,1),1,0);
    x=trimr(x,1,0);

  rho0=sum(sum(lagx.*x))/(sum(sum(lagx.*lagx)));
  w=x-rho0*lagx;
   [ic,lamhat,fhat]=getnfac(w,nfac,2);

  Q=eye(N)-lamhat*inv(lamhat'*lamhat)*lamhat';
  Qlagx=lagx*Q;
  Qx=x*Q;
  top=trace(Qlagx*Qx');
  bottom=trace(Qlagx*Qlagx');
  rho1=top/bottom;

  ehat=Qx-rho1*Qlagx;         % now estimate nuisance parameters
  [sig2,omega2,half]=nuisance(ehat,0);
  OMEGA2=mean(omega2);
  PHI4=mean(omega2.*omega2);

  switch(p);
   case -1 
     ADJ=M1*mean(half);
   case 0 
    ADJ=M1*mean(sig2); 
   case 1;
    ADJ=M1*mean(sig2); 
  end;  
  rhohat(1)= rho0;
  rhohat(2)= (top-N*T*ADJ)/bottom;
  t_a=scale *(rhohat(2)-1)/sqrt(A1*PHI4/(OMEGA2*OMEGA2));
  t_b=scale *(rhohat(2)-1)*sqrt(bottom/(scale^2))*sqrt(B1*OMEGA2/PHI4);

ttest=[ t_a t_b];
