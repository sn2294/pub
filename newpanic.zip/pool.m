function [pvala, pvalb]= pool(a,x);
N=rows(x);
pval=zeros(N,1);
for i=1:N;
aa=abs(a(:,1)-x(i));
[j1,j2]=min(aa);
pval(i)=a(j2,2);
end;


pvala=-2*sum(log(pval));
pvalb=(pvala-2*N)/sqrt(4*N);

