
function [rho1,ic,ttest,adf31b]=newpanic1_08(X,nfac,p,k1,lm1);


  dX=trimr(mydiff(X,1),1,0);
  dx=dX-repmat(mean(dX),rows(X)-1,1);
   [T,N]=size(dx);


 scale=sqrt(N)*T;
 
 [ic,lamhat,dfhat]=getnfac(dx,nfac,2);
fhat=cumsum(dfhat);
dehat=dx-dfhat*lamhat';
ehat0=cumsum(dehat);
lagehat0=trimr(lagn(ehat0,1),1,0);
ehat0=trimr(ehat0,1,0);

% now do old panic  
 adf31 =adf(ehat0,k1,-1);

[adf31a adf31b]=pool(lm1,adf31');


bottom0=sum(sum(lagehat0.*lagehat0));
top0=sum(sum(lagehat0.*ehat0));
rho0=top0/bottom0;
res0=ehat0-lagehat0*rho0;
[sig2,omega2,half]=nuisance(res0,0);
 OMEGA2=mean(omega2);
 PHI4=mean(omega2.*omega2);
 SIG2=mean(sig2);
 HALF=mean(half);



% Now we no longer do detrending
A1= 36/5; B1=5/6;U1=1/6; V1=1/45;
ADJ=SIG2/OMEGA2;
  t_a=scale *(rho0-1+ADJ*3/T)/sqrt(A1*PHI4*SIG2^2/(OMEGA2^4));
  t_b=scale *(rho0-1+ADJ*3/T)*sqrt(bottom0/(scale^2))*sqrt(B1*OMEGA2^3/(PHI4*SIG2^2));
  t_c= sqrt(N)*(trace(ehat0*ehat0')/(N*T^2)-U1*OMEGA2)/sqrt(V1*PHI4);      

 % tests that project on intercept and trends
one=[ones(T-1,1) (1:1:T-1)'];
Q_T=eye(T-1)-one*inv(one'*one)*one';
ehat=Q_T*ehat0;
lagehat=Q_T*lagehat0;
top=sum(sum(lagehat.*ehat));
bottom=sum(sum(lagehat.*lagehat));
rho1=top/bottom;
res1=ehat-lagehat*rho1;
[sig2,omega2,half]=nuisance(res1,0);
 OMEGA2=mean(omega2);
 PHI4=mean(omega2.*omega2);
 SIG2=mean(sig2);
 HALF=mean(half);
  A1=15/4; B1=4;   
   ADJ=-N*T*SIG2/2;
  rho1=(top-ADJ)/bottom;
  t_a1=scale *(rho1-1)/sqrt(A1*PHI4/(OMEGA2*OMEGA2));
  t_a2=scale *(rho1-1)*sqrt(bottom/(scale^2))*sqrt(B1*OMEGA2/PHI4);
ttest=[ t_c t_a t_b t_a1 t_a2];



