% iter==0  no iteration on rhohat
function [rho1,ic,ttest,adf30b ]=newpanic0_08(X,nfac,p,k1,adfnc);
T=rows(X);



dx=trimr(mydiff(X,1),1,0);
   [T,N]=size(dx);
 scale=sqrt(N)*T;


 [ic,lamhat,dfhat]=getnfac(dx,nfac,2);
fhat=cumsum(dfhat);
dehat=dx-dfhat*lamhat';
ehat0=cumsum(dehat);
lagehat0=trimr(lagn(ehat0,1),1,0);
ehat0=trimr(ehat0,1,0);

% now do the old panic
adf30 =adf(ehat0,k1,-1);

[adf30a, adf30b]=pool(adfnc,adf30');

% compute rho0 (no demeaning)
top0=sum(sum(lagehat0.*ehat0));
bottom0=sum(sum(lagehat0.*lagehat0));
rho0=top0/bottom0;
res0=ehat0-lagehat0*rho0;
[sig2,omega2,half]=nuisance(res0,0);
 OMEGA2=mean(omega2);
 PHI4=mean(omega2.*omega2);
 SIG2=mean(sig2);
 HALF=mean(half);


 % tests using rho0 (do not project on deterministic terms)
 A1=2; B1=1;  U1=1/2; V1=1/3; 
  ADJ=N*T*HALF;
 rho1=(top0-ADJ)/bottom0;
    t_a=scale *(rho1-1)/sqrt(A1*PHI4/(OMEGA2*OMEGA2));
    t_b=scale *(rho1-1)*sqrt(bottom0/(scale^2))*sqrt(B1*OMEGA2/PHI4);
    t_c= sqrt(N)*(trace(ehat0*ehat0')/(N*T^2)-U1*OMEGA2)/sqrt(V1*PHI4);    

 % tests that project on constants 
one=[ones(T-1,1) ];
Q_T=eye(T-1)-one*inv(one'*one)*one';
ehat=Q_T*ehat0;
lagehat=Q_T*lagehat0;
top=sum(sum(lagehat.*ehat));
bottom=sum(sum(lagehat.*lagehat));
rho1=top/bottom;
res1=ehat-lagehat*rho1;
[sig2,omega2,half]=nuisance(res1,0);
 OMEGA2=mean(omega2);
 PHI4=mean(omega2.*omega2);
 SIG2=mean(sig2);
 HALF=mean(half);

  A1=3; B1=2;
  ADJ=-N*T*SIG2/2;
  rho1=(top-ADJ)/bottom;
  t_a1=scale *(rho1-1)/sqrt(A1*PHI4/(OMEGA2*OMEGA2));
  t_a2=scale *(rho1-1)*sqrt(bottom/(scale^2))*sqrt(B1*OMEGA2/PHI4);
  ttest=[ t_c t_a t_b t_a1 t_a2];
	 




