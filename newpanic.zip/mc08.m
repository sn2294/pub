


clear;
addpath ~/matlab/factors;
load -ascii adfnc.asc;
load -ascii lm1.asc;

kappa=1;
r=1;
maxit=5000;
nfac=2*r;
ncases=4;
icases=[1 5 6 8];
xNT=[ 20 20; 20 50; 20 100; 50 20; 50 50; 50 100; 100 20; 100 50;    100 100];

xkappa=[1 2];


for p=1:1:1;
  outfile='mc08.';
  outfile=[outfile num2str(p)];
  fp=fopen(outfile,'w');
  fclose(fp);
  if p==0; p_mp=-1; end;
  if p==1; p_mp=p; end;
for inorm=0:0;
for ikappa=1:rows(xkappa);
kappa=sqrt(xkappa(ikappa));
 for iicase=1:ncases;
  icase=icases(iicase);
  table=[];
  for iNT=1:rows(xNT);
    N=xNT(iNT,1); T=xNT(iNT,2);k1=ceil(4*(T/100)^(1/4));
      switch(icase);
   case 1; rho=ones(r,1); theta=ones(N,1);  DGP=1; xif=1; xie=1;
   case 2; rho=ones(r,1); theta=uniform_ab(N,.97,.99); DGP=1; xif=1;xie=0;
   case 3; rho=.98*ones(r,1); theta=ones(N,1); DGP=1; xif=0; xie=1;
   case 4; rho=.95*ones(r,1); theta=.95*ones(N,1); DGP=1; xif=0; xie=0;
   case 5; rho=.5*ones(r,1); theta=uniform_ab(N,.9,.99); DGP=1; xif=0; xie=0;
%   case 6; rho=.5; theta=uniform_ab(N,.97,.99); theta(1:ceil(N/5))=1;DGP=1; xif=0;xie=.5;
   case 6; rho=.5; theta=uniform_ab(N,.9,.99); theta(1:ceil(N/5))=1;DGP=1; xif=0;xie=.5;
   case 7; delta=ones(N,1);  DGP=2; xif=1;xie=1;
   case 8; delta=uniform_ab(N,.9,.99);  DGP=2; xif=0;xie=0;

  end;  


t_a=[];t_a1=[];rhohat=[];ic=[];
randn('state',999);
rand('state',123);

for it=1:maxit;
  switch(DGP);
  case 1;
u=randn(T,N);     % begin DGP
L=zeros(N,r);;
for i=1:r;
L(:,i)=uniform_ab(N,-1,3);
end;
f=kappa*randn(T,r);
F=f;
for i=1:r;
  F(:,i)=filter(1,[1 -rho(i)], f(:,i));
end;  
mu=0*repmat(rand(1,N),T,1);     % fixed effects
C=F*L';
U=u;
for i=1:N;
  U(:,i)=filter(1,[1 -theta(i)],u(:,i));
end;  
X=mu+C+U;            % end DGP

 case 2;
  u=randn(T,N);     % begin DGP
L=zeros(N,r);
if inorm==0;
for i=1:r;
L(:,i)=uniform_ab(N,-1,3);
end;
mu=repmat(rand(1,N),T,1);     % non-normal lambdas and fixed effects
else;
L=randn(N,r);;
mu=repmat(randn(1,N),T,1);     % normal lambda and fixed effects
end;
F=kappa*randn(T,r);
C=F*L';
U=C+u;
Y=U;
for i=1:N;
  Y(:,i)=filter(1,[1 -delta(i)],U(:,i));
end;  
X=mu+Y;            % end DGP
end;



if p<1;;
[xrho1,xic1,t_b,t_p]=newpanic0_08(X,nfac,p,k1,adfnc);
end;
if p==1;
[xrho1,xic1,t_b,t_p]=newpanic1_08(X,nfac,p,k1,lm1);
end;

[xrho2,xic2,t_c]=interact_08(X,nfac,p_mp);  % these give the MP tests

t_a=[t_a; t_b  t_c ];
t_a1=[t_a1; t_p];

rhohat=[rhohat;xrho1 xrho2];
ic=[ic; xic1;xic2];
 end;    % end monte carlo

temp=[ N T  mean(abs(t_a1) >1.96)  mean(t_a < -1.64)];
table=[table; temp];

fmt=['\n %4d &%4d' repmat('& %5.3f ',1,cols(t_a)+cols(t_a1)) '\\\\ '];;
disp(sprintf(fmt,temp));
if iNT==1;
  fp=fopen(outfile,'a+');
fprintf(fp,'\n DGP = % 3d kappa= %3f F=I(%1d) e=I(%1d)\n',icase,kappa,xif,xie);
fclose(fp);
end;
fp=fopen(outfile,'a+');
fprintf(fp,fmt,temp);
fclose(fp);
  end; % end NT
fp=fopen(outfile,'a+');
fprintf(fp,'\n');
fclose(fp);
end; % end cases
fp=fopen(outfile,'a+');
fprintf(fp,'\n');
fclose(fp);
end; % end kappa
end; % end inorm
end;  % end p

  
