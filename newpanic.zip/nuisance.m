function [sig2,omega2,half]=nuisance(res,k);
  [T,N]=size(res);
    omega2=zeros(N,1); sig2=zeros(N,1); half=zeros(N,1);
  for i=1:N;
    [K,K_w]=nw(res(:,i),k);       % fix bandwidth of 2 for now
    sig2(i)=res(:,i)'*res(:,i)/T;
    omega2(i)=sig2(i);
    half(i)=0;
    for j=1:K;
        temp= res(1:T-j-1,i)'*res(j+1:T-1,i)/T;
	omega2(i)=omega2(i)+2*K_w(j)*temp;
	half(i)=half(i)+K_w(j)*temp;
    end;  % end j
  end;   % end i 
