params.B=B;
params.Nsub=Nsub;
params.Bsub=Bsub;

params.K_F=K_F;
params.K_G=K_G;
params.K_H=K_H;

params.q_F=q_F;
params.q_G=q_G;
params.q_H=q_H;
params.q_Z=q_Z;

params.l_F=l_F;
params.l_G=l_G;
params.l_H=l_H;

params.n_gibbs=n_gibbs;
params.n_keep=n_keep;
params.n_skip=n_skip;
  