function [adf,kstar]=adfp(y,penalty,kmax,kmin,p);
yt=olsd(y,p);
reg=lagn(yt,1);
dyt=mydiff(yt,1);
kstar=s2ar(yt,penalty,kmax,kmin);
for i=1:kstar;
reg=[reg lagn(dyt,i)];
end;
dyt=trimr(dyt,kstar+1,0);
reg=trimr(reg,kstar+1,0);
rho=reg\dyt;
e=dyt-reg*rho;
nef=size(dyt,1);
s2e=e'*e/nef;
xx=inv(reg'*reg);
sre=xx(1,1)*s2e;
adf=rho(1,1)/sqrt(sre);
rho1=rho(1,1)+1;
if kstar> 0;
sumb=sum(rho(2:kstar+1));
else;
sumb=0;
end;
s2vec=s2e/(1-sumb)^2;


function [e]=olsd(y,p);
reg=ones(rows(y),1);
trend=seqa(1,1,rows(y));
dt=ones(rows(y),1);
if p==1;
dt=[dt trend];
end;
beta=dt\y;
e=y-dt*beta;


function kstar=s2ar(yts,penalty,kmax,kmin);
nt=rows(yts);
min=9999999999;
tau=zeros(kmax+1,1);
s2e=999*ones(kmax+1,1);

dyts=mydiff(yts,1);
reg=lagn(yts,1);
for i=1:kmax;
reg=[reg lagn(dyts,i)];
end;
dyts0=dyts;
reg0=reg;
dyts0=trimr(dyts,kmax+1,0);
reg0=trimr(reg,kmax+1,0);
sumy=sum(reg0(:,1).*reg0(:,1));
nef=nt-kmax-1;
for k=kmin:kmax;
b=reg0(:,1:k+1)\dyts0;
e=dyts0-reg0(:,1:k+1)*b;
s2e(k+1)=e'*e/nef;
tau(k+1)=(b(1)*b(1))*sumy/s2e(k+1);
end;
kk=seqa(0,1,kmax+1);
if penalty == 0;
mic=log(s2e)+2.0*(kk+tau)./nef;
else;
mic=log(s2e)+log(nef)*(kk)./nef;
end;
kstar=minindc(mic)-1;

