clear;
p=0;
penalty=1;
kmax=6;
kmin=0;
load -ascii data1.asc;
y1=data1(:,1);
[tstat,kstar]=adfp(y1,penalty,kmax,kmin,p);
tstat
kstar
[tstat,kstar]=dfgls(y1,penalty,kmax,kmin,p);
tstat
kstar
